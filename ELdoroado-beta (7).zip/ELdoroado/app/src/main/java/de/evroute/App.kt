package de.evroute

import android.Manifest
import android.app.Application
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import okhttp3.ResponseBody.Companion.toResponseBody
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.maplibre.android.MapLibre

class EvRouteApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.init(this)
        HangWatchdog.start()
        LastSoc.init(this)
        SavedRoutes.init(this)
        EcoStore.init(this)
        SpeedLimits.init(this)
        WeeklyReview.schedule(this)
        // KI im Hintergrund vorladen, damit die erste Anfrage schnell ist
        BuildConfigLite.version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: "?"
        MapLibre.getInstance(this)
        // Anfragen der Karte an TomTom bekommen automatisch den Key angehängt (Kacheln, Schriften, Symbole)
        runCatching {
            val client = okhttp3.OkHttpClient.Builder().addInterceptor { chain ->
                var req = chain.request()
                val url = req.url
                if (url.host == "api.tomtom.com" && url.queryParameter("key") == null) {
                    val k = Settings.state.value.tomtomKey.trim()
                    if (k.isNotBlank()) req = req.newBuilder().url(url.newBuilder().addQueryParameter("key", k).build()).build()
                }
                val isTraffic = url.host == "api.tomtom.com" && url.encodedPath.startsWith("/traffic/map/")
                if (!(isTraffic && TrafficGuard.isBlocked())) ApiCounter.classify(url.host, url.encodedPath)?.let { ApiCounter.count(it) }
                // Verkehrskacheln: nach einer Ablehnung durch TomTom (Kontingent, Schlüssel) nicht endlos neu fragen
                if (isTraffic && TrafficGuard.isBlocked()) {
                    okhttp3.Response.Builder().request(req).protocol(okhttp3.Protocol.HTTP_1_1).code(204).message("blocked")
                        .body(ByteArray(0).toResponseBody(null)).build()
                } else {
                    val resp = chain.proceed(req)
                    if (isTraffic && resp.code in 400..499) TrafficGuard.block()
                    resp
                }
            }.build()
            org.maplibre.android.module.http.HttpRequestUtil.setOkHttpClient(client)
        }
        Settings.init(this)
        Recents.init(this)
        ApiCounter.init(this)
        Favorites.init(this)
        EvDatabase.init(this)
        ManualLearn.init(this)
        JamWatch.init(this)
        KnownOperators.init(this)
        ChargerRegistry.init(this)
        ValhallaTiles.init(this)
        ValhallaRouter.init(this)
        Obd.init(this)
        Learner.init(this)
        TripRecorder.init(this)
        NavSession.init(this)
    }
}

/** Schutz vor Endlos-Anfragen der Verkehrskacheln, wenn TomTom sie ablehnt (z. B. Monatskontingent erschöpft) */
object TrafficGuard {
    private const val PAUSE_MS = 6 * 3600_000L
    @Volatile private var until = 0L
    val blocked = kotlinx.coroutines.flow.MutableStateFlow(false)

    fun isBlocked(): Boolean {
        if (until == 0L) return false
        if (System.currentTimeMillis() > until) { until = 0L; blocked.value = false; return false }
        return true
    }

    fun block() {
        until = System.currentTimeMillis() + PAUSE_MS
        blocked.value = true
    }
}

/** Ist die App gerade sichtbar (Vordergrund oder Bild-im-Bild)? Hintergrund-Schleifen drosseln sich danach. */
object AppVisibility {
    @Volatile var visible = false
}

/** Bild-im-Bild-Zustand (kleines schwebendes Navigationsfenster) */
object Pip {
    val active = kotlinx.coroutines.flow.MutableStateFlow(false)
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        LocationHub.refreshPermission(this)
        LocationHub.acquire(this, "ui")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { EvRouteApp(vm) }
        // Bild-im-Bild nur während der Navigation: beim Hochwischen automatisch ins kleine Fenster
        lifecycleScope.launch {
            NavSession.state.collect { st ->
                val on = st.navigating && !st.arrived
                if (on != pipAllowed) { pipAllowed = on; updatePip() }
            }
        }
        if (Settings.state.value.setupDone) {
            val list = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
            perms.launch(list.toTypedArray())
        }
    }

    override fun onStart() {
        super.onStart()
        AppVisibility.visible = true
        LocationHub.refreshPermission(this)
        LocationHub.acquire(this, "ui")
        if (Settings.state.value.obdAuto) Obd.acquire("ui")
    }

    private var pipAllowed = false

    private fun pipParams(): android.app.PictureInPictureParams? {
        if (Build.VERSION.SDK_INT < 26) return null
        val b = android.app.PictureInPictureParams.Builder().setAspectRatio(android.util.Rational(3, 4))
        if (Build.VERSION.SDK_INT >= 31) b.setAutoEnterEnabled(pipAllowed).setSeamlessResizeEnabled(false)
        return b.build()
    }

    private fun updatePip() {
        if (Build.VERSION.SDK_INT < 26) return
        runCatching { pipParams()?.let { setPictureInPictureParams(it) } }
    }

    // Android 8–11: kein automatischer Wechsel, deshalb beim Verlassen der App selbst umschalten
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT in 26..30 && pipAllowed) runCatching { pipParams()?.let { enterPictureInPictureMode(it) } }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        Pip.active.value = isInPictureInPictureMode
    }

    override fun onStop() {
        AppVisibility.visible = false
        LocationHub.release("ui")
        Obd.release("ui")
        super.onStop()
    }
}

enum class SearchMode { DEST, HOME, WORK, FAV, VIA, START }

class MainViewModel : ViewModel() {
    data class LongPress(val pos: LatLon, val name: String? = null)

    data class Ui(
        val query: String = "",
        val suggestions: List<Place> = emptyList(),
        val searching: Boolean = false,
        val searchActive: Boolean = false,
        val showSettings: Boolean = false,
        val settingsPage: String? = null, // direkt eine Unterseite öffnen (z. B. "ECO")
        val follow: Boolean = true,
        val recenter: Int = 0,
        val mode: SearchMode = SearchMode.DEST,
        val longPress: LongPress? = null,
        val viaAsk: Place? = null, // Frage „Als Zwischenstopp oder neues Ziel?“ (Navigation / Zwischenstopp-Suche)
        val editFav: Favorite? = null,
        val sheetPx: Int = 0,
        val showObd: Boolean = false,
        val showTrips: Boolean = false,
        val card: Place? = null,
        val chargerHits: List<ChargerHit> = emptyList(),
        val destInfo: String? = null,
        val overviewLevel: Int = 0,          // 0 = Fahransicht, 1 = nächster Abschnitt, 2 = ganze Reststrecke
        val overviewPts: List<LatLon>? = null,
        val overviewKey: Int = 0,
        val navMore: Boolean = false,
        val askEnd: Boolean = false,
        val assistant: Boolean = false,
        val assistantListen: Boolean = false,
        val askPrecise: Boolean = false,
        val saveDialog: Boolean = false,
        val deleteSaved: SavedRoute? = null, // "park" oder "charge": Liste am Ziel während der Fahrt
        val chargerOnly: Boolean = false,
        val cardDetails: PlaceDetails? = null,
        val cardLoading: Boolean = false,
    )

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()
    private var searchJob: Job? = null

    fun onQuery(q: String) {
        _ui.update { it.copy(query = q) }
        searchJob?.cancel()
        if (q.trim().length < 3) {
            _ui.update { it.copy(suggestions = emptyList(), chargerHits = emptyList(), searching = false) }
            return
        }
        val set = Settings.state.value
        val wantChargers = set.hasChargerSource && _ui.value.mode == SearchMode.DEST && (_ui.value.chargerOnly || isChargingQuery(q))
        searchJob = viewModelScope.launch {
            delay(350)
            _ui.update { it.copy(searching = true) }
            val near = LocationHub.fix.value?.pos
            val chargers: Deferred<List<ChargerHit>>? = if (wantChargers) {
                async { runCatching { Chargers.searchSmart(set, q.trim(), near) }.getOrDefault(emptyList()) }
            } else {
                null
            }
            val places = if (_ui.value.chargerOnly) emptyList() else runCatching { Geocode.search(q.trim(), near) }.getOrDefault(emptyList())
            val ch = chargers?.await() ?: emptyList()
            MapChargers.extraHits = ch
            _ui.update { it.copy(suggestions = places, chargerHits = ch, searching = false) }
        }
    }

    fun toggleChargerOnly() {
        _ui.update { it.copy(chargerOnly = !it.chargerOnly) }
        onQuery(_ui.value.query)
    }

    /** Ladestation aus den Suchvorschlägen: hinfliegen und Ladestations-Fenster öffnen */
    fun openCharger(h: ChargerHit) {
        chargerSnap = snapSearch()?.let { h.id to it }
        searchJob?.cancel()
        _ui.update { it.copy(query = "", suggestions = emptyList(), searchActive = false, searching = false, follow = false) }
        MapChargers.show(h)
    }

    fun setSearchActive(b: Boolean) { _ui.update { it.copy(searchActive = b) } }

    fun pick(p: Place) {
        val mode = _ui.value.mode
        val snap = snapSearch()
        searchJob?.cancel()
        _ui.update { it.copy(query = "", suggestions = emptyList(), searchActive = false, searching = false, mode = SearchMode.DEST, longPress = null) }
        when (mode) {
            SearchMode.DEST -> { Recents.add(p); openCard(p, snap) }
            SearchMode.HOME -> Favorites.set(FavKind.HOME, p)
            SearchMode.WORK -> Favorites.set(FavKind.WORK, p)
            SearchMode.FAV -> Favorites.set(FavKind.OTHER, p)
            SearchMode.VIA -> { Recents.add(p); NavSession.addVia(p) }
            SearchMode.START -> { Recents.add(p); NavSession.setStart(p) }
        }
    }

    // ----- Schritt zurück: was war vorher offen? -----

    /** Suchergebnisse, zu denen „Zurück“ aus einem Orts-/Ladestations-Fenster führt */
    data class SearchSnap(val query: String, val places: List<Place>, val chargers: List<ChargerHit>, val chargerOnly: Boolean)
    private var searchSnap: SearchSnap? = null
    private var chargerSnap: Pair<String, SearchSnap>? = null

    /** Ortsfenster, zu dem „Zurück“ aus der Routenauswahl führt */
    private var lastCard: Pair<Place, PlaceDetails?>? = null

    private fun snapSearch(): SearchSnap? = _ui.value.let { u ->
        if (u.query.trim().length >= 3) SearchSnap(u.query, u.suggestions, u.chargerHits, u.chargerOnly) else null
    }

    private fun restoreSearch(snap: SearchSnap) {
        _ui.update { it.copy(query = snap.query, suggestions = snap.places, chargerHits = snap.chargers, chargerOnly = snap.chargerOnly, searchActive = true, mode = SearchMode.DEST) }
        MapChargers.extraHits = snap.chargers
    }

    // ----- Übersicht und Streckenleiste -----

    private var overviewJob: Job? = null

    /** Übersicht: 1. Tipp nächster Abschnitt, 2. Tipp ganze Reststrecke, 3. Tipp zurück; nach 10 s automatisch zurück */
    fun toggleOverview() {
        val nav = NavSession.state.value
        val r = nav.route ?: return
        val along = nav.progress?.alongM ?: 0.0
        val level = (_ui.value.overviewLevel + 1) % 3
        if (level == 0) { endOverview(); return }
        val range = 50_000.0
        val to = if (level == 1) {
            val nextStop = r.stops.firstOrNull { it.alongM > along + 500 }?.alongM ?: r.cumM.last()
            minOf(nextStop, along + range).coerceAtLeast(along + 3000)
        } else {
            r.cumM.last()
        }
        val pts = RouteBarData.slice(r, along, to)
        _ui.update { it.copy(overviewLevel = level, overviewPts = pts, overviewKey = it.overviewKey + 1, follow = false, navMore = false) }
        scheduleBack()
    }

    private fun scheduleBack() {
        overviewJob?.cancel()
        overviewJob = viewModelScope.launch {
            delay(10_000)
            endOverview()
        }
    }

    fun endOverview() {
        overviewJob?.cancel()
        _ui.update { it.copy(overviewLevel = 0, overviewPts = null) }
        recenter()
    }

    fun openSaveDialog() { _ui.update { it.copy(saveDialog = true) } }
    fun closeSaveDialog() { _ui.update { it.copy(saveDialog = false) } }

    fun saveRoute(name: String) {
        val n = NavSession.state.value
        val dest = n.dest ?: return
        SavedRoutes.save(
            SavedRoute(System.currentTimeMillis().toString(), name.ifBlank { dest.title }, n.start, if (n.start != null) n.startSoc else null, dest, n.vias, System.currentTimeMillis()),
        )
        closeSaveDialog()
    }

    fun openSaved(r: SavedRoute) {
        collapseSearch()
        lastCard = null
        NavSession.openSaved(r)
    }

    fun askDeleteSaved(r: SavedRoute?) { _ui.update { it.copy(deleteSaved = r) } }

    fun setAskPrecise(v: Boolean) { _ui.update { it.copy(askPrecise = v) } }

    fun openAssistant(listen: Boolean = false) { collapseSearch(); _ui.update { it.copy(assistant = true, assistantListen = listen) } }
    fun closeAssistant() { _ui.update { it.copy(assistant = false, assistantListen = false) } }
    fun listenStarted() { _ui.update { it.copy(assistantListen = false) } }

    fun askEnd() { _ui.update { it.copy(askEnd = true) } }

    fun closeAskEnd() { _ui.update { it.copy(askEnd = false) } }

    fun toggleNavMore() { _ui.update { it.copy(navMore = !it.navMore) } }

    fun openDestInfo(kind: String) { _ui.update { it.copy(destInfo = kind) } }

    fun closeDestInfo() { _ui.update { it.copy(destInfo = null) } }

    fun collapseSearch() {
        searchJob?.cancel()
        _ui.update { it.copy(query = "", suggestions = emptyList(), chargerHits = emptyList(), searchActive = false, searching = false) }
    }

    /** Ladestations-Fenster schließen: zurück zur Alternativen-Liste bzw. zu den Suchergebnissen */
    fun closeChargerCard() {
        val sel = MapChargers.state.value.selected
        MapChargers.closeInfo()
        val snap = chargerSnap
        chargerSnap = null
        if (snap != null && snap.first == sel?.id) restoreSearch(snap.second)
    }

    /** Routenauswahl verlassen: zurück zum Ortsfenster, falls die Route von dort kam */
    fun backFromRoute() {
        NavSession.clear()
        val lc = lastCard ?: return
        lastCard = null
        _ui.update { it.copy(card = lc.first, cardDetails = lc.second, cardLoading = false, follow = false) }
    }

    // ----- Ortsfenster -----

    private var cardJob: Job? = null

    /** Ort mit Details anzeigen (statt sofort zu routen) */
    fun openCard(p: Place, fromSearch: SearchSnap? = null) {
        // Während der Fahrt kein Orts-Fenster mit „Route“ (würde das Ziel ersetzen) – stattdessen nachfragen
        if (NavSession.state.value.navigating) { askVia(p); return }
        cardJob?.cancel()
        searchSnap = fromSearch
        _ui.update { it.copy(card = p, cardDetails = null, cardLoading = true, longPress = null, follow = false) }
        cardJob = viewModelScope.launch {
            val d = runCatching { Nominatim.details(p) }.getOrNull()
            _ui.update { s ->
                if (s.card != p) s
                else s.copy(
                    cardDetails = d, cardLoading = false,
                    // bei langem Drücken: Namen aus den Details übernehmen
                    card = if (p.name == "Markierter Ort" && d != null) p.copy(name = listOf(d.name, d.address).filter { it.isNotBlank() }.distinct().joinToString(", ")) else p,
                )
            }
        }
    }

    /** Ortsfenster schließen; mit „Zurück“ wieder zu den Suchergebnissen */
    fun closeCard(restore: Boolean = true) {
        cardJob?.cancel()
        _ui.update { it.copy(card = null, cardDetails = null, cardLoading = false) }
        val snap = searchSnap
        searchSnap = null
        if (restore && snap != null) restoreSearch(snap)
    }

    /** „Route“ im Ortsfenster: jetzt erst die Routen berechnen */
    fun routeToCard() {
        val s = _ui.value
        val p = s.card ?: return
        val name = s.cardDetails?.let { d -> listOf(d.name, d.address).filter { it.isNotBlank() }.distinct().joinToString(", ") } ?: p.name
        lastCard = p to s.cardDetails
        val keepSnap = searchSnap
        closeCard(restore = false)
        searchSnap = keepSnap
        NavSession.plan(p.copy(name = name.ifBlank { p.name }))
    }

    fun cardAsStop() {
        val p = _ui.value.card ?: return
        closeCard()
        NavSession.addVia(p)
    }

    /** Zuhause/Arbeit: direkt die Route berechnen */
    /** Ort aus Favoriten/Startbildschirm: im Zwischenstopp-Modus einfügen, sonst direkt als Ziel planen */
    fun choose(p: Place) {
        when {
            _ui.value.mode == SearchMode.VIA -> pick(p)
            NavSession.state.value.navigating -> askVia(p)
            else -> pickDirect(p)
        }
    }

    /** Während der Fahrt oder in der Zwischenstopp-Suche: nachfragen statt das Ziel zu ersetzen */
    fun askVia(p: Place) {
        searchJob?.cancel()
        _ui.update { it.copy(viaAsk = p, query = "", suggestions = emptyList(), searchActive = false, searching = false, longPress = null, card = null) }
        if (p.title == "Markierter Ort") {
            viewModelScope.launch {
                val n = runCatching { Reverse.name(p.pos) }.getOrNull()?.takeIf { it.isNotBlank() } ?: return@launch
                _ui.update { s -> if (s.viaAsk?.pos == p.pos) s.copy(viaAsk = p.copy(name = n)) else s }
            }
        }
    }

    fun answerVia(asVia: Boolean) {
        val p = _ui.value.viaAsk ?: return
        _ui.update { it.copy(viaAsk = null, mode = SearchMode.DEST) }
        Recents.add(p)
        if (asVia) NavSession.addVia(p) else if (NavSession.state.value.navigating) NavSession.changeDestinationDuringNav(p) else NavSession.plan(p)
    }

    fun cancelVia() { _ui.update { it.copy(viaAsk = null, mode = SearchMode.DEST) } }

    fun pickDirect(p: Place) {
        lastCard = null
        _ui.update { it.copy(query = "", suggestions = emptyList(), searchActive = false, searching = false, mode = SearchMode.DEST) }
        NavSession.plan(p)
    }

    fun startSearch(mode: SearchMode) {
        _ui.update { it.copy(mode = mode, query = "", suggestions = emptyList(), searchActive = true, longPress = null) }
    }

    fun cancelSearch() {
        searchJob?.cancel()
        _ui.update { it.copy(mode = SearchMode.DEST, query = "", suggestions = emptyList(), searchActive = false, searching = false) }
    }

    // ----- Langes Drücken auf die Karte -----

    fun onLongPress(ll: LatLon) {
        val p = Place("Markierter Ort", ll)
        // In der Zwischenstopp-Suche oder während der Fahrt: direkt fragen, ob Zwischenstopp oder neues Ziel
        if (_ui.value.mode == SearchMode.VIA || NavSession.state.value.navigating) askVia(p) else openCard(p)
    }

    fun closeLongPress() { _ui.update { it.copy(longPress = null) } }

    private fun longPressPlace(): Place? = _ui.value.longPress?.let { Place(it.name ?: "Markierter Ort", it.pos) }

    fun longPressRoute() { longPressPlace()?.let { closeLongPress(); NavSession.plan(it) } }

    fun longPressVia() { longPressPlace()?.let { closeLongPress(); NavSession.addVia(it) } }

    fun longPressFavorite() { longPressPlace()?.let { closeLongPress(); Favorites.set(FavKind.OTHER, it) } }

    // ----- Favoriten bearbeiten -----

    fun editFavorite(f: Favorite?) { _ui.update { it.copy(editFav = f) } }

    fun setSheetPx(px: Int) { _ui.update { it.copy(sheetPx = px) } }

    fun openObd() { Obd.acquire("screen"); _ui.update { it.copy(showObd = true) } }

    fun closeObd() { Obd.release("screen"); _ui.update { it.copy(showObd = false) } }

    fun openTrips() { _ui.update { it.copy(showTrips = true) } }

    fun closeTrips() { _ui.update { it.copy(showTrips = false) } }

    fun onGesture() { _ui.update { it.copy(follow = false) } }

    fun recenter() { _ui.update { it.copy(follow = true, recenter = it.recenter + 1) } }

    fun openSettings(page: String? = null) { _ui.update { it.copy(showSettings = true, settingsPage = page) } }

    fun closeSettings() { _ui.update { it.copy(showSettings = false) } }

    /** Tippen auf eine graue Alternativroute wählt sie aus */
    fun onMapTap(ll: LatLon, metersPerPx: Double) {
        if (_ui.value.longPress != null) closeLongPress()
        if (_ui.value.card != null) { closeCard(restore = false); return }
        val s = NavSession.state.value
        if (s.navigating || s.routes.size < 2) return
        var best = -1
        var bd = Double.MAX_VALUE
        s.routes.forEachIndexed { i, r ->
            if (i == s.selected) return@forEachIndexed
            for (k in 0 until r.points.size - 1) {
                val d = distToSeg(ll, r.points[k], r.points[k + 1])
                if (d < bd) { bd = d; best = i }
            }
        }
        if (best >= 0 && bd < 28 * metersPerPx) NavSession.select(best)
    }
}
