package de.evroute

import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.maps.Style
import org.maplibre.android.style.sources.VectorSource
import org.maplibre.geojson.Point

/**
 * Orte (POI) direkt aus den OpenStreetMap-Kartenkacheln (OpenMapTiles, Ebene „poi“).
 * Kein eigener Server nötig: Die Daten kommen mit der Karte und sind auch offline da.
 */
object TilePois {
    const val LAYER = "pois-tiles"
    private const val OWN_SOURCE = "evr-omt"
    private const val TILE_URL = "https://tiles.openfreemap.org/planet"

    /** OSM-Werte (subclass) je Kategorie */
    val VALUES = mapOf(
        "food" to listOf("restaurant", "cafe", "fast_food", "bar", "pub", "ice_cream", "biergarten", "food_court"),
        "shop" to listOf("supermarket", "convenience", "bakery", "mall", "department_store", "doityourself", "hardware", "chemist", "butcher", "beverages", "greengrocer", "kiosk"),
        "wc" to listOf("toilets"),
        "fuel" to listOf("fuel"),
        "parking" to listOf("parking"),
        "hotel" to listOf("hotel", "motel", "guest_house", "hostel"),
        "sight" to listOf("attraction", "museum", "viewpoint", "zoo", "theme_park", "castle", "monument"),
        "health" to listOf("pharmacy", "hospital", "doctors", "dentist", "clinic"),
        "money" to listOf("atm", "bank"),
    )

    @Volatile private var style: Style? = null
    @Volatile private var sourceId: String? = null

    fun catOf(subclass: String): String? = VALUES.entries.firstOrNull { subclass in it.value }?.key

    /** OSM-Art („shop=supermarket“) für Kategorie-Namen im Ortsfenster */
    fun kindOf(subclass: String): String = when (catOf(subclass)) {
        "shop" -> "shop=$subclass"
        "hotel", "sight" -> if (subclass in setOf("castle", "monument")) "historic=$subclass" else "tourism=$subclass"
        else -> "amenity=$subclass"
    }

    /** Ebene anlegen bzw. neu filtern (nach Stilwechsel oder geänderten Einstellungen) */
    fun apply(s: Style, enabled: Boolean, cats: Set<String>) {
        style = s
        s.getLayer(LAYER)?.let { s.removeLayer(it) }
        val src = if (s.getSource("openmaptiles") != null) {
            "openmaptiles"
        } else {
            if (s.getSource(OWN_SOURCE) == null) s.addSource(VectorSource(OWN_SOURCE, TILE_URL))
            OWN_SOURCE
        }
        sourceId = src
        // Ist die Anzeige aus, bleibt die Ebene unsichtbar bestehen, damit „In der Nähe“ die Daten trotzdem hat
        val active = if (enabled && cats.isNotEmpty()) cats else VALUES.keys
        val allowed = active.flatMap { VALUES[it].orEmpty() }.toTypedArray()
        val iconExpr = Expression.match(
            Expression.get("subclass"), Expression.literal("poi-shop"),
            *VALUES.flatMap { (cat, vals) -> vals.map { v -> Expression.stop(v, Pois.iconId(cat)) } }.toTypedArray(),
        )
        val layer = SymbolLayer(LAYER, src)
        layer.sourceLayer = "poi"
        layer.minZoom = 13f
        layer.setFilter(
            Expression.match(Expression.get("subclass"), Expression.literal(false), *allowed.map { Expression.stop(it, true) }.toTypedArray()),
        )
        layer.setProperties(
            PropertyFactory.iconImage(iconExpr),
            PropertyFactory.iconAllowOverlap(true),
            PropertyFactory.iconIgnorePlacement(false),
            PropertyFactory.iconOpacity(if (enabled && cats.isNotEmpty()) 1f else 0f),
            PropertyFactory.iconSize(
                Expression.interpolate(Expression.linear(), Expression.zoom(), Expression.stop(13, 0.7f), Expression.stop(17, 1.0f)),
            ),
            PropertyFactory.visibility(Property.VISIBLE),
        )
        when {
            s.getLayer("map-chargers-pulse") != null -> s.addLayerBelow(layer, "map-chargers-pulse")
            s.getLayer("map-chargers") != null -> s.addLayerBelow(layer, "map-chargers")
            else -> s.addLayer(layer)
        }
    }

    data class TileHit(val subclass: String, val name: String, val pos: LatLon)

    /** Orte im Umkreis aus den bereits geladenen Kacheln (muss auf dem Hauptthread laufen) */
    fun around(c: LatLon, radiusM: Double): List<TileHit>? {
        val s = style ?: return null
        val id = sourceId ?: return null
        val src = runCatching { s.getSourceAs<VectorSource>(id) }.getOrNull() ?: return null
        val feats = runCatching { src.querySourceFeatures(arrayOf("poi"), null) }.getOrNull() ?: return null
        return feats.mapNotNull { f ->
            val g = f.geometry() as? Point ?: return@mapNotNull null
            val p = LatLon(g.latitude(), g.longitude())
            if (haversine(c, p) > radiusM) return@mapNotNull null
            val sub = runCatching { f.getStringProperty("subclass") }.getOrNull() ?: return@mapNotNull null
            val name = listOf("name:de", "name_de", "name").firstNotNullOfOrNull { k ->
                runCatching { f.getStringProperty(k) }.getOrNull()?.takeIf { it.isNotBlank() }
            } ?: ""
            TileHit(sub, name, p)
        }.distinctBy { "${it.subclass}|${it.name}|${(it.pos.lat * 1e4).toInt()}|${(it.pos.lon * 1e4).toInt()}" }
    }
}
