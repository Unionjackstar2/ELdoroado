package de.evroute

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import okhttp3.FormBody
import okhttp3.Request
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.WeakHashMap
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Tempolimits aus mehreren Quellen:
 * 0 = TomTom (Route), 1 = TomTom (Straßendaten), 2 = OpenStreetMap, 3 = Kombiniert (OSM, sonst TomTom-Route).
 */
object SpeedLimits {
    const val NONE = -1 // „keine Begrenzung“ (z. B. Autobahn ohne Limit)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var logFile: File? = null
    private var lastLogAlong = -1e9

    fun init(ctx: Context) { logFile = File(ctx.filesDir, "tempolimits.csv") }

    /** Tempolimit an einer Stelle der Route und seine Quelle („TT“, „TT·S“, „OSM“) */
    fun at(r: Route, along: Double): Pair<Int?, String?> {
        val tt = r.limitAt(along)
        // Tempolimits aus den Valhalla-Kacheln (OpenStreetMap, offline) – Overpass nur, wenn die Route keine mitbringt
        if (TomTomPolicy.TRAFFIC_ONLY && r.speedLimits != null) {
            return (tt ?: OsmSpeed.at(r, along)?.let { v -> if (v == NONE) null else v }) to "OSM"
        }
        val src = if (TomTomPolicy.TRAFFIC_ONLY) 2 else Settings.state.value.speedSource
        return when (src) {
            0 -> tt to "TT"
            1 -> TomTomRoadSpeed.current()?.let { v -> (if (v == NONE) null else v) to "TT·S" } ?: (tt to "TT")
            2 -> OsmSpeed.at(r, along)?.let { v -> (if (v == NONE) null else v) to "OSM" } ?: (null to "OSM")
            else -> OsmSpeed.at(r, along)?.let { v -> (if (v == NONE) null else v) to "OSM" } ?: (tt to "TT")
        }
    }

    /** Beim Planen: OSM-Daten für den Anfang der Route holen */
    fun prefetch(r: Route) {
        if (r.speedLimits == null) OsmSpeed.ensure(r, 0.0)
    }

    /** Während der Fahrt: Daten nachladen, TomTom-Straßendaten abfragen, Vergleich protokollieren */
    fun onFix(f: Fix, r: Route, p: NavProgress) {
        val set = Settings.state.value
        if (r.speedLimits == null) OsmSpeed.ensure(r, p.alongM)
        if (!TomTomPolicy.TRAFFIC_ONLY && (set.speedSource == 1 || set.speedLog)) TomTomRoadSpeed.maybeQuery(f)
        if (set.speedLog && abs(p.alongM - lastLogAlong) >= 150) {
            lastLogAlong = p.alongM
            val line = listOf(
                SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.GERMANY).format(Date()),
                "%.6f".format(Locale.US, f.pos.lat), "%.6f".format(Locale.US, f.pos.lon),
                (f.speed * 3.6).roundToInt().toString(),
                r.limitAt(p.alongM)?.toString() ?: "",
                TomTomRoadSpeed.current()?.let { if (it == NONE) "frei" else it.toString() } ?: "",
                OsmSpeed.at(r, p.alongM)?.let { if (it == NONE) "frei" else it.toString() } ?: "",
                at(r, p.alongM).first?.toString() ?: "",
            ).joinToString(";")
            scope.launch {
                runCatching {
                    val file = logFile ?: return@runCatching
                    if (!file.exists()) file.writeText("Zeit;Breite;Länge;km/h;TomTom Route;TomTom Straße;OSM;angezeigt\n")
                    file.appendText(line + "\n")
                }
            }
        }
    }

    fun logText(): String = runCatching { logFile?.readText() }.getOrNull().orEmpty()
    fun logLines(): Int = logText().lines().count { it.isNotBlank() }.minus(1).coerceAtLeast(0)
    fun clearLog() { runCatching { logFile?.delete() } }
}

/** TomTom „Straßendaten“: Tempolimit der Straße an der eigenen Position (Rückwärtssuche) */
object TomTomRoadSpeed {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var value: Int? = null
    @Volatile private var valueAt: LatLon? = null
    @Volatile private var lastQuery: LatLon? = null
    @Volatile private var lastQueryTime = 0L
    @Volatile private var busy = false

    /** Wert, solange man in der Nähe der Abfrage ist */
    fun current(): Int? {
        val at = valueAt ?: return null
        val me = LocationHub.fix.value?.pos ?: return null
        return if (haversine(at, me) < 700) value else null
    }

    fun maybeQuery(f: Fix) {
        val set = Settings.state.value
        if (!set.hasTomTom || busy || f.speed < 2) return
        val last = lastQuery
        val now = System.currentTimeMillis()
        // höchstens alle 400 m bzw. 60 s (schont das Tageskontingent)
        if (last != null && haversine(last, f.pos) < 400 && now - lastQueryTime < 60_000) return
        busy = true
        lastQuery = f.pos; lastQueryTime = now
        scope.launch {
            runCatching {
                val heading = f.bearing?.let { "&heading=${it.roundToInt()}" } ?: ""
                val url = "https://api.tomtom.com/search/2/reverseGeocode/${"%.6f".format(Locale.US, f.pos.lat)},${"%.6f".format(Locale.US, f.pos.lon)}.json" +
                    "?key=${set.tomtomKey.trim()}&returnSpeedLimit=true&radius=40$heading&language=de-DE"
                ApiCounter.hit()
                val o = json.parseToJsonElement(Http.get(url)).jsonObject
                val addr = ((o["addresses"] as? JsonArray)?.firstOrNull() as? JsonObject)?.get("address") as? JsonObject
                val raw = (addr?.get("speedLimit") as? JsonPrimitive)?.contentOrNull // z. B. „70.00KPH“
                val v = raw?.let { s ->
                    val n = Regex("([0-9.]+)").find(s)?.groupValues?.get(1)?.toDoubleOrNull()
                    when {
                        n == null -> null
                        s.contains("MPH", true) -> (n * 1.609).roundToInt()
                        else -> n.roundToInt()
                    }
                }
                value = v; valueAt = f.pos
            }
            busy = false
        }
    }
}

/** OpenStreetMap: Tempolimits (maxspeed) entlang der Route über Overpass, abschnittsweise nachgeladen */
object OsmSpeed {
    private class Data(n: Int) {
        val limits = IntArray(n) // 0 = unbekannt, NONE = keine Begrenzung
        var coveredTo = 0.0
        @Volatile var loading = false
        @Volatile var failedAt = 0L
        var fails = 0
    }

    // Schlüssel ist die Punktliste der Route (bleibt bei r.copy() gleich, z. B. nach dem Auffrischen von Verkehrsmeldungen).
    // Identität statt Inhalt: der Hash einer ganzen Route wäre bei jeder Abfrage teuer.
    private val cache = java.util.IdentityHashMap<List<LatLon>, Data>()

    private fun data(r: Route, create: Boolean): Data? = synchronized(cache) {
        cache[r.points] ?: if (!create) null else {
            if (cache.size > 6) cache.clear()
            Data(r.points.size - 1).also { cache[r.points] = it }
        }
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val servers = listOf("https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter")

    fun at(r: Route, along: Double): Int? {
        val d = data(r, false) ?: return null
        if (r.cumM.isEmpty()) return null
        var i = r.cumM.binarySearch(along)
        if (i < 0) i = -i - 2
        val v = d.limits.getOrNull(i.coerceIn(0, d.limits.lastIndex)) ?: return null
        return v.takeIf { it != 0 }
    }

    /** Sicherstellen, dass die nächsten ~15 km geladen sind (lädt bis 40 km voraus) */
    fun ensure(r: Route, along: Double) {
        if (r.points.size < 2) return
        val d = data(r, true) ?: return
        val end = r.cumM.last()
        if (d.loading || d.coveredTo >= end || d.coveredTo > along + 15_000) return
        // nach Fehlern (offline, Server überlastet) nicht jede Sekunde neu fragen: 1, 2, 4 … bis 15 Minuten warten
        val wait = (60_000L shl (d.fails - 1).coerceIn(0, 4)).coerceAtMost(15 * 60_000L)
        if (d.fails > 0 && System.currentTimeMillis() - d.failedAt < wait) return
        d.loading = true
        scope.launch {
            try {
                var from = maxOf(d.coveredTo, along - 200)
                val to = minOf(end, along + 40_000)
                while (from < to) {
                    val chunkEnd = minOf(to, from + 15_000)
                    if (!loadChunk(r, d, from, chunkEnd)) { d.fails++; d.failedAt = System.currentTimeMillis(); break }
                    d.fails = 0
                    d.coveredTo = chunkEnd
                    from = chunkEnd
                }
            } finally {
                d.loading = false
            }
        }
    }

    private suspend fun loadChunk(r: Route, d: Data, from: Double, to: Double): Boolean {
        val i0 = r.cumM.indexOfFirst { it >= from }.coerceAtLeast(0)
        val i1 = r.cumM.indexOfLast { it <= to }.coerceAtLeast(i0)
        // Punkte für die Abfrage ausdünnen (etwa alle 60 m, höchstens 250 Punkte)
        val q = mutableListOf<LatLon>()
        var last: LatLon? = null
        for (i in i0..i1) {
            val pt = r.points[i]
            if (last == null || haversine(last, pt) >= 60 || i == i1) { q += pt; last = pt }
        }
        val step = maxOf(1, q.size / 250)
        val coords = q.filterIndexed { k, _ -> k % step == 0 || k == q.lastIndex }
            .joinToString(",") { "%.5f,%.5f".format(Locale.US, it.lat, it.lon) }
        val query = "[out:json][timeout:25];way(around:20,$coords)[\"highway\"][~\"^maxspeed(:forward|:backward)?$\"~\".\"];out tags geom;"
        val body = servers.firstNotNullOfOrNull { url ->
            runCatching {
                val req = Request.Builder().url(url).header("User-Agent", "ELdoroado (privat)").post(FormBody.Builder().add("data", query).build()).build()
                Http.call(req).takeIf { it.code == 200 }?.body
            }.getOrNull()
        } ?: return false
        val els = (json.parseToJsonElement(body).jsonObject["elements"] as? JsonArray) ?: return true
        // Wegsegmente in ein Raster legen (schnelle Suche)
        class Seg(val a: LatLon, val b: LatLon, val fwd: Int?, val bwd: Int?)
        val grid = HashMap<Long, MutableList<Seg>>()
        fun cell(p: LatLon): Long = ((p.lat / 0.002).toLong() shl 32) xor ((p.lon / 0.002).toLong() and 0xffffffffL)
        els.forEach { e ->
            val o = e as? JsonObject ?: return@forEach
            val tags = o["tags"] as? JsonObject ?: return@forEach
            fun tag(k: String) = (tags[k] as? JsonPrimitive)?.contentOrNull
            val base = parse(tag("maxspeed"))
            val fwd = parse(tag("maxspeed:forward")) ?: base
            val bwd = parse(tag("maxspeed:backward")) ?: base
            if (fwd == null && bwd == null) return@forEach
            val geom = (o["geometry"] as? JsonArray)?.mapNotNull { g ->
                val go = g as? JsonObject ?: return@mapNotNull null
                val la = (go["lat"] as? JsonPrimitive)?.doubleOrNull ?: return@mapNotNull null
                val lo = (go["lon"] as? JsonPrimitive)?.doubleOrNull ?: return@mapNotNull null
                LatLon(la, lo)
            } ?: return@forEach
            for (k in 0 until geom.size - 1) {
                val s = Seg(geom[k], geom[k + 1], fwd, bwd)
                val c = cell(LatLon((s.a.lat + s.b.lat) / 2, (s.a.lon + s.b.lon) / 2))
                for (dy in -1..1) for (dx in -1..1) {
                    val key = c + (dy.toLong() shl 32) + dx
                    grid.getOrPut(key) { mutableListOf() }.add(s)
                }
            }
        }
        // jedem Routenabschnitt das nächste passende Wegsegment zuordnen (Abstand < 15 m, Richtung passt)
        val kx = 111320.0 * cos(Math.toRadians(r.points[i0].lat)); val ky = 110540.0
        for (i in i0 until minOf(i1, d.limits.size)) {
            val a = r.points[i]; val b = r.points[i + 1]
            val mid = LatLon((a.lat + b.lat) / 2, (a.lon + b.lon) / 2)
            val dir = bearing(a, b)
            var best: Seg? = null; var bestD = 15.0; var bestFwd = true
            grid[cell(mid)]?.forEach { s ->
                val dist = segDist(mid, s.a, s.b, kx, ky)
                if (dist >= bestD) return@forEach
                var dd = abs(bearing(s.a, s.b) - dir) % 360
                if (dd > 180) dd = 360 - dd
                val forward = dd < 40
                val backward = dd > 140
                if (!forward && !backward) return@forEach
                best = s; bestD = dist; bestFwd = forward
            }
            best?.let { s -> (if (bestFwd) s.fwd else s.bwd)?.let { d.limits[i] = it } }
        }
        return true
    }

    private fun segDist(p: LatLon, a: LatLon, b: LatLon, kx: Double, ky: Double): Double {
        val px = p.lon * kx; val py = p.lat * ky
        val ax = a.lon * kx; val ay = a.lat * ky
        val bx = b.lon * kx; val by = b.lat * ky
        val dx = bx - ax; val dy = by - ay
        val l2 = dx * dx + dy * dy
        val t = if (l2 > 0) (((px - ax) * dx + (py - ay) * dy) / l2).coerceIn(0.0, 1.0) else 0.0
        return hypot(px - (ax + t * dx), py - (ay + t * dy))
    }

    /** OSM-maxspeed in km/h: Zahl, „DE:urban“ (50), „DE:rural“ (100), „none“/„DE:motorway“ (keine Begrenzung), „walk“ (7) */
    fun parse(v: String?): Int? {
        val s = v?.trim()?.lowercase() ?: return null
        if (s.isEmpty()) return null
        Regex("^(\\d+)\\s*(mph)?").find(s)?.let { m ->
            val n = m.groupValues[1].toInt()
            return if (m.groupValues[2].isNotEmpty()) (n * 1.609).roundToInt() else n
        }
        return when {
            s == "none" || s.endsWith(":motorway") -> SpeedLimits.NONE
            s == "walk" || s.endsWith(":living_street") -> 7
            s.contains("zone30") || s.contains("zone:30") -> 30
            s.contains("zone20") || s.contains("zone:20") -> 20
            s.endsWith(":urban") -> 50
            s == "ch:rural" || s == "fr:rural" || s == "nl:rural" -> 80
            s.endsWith(":rural") -> 100
            s.endsWith(":trunk") -> 100
            else -> null // signals, variable, …
        }
    }
}
