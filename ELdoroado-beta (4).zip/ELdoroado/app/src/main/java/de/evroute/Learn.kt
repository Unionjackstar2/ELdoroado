package de.evroute

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import kotlin.math.min

/** Eine aufgezeichnete Fahrt */
data class Trip(
    val start: Long,
    val km: Double,
    val kwh: Double,
    val durationS: Double,
    val avgKmh: Double,
    val tempC: Double?,
) {
    val per100: Double get() = if (km > 0.1) kwh / km * 100 else 0.0
}

/**
 * Lernt den Verbrauch aus echten Fahrten: je Tempo- und Temperaturbereich ein Faktor gegenüber dem Grundmodell.
 * Grundlage: Energie im Akku (OBD, 0,01 kWh genau), GPS-Strecke und -Höhe, Außentemperatur.
 */
object Learner {
    val SPEED_EDGES = doubleArrayOf(0.0, 40.0, 70.0, 100.0, 120.0, 999.0)
    val SPEED_LABELS = listOf("bis 40", "40–70", "70–100", "100–120", "über 120")
    val TEMP_EDGES = doubleArrayOf(-99.0, 5.0, 15.0, 99.0)
    val TEMP_LABELS = listOf("unter 5 °C", "5–15 °C", "über 15 °C")
    private const val NS = 5
    private const val NT = 3

    private lateinit var prefs: SharedPreferences
    private var ratio = DoubleArray(NS * NT) { 1.0 }
    private var km = DoubleArray(NS * NT)
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    // Ladekurve: höchste beobachtete Leistung je 5-%-Bereich
    private var chargeMax = DoubleArray(20)
    private var chargeN = IntArray(20)

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("learn", Context.MODE_PRIVATE)
        fun arr(key: String, n: Int, def: Double): DoubleArray {
            val parts = (prefs.getString(key, "") ?: "").split(',').mapNotNull { it.toDoubleOrNull() }
            return if (parts.size == n) parts.toDoubleArray() else DoubleArray(n) { def }
        }
        ratio = arr("ratio", NS * NT, 1.0)
        km = arr("km", NS * NT, 0.0)
        chargeMax = arr("chargeMax", 20, 0.0)
        chargeN = arr("chargeN", 20, 0.0).map { it.toInt() }.toIntArray()
        if (!prefs.getBoolean("tempFix1", false)) {
            for (sb in 0 until NS) { ratio[sb * NT] = 1.0; km[sb * NT] = 0.0 }
            prefs.edit().putBoolean("tempFix1", true).apply()
            save()
        }
    }

    private fun save() {
        prefs.edit()
            .putString("ratio", ratio.joinToString(",") { String.format(Locale.US, "%.4f", it) })
            .putString("km", km.joinToString(",") { String.format(Locale.US, "%.2f", it) })
            .putString("chargeMax", chargeMax.joinToString(",") { String.format(Locale.US, "%.1f", it) })
            .putString("chargeN", chargeN.joinToString(","))
            .apply()
        _version.value++
    }

    fun reset() {
        ratio = DoubleArray(NS * NT) { 1.0 }
        km = DoubleArray(NS * NT)
        chargeMax = DoubleArray(20)
        chargeN = IntArray(20)
        save()
    }

    private fun sBin(v: Double) = (1 until SPEED_EDGES.size).first { v < SPEED_EDGES[it] || it == SPEED_EDGES.lastIndex } - 1
    private fun tBin(t: Double) = (1 until TEMP_EDGES.size).first { t < TEMP_EDGES[it] || it == TEMP_EDGES.lastIndex } - 1

    /** Einen gefahrenen Abschnitt einlernen */
    fun learnSegment(distKm: Double, measuredKwh: Double, avgKmh: Double, tempC: Double, hours: Double) {
        if (distKm < 0.3) return
        val s = Settings.state.value
        // Vorhersage des Grundmodells ohne Gelerntes und ohne Fahrweise
        val predicted = distKm * EvModel.basePer100(avgKmh, tempC) / 100 + EvModel.auxKw(WeatherInfo(tempC, 0.0, false)) * hours
        if (predicted <= 0.01) return
        val r = (measuredKwh / predicted).coerceIn(0.5, 2.0)
        val i = sBin(avgKmh) * NT + tBin(tempC)
        val w = min(km[i], 150.0)
        ratio[i] = (ratio[i] * w + r * distKm) / (w + distKm)
        km[i] += distKm
        if (s.learnEnabled) save()
    }

    /** Gelernter Faktor für Tempo und Temperatur samt Vertrauen (0..1) */
    fun factor(v: Double, t: Double): Pair<Double, Double> {
        val si = sBin(v)
        val i = si * NT + tBin(t)
        if (km[i] >= 3) return ratio[i] to min(1.0, km[i] / 30.0)
        // zu wenig Daten bei dieser Temperatur: über alle Temperaturen dieses Tempos mitteln
        var sum = 0.0
        var k = 0.0
        for (ti in 0 until NT) { sum += ratio[si * NT + ti] * km[si * NT + ti]; k += km[si * NT + ti] }
        return if (k >= 3) (sum / k) to min(1.0, k / 60.0) else 1.0 to 0.0
    }

    fun cell(si: Int, ti: Int): Pair<Double, Double> = ratio[si * NT + ti] to km[si * NT + ti]

    fun totalKm(): Double = km.sum()

    // ----- Ladekurve -----

    fun learnCharge(socPct: Double, powerKw: Double) {
        if (powerKw < 15 || powerKw > 200 || socPct !in 0.0..100.0) return
        val b = (socPct / 5).toInt().coerceIn(0, 19)
        chargeN[b]++
        if (powerKw > chargeMax[b]) chargeMax[b] = powerKw
        if (chargeN[b] % 5 == 0 || powerKw >= chargeMax[b]) save()
    }

    /** Gelernte Höchstleistung bei einem Akkustand oder null */
    fun chargeAt(socPct: Double): Double? {
        val b = (socPct / 5).toInt().coerceIn(0, 19)
        return if (chargeN[b] >= 3 && chargeMax[b] >= 25) chargeMax[b] else null
    }

    fun chargeBins(): List<Triple<Int, Double, Int>> = (0 until 20).map { Triple(it * 5, chargeMax[it], chargeN[it]) }
}

/** Zeichnet Fahrten und Ladevorgänge auf, solange OBD verbunden ist */
object TripRecorder {
    private lateinit var file: File
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _trips = MutableStateFlow<List<Trip>>(emptyList())
    val trips: StateFlow<List<Trip>> = _trips.asStateFlow()
    private val _recording = MutableStateFlow(false)
    val recording: StateFlow<Boolean> = _recording.asStateFlow()

    // laufende Fahrt
    private var tripStart = 0L
    private var tripKm = 0.0
    private var tripKwh = 0.0
    private var tripS = 0.0
    private var tripTempSum = 0.0
    private var tripTempN = 0
    private var stillSince = 0L

    // laufender Abschnitt
    private var segKwh0 = Double.NaN
    private var segT0 = 0L
    private var segDist = 0.0
    private var segAlt0: Double? = null
    private var lastPos: LatLon? = null

    // Laden
    private var chKwh0 = Double.NaN
    private var chT0 = 0L

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "trips.csv")
        reload()
        // alte Fahrten mit unplausiblen Temperaturen (fehlerhafte OBD-Werte) bereinigen
        val bad = _trips.value.any { t -> t.tempC != null && (t.tempC < -20 || t.tempC > 48) }
        if (bad) {
            _trips.value = _trips.value.map { t -> if (t.tempC != null && (t.tempC < -20 || t.tempC > 48)) t.copy(tempC = null) else t }
            runCatching { file.writeText(_trips.value.joinToString("\n") { listOf(it.start, it.km, it.kwh, it.durationS, it.avgKmh, it.tempC ?: "").joinToString(";") } + "\n") }
        }
        scope.launch {
            while (true) {
                delay(if (Obd.conn.value == Obd.Conn.READY) 2000 else 15_000)
                runCatching { tick() }
            }
        }
    }

    /** Fahrten neu aus der Datei laden (nach dem Wiederherstellen einer Sicherung) */
    fun reload() {
        _trips.value = runCatching {
            file.readLines().mapNotNull { l ->
                val p = l.split(';')
                if (p.size < 6) null else Trip(p[0].toLong(), p[1].toDouble(), p[2].toDouble(), p[3].toDouble(), p[4].toDouble(), p[5].toDoubleOrNull())
            }
        }.getOrDefault(emptyList())
    }

    fun clear() {
        _trips.value = emptyList()
        runCatching { file.delete() }
    }

    fun csv(): String = "Start;km;kWh;Dauer_s;km/h;°C;kWh/100km\n" + _trips.value.joinToString("\n") { t ->
        String.format(Locale.GERMANY, "%tF %<tR;%.1f;%.2f;%.0f;%.0f;%s;%.1f", t.start, t.km, t.kwh, t.durationS, t.avgKmh, t.tempC?.let { "%.0f".format(it) } ?: "", t.per100)
    }

    private fun ambient(): Double? = AmbientTemp.best()

    private var lastFresh = 0L

    private fun tick() {
        val set = Settings.state.value
        val soc = Obd.freshSoc()
        val now = System.currentTimeMillis()
        if (soc != null) lastFresh = now
        // nur frische OBD-Werte zählen: nach dem Ausschalten liefert der Adapter keine neuen Daten mehr
        val kwh = if (now - lastFresh < 20_000) Obd.value("kwh") else null
        val f = LocationHub.fix.value
        val fixAge = f?.let { if (it.elapsedNs > 0) (android.os.SystemClock.elapsedRealtimeNanos() - it.elapsedNs) / 1_000_000 else now - it.time } ?: Long.MAX_VALUE
        if (!set.learnEnabled || kwh == null || f == null || fixAge > 10_000) {
            // Auto aus (OBD seit 1 min still) oder lange Stillstand: Fahrt abschließen und speichern
            if (tripStart > 0 && (now - lastFresh > 60_000 || now - stillSince > 3 * 60_000)) finishTrip()
            return
        }
        val moving = f.speed > 1.5

        // ----- Laden (steht, Energie steigt) -----
        if (!moving) {
            if (chKwh0.isNaN()) { chKwh0 = kwh; chT0 = now }
            val dt = (now - chT0) / 1000.0
            if (dt >= 30) {
                val p = (kwh - chKwh0) / dt * 3600
                if (p > 3 && soc != null) Learner.learnCharge(soc, p)
                chKwh0 = kwh; chT0 = now
            }
        } else {
            chKwh0 = Double.NaN
        }

        // ----- Fahren -----
        if (moving) {
            stillSince = now
            if (tripStart == 0L) {
                tripStart = now; tripKm = 0.0; tripKwh = 0.0; tripS = 0.0; tripTempSum = 0.0; tripTempN = 0
                _recording.value = true
            }
            if (segKwh0.isNaN()) startSegment(kwh, now, f)
            val prev = lastPos
            if (prev != null && f.accuracy < 35) {
                val d = haversine(prev, f.pos)
                if (d < 250) segDist += d
            }
            lastPos = f.pos
            val segS = (now - segT0) / 1000.0
            if (segDist >= 1000 || (segS >= 180 && segDist >= 300)) closeSegment(kwh, now, f)
        } else {
            lastPos = null
            if (!segKwh0.isNaN() && segDist >= 300) closeSegment(kwh, now, f) else if (!segKwh0.isNaN() && now - stillSince > 60_000) segKwh0 = Double.NaN
            if (tripStart > 0 && now - stillSince > 3 * 60_000) finishTrip()
        }
    }

    /** Von außen abschließen (z. B. Ziel erreicht oder App wird geschlossen) */
    fun finishNow() { scope.launch { runCatching { if (tripStart > 0) finishTrip() } } }

    private fun startSegment(kwh: Double, now: Long, f: Fix) {
        segKwh0 = kwh; segT0 = now; segDist = 0.0; segAlt0 = f.alt; lastPos = f.pos
    }

    private fun closeSegment(kwh: Double, now: Long, f: Fix) {
        val used = segKwh0 - kwh
        val distKm = segDist / 1000
        val hours = (now - segT0) / 3_600_000.0
        val dh = if (segAlt0 != null && f.alt != null) f.alt - segAlt0!! else 0.0
        val perKm = if (distKm > 0) used / distKm else 0.0
        // Plausibel? (Laden oder Messfehler ausschließen)
        if (distKm >= 0.3 && hours > 0 && perKm in -1.0..1.2) {
            val flat = used - (if (dh > 0) dh * 0.0053 else dh * 0.0030)
            val avgKmh = distKm / hours
            val temp = ambient() ?: 12.0
            Learner.learnSegment(distKm, flat, avgKmh, temp, hours)
            tripKm += distKm
            tripKwh += used
            tripS += hours * 3600
            ambient()?.let { tripTempSum += it; tripTempN++ }
        }
        startSegment(kwh, now, f)
    }

    private fun finishTrip() {
        _recording.value = false
        if (tripKm >= 1.0) {
            val t = Trip(
                tripStart, tripKm, tripKwh, tripS,
                if (tripS > 0) tripKm / (tripS / 3600) else 0.0,
                if (tripTempN > 0) tripTempSum / tripTempN else null,
            )
            val list = (_trips.value + t).takeLast(200)
            _trips.value = list
            runCatching {
                file.writeText(list.joinToString("\n") {
                    listOf(it.start, it.km, it.kwh, it.durationS, it.avgKmh, it.tempC ?: "").joinToString(";")
                })
            }
        }
        tripStart = 0L
        segKwh0 = Double.NaN
    }

    /** Durchschnitt der letzten Fahrten (kWh/100 km), nach Strecke gewichtet */
    fun average(): Double? {
        val l = _trips.value.takeLast(30)
        val k = l.sumOf { it.km }
        return if (k >= 5) l.sumOf { it.kwh } / k * 100 else null
    }
}


/**
 * Außentemperatur mit Plausibilitätsprüfung: Der OBD-Wert wird mit der Wettertemperatur am Standort (Open-Meteo) verglichen.
 * Weicht er mehr als 10 °C ab oder liegt außerhalb von −25…48 °C, gilt die Wettertemperatur.
 */
object AmbientTemp {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile var weatherC: Double? = null
    @Volatile private var lastFetch = 0L
    @Volatile var lastObdImplausible = false

    private fun refresh() {
        val pos = LocationHub.fix.value?.pos ?: return
        if (System.currentTimeMillis() - lastFetch < 15 * 60_000) return
        lastFetch = System.currentTimeMillis()
        scope.launch { runCatching { weatherC = Weather.along(pos, pos).tempC } }
    }

    fun best(): Double? {
        refresh()
        val obd = Obd.value("ambient")
        val w = weatherC
        val plausible = obd != null && obd in -25.0..48.0 && (w == null || kotlin.math.abs(obd - w) <= 10.0)
        lastObdImplausible = obd != null && !plausible
        return if (plausible) obd else w
    }

    /** Für die Diagnose: „OBD 11 °C · Wetter 12 °C“ */
    fun status(): String {
        val obd = Obd.value("ambient")
        val w = weatherC
        return "OBD " + (obd?.let { "%.0f °C".format(it) } ?: "–") + " · Wetter " + (w?.let { "%.0f °C".format(it) } ?: "–") +
            if (lastObdImplausible) " · OBD-Wert unplausibel, nutze Wetter" else ""
    }
}
