package de.evroute

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Eigene Ladeplanung (offline, ohne TomTom):
 * 1. Energiebedarf entlang der Route je Punkt (Tempo je Abschnitt, Wetter, Nebenverbraucher, Höhenmeter)
 * 2. Schnelllader im Korridor aus dem Ladesäulenverzeichnis
 * 3. Schnellste Stopp-Folge per Kürzeste-Wege-Suche: Fahrzeit + Umweg + Ladezeit nach Ladekurve + Standzeit,
 *    der Akku fällt dabei nie unter die Lade-Reserve und kommt mit der Ziel-Reserve an
 * 4. Route über die gewählten Lader neu berechnen und Ladeziele/-zeiten auf der echten Strecke nachrechnen
 */
/** Was die Planung gerade tut – für die Anzeige im Routenfenster („Suche Ladepunkte …“) */
object PlanProgress {
    val step = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)
    @Volatile var prefix: String = ""
    fun set(s: String?) { step.value = s?.let { prefix + it } }
}

object LocalCharging {
    private const val CAP = 80.0        // üblicherweise nur bis hier laden (danach wird es langsam)
    private const val CAP_HARD = 90.0   // nur wenn es anders nicht geht
    private const val STOP_S = 300.0    // Anfahrt, Parken, Bezahlen je Stopp
    private const val DETOUR_MS = 9.0   // Umweg-Tempo (m/s, ~32 km/h) für die Schätzung
    private const val MAX_CANDIDATES = 70

    /** kumulierte Energie (kWh) und Zeit (s) je Routenpunkt */
    class Profile(val e: DoubleArray, val t: DoubleArray) {
        fun at(arr: DoubleArray, r: Route, along: Double): Double {
            // erster Punkt mit cumM >= along (Binärsuche)
            var lo = 0
            var hi = r.cumM.lastIndex
            if (along >= r.cumM[hi]) return arr[hi]
            while (lo < hi) { val mid = (lo + hi) ushr 1; if (r.cumM[mid] >= along) hi = mid else lo = mid + 1 }
            val i = lo
            if (i <= 0) return arr[0]
            val a = r.cumM[i - 1]; val b = r.cumM[i]
            val f = if (b > a) ((along - a) / (b - a)).coerceIn(0.0, 1.0) else 0.0
            return arr[i - 1] + (arr[i] - arr[i - 1]) * f
        }
    }

    fun profile(r: Route, s: AppSettings, w: WeatherInfo?): Profile {
        val n = r.points.size
        val e = DoubleArray(n)
        val t = DoubleArray(n)
        val aux = EvModel.auxKw(w)
        var step = 0
        val ele = r.elevations?.takeIf { it.size == n }
        val massG = 1650.0 * 9.81
        for (i in 1 until n) {
            val along = r.cumM[i]
            while (step < r.stepAlongM.size - 1 && r.stepAlongM[step + 1] <= along) step++
            val st = r.steps.getOrNull(step)
            val v = if (st != null && st.durationS > 1 && st.distanceM > 1) st.distanceM / st.durationS else r.distanceM / max(1.0, r.driveS)
            val d = r.cumM[i] - r.cumM[i - 1]
            val dt = d / max(1.0, v)
            // Gegen- oder Rückenwind je Abschnitt zur tatsächlichen Fahrtrichtung
            val ws = w?.windKmh
            val wSeg = if (w != null && ws != null && w.windFromDeg != null && d > 1) {
                w.copy(headwindKmh = ws * kotlin.math.cos(Math.toRadians(w.windFromDeg - bearing(r.points[i - 1], r.points[i]))))
            } else {
                w
            }
            var kwh = d / 1000 * EvModel.kwhPer100(v * 3.6 * 1.05, s, wSeg) / 100 + aux * dt / 3600
            if (ele != null) {
                val dh = (ele[i] - ele[i - 1]).toDouble()
                kwh += if (dh > 0) massG * dh / 3.6e6 / 0.88 else massG * dh / 3.6e6 * 0.62
            }
            e[i] = e[i - 1] + kwh
            t[i] = t[i - 1] + dt
        }
        // Zeit auf die Fahrzeit der Route eichen
        val total = t[n - 1]
        if (total > 0 && r.driveS > 0) { val k = r.driveS / total; for (i in t.indices) t[i] *= k }
        return Profile(e, t)
    }

    private data class Node(val along: Double, val hit: ChargerHit?, val offsetM: Double)

    /** Zustand in der Suche: an Knoten [node] angekommen, nach [time] s, mit [soc] % Akku */
    private class Label(val node: Int, val time: Double, val soc: Double, val parent: Label?, val chargedTo: Double)

    /**
     * Route mit Ladestopps planen, falls der Akku nicht reicht.
     * [userVias]: eigene Zwischenziele (Lage auf der Basisroute bleibt erhalten).
     * [forced]: selbst gewählte Ladestationen – dann keine automatische Suche, nur Ladeziele/-zeiten rechnen.
     * [routeVia] berechnet dieselbe Strecke über die angegebenen Zwischenpunkte.
     */
    suspend fun plan(
        base0: Route,
        s: AppSettings,
        startSoc: Double,
        w: WeatherInfo?,
        userVias: List<Via>,
        routeVia: suspend (List<LatLon>) -> Route?,
    ): Route {
        // Höhenprofil: kommt aus den Valhalla-Kacheln; nur wenn dort keine Höhen sind, online von Open-Meteo
        if (base0.elevations == null) PlanProgress.set("Lade Höhenprofil (online) …")
        val base = runCatching { Elevation.enrich(base0) }.getOrDefault(base0)
        PlanProgress.set("Prüfe, ob der Akku reicht …")
        val simple = EvModel.estimateSimple(base, s, startSoc, w)
        // Selbst gewählte Ladestationen: Route enthält sie schon als Zwischenhalt
        if (userVias.any { it.isCharger }) {
            val hits = userVias.map { v ->
                if (!v.isCharger) null
                else ChargerHit(v.place.title, "", v.place.pos, if (v.powerKw > 0) v.powerKw else 50.0, 0.0, 0.0, null, id = v.chargeParkId ?: "")
            }
            return annotate(base, s, startSoc, w, hits, hits.map { CAP })
        }
        val prof = profile(base, s, w)
        val end = base.cumM.lastOrNull() ?: return simple
        val usable = s.usableKwh
        fun drop(a: Double, b: Double) = (prof.at(prof.e, base, b) - prof.at(prof.e, base, a)) / usable * 100
        val arrival = startSoc - drop(0.0, end)
        // Akku reicht: kein Ladestopp
        if (arrival >= s.minSocDest) {
            return simple.copy(arrivalSoc = arrival, socProfile = listOf(0.0 to startSoc, end to arrival), feasible = true, reason = null)
        }

        // --- Kandidaten im Korridor, nahe beieinander liegende Lader zu einem Park zusammengefasst ---
        PlanProgress.set("Suche Ladepunkte entlang der Route …")
        val minKw = max(s.searchMinKw, 40)
        val raw = runCatching { Chargers.corridor(s, base, 0.0, end, s.corridorKm.coerceIn(2, 10), minKw) }.getOrDefault(emptyList())
            .filter { h -> h.powerKw >= minKw && s.avoidOperators.none { a -> h.operator.contains(a, true) || h.name.contains(a, true) } }
            .filter { it.alongM in 3_000.0..(end - 3_000.0) }
            .sortedByDescending { it.powerKw }
        val parks = mutableListOf<ChargerHit>()
        for (h in raw) if (parks.none { haversine(it.pos, h.pos) < 250 }) parks += h
        if (parks.isEmpty()) {
            return simple.copy(feasible = false, reason = "Akku reicht nicht, und entlang der Route wurde kein passender Schnelllader gefunden.")
        }
        // je 8 km Strecke die zwei besten Parks (Leistung, Nähe zur Route)
        val cands = parks.groupBy { (it.alongM / 8_000).toInt() }.values
            .flatMap { g -> g.sortedWith(compareByDescending<ChargerHit> { it.powerKw }.thenBy { it.offsetM }).take(2) }
            .sortedByDescending { it.powerKw }.take(MAX_CANDIDATES)
            .sortedBy { it.alongM }
        val nodes = listOf(Node(0.0, null, 0.0)) + cands.map { Node(it.alongM, it, it.offsetM) } + Node(end, null, 0.0)
        val last = nodes.lastIndex
        PlanProgress.set("Vergleiche ${cands.size} Ladeparks …")
        // Energie und Zeit je Knoten einmal vorab (statt in der Suche hunderttausendfach)
        val eAt = DoubleArray(nodes.size) { prof.at(prof.e, base, nodes[it].along) }
        val tAt = DoubleArray(nodes.size) { prof.at(prof.t, base, nodes[it].along) }
        fun detourSoc(off: Double) = off * 2 / 1000 * EvModel.kwhPer100(50.0, s, w) / 100 / usable * 100
        fun prefer(h: ChargerHit?) = h != null && s.preferOperators.any { p -> h.operator.contains(p, true) || h.name.contains(p, true) }
        fun timeAt(a: Double) = prof.at(prof.t, base, a)

        /*
         * Suche über einen Stationsgraphen mit mehreren Ladeständen je Station (vgl. Baum et al., KIT):
         * Die Knoten liegen in Fahrtrichtung, also reicht ein Durchlauf in Reihenfolge. Je Knoten bleiben nur
         * Pareto-optimale Zustände (schneller ODER mehr Akku). An jedem Lader werden Ladeziele in 5-%-Schritten probiert.
         */
        fun search(cap: Double): Label? {
            val labels = Array(nodes.size) { mutableListOf<Label>() }
            labels[0] += Label(0, 0.0, startSoc, null, startSoc)
            for (u in 0 until last) {
                // nur die besten Zustände weiterverfolgen
                val here = labels[u].sortedBy { it.time }.take(8)
                if (here.isEmpty()) continue
                val nu = nodes[u]
                for (lab in here) {
                    val targets: List<Double> = if (u == 0) listOf(startSoc) else {
                        val lo = (kotlin.math.ceil((lab.soc + 1) / 5.0) * 5).coerceAtLeast(lab.soc)
                        generateSequence(lo) { it + 5 }.takeWhile { it <= cap + 0.01 }.toList().ifEmpty { listOf(cap) }
                    }
                    for (tg in targets) {
                        val stopS = if (u == 0) 0.0 else {
                            val kw = nu.hit?.powerKw ?: 50.0
                            UserCharging.chargeSeconds(lab.soc, tg, kw, usable) * (if (prefer(nu.hit)) 0.9 else 1.0) +
                                STOP_S + nu.offsetM * 2 / DETOUR_MS
                        }
                        for (v in u + 1..last) {
                            val nv = nodes[v]
                            val need = (eAt[v] - eAt[u]) / usable * 100 + detourSoc(nu.offsetM) / 2 + detourSoc(nv.offsetM) / 2
                            val reserve = if (v == last) s.minSocDest else s.minSocStop
                            val arrive = tg - need
                            if (arrive < reserve) {
                                if (need > cap) break // weiter entfernte Knoten sind erst recht nicht erreichbar
                                continue
                            }
                            val t = lab.time + stopS + (tAt[v] - tAt[u])
                            val list = labels[v]
                            if (list.any { it.time <= t && it.soc >= arrive - 0.5 }) continue
                            list.removeAll { it.time >= t && it.soc <= arrive + 0.5 }
                            list += Label(v, t, arrive, lab, tg)
                        }
                    }
                }
            }
            return labels[last].minByOrNull { it.time }
        }
        val goal = search(CAP) ?: search(CAP_HARD)
            ?: return simple.copy(feasible = false, reason = "Mit den Ladern entlang der Route ist das Ziel nicht erreichbar. Lade-Reserve oder Mindestleistung in den Einstellungen prüfen.")
        // Weg rückwärts auslesen: (Knoten, Ladeziel)
        val path = mutableListOf<Pair<Int, Double>>()
        var cur: Label? = goal
        while (cur?.parent != null) {
            val p = cur.parent!!
            if (p.node != 0) path += p.node to cur.chargedTo
            cur = p
        }
        path.reverse()
        if (path.isEmpty()) return simple

        // --- Route über die gewählten Lader (und eigene Zwischenziele) neu berechnen ---
        PlanProgress.set("Berechne Route über ${path.size} Ladestopp" + (if (path.size > 1) "s" else "") + " …")
        data class V(val pos: LatLon, val along: Double, val hit: ChargerHit?)
        val vias = (path.map { (n, _) -> V(nodes[n].hit!!.pos, nodes[n].along, nodes[n].hit) } +
            userVias.map { v -> V(v.place.pos, TomTom.locateOnRoute(base, v.place.pos).first, null) }).sortedBy { it.along }
        val routed0 = runCatching { routeVia(vias.map { it.pos }) }.getOrNull()
            ?: return simple.copy(feasible = false, reason = "Route über die Ladestopps konnte nicht berechnet werden.")
        val routed = runCatching { Elevation.enrich(routed0) }.getOrDefault(routed0)
        PlanProgress.set("Rechne Ladezeiten nach Ladekurve …")
        val targets = vias.map { v -> path.firstOrNull { nodes[it.first].hit === v.hit }?.second ?: CAP }
        return annotate(routed, s, startSoc, w, vias.map { it.hit }, targets, compared = cands.size)
    }

    /** Ladestopps auf der echten Strecke eintragen: Ankunfts-Akku, Ladeziel, Ladezeit, Zeiten inkl. Laden */
    private fun annotate(
        r: Route,
        s: AppSettings,
        startSoc: Double,
        w: WeatherInfo?,
        viaHits: List<ChargerHit?>,
        plannedTargets: List<Double>,
        compared: Int = 0,
    ): Route {
        val prof = profile(r, s, w)
        val usable = s.usableKwh
        val end = r.cumM.lastOrNull() ?: 0.0
        // Positionen der Zwischenhalte = Schritte vom Typ „via“ in Reihenfolge
        val viaSteps = r.steps.indices.filter { r.steps[it].type == "via" }
        if (viaSteps.size != viaHits.size) return EvModel.estimateSimple(r, s, startSoc, w)
        val stopAlong = viaSteps.map { r.stepAlongM[it] }
        fun socDrop(a: Double, b: Double) = (prof.at(prof.e, r, b) - prof.at(prof.e, r, a)) / usable * 100
        val chargerIdx = viaHits.indices.filter { viaHits[it] != null }
        val stops = mutableListOf<ChargeStop>()
        val profile = mutableListOf(0.0 to startSoc)
        var soc = startSoc
        var pos = 0.0
        for ((k, a) in stopAlong.withIndex()) {
            soc -= socDrop(pos, a)
            pos = a
            val h = viaHits[k] ?: continue
            profile += a to soc
            // bis zum nächsten Lader bzw. Ziel reichen
            val nextCharger = chargerIdx.firstOrNull { it > k }
            val nextAlong = nextCharger?.let { stopAlong[it] } ?: end
            val reserve = if (nextCharger == null) s.minSocDest else s.minSocStop
            val need = socDrop(a, nextAlong)
            val planned = plannedTargets.getOrNull(k) ?: CAP
            // geplantes Ziel, aber mindestens so viel, wie die echte Strecke bis zum nächsten Halt braucht
            val tg = max(planned, need + reserve + 2).coerceIn(soc, 100.0)
            val cs = UserCharging.chargeSeconds(soc, tg, h.powerKw, usable)
            stops += ChargeStop(
                name = h.name, operator = h.operator, pos = h.pos, alongM = a, powerKw = h.powerKw,
                arriveSoc = soc, targetSoc = tg, chargeS = cs, uuid = null,
            )
            profile += a to tg
            soc = tg
        }
        soc -= socDrop(pos, end)
        profile += end to soc
        // Begründung je Stopp – wie bei ABRP nachvollziehbar, warum genau dieser Lader und dieses Ladeziel
        val hitByStop = viaHits.filterNotNull()
        val explained = stops.mapIndexed { k, st ->
            val h = hitByStop.getOrNull(k)
            val next = stops.getOrNull(k + 1)
            val nextArrive = next?.arriveSoc ?: soc
            val detourMin = ((h?.offsetM ?: 0.0) * 2 / DETOUR_MS / 60).roundToInt()
            val pref = h != null && s.preferOperators.any { p -> h.operator.contains(p, true) || h.name.contains(p, true) }
            val parts = listOfNotNull(
                "${st.powerKw.roundToInt()} kW",
                if (detourMin >= 1) "ca. $detourMin min Umweg" else "direkt an der Route",
                if (pref) "bevorzugter Anbieter" else null,
                "bis ${st.targetSoc.roundToInt()} % reicht ${if (next != null) "bis zum nächsten Stopp" else "bis zum Ziel"} (dort ${nextArrive.roundToInt()} %)",
            )
            st.copy(why = parts.joinToString(" · "))
        }
        stops.clear()
        stops += explained
        val chargeS = stops.sumOf { it.chargeS }
        // Schritte: Lader-Halte als „Laden“, Zeiten inkl. Ladezeit
        var stopNo = 0
        val steps = r.steps.mapIndexed { i, st ->
            if (st.type != "via") return@mapIndexed st
            val k = viaSteps.indexOf(i)
            val h = viaHits.getOrNull(k) ?: return@mapIndexed st
            val cs = stops.getOrNull(stopNo++) ?: return@mapIndexed st
            st.copy(
                type = "charge", mod = null, road = h.name,
                phrase = Phrases.build("charge", null, null),
                note = "Laden auf ${cs.targetSoc.roundToInt()} Prozent, etwa ${(cs.chargeS / 60).roundToInt()} Minuten.",
            )
        }
        val stepTime = DoubleArray(r.stepTimeS.size) { i ->
            r.stepTimeS[i] + stops.filter { it.alongM < r.stepAlongM[i] - 1 }.sumOf { it.chargeS }
        }
        val ok = soc >= s.minSocDest - 1 && stops.all { it.arriveSoc >= s.minSocStop - 2 }
        return r.copy(
            steps = steps,
            stepTimeS = stepTime,
            stops = stops,
            socProfile = profile,
            arrivalSoc = soc,
            chargeS = chargeS,
            durationS = r.driveS + chargeS,
            timesIncludeCharging = true,
            feasible = ok,
            reason = if (ok) null else "Die Akku-Reserve wird knapp – Ladestopps prüfen.",
            weather = w,
            note = if (stops.isNotEmpty()) {
                "Offline geplant: ${if (compared > 0) "$compared Ladeparks verglichen, " else ""}schnellste Gesamtzeit aus Fahren, Umwegen und Laden " +
                    "nach der Ladekurve; Akku nie unter ${s.minSocStop.roundToInt()} %, am Ziel mindestens ${s.minSocDest.roundToInt()} %."
            } else {
                r.note
            },
        )
    }

    /** für Tests */
    internal fun absDiff(a: Double, b: Double) = abs(a - b)
}
