package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Automatische Prüfungen der rechnenden Teile (laufen bei jedem Build).
 * Schlägt hier etwas fehl, bricht der Build mit einer klaren Meldung ab.
 */
class PlanningTest {

    /** Gerade Teststrecke nach Norden: 20 km, alle 100 m ein Punkt, 90 km/h, Abbiegung bei 5 km */
    private fun testRoute(): Route {
        val n = 201
        val pts = (0 until n).map { LatLon(51.0 + it * 0.000899, 7.4) }
        val cum = DoubleArray(n)
        for (i in 1 until n) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
        val end = cum.last()
        val v = 25.0
        fun step(type: String, at: Double, len: Double) =
            Step(type, if (type == "turn") "right" else null, null, "Teststraße", "", len, len / v, "rechts abbiegen")
        val steps = listOf(step("depart", 0.0, 5000.0), step("turn", 5000.0, end - 5000), step("arrive", end, 0.0))
        return Route(
            points = pts, cumM = cum,
            stepAlongM = doubleArrayOf(0.0, 5000.0, end), stepTimeS = doubleArrayOf(0.0, 5000 / v, end / v),
            distanceM = end, durationS = end / v, driveS = end / v, steps = steps, summary = "Test",
            socProfile = listOf(0.0 to 80.0, end to 70.0), arrivalSoc = 70.0,
        )
    }

    @Test fun ladezeitSteigtMitZielLadestand() {
        val a = UserCharging.chargeSeconds(10.0, 50.0, 100.0, 46.0)
        val b = UserCharging.chargeSeconds(10.0, 80.0, 100.0, 46.0)
        assertTrue("Ladezeit muss positiv sein", a > 0)
        assertTrue("Mehr Ladung muss länger dauern", b > a)
        assertEquals("Ohne Ladung keine Zeit", 0.0, UserCharging.chargeSeconds(50.0, 50.0, 100.0, 46.0), 0.001)
        assertTrue("10→80 % bei 100 kW sollte unter einer Stunde liegen", b < 3600)
    }

    @Test fun langsameStationLaedtLaenger() {
        val fast = UserCharging.chargeSeconds(10.0, 80.0, 150.0, 46.0)
        val slow = UserCharging.chargeSeconds(10.0, 80.0, 22.0, 46.0)
        assertTrue(slow > fast * 2)
    }

    @Test fun akkuverlaufWirdInterpoliert() {
        val r = testRoute()
        assertEquals(80.0, r.socAt(0.0)!!, 0.01)
        assertEquals(75.0, r.socAt(r.cumM.last() / 2)!!, 0.2)
        assertEquals(70.0, r.socAt(r.cumM.last())!!, 0.01)
    }

    @Test fun uhrzeitUndStreckePassenZusammen() {
        val r = testRoute()
        listOf(1000.0, 7500.0, 15000.0).forEach { m ->
            val t = WishPlanner.timeAt(r, m)
            val back = WishPlanner.alongAt(r, t)!!
            assertEquals("Position aus Zeit muss zur Zeit aus Position passen", m, back, 30.0)
        }
        assertNull("Nach der Ankunft gibt es keine Position", WishPlanner.alongAt(r, r.durationS + 600))
    }

    @Test fun fortschrittImTunnel() {
        val r = testRoute()
        val p = NavEngine.progressAt(r, 3000.0)
        assertNotNull(p)
        assertEquals(3000.0, p!!.alongM, 60.0)
        assertEquals("Bis zur Abbiegung bei 5 km", 2000.0, p.distToStepM, 80.0)
        assertTrue(p.remainingM > 0 && p.remainingM < r.distanceM)
    }

    @Test fun naechsterHaltLiegtVorne() {
        val r = testRoute().let { it.copy(stops = listOf(ChargeStop("IONITY Test", "IONITY", it.points[150], 15000.0, 150.0, 30.0, 80.0, 1200.0, null))) }
        val p = NavEngine.progressAt(r, 2000.0)!!
        val h = nextHalt(r, p, 0.0)
        assertNotNull(h)
        assertTrue(h!!.charge)
        assertEquals(13000.0, h.distM, 150.0)
        assertTrue("Ankunft am Stopp liegt in der Zukunft", h.etaS > 0)
    }

    @Test fun ordnungszahlenUndSpuren() {
        assertEquals("zweite", ordinalDe(2))
        assertEquals("dritte", ordinalDe(3))
        val ls = LaneSection(0, 1, listOf(Lane(listOf("STRAIGHT"), null), Lane(listOf("STRAIGHT"), null), Lane(listOf("RIGHT"), "RIGHT")))
        assertEquals("die rechte Spur", lanePhrase(ls))
        val two = LaneSection(0, 1, listOf(Lane(listOf("STRAIGHT"), null), Lane(listOf("RIGHT"), "RIGHT"), Lane(listOf("RIGHT"), "RIGHT")))
        assertEquals("eine der beiden rechten Spuren", lanePhrase(two))
    }

    @Test fun oeffnungszeiten() {
        val w = OpeningHours.parse("Mo-Fr 08:00-20:00; Sa 09:00-14:00; Su off")
        assertNotNull(w)
        assertEquals(1, w!![0].size)
        assertTrue(w[6].isEmpty())
        assertNotNull(OpeningHours.parse("24/7"))
    }

    @Test fun anbieterErkennen() {
        val h = ChargerHit("Tesla Supercharger Kamen", "", LatLon(51.5, 7.6), 250.0, 0.0, 0.0, null)
        assertTrue(operatorMatches(h, setOf("Tesla")))
        assertTrue(!operatorMatches(h, setOf("EnBW")))
    }

    @Test fun osmTempolimitsLesen() {
        assertEquals(70, OsmSpeed.parse("70"))
        assertEquals(50, OsmSpeed.parse("DE:urban"))
        assertEquals(100, OsmSpeed.parse("DE:rural"))
        assertEquals(SpeedLimits.NONE, OsmSpeed.parse("none"))
        assertEquals(48, OsmSpeed.parse("30 mph"))
        assertNull(OsmSpeed.parse("signals"))
    }

    @Test fun schluesselWirdGeschwaerzt() {
        val s = scrubSecrets("HTTP 403 https://api.tomtom.com/x?key=ABC123def&lat=1")
        assertTrue(!s.contains("ABC123def"))
        assertTrue(s.contains("key=***"))
    }
}
