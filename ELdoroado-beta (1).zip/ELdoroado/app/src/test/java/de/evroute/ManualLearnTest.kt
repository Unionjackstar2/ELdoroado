package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Test

class ManualLearnTest {
    @Test
    fun aufheizenNurBeiKaelte() {
        assertEquals(0.0, EvModel.warmupKwh(WeatherInfo(20.0, 0.0, false)), 1e-9)
        assertEquals(0.72, EvModel.warmupKwh(WeatherInfo(0.0, 0.0, false)), 1e-9)
        assertEquals(1.2, EvModel.warmupKwh(WeatherInfo(-20.0, 0.0, false)), 1e-9)
    }
}
