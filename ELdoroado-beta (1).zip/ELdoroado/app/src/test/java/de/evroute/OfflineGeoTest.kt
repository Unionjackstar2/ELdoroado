package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Test

/** Die Normalisierung muss exakt zu norm() in build_geocoder.py passen */
class OfflineGeoTest {
    @Test
    fun normWieAufDemServer() {
        assertEquals("dusterstr", OfflineGeo.norm("Düsterstraße"))
        assertEquals("brackeler hellweg", OfflineGeo.norm("Brackeler Hellweg"))
        assertEquals("str des 17 juni", OfflineGeo.norm("Str. des 17. Juni"))
        assertEquals("muhlen str", OfflineGeo.norm("Mühlen-Strasse"))
        assertEquals("herdecke", OfflineGeo.norm("  HERDECKE "))
    }

    @Test
    fun sucheZerlegen() {
        val q = OfflineGeo.parse("Brackeler Hellweg 101 Dortmund")
        assertEquals(listOf("brackeler", "hellweg", "dortmund"), q.words)
        assertEquals("101", q.house)
        val r = OfflineGeo.parse("Hauptstr 12 a 58313 Herdecke")
        assertEquals("12a", r.house)
        assertEquals("58313", r.plz)
        assertEquals(listOf("hauptstr", "herdecke"), r.words)
        // Zahl am Anfang ist keine Hausnummer (z. B. „17. Juni“-Straßen)
        assertEquals(null, OfflineGeo.parse("17 juni").house)
    }
}
