package de.evroute

import android.app.DownloadManager
import android.content.Context
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.StatFs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.text.Normalizer
import java.util.Locale
import java.util.zip.GZIPInputStream
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.ln

/**
 * Offline-Adressverzeichnis (Orte, Straßen, Hausnummern) vom eigenen Server, gebaut mit build_geocoder.py.
 * Download per Downloadmanager (nur WLAN), danach Entpacken und Prüfen; die Suche läuft komplett auf dem Handy.
 */
object OfflineGeo {
    private const val SCHEMA = 1
    private const val DB_NAME = "geocoder_germany.sqlite"

    data class Remote(val version: String, val buildDate: String, val fileName: String, val sizeBytes: Long?, val rawBytes: Long?, val schema: Int)

    data class State(
        val installedVersion: String? = null,
        val installedBytes: Long = 0,
        val remote: Remote? = null,
        val checking: Boolean = false,
        val downloading: Boolean = false,
        val unpacking: Boolean = false,
        val bytes: Long = 0,
        val total: Long = 0,
        val waitingForWifi: Boolean = false,
        val error: String? = null,
    ) {
        val ready get() = installedVersion != null
        val updateAvailable get() = remote != null && remote.version != installedVersion && remote.schema == SCHEMA
    }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    private lateinit var dir: File
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var watchJob: Job? = null
    @Volatile private var db: SQLiteDatabase? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        prefs = ctx.getSharedPreferences("geodb", Context.MODE_PRIVATE)
        dir = (ctx.getExternalFilesDir("geocoder") ?: File(ctx.filesDir, "geocoder")).also { it.mkdirs() }
        refreshInstalled()
        if (prefs.getLong("dlId", -1L) >= 0) watch()
        if (System.currentTimeMillis() - prefs.getLong("checked", 0L) > 12 * 3600_000L) scope.launch { check() }
    }

    private fun dbFile() = File(dir, DB_NAME)

    fun ready(): Boolean = ::prefs.isInitialized && _state.value.ready && dbFile().exists()

    private fun refreshInstalled() {
        val f = dbFile()
        val ok = f.exists() && f.length() > 10_000_000 && prefs.getString("version", null) != null
        _state.update { it.copy(installedVersion = if (ok) prefs.getString("version", null) else null, installedBytes = if (ok) f.length() else 0) }
    }

    private fun auth(b: Request.Builder) = b.header(ValhallaEngine.authHeader().first, ValhallaEngine.authHeader().second)

    /** geocoder.json abrufen */
    suspend fun check(): Remote? {
        if (!ValhallaEngine.serverConfigured()) return null
        _state.update { it.copy(checking = true, error = null) }
        return try {
            val r = Http.call(auth(Request.Builder().url(ValhallaEngine.url("geocoder.json"))).build())
            if (r.code != 200) throw IOException("Adressverzeichnis auf dem Server nicht gefunden (Fehler ${r.code}).")
            val o = json.parseToJsonElement(r.body).jsonObject
            fun str(k: String) = (o[k] as? JsonPrimitive)?.content ?: ""
            val remote = Remote(
                version = str("version"), buildDate = str("build_date"),
                fileName = str("file_name").ifBlank { "geocoder_germany.sqlite.gz" },
                sizeBytes = str("size_bytes").toLongOrNull(), rawBytes = str("raw_bytes").toLongOrNull(),
                schema = str("schema").toIntOrNull() ?: 1,
            )
            prefs.edit().putLong("checked", System.currentTimeMillis()).apply()
            _state.update { it.copy(remote = remote, checking = false) }
            remote
        } catch (e: Exception) {
            _state.update { it.copy(checking = false, error = e.message) }
            null
        }
    }

    /** Download starten (nur WLAN); Platz für gepackte + entpackte Datei wird vorher geprüft */
    suspend fun startDownload() = withContext(Dispatchers.IO) {
        val remote = _state.value.remote ?: check() ?: return@withContext
        if (remote.schema != SCHEMA) {
            _state.update { it.copy(error = "Das Adressverzeichnis auf dem Server passt nicht zu dieser App-Version.") }
            return@withContext
        }
        val need = (remote.sizeBytes ?: 700_000_000L) + (remote.rawBytes ?: 1_600_000_000L) + 200_000_000L
        val free = runCatching { StatFs(dir.path).availableBytes }.getOrDefault(Long.MAX_VALUE)
        if (free < need) {
            _state.update { it.copy(error = "Zu wenig freier Speicher: nötig etwa ${ValhallaTiles.gb(need)}, frei ${ValhallaTiles.gb(free)}.") }
            return@withContext
        }
        val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        prefs.getLong("dlId", -1L).takeIf { it >= 0 }?.let { runCatching { dm.remove(it) } }
        File(dir, "download.gz").delete()
        val req = DownloadManager.Request(Uri.parse(ValhallaEngine.url(remote.fileName)))
            .addRequestHeader(ValhallaEngine.authHeader().first, ValhallaEngine.authHeader().second)
            .setTitle("ELdoroado Adressverzeichnis")
            .setDescription("Offline-Suche · ${remote.version}")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(app, "geocoder", "download.gz")
            .setAllowedOverMetered(false)
            .setAllowedOverRoaming(false)
        val id = dm.enqueue(req)
        prefs.edit().putLong("dlId", id).putString("dlVersion", remote.version).apply()
        _state.update { it.copy(downloading = true, bytes = 0, total = remote.sizeBytes ?: 0, error = null) }
        watch()
    }

    fun cancel() {
        val id = prefs.getLong("dlId", -1L)
        if (id >= 0) runCatching { (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id) }
        prefs.edit().remove("dlId").apply()
        watchJob?.cancel()
        _state.update { it.copy(downloading = false, unpacking = false, bytes = 0, total = 0, waitingForWifi = false) }
    }

    fun delete() {
        cancel()
        close()
        dbFile().delete()
        File(dir, "download.gz").delete()
        prefs.edit().remove("version").apply()
        refreshInstalled()
    }

    private fun watch() {
        watchJob?.cancel()
        watchJob = scope.launch {
            val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            while (isActive) {
                val id = prefs.getLong("dlId", -1L)
                if (id < 0) break
                val c = dm.query(DownloadManager.Query().setFilterById(id))
                if (c == null || !c.moveToFirst()) {
                    c?.close()
                    prefs.edit().remove("dlId").apply()
                    _state.update { it.copy(downloading = false) }
                    break
                }
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                c.close()
                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> { prefs.edit().remove("dlId").apply(); unpack(); break }
                    DownloadManager.STATUS_FAILED -> {
                        prefs.edit().remove("dlId").apply()
                        _state.update { it.copy(downloading = false, error = "Download fehlgeschlagen (Code $reason).") }
                        break
                    }
                    else -> _state.update {
                        it.copy(
                            downloading = true, bytes = done, total = if (total > 0) total else it.total,
                            waitingForWifi = status == DownloadManager.STATUS_PAUSED && reason == DownloadManager.PAUSED_QUEUED_FOR_WIFI,
                        )
                    }
                }
                delay(1000)
            }
        }
    }

    /** Gepackte Datei entpacken, prüfen und an die Stelle der alten setzen */
    private suspend fun unpack() = withContext(Dispatchers.IO) {
        val gz = File(dir, "download.gz")
        val tmp = File(dir, "$DB_NAME.tmp")
        val raw = _state.value.remote?.rawBytes ?: 0
        _state.update { it.copy(downloading = false, unpacking = true, bytes = 0, total = raw) }
        try {
            GZIPInputStream(gz.inputStream().buffered(1 shl 20), 1 shl 16).use { ins ->
                tmp.outputStream().buffered(1 shl 20).use { out ->
                    val buf = ByteArray(1 shl 20)
                    var sum = 0L
                    var lastShown = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        sum += n
                        if (sum - lastShown > 16_000_000) { lastShown = sum; _state.update { it.copy(bytes = sum) } }
                    }
                }
            }
            // Prüfen: Schema und Inhalt
            val ok = runCatching {
                SQLiteDatabase.openDatabase(tmp.path, null, SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS).use { d ->
                    val schema = d.rawQuery("SELECT v FROM meta WHERE k = 'schema'", null).use { c -> if (c.moveToFirst()) c.getString(0) else null }
                    val streets = d.rawQuery("SELECT COUNT(*) FROM streets", null).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }
                    schema == SCHEMA.toString() && streets > 1000
                }
            }.getOrDefault(false)
            if (!ok) throw IOException("Die heruntergeladene Datei ist beschädigt. Bitte erneut laden.")
            close()
            val target = dbFile()
            target.delete()
            if (!tmp.renameTo(target)) throw IOException("Adressverzeichnis konnte nicht übernommen werden.")
            gz.delete()
            prefs.edit().putString("version", prefs.getString("dlVersion", "")).apply()
            _state.update { it.copy(unpacking = false, bytes = 0, total = 0, error = null) }
            refreshInstalled()
        } catch (e: Exception) {
            tmp.delete()
            _state.update { it.copy(unpacking = false, error = e.message ?: "Entpacken fehlgeschlagen.") }
        }
    }

    private fun open(): SQLiteDatabase? {
        db?.let { return it }
        if (!ready()) return null
        return runCatching {
            SQLiteDatabase.openDatabase(dbFile().path, null, SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS)
        }.getOrNull()?.also { db = it }
    }

    private fun close() {
        runCatching { db?.close() }
        db = null
    }

    // ---------------- Suche ----------------

    private val STRASSE = Regex("strasse\\b")
    private val STR_DOT = Regex("\\bstr\\.")
    private val NON_ALNUM = Regex("[^a-z0-9]+")
    private val SPACES = Regex("\\s+")
    private val MARKS = Regex("\\p{M}+")
    private val HOUSE = Regex("^\\d{1,4}[a-z]?$")
    private val PLZ = Regex("^\\d{5}$")

    /** Gleiche Regeln wie norm() in build_geocoder.py – sonst findet die Suche nichts */
    fun norm(s: String): String {
        var t = s.lowercase(Locale.ROOT).replace("ß", "ss")
        t = Normalizer.normalize(t, Normalizer.Form.NFKD).replace(MARKS, "")
        t = STRASSE.replace(t, "str")
        t = STR_DOT.replace(t, "str ")
        t = NON_ALNUM.replace(t, " ")
        return SPACES.replace(t, " ").trim()
    }

    private fun normNum(s: String) = s.lowercase(Locale.ROOT).replace(" ", "")

    /** Suchtext zerlegen: Hausnummer („101“, „12a“, „12 a“), Postleitzahl, übrige Wörter */
    data class Query(val words: List<String>, val house: String?, val plz: String?)

    fun parse(q: String): Query {
        val t = norm(q).split(' ').filter { it.isNotBlank() }.toMutableList()
        var house: String? = null
        var plz: String? = null
        var i = 0
        while (i < t.size) {
            val w = t[i]
            when {
                PLZ.matches(w) && plz == null -> { plz = w; t.removeAt(i); continue }
                HOUSE.matches(w) && house == null && i > 0 -> {
                    // „12 a“ → „12a“
                    house = if (i + 1 < t.size && t[i + 1].length == 1 && t[i + 1][0].isLetter()) { val h = w + t[i + 1]; t.removeAt(i + 1); h } else w
                    t.removeAt(i)
                    continue
                }
            }
            i++
        }
        return Query(t, house, plz)
    }

    /**
     * FTS-Abfrage: jedes Wort als Wortanfang. Ein einzelnes „str“ (aus „Düster Straße“) wird weggelassen,
     * weil im Verzeichnis „Düsterstraße“ zu einem Wort „dusterstr“ wird – „duster*“ findet es trotzdem.
     */
    private fun ftsQuery(words: List<String>, plz: String?): String {
        val w = words.filter { it != "str" }.ifEmpty { words }
        return (w.map { "$it*" } + listOfNotNull(plz)).joinToString(" ")
    }

    /** Offline suchen: Orte, Straßen und Hausnummern. Leer, wenn kein Verzeichnis geladen ist. */
    suspend fun search(q: String, near: LatLon?, limit: Int = 8): List<Place> = withContext(Dispatchers.IO) {
        val d = open() ?: return@withContext emptyList()
        val p = parse(q)
        if (p.words.isEmpty() || p.words.all { it.length < 2 }) return@withContext emptyList()
        val match = ftsQuery(p.words, p.plz)
        val first = p.words.first()
        data class Hit(val place: Place, val rank: Double)
        val hits = ArrayList<Hit>()
        fun distKm(lat: Double, lon: Double) = near?.let { haversine(it, LatLon(lat, lon)) / 1000 } ?: 0.0

        // Orte (nur ohne Hausnummer)
        if (p.house == null) {
            runCatching {
                d.rawQuery(
                    "SELECT name, kind, lat, lon, pop FROM places WHERE id IN (SELECT docid FROM places_fts WHERE places_fts MATCH ? LIMIT 60)",
                    arrayOf(ftsQuery(p.words, null)),
                ).use { c ->
                    while (c.moveToNext()) {
                        val name = c.getString(0)
                        val kind = c.getInt(1)
                        val lat = c.getDouble(2)
                        val lon = c.getDouble(3)
                        val pop = c.getLong(4)
                        val n = norm(name)
                        var rank = ln(1 + distKm(lat, lon)) * 4 - ln(1.0 + pop) * 1.2 + kind * 0.8
                        if (n == p.words.joinToString(" ")) rank -= 12 else if (n.startsWith(first)) rank -= 4
                        val kindName = listOf("city", "town", "village", "suburb", "quarter", "hamlet", "neighbourhood", "isolated_dwelling").getOrElse(kind) { "place" }
                        hits += Hit(Place(name, LatLon(lat, lon), kind = "place=$kindName"), rank)
                    }
                }
            }
        }

        // Straßen
        val streets = ArrayList<Pair<Long, Hit>>()
        runCatching {
            d.rawQuery(
                "SELECT id, name, postcode, city, lat, lon, n FROM streets WHERE id IN (SELECT docid FROM streets_fts WHERE streets_fts MATCH ? LIMIT 300)",
                arrayOf(match),
            ).use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1)
                    val pc = c.getString(2) ?: ""
                    val city = c.getString(3) ?: ""
                    val lat = c.getDouble(4)
                    val lon = c.getDouble(5)
                    val houses = c.getLong(6)
                    val n = norm(name)
                    var rank = ln(1 + distKm(lat, lon)) * 4 - ln(1.0 + houses) * 0.6
                    if (n.startsWith(first)) rank -= 3
                    // Ort im Suchtext genannt? (z. B. „… Dortmund“) – dann deutlich bevorzugen
                    val nc = norm(city)
                    if (p.words.size > 1 && p.words.drop(1).any { w -> nc.startsWith(w) }) rank -= 6
                    val label = name + (if (pc.isNotBlank() || city.isNotBlank()) ", " + listOf(pc, city).filter { it.isNotBlank() }.joinToString(" ") else "")
                    streets += id to Hit(Place(label, LatLon(lat, lon), kind = "highway=street"), rank)
                }
            }
        }
        streets.sortBy { it.second.rank }

        // Hausnummer: in den besten Straßen nachschlagen (exakt, sonst die nächstliegende Nummer)
        if (p.house != null) {
            val want = normNum(p.house)
            val wantNum = want.takeWhile { it.isDigit() }.toIntOrNull()
            for ((id, h) in streets.take(limit)) {
                var best: Triple<String, Double, Double>? = null
                var bestDiff = Int.MAX_VALUE
                runCatching {
                    d.rawQuery("SELECT num, lat, lon FROM houses WHERE street = ?", arrayOf(id.toString())).use { c ->
                        while (c.moveToNext()) {
                            val num = c.getString(0)
                            val nn = normNum(num)
                            val diff = if (nn == want) -1 else {
                                val v = nn.takeWhile { it.isDigit() }.toIntOrNull()
                                if (v == null || wantNum == null) Int.MAX_VALUE - 1 else abs(v - wantNum)
                            }
                            if (diff < bestDiff) { bestDiff = diff; best = Triple(num, c.getInt(1) / 1e6, c.getInt(2) / 1e6) }
                        }
                    }
                }
                val b = best
                if (b != null) {
                    val street = h.place.name.substringBefore(",")
                    val rest = h.place.name.substringAfter(", ", "")
                    val exact = bestDiff == -1
                    hits += Hit(
                        Place("$street ${b.first}" + (if (rest.isNotBlank()) ", $rest" else ""), LatLon(b.second, b.third), kind = "addr"),
                        h.rank - (if (exact) 8 else 2),
                    )
                } else {
                    hits += h
                }
            }
        } else {
            streets.take(limit).forEach { hits += it.second }
        }
        hits.sortedBy { it.rank }.map { it.place }.distinctBy { it.name }.take(limit)
    }

    /** Adresse zu einem Punkt: nächstgelegene Hausnummer (bis 150 m), sonst null */
    suspend fun reverse(p: LatLon): String? = withContext(Dispatchers.IO) {
        val d = open() ?: return@withContext null
        val cy = floor(p.lat * 100).toInt()
        val cx = floor(p.lon * 100).toInt()
        val cells = (-1..1).flatMap { dy -> (-1..1).map { dx -> ((cy + dy) * 100000 + (cx + dx)).toString() } }
        var best: String? = null
        var bestD = 150.0
        runCatching {
            d.rawQuery(
                "SELECT h.num, h.lat, h.lon, s.name, s.postcode, s.city FROM houses h JOIN streets s ON s.id = h.street WHERE h.cell IN (${cells.joinToString(",") { "?" }})",
                cells.toTypedArray(),
            ).use { c ->
                while (c.moveToNext()) {
                    val q = LatLon(c.getInt(1) / 1e6, c.getInt(2) / 1e6)
                    val dist = haversine(p, q)
                    if (dist < bestD) {
                        bestD = dist
                        val pc = c.getString(4) ?: ""
                        val city = c.getString(5) ?: ""
                        best = "${c.getString(3)} ${c.getString(0)}" + (if (pc.isNotBlank() || city.isNotBlank()) ", " + listOf(pc, city).filter { it.isNotBlank() }.joinToString(" ") else "")
                    }
                }
            }
        }
        best
    }

    /** Lokale Treffer zuerst; Online-Treffer, die nicht schon (bis 80 m) dabei sind, dahinter */
    fun merge(local: List<Place>, online: List<Place>, limit: Int = 10): List<Place> =
        (local + online.filter { o -> local.none { l -> haversine(l.pos, o.pos) < 80 } }).take(limit)
}
