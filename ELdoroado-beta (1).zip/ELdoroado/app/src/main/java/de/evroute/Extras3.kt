package de.evroute

import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ======================= Tempo-Coach =======================

/** Ein Tipp des Tempo-Coachs */
data class CoachTip(
    val capKmh: Int,
    val title: String,   // „115 statt 130 km/h“
    val detail: String,  // „Ladestopp entfällt · nur +6 min“
    val warning: Boolean,
    val spoken: String,
)

/**
 * Rechnet während der Fahrt durch, ob eine niedrigere Höchstgeschwindigkeit
 * einen Ladestopp spart oder einen zu knappen Akku verhindert.
 * Rein lokal (gelernter Verbrauch + verbleibende Strecke), ohne TomTom-Anfrage.
 */
object TempoCoach {
    private val CAPS = listOf(130, 120, 110, 100, 90)

    internal data class Seg(val km: Double, val kmh: Double)

    /** Abschnitte der Route zwischen zwei Positionen, mit geplantem Tempo je Abbiegeschritt */
    internal fun segments(r: Route, from: Double, to: Double): List<Seg> {
        val out = mutableListOf<Seg>()
        for (i in r.steps.indices) {
            val a = r.stepAlongM[i]
            val b = if (i + 1 < r.steps.size) r.stepAlongM[i + 1] else r.cumM.last()
            val lo = max(a, from)
            val hi = min(b, to)
            if (hi <= lo) continue
            val st = r.steps[i]
            val kmh = if (st.durationS > 1 && st.distanceM > 1) st.distanceM / st.durationS * 3.6 else 80.0
            out += Seg((hi - lo) / 1000, kmh.coerceIn(10.0, 180.0))
        }
        return out
    }

    /** Energie (kWh) und Zeit (h) für Abschnitte bei Tempo-Obergrenze cap */
    internal fun cost(segs: List<Seg>, cap: Int?, s: AppSettings, w: WeatherInfo?): Pair<Double, Double> {
        var kwh = 0.0
        var h = 0.0
        val aux = EvModel.auxKw(w)
        segs.forEach { sg ->
            val v = if (cap != null) min(sg.kmh, cap.toDouble()) else sg.kmh
            val t = sg.km / v
            kwh += sg.km * EvModel.kwhPer100(v, s, w) / 100 + aux * t
            h += t
        }
        return kwh to h
    }

    fun evaluate(r: Route, along: Double, socNow: Double, s: AppSettings): CoachTip? {
        val w = r.weather
        val usable = s.usableKwh
        val nextStop = r.stops.firstOrNull { it.alongM > along + 2000 }
        val targetAlong = nextStop?.alongM ?: r.cumM.last()
        val segsA = segments(r, along, targetAlong)
        if (segsA.sumOf { it.km } < 15) return null
        val base = cost(segsA, null, s, w)
        // Plan-Akku am Ziel bzw. nächsten Stopp, korrigiert um die aktuelle Abweichung vom Plan
        val planNow = r.socAt(along) ?: socNow
        val planArrive = nextStop?.arriveSoc ?: r.arrivalSoc ?: return null
        val arriveBase = planArrive + (socNow - planNow)
        val maxPlanned = segsA.maxOf { it.kmh }

        // Nur noch ein Fall: Der Akku wird bis zum nächsten Ladestopp bzw. Ziel zu knapp → langsamer fahren anbieten
        // 2) Akku wird knapp?
        val minOk = if (nextStop != null) s.minSocStop else s.minSocDest
        if (arriveBase < minOk - 2) {
            for (cap in CAPS) {
                if (cap >= maxPlanned - 3) continue
                val a = cost(segsA, cap, s, w)
                val arriveA = arriveBase - (a.first - base.first) / usable * 100
                if (arriveA >= minOk) {
                    val extraMin = ((a.second - base.second) * 60).roundToInt()
                    val where = if (nextStop != null) "am Ladestopp" else "am Ziel"
                    return CoachTip(
                        cap, "Akku wird knapp: max. $cap km/h",
                        "Sonst ${fmtPct(arriveBase)} $where, so ${fmtPct(arriveA)} · +$extraMin min",
                        true,
                        "Achtung, der Akku wird knapp. Fahr höchstens $cap Kilometer pro Stunde, dann kommst du mit ${arriveA.roundToInt()} Prozent an.",
                    )
                }
            }
        }
        return null
    }
}

// ======================= Reichweiten-Blase =======================



// ======================= Letzter Akkustand vom OBD =======================

/** Merkt sich den letzten OBD-Akkustand mit Uhrzeit („zuletzt gesehen vor 22 min“) */
object LastSoc {
    private lateinit var prefs: android.content.SharedPreferences
    private val _state = MutableStateFlow<Pair<Double, Long>?>(null)
    val state: StateFlow<Pair<Double, Long>?> = _state.asStateFlow()
    private var lastSaved = 0L

    fun init(ctx: android.content.Context) {
        prefs = ctx.getSharedPreferences("lastsoc", android.content.Context.MODE_PRIVATE)
        val at = prefs.getLong("at", 0L)
        if (at > 0) _state.value = prefs.getFloat("soc", 0f).toDouble() to at
    }

    /** Neuer OBD-Wert: anzeigen, höchstens einmal pro Minute speichern und als „Akku jetzt“ übernehmen */
    fun note(soc: Double) {
        val now = System.currentTimeMillis()
        _state.value = soc to now
        if (now - lastSaved < 60_000) return
        lastSaved = now
        if (::prefs.isInitialized) prefs.edit().putFloat("soc", soc.toFloat()).putLong("at", now).apply()
        if (kotlin.math.abs(Settings.state.value.socStart - soc) >= 1.0) Settings.update { it.copy(socStart = soc.roundToInt().toDouble()) }
    }
}


// ======================= Planung mit Wünschen =======================

/** Zeit ↔ Strecke entlang einer Route (aus den Zeiten an den Manövern) */
object WishPlanner {
    fun timeAt(r: Route, along: Double): Double {
        var i = r.stepAlongM.indexOfLast { it <= along }.coerceAtLeast(0)
        if (i >= r.stepAlongM.lastIndex) i = (r.stepAlongM.size - 2).coerceAtLeast(0)
        val a = r.stepAlongM.getOrElse(i) { 0.0 }
        val b = r.stepAlongM.getOrElse(i + 1) { r.cumM.last() }
        val ta = r.stepTimeS.getOrElse(i) { 0.0 }
        val tb = r.stepTimeS.getOrElse(i + 1) { r.driveS }
        var t = ta + (tb - ta) * ((along - a) / (b - a).coerceAtLeast(1.0)).coerceIn(0.0, 1.0)
        if (!r.timesIncludeCharging) t += r.stops.filter { it.alongM <= along }.sumOf { it.chargeS }
        return t
    }

    /** Stelle der Route, an der man nach t Sekunden ist */
    fun alongAt(r: Route, t: Double): Double? {
        val end = r.cumM.last()
        if (t <= 0) return 0.0
        if (t > timeAt(r, end)) return null
        var lo = 0.0; var hi = end
        repeat(40) { val mid = (lo + hi) / 2; if (timeAt(r, mid) < t) lo = mid else hi = mid }
        return (lo + hi) / 2
    }

    /**
     * Ladestopps nur bei den gewünschten Anbietern: jeweils den am weitesten erreichbaren passenden Lader wählen.
     * Ergebnis: gewählte Lader und ggf. ein Hinweis, wo es keinen passenden gab.
     */
}
