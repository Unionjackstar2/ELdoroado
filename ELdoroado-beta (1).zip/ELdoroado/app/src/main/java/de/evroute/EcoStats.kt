package de.evroute

import androidx.compose.runtime.mutableIntStateOf
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/** Auswertungen über viele Fahrten: Zeiträume, Abzeichen, Serien, Bestwerte, Stammstrecken, CO₂ */
object EcoStats {
    enum class Period(val label: String) { DAY("Tag"), WEEK("Woche"), MONTH("Monat"), YEAR("Jahr") }

    data class Bucket(val label: String, val from: Long, val to: Long, val trips: List<TripSummary>) {
        val km: Double get() = trips.sumOf { it.km }
        val score: Double? get() = EcoStats.weighted(trips) { it.score.toDouble() }
        val per100: Double? get() {
            val withKwh = trips.filter { it.kwhUsed != null && it.km > 0.5 }
            val k = withKwh.sumOf { it.km }
            return if (k > 0) withKwh.sumOf { it.kwhUsed!! } / k * 100 else null
        }
    }

    /** nach Strecke gewichteter Durchschnitt */
    fun weighted(list: List<TripSummary>, value: (TripSummary) -> Double?): Double? {
        var sum = 0.0; var w = 0.0
        list.forEach { t -> value(t)?.let { v -> val k = t.km.coerceAtLeast(0.5); sum += v * k; w += k } }
        return if (w > 0) sum / w else null
    }

    private fun cal(t: Long) = Calendar.getInstance(Locale.GERMANY).apply { firstDayOfWeek = Calendar.MONDAY; minimalDaysInFirstWeek = 4; timeInMillis = t }

    /** Beginn des Zeitraums, in dem t liegt */
    fun startOf(p: Period, t: Long): Long = cal(t).apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        when (p) {
            Period.WEEK -> set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            Period.MONTH -> set(Calendar.DAY_OF_MONTH, 1)
            Period.YEAR -> set(Calendar.DAY_OF_YEAR, 1)
            else -> {}
        }
    }.timeInMillis

    private fun shift(p: Period, t: Long, n: Int): Long = cal(t).apply {
        when (p) {
            Period.DAY -> add(Calendar.DAY_OF_YEAR, n)
            Period.WEEK -> add(Calendar.WEEK_OF_YEAR, n)
            Period.MONTH -> add(Calendar.MONTH, n)
            Period.YEAR -> add(Calendar.YEAR, n)
        }
    }.timeInMillis

    /** die letzten [count] Zeiträume, ältester zuerst */
    fun buckets(all: List<TripSummary>, p: Period, count: Int): List<Bucket> {
        val now = startOf(p, System.currentTimeMillis())
        return (count - 1 downTo 0).map { i ->
            val from = shift(p, now, -i)
            val to = shift(p, from, 1)
            val fmt = when (p) {
                Period.DAY -> SimpleDateFormat("EE", Locale.GERMANY)
                Period.WEEK -> SimpleDateFormat("'KW'w", Locale.GERMANY)
                Period.MONTH -> SimpleDateFormat("MMM", Locale.GERMANY)
                Period.YEAR -> SimpleDateFormat("yyyy", Locale.GERMANY)
            }
            Bucket(fmt.format(Date(from)).trimEnd('.'), from, to, all.filter { it.start in from until to })
        }
    }

    // ----- Abzeichen -----
    data class Badge(val emoji: String, val name: String, val desc: String, val earned: Boolean, val progress: String? = null)

    fun badges(all: List<TripSummary>): List<Badge> {
        val totalKm = all.sumOf { it.km }
        val regenFull = all.count { (it.subAnticipation ?: 0) >= 100 }
        val noSpeeding = all.count { it.speedingShare != null && it.speedingShare <= 0.0 }
        return listOf(
            Badge("🌿", "Sparfuchs", "Eine Fahrt ab 10 km unter 12 kWh/100 km", all.any { it.km >= 10 && (it.per100 ?: 99.0) < 12 }),
            Badge("🔋", "Rekuperations-Profi", "10 Fahrten mit voller Vorausschau", regenFull >= 10, "${regenFull.coerceAtMost(10)}/10"),
            Badge("🎯", "Punktlandung", "Am Ziel genau mit dem geplanten Akku", all.any { it.socPlanEnd != null && it.socActualEnd != null && abs(it.socActualEnd - it.socPlanEnd) < 0.5 }),
            Badge("🛣️", "Langstrecke", "Über 300 km am Stück mit mindestens 85 Punkten", all.any { it.km >= 300 && it.score >= 85 }),
            Badge("🚦", "Regelkonform", "10 Fahrten ohne Tempoüberschreitung", noSpeeding >= 10, "${noSpeeding.coerceAtMost(10)}/10"),
            Badge("🏅", "100 km", "100 km mit ELdoroado gefahren", totalKm >= 100, "${totalKm.coerceAtMost(100.0).roundToInt()}/100"),
            Badge("🥈", "1.000 km", "1.000 km mit ELdoroado gefahren", totalKm >= 1000, "${totalKm.coerceAtMost(1000.0).roundToInt()}/1.000"),
            Badge("🥇", "10.000 km", "10.000 km mit ELdoroado gefahren", totalKm >= 10_000, "${totalKm.coerceAtMost(10_000.0).roundToInt()}/10.000"),
        )
    }

    /** Serie: Fahrten in Folge mit mindestens 85 Punkten (aktuell, Rekord) */
    fun streak(all: List<TripSummary>): Pair<Int, Int> {
        val sorted = all.sortedBy { it.start }
        var best = 0; var run = 0
        sorted.forEach { if (it.score >= 85) { run++; best = maxOf(best, run) } else run = 0 }
        return run to best
    }

    data class Route(val name: String, val count: Int, val avg: Int, val best: TripSummary, val recent: List<Int>)

    /** Stammstrecken: dasselbe Ziel mindestens 3-mal */
    fun routes(all: List<TripSummary>): List<Route> = all.groupBy { it.dest.substringBefore(",").trim() }
        .filter { it.value.size >= 3 && it.key.isNotBlank() }
        .map { (name, list) ->
            Route(name, list.size, (weighted(list) { it.score.toDouble() } ?: 0.0).roundToInt(), list.maxBy { it.score },
                list.sortedBy { it.start }.takeLast(8).map { it.score })
        }
        .sortedByDescending { it.count }
        .take(4)

    /** CO₂-Ersparnis gegenüber einem Benziner (Schätzung) in kg */
    fun co2SavedKg(list: List<TripSummary>): Double = list.sumOf { t ->
        val petrol = t.km / 100 * 6.5 * 2.37
        val kwh = t.kwhUsed ?: (t.km / 100 * 16.0)
        petrol - kwh * 0.38
    }

    fun focusHint(list: List<TripSummary>): String? {
        val subs = listOf(
            "Verbrauch" to weighted(list) { it.subConsumption?.toDouble() },
            "Gleichmäßigkeit" to weighted(list) { it.subSmooth?.toDouble() },
            "Tempo" to weighted(list) { it.subSpeed?.toDouble() },
            "Kurven" to weighted(list) { it.subCorner?.toDouble() },
            "Vorausschau" to weighted(list) { it.subAnticipation?.toDouble() },
        ).filter { it.second != null }
        val weakest = subs.minByOrNull { it.second!! } ?: return null
        if (weakest.second!! >= 95) return "Alles im grünen Bereich – stark gefahren!"
        return "Dein Fokus: ${weakest.first}. " + when (weakest.first) {
            "Verbrauch" -> "Sanfter beschleunigen und auf der Autobahn 10 km/h weniger sparen am meisten."
            "Gleichmäßigkeit" -> "Früher vom Strompedal gehen und sanfter anfahren."
            "Tempo" -> "Öfter knapp über dem Limit – ein, zwei km/h Puffer helfen."
            "Kurven" -> "Vor der Kurve abbremsen und in der Kurve gleichmäßig fahren."
            else -> "Früher vom Gas gehen und das Auto rekuperieren lassen."
        }
    }

    // ----- Teilen als Bild -----
    fun shareImage(ctx: Context, title: String, score: Int, lines: List<String>, badges: Int) {
        val w = 1080; val h = 1350
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bmp)
        val bg = Paint().apply { shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF0C204E.toInt(), 0xFF2A72EC.toInt(), Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        val font = runCatching { androidx.core.content.res.ResourcesCompat.getFont(ctx, R.font.noto_sans_700) }.getOrNull()
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; typeface = font; textAlign = Paint.Align.CENTER }
        text.textSize = 52f; c.drawText("ELdoroado · Eco-Score", w / 2f, 150f, text)
        text.textSize = 40f; text.alpha = 200; c.drawText(title, w / 2f, 215f, text); text.alpha = 255
        // Ring
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 42f; strokeCap = Paint.Cap.ROUND }
        val r = RectF(w / 2f - 230, 300f, w / 2f + 230, 760f)
        ring.color = 0x33FFFFFF; c.drawArc(r, 0f, 360f, false, ring)
        ring.color = when { score >= 80 -> 0xFF34D399.toInt(); score >= 60 -> 0xFFFBBF24.toInt(); else -> 0xFFF87171.toInt() }
        c.drawArc(r, -90f, score * 3.6f, false, ring)
        text.textSize = 190f; c.drawText("$score", w / 2f, 600f, text)
        text.textSize = 44f
        lines.forEachIndexed { i, l -> c.drawText(l, w / 2f, 900f + i * 70f, text) }
        if (badges > 0) { text.textSize = 40f; text.alpha = 220; c.drawText("🏅 $badges Abzeichen", w / 2f, 900f + lines.size * 70f + 40f, text) }
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, "eldoroado-eco.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        ctx.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                "Eco-Score teilen",
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}

// ======================= Wochenrückblick (Sonntag 19 Uhr) =======================

object WeeklyReview {
    private const val CHANNEL = "eco_review"

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(ctx, 7, Intent(ctx, WeeklyReviewReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        am.cancel(pi)
        return // Wochenrückblick entfernt (Eco-Score vereinfacht); ein früher geplanter Alarm ist oben gelöscht
        val next = Calendar.getInstance(Locale.GERMANY).apply {
            set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY); set(Calendar.HOUR_OF_DAY, 19); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.WEEK_OF_YEAR, 1)
        }.timeInMillis
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
    }

    fun post(ctx: Context) {
        val all = EcoStore.items.value
        val p = EcoStats.Period.WEEK
        val b = EcoStats.buckets(all, p, 2)
        val cur = b.last(); val prev = b.first()
        if (cur.trips.isEmpty()) return
        val s = cur.score?.roundToInt() ?: return
        val trend = prev.score?.let { val d = s - it.roundToInt(); if (d >= 0) " (+$d)" else " ($d)" } ?: ""
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Wochenrückblick", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(ctx, 8, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("Deine Woche: Ø $s Punkte$trend")
            .setContentText("${cur.trips.size} Fahrten · ${cur.km.roundToInt()} km" + (cur.per100?.let { " · ${"%.1f".format(it)} kWh/100 km" } ?: ""))
            .setContentIntent(open).setAutoCancel(true).build()
        runCatching { nm.notify(77, n) }
    }
}

class WeeklyReviewReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        runCatching {
            Settings.init(ctx)
            EcoStore.init(ctx)
            WeeklyReview.post(ctx)
            WeeklyReview.schedule(ctx)
        }
    }
}

// ======================= Oberfläche =======================

@Composable
fun EcoPage(s: AppSettings, onAllTrips: () -> Unit = {}) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val all by EcoStore.items.collectAsState()
    var period by rememberSaveable { mutableStateOf(EcoStats.Period.WEEK) }
    val count = when (period) { EcoStats.Period.DAY -> 14; EcoStats.Period.WEEK -> 12; EcoStats.Period.MONTH -> 12; EcoStats.Period.YEAR -> 5 }
    val buckets = remember(all, period) { EcoStats.buckets(all, period, count) }
    val cur = buckets.last()
    val prev = buckets.getOrNull(buckets.size - 2)
    var open by remember { mutableStateOf<TripSummary?>(null) }

    Section("Zeitraum") {
        Segmented(EcoStats.Period.entries.map { it.label }, period.ordinal) { period = EcoStats.Period.entries[it] }
    }

    // ----- Kopf: Ring, Trend, Eckdaten -----
    Section(
        when (period) {
            EcoStats.Period.DAY -> "Heute"
            EcoStats.Period.WEEK -> "Diese Woche"
            EcoStats.Period.MONTH -> "Dieser Monat"
            EcoStats.Period.YEAR -> "Dieses Jahr"
        },
    ) {
        val sc = cur.score?.roundToInt()
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScoreRing(sc, 120)
            Spacer(Modifier.width(18.dp))
            Column {
                val prevScore = prev?.score
                if (sc != null && prevScore != null) {
                    val d = sc - prevScore.roundToInt()
                    Text(
                        (if (d >= 0) "▲ +$d" else "▼ $d") + " zum " + when (period) {
                            EcoStats.Period.DAY -> "Vortag"; EcoStats.Period.WEEK -> "Vorwoche"; EcoStats.Period.MONTH -> "Vormonat"; else -> "Vorjahr"
                        },
                        color = if (d >= 0) pal.green else pal.red, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
                Text("${cur.trips.size} Fahrten · ${cur.km.roundToInt()} km", color = pal.text, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
                cur.per100?.let { Text("Ø ${"%.1f".format(it)} kWh/100 km", color = pal.sub, fontSize = 14.sp) }
            }
        }
        if (sc == null) Text("In diesem Zeitraum gibt es noch keine ausgewerteten Fahrten.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    }

    // ----- Verlauf -----
    Section("Verlauf") {
        EcoChart(buckets)
        Text("Balken: Eco-Score · Linie: Verbrauch (kWh/100 km)", color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }

    // ----- Stärken und Schwächen -----
    val list = cur.trips.ifEmpty { all }
    Section("Stärken und Schwächen") {
        val subs = listOf(
            "Verbrauch" to EcoStats.weighted(list) { it.subConsumption?.toDouble() },
            "Gleichmäßigkeit" to EcoStats.weighted(list) { it.subSmooth?.toDouble() },
            "Tempo" to EcoStats.weighted(list) { it.subSpeed?.toDouble() },
            "Kurven" to EcoStats.weighted(list) { it.subCorner?.toDouble() },
            "Vorausschau" to EcoStats.weighted(list) { it.subAnticipation?.toDouble() },
        ).filter { it.second != null }
        if (subs.isEmpty()) Text("Noch keine Teilwerte – die gibt es ab den neueren Auswertungen.", color = pal.sub, fontSize = 13.sp)
        subs.forEach { (label, v) -> SubBar(label, v!!.roundToInt()) }
        EcoStats.focusHint(list)?.let { Text(it, color = pal.text, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)) }
    }

    // ----- Teilen -----
    TextButton(onClick = {
        val sc = cur.score?.roundToInt() ?: return@TextButton
        EcoStats.shareImage(
            ctx,
            when (period) { EcoStats.Period.DAY -> "Heute"; EcoStats.Period.WEEK -> "Diese Woche"; EcoStats.Period.MONTH -> "Dieser Monat"; else -> "Dieses Jahr" },
            sc,
            listOfNotNull("${cur.trips.size} Fahrten · ${cur.km.roundToInt()} km", cur.per100?.let { "Ø ${"%.1f".format(it)} kWh/100 km" }),
            0,
        )
    }) { Text("Als Bild teilen …") }

    // ----- die letzten Fahrten, alle weiteren auf einer eigenen Seite -----
    Section("Letzte Fahrten") {
        if (all.isEmpty()) Text("Noch keine navigierte Fahrt ausgewertet.", color = pal.sub, fontSize = 14.sp)
        all.sortedByDescending { it.start }.take(3).forEach { t -> TripRow(t, showDay = true) { open = t } }
        if (all.size > 3) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onAllTrips).padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Alle ${all.size} Fahrten", color = pal.blue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("›", color = pal.blue, fontSize = 20.sp)
            }
        }
    }
    open?.let { t ->
        AlertDialog(
            onDismissRequest = { open = null }, shape = RoundedCornerShape(28.dp),
            title = { Text(t.dest.substringBefore(","), fontWeight = FontWeight.Bold) },
            text = { Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState())) { SummaryView(t) } },
            confirmButton = { TextButton(onClick = { open = null }) { Text("Schließen") } },
            dismissButton = { TextButton(onClick = { EcoStore.remove(t.start); open = null }) { Text("Löschen", color = pal.red) } },
        )
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    val pal = LocalPal.current
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, color = pal.sub, fontSize = 12.sp)
        Text(value, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SubBar(label: String, value: Int) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = pal.sub, fontSize = 13.sp, modifier = Modifier.width(118.dp))
        Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.sub.copy(alpha = 0.18f))) {
            Box(Modifier.fillMaxWidth(value / 100f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(scoreColor(value)))
        }
        Text("$value", color = pal.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(34.dp).padding(start = 8.dp))
    }
}

/** Score als Ring mit Zahl in der Mitte */
@Composable
fun ScoreRing(score: Int?, sizeDp: Int) {
    val pal = LocalPal.current
    Box(Modifier.size(sizeDp.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val st = 11.dp.toPx()
            val r = (size.minDimension - st) / 2
            val tl = Offset(center.x - r, center.y - r)
            drawArc(pal.sub.copy(alpha = 0.18f), -90f, 360f, false, tl, Size(r * 2, r * 2), style = Stroke(st))
            if (score != null) drawArc(scoreColor(score), -90f, score * 3.6f, false, tl, Size(r * 2, r * 2), style = Stroke(st, cap = StrokeCap.Round))
        }
        Text(score?.toString() ?: "–", color = score?.let { scoreColor(it) } ?: pal.sub, fontSize = (sizeDp / 3.4f).sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** Balken (Score je Zeitraum) mit Verbrauchslinie */
@Composable
private fun EcoChart(buckets: List<EcoStats.Bucket>) {
    val pal = LocalPal.current
    val maxPer = (buckets.mapNotNull { it.per100 }.maxOrNull() ?: 20.0).coerceAtLeast(10.0) * 1.15
    Column {
        Canvas(Modifier.fillMaxWidth().height(150.dp)) {
            val n = buckets.size
            val slot = size.width / n
            val bw = slot * 0.56f
            // Hilfslinien bei 50 und 100
            listOf(50f, 100f).forEach { v ->
                val y = size.height * (1 - v / 100f)
                drawLine(pal.sub.copy(alpha = 0.15f), Offset(0f, y), Offset(size.width, y), strokeWidth = 1.dp.toPx())
            }
            buckets.forEachIndexed { i, b ->
                val x = i * slot + (slot - bw) / 2
                val sc = b.score
                if (sc != null) {
                    val h = size.height * (sc.toFloat() / 100f)
                    drawRoundRect(scoreColor(sc.roundToInt()), Offset(x, size.height - h), Size(bw, h), androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
                } else {
                    drawRoundRect(pal.sub.copy(alpha = 0.15f), Offset(x, size.height - 4.dp.toPx()), Size(bw, 4.dp.toPx()), androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()))
                }
            }
            // Verbrauchslinie
            val path = Path()
            var started = false
            buckets.forEachIndexed { i, b ->
                val v = b.per100 ?: return@forEachIndexed
                val x = i * slot + slot / 2
                val y = size.height * (1 - (v / maxPer).toFloat())
                if (!started) { path.moveTo(x, y); started = true } else path.lineTo(x, y)
                drawCircle(pal.blue, 3.dp.toPx(), Offset(x, y))
            }
            if (started) drawPath(path, pal.blue, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
            buckets.forEachIndexed { i, b ->
                Text(
                    if (buckets.size > 8 && i % 2 == 1) "" else b.label,
                    color = pal.sub, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1, modifier = Modifier.weight(1f),
                )
            }
        }
    }
}


/** Eine Fahrt als Zeile: Score, Ziel, Uhrzeit, Strecke, Verbrauch */
@Composable
private fun TripRow(t: TripSummary, showDay: Boolean = false, onClick: () -> Unit) {
    val pal = LocalPal.current
    val fmt = SimpleDateFormat(if (showDay) "EE, dd.MM. HH:mm" else "HH:mm", Locale.GERMANY)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${t.score}", color = scoreColor(t.score), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(44.dp))
        Column(Modifier.weight(1f)) {
            Text(t.dest.substringBefore(","), color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${fmt.format(Date(t.start))} · ${fmtKm(t.km * 1000)}" + (t.per100?.let { " · ${"%.1f".format(it)} kWh/100 km" } ?: ""), color = pal.sub, fontSize = 12.sp)
        }
        Text("›", color = pal.sub, fontSize = 20.sp)
    }
}

/** Alle ausgewerteten Fahrten nach Tagen (eigene Unterseite des Eco-Scores) */
@Composable
fun EcoTripsPage() {
    val pal = LocalPal.current
    val all by EcoStore.items.collectAsState()
    var open by remember { mutableStateOf<TripSummary?>(null) }
    var shown by remember { mutableIntStateOf(60) }
    Section("Fahrten nach Tagen") {
        if (all.isEmpty()) Text("Noch keine navigierte Fahrt ausgewertet.", color = pal.sub, fontSize = 14.sp)
        val dayFmt = SimpleDateFormat("EE, dd.MM.yyyy", Locale.GERMANY)
        val today = EcoStats.startOf(EcoStats.Period.DAY, System.currentTimeMillis())
        val sorted = all.sortedByDescending { it.start }
        sorted.take(shown).groupBy { EcoStats.startOf(EcoStats.Period.DAY, it.start) }.forEach { (day, trips) ->
            Text(
                when (day) { today -> "Heute"; today - 86_400_000L -> "Gestern"; else -> dayFmt.format(Date(day)) },
                color = pal.sub, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp, bottom = 2.dp),
            )
            trips.forEach { t -> TripRow(t) { open = t } }
        }
        if (sorted.size > shown) TextButton(onClick = { shown += 60 }) { Text("Weitere Fahrten laden") }
        if (all.isNotEmpty()) TextButton(onClick = { EcoStore.clear() }) { Text("Alle Auswertungen löschen", color = pal.red) }
    }
    open?.let { t ->
        AlertDialog(
            onDismissRequest = { open = null }, shape = RoundedCornerShape(28.dp),
            title = { Text(t.dest.substringBefore(","), fontWeight = FontWeight.Bold) },
            text = { Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState())) { SummaryView(t) } },
            confirmButton = { TextButton(onClick = { open = null }) { Text("Schließen") } },
            dismissButton = { TextButton(onClick = { EcoStore.remove(t.start); open = null }) { Text("Löschen", color = pal.red) } },
        )
    }
}
