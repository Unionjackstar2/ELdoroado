package de.evroute

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

// ---------------- HTTP ----------------

/** TomTom wird ausschließlich für Verkehrsdaten genutzt (Störungen, Verkehrslage-Kacheln) */
object TomTomPolicy {
    const val TRAFFIC_ONLY = true
    fun allowed(host: String, path: String) = !TRAFFIC_ONLY || host != "api.tomtom.com" || path.startsWith("/traffic/")
}

object Http {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    data class Resp(val code: Int, val body: String)

    suspend fun call(req: Request): Resp = withContext(Dispatchers.IO) {
        if (!TomTomPolicy.allowed(req.url.host, req.url.encodedPath)) throw IOException("TomTom ist nur noch für Verkehrsdaten freigegeben.")
        ApiCounter.classify(req.url.host, req.url.encodedPath)?.let { ApiCounter.count(it) }
        client.newCall(req).execute().use { r -> Resp(r.code, r.body?.string() ?: "") }
    }

    /** Liefert den Text auch bei 4xx (Fehlermeldung des Servers), wirft bei 5xx */
    suspend fun get(url: String): String {
        val r = call(Request.Builder().url(url).header("User-Agent", "ELdoroado/${BuildConfigLite.version}").build())
        if (r.code >= 500) throw IOException("Server-Fehler ${r.code}")
        return r.body
    }
}

val json = Json { ignoreUnknownKeys = true }

// kleine Helfer für JSON
private fun JsonObject.obj(k: String): JsonObject? = (this[k] as? JsonObject)
private fun JsonObject.arr(k: String): JsonArray = (this[k] as? JsonArray) ?: JsonArray(emptyList())
private fun JsonObject.num(k: String): Double? = (this[k] as? JsonPrimitive)?.doubleOrNull
private fun JsonObject.int(k: String): Int? = (this[k] as? JsonPrimitive)?.let { it.intOrNull ?: it.contentOrNull?.toIntOrNull() }
private fun JsonObject.str(k: String): String = (this[k] as? JsonPrimitive)?.contentOrNull ?: ""
private val JsonElement.d: Double get() = jsonPrimitive.doubleOrNull ?: 0.0

private fun cumulative(pts: List<LatLon>): DoubleArray {
    val cum = DoubleArray(pts.size)
    for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
    return cum
}

// ---------------- Routen-Auswertung (Valhalla antwortet im OSRM-Format) ----------------

object Routing {
    /** OSRM-Antwort (auch von Valhalla im OSRM-Format) in Routen übersetzen */
    fun parseResponse(body: String, precision: Int, source: String): List<Route> {
        val root = json.parseToJsonElement(body).jsonObject
        val code = root.str("code")
        if (code.isNotBlank() && !code.equals("Ok", true)) throw IOException(root.str("message").ifBlank { "Routing-Fehler ($code)" })
        return root.arr("routes").map { parse(it.jsonObject, precision, source) }
    }

    /** Google-Polyline mit wählbarer Genauigkeit (5 = OSRM, 6 = Valhalla) */
    fun decodePolyline(s: String, precision: Int): List<LatLon> {
        val f = Math.pow(10.0, precision.toDouble())
        val out = ArrayList<LatLon>(s.length / 4)
        var i = 0; var lat = 0L; var lon = 0L
        fun next(): Long {
            var shift = 0; var res = 0L; var b: Int
            do { b = s[i++].code - 63; res = res or ((b and 0x1f).toLong() shl shift); shift += 5 } while (b >= 0x20 && i < s.length)
            return if (res and 1L != 0L) (res shr 1).inv() else res shr 1
        }
        while (i < s.length) {
            lat += next(); if (i >= s.length) break
            lon += next()
            out += LatLon(lat / f, lon / f)
        }
        return out
    }

    private fun parse(r: JsonObject, precision: Int = 5, source: String = "OSRM"): Route {
        val g = r["geometry"]
        val pts = if (g is JsonPrimitive && g.isString) decodePolyline(g.content, precision)
        else r.obj("geometry")?.arr("coordinates")?.map { c ->
            val a = c.jsonArray
            LatLon(a[1].d, a[0].d)
        } ?: emptyList()
        val steps = mutableListOf<Step>()
        var summary = ""
        val legsArr = r.arr("legs")
        val angles = ArrayList<Double?>()
        val laneRaw = ArrayList<List<Lane>?>() // Spuren an der Kreuzung des jeweiligen Manövers
        legsArr.forEachIndexed { li, lg ->
            val leg = lg.jsonObject
            if (summary.isEmpty()) summary = leg.str("summary")
            leg.arr("steps").forEach { st ->
                val mm = st.jsonObject.obj("maneuver")
                val b0 = mm?.num("bearing_before"); val b1 = mm?.num("bearing_after")
                angles += if (b0 == null || b1 == null) null else ((b1 - b0 + 540) % 360) - 180
                laneRaw += osrmLanes(st.jsonObject, mm?.str("modifier"))
                var step = parseStep(st.jsonObject)
                // Zwischenstopps: „Ankunft“ mitten in der Route ist ein Zwischenziel, „Abfahrt“ danach ein Weiterfahren
                if (li < legsArr.size - 1 && step.type == "arrive") step = step.copy(type = "via", mod = null, phrase = Phrases.build("via", null, null))
                if (li > 0 && step.type == "depart") step = step.copy(type = "continue", mod = "straight", phrase = Phrases.build("continue", "straight", null))
                steps += step
            }
        }
        val cum = cumulative(pts)
        val osrmDist = r.num("distance") ?: 0.0
        val dur = r.num("duration") ?: 0.0
        val scale = if (osrmDist > 0 && cum.isNotEmpty()) cum.last() / osrmDist else 1.0
        val stepAlong = DoubleArray(steps.size)
        val stepTime = DoubleArray(steps.size)
        var acc = 0.0
        var t = 0.0
        steps.forEachIndexed { i, s ->
            stepAlong[i] = acc * scale
            stepTime[i] = t
            acc += s.distanceM
            t += s.durationS
        }
        // Manöver anhand von Winkel und Straßenart genauer einordnen (wie bei TomTom und ORS)
        val refined = steps.mapIndexed { i, st ->
            val nums = { x: Step -> Regex("\\b([ABLK])\\s?(\\d{1,4})\\b").findAll(x.road).map { it.groupValues[1] + it.groupValues[2] }.toList() }
            val ref = ManeuverRefiner.refine(
                st.type, st.mod,
                when {
                    st.mod?.contains("left") == true -> if (st.type == "fork") "KEEP_LEFT" else "TURN_LEFT"
                    st.mod?.contains("right") == true -> if (st.type == "fork") "KEEP_RIGHT" else "TURN_RIGHT"
                    else -> "STRAIGHT"
                },
                if (st.type == "fork") "BIFURCATION" else if (st.type.startsWith("roundabout") || st.type == "rotary") "ROUNDABOUT" else "REGULAR",
                angles.getOrNull(i), steps.getOrNull(i - 1)?.let(nums) ?: emptyList(), nums(st), st.towards,
            )
            if (ref.type == st.type && ref.mod == st.mod && ref.phrase == null) st
            else st.copy(type = ref.type, mod = ref.mod, phrase = ref.phrase ?: Phrases.build(ref.type, ref.mod, st.exit), phraseHasRoad = ref.phraseHasRoad)
        }
        // Spurabschnitte: die letzten 300 m vor dem Manöver
        fun idxAt(a: Double): Int {
            var i = cum.binarySearch(a)
            if (i < 0) i = (-i - 1).coerceAtMost(cum.lastIndex)
            return i.coerceIn(0, cum.lastIndex)
        }
        val lanes = laneRaw.mapIndexedNotNull { i, l ->
            if (l == null || l.size < 2 || i >= stepAlong.size) null
            else LaneSection(idxAt(stepAlong[i] - 300), idxAt(stepAlong[i]), l)
        }
        return Route(pts, cum, stepAlong, stepTime, osrmDist, dur, dur, refined, summary, source = source, laneSections = lanes)
    }

    /**
     * OSRM-Spuren in unser Format (wie früher TomTom): Richtungen je Spur von links nach rechts,
     * „follow“ = empfohlene Richtung auf den gültigen Spuren, null auf Spuren, die nicht passen.
     */
    private fun osrmLanes(st: JsonObject, modifier: String?): List<Lane>? {
        val first = st.arr("intersections").firstOrNull() as? JsonObject ?: return null
        val raw = first["lanes"] as? kotlinx.serialization.json.JsonArray ?: return null
        val out = raw.mapNotNull { e ->
            val o = e as? JsonObject ?: return@mapNotNull null
            val ind = o.arr("indications").mapNotNull { (it as? JsonPrimitive)?.contentOrNull }.ifEmpty { listOf("straight") }
            val dirs = ind.map { d -> if (d == "none") "STRAIGHT" else d.uppercase().replace(' ', '_') }
            val valid = (o["valid"] as? JsonPrimitive)?.content == "true"
            val want = modifier?.uppercase()?.replace(' ', '_')
            Lane(dirs, if (valid) (dirs.firstOrNull { it == want } ?: dirs.first()) else null)
        }
        // nur sinnvoll, wenn es gültige und ungültige Spuren gibt
        return if (out.size >= 2 && out.any { it.follow != null } && out.any { it.follow == null }) out else null
    }

    private fun parseStep(s: JsonObject): Step {
        val m = s.obj("maneuver") ?: JsonObject(emptyMap())
        val type = m.str("type")
        val mod = (m["modifier"] as? JsonPrimitive)?.contentOrNull
        val exit = m.int("exit")
        val ref = s.str("ref").split(';').firstOrNull()?.trim() ?: ""
        val road = listOf(ref, s.str("name")).filter { it.isNotBlank() }.distinct().joinToString(" · ")
        val dest = s.str("destinations")
        val exits = s.str("exits")
        val towards0 = if (dest.contains(": ")) dest.substringAfter(": ") else dest
        // Ausfahrtnummer bei Abfahrten mit ansagen („Ausfahrt 89, Schwerte“)
        val towards = if (type == "off ramp" && exits.isNotBlank()) listOf("Ausfahrt ${exits.split(';').first().trim()}", towards0).filter { it.isNotBlank() }.joinToString(" · ") else towards0
        return Step(type, mod, exit, road, towards, s.num("distance") ?: 0.0, s.num("duration") ?: 0.0, Phrases.build(type, mod, exit))
    }
}

/** Ordnungszahl als Wort, damit die Ansage „zweite“ statt „zwei“ sagt */
fun ordinalDe(n: Int): String = when (n) {
    1 -> "erste"; 2 -> "zweite"; 3 -> "dritte"; 4 -> "vierte"; 5 -> "fünfte"
    6 -> "sechste"; 7 -> "siebte"; 8 -> "achte"; 9 -> "neunte"; 10 -> "zehnte"
    else -> "$n."
}

/** Deutsche Manöver-Texte */
object Phrases {
    private fun dir(mod: String?) = when (mod) {
        "left" -> "links"
        "right" -> "rechts"
        "slight left" -> "leicht links"
        "slight right" -> "leicht rechts"
        "sharp left" -> "scharf links"
        "sharp right" -> "scharf rechts"
        else -> "geradeaus"
    }

    fun build(type: String, mod: String?, exit: Int?): String = when (type) {
        "depart" -> "losfahren"
        "arrive" -> "Ziel erreichen"
        "charge" -> "Ladestopp erreichen"
        "via" -> "Zwischenziel erreichen"
        "ferry" -> "die Fähre nehmen"
        "roundabout", "rotary", "roundabout turn" ->
            if (exit != null) "im Kreisverkehr die ${ordinalDe(exit)} Ausfahrt nehmen" else "in den Kreisverkehr fahren"
        "merge" -> if (mod == null || mod == "straight") "einfädeln" else "${dir(mod)} einfädeln"
        "on ramp" -> "die Auffahrt nehmen"
        "off ramp" -> if (mod == null || mod == "straight") "die Ausfahrt nehmen" else "${dir(mod)} die Ausfahrt nehmen"
        "fork" -> "an der Gabelung ${dir(mod)} halten"
        "end of road" -> "am Ende der Straße ${dir(mod)} abbiegen"
        "continue", "new name" -> when (mod) {
            null, "straight" -> "geradeaus weiterfahren"
            "uturn" -> "wenden"
            else -> "${dir(mod)} halten"
        }
        else -> when (mod) {
            null, "straight" -> "geradeaus weiterfahren"
            "uturn" -> "wenden"
            else -> "${dir(mod)} abbiegen"
        }
    }
}

// ---------------- Suche (Photon / OpenStreetMap) ----------------

object Geocode {
    private val cache = TtlCache<List<Place>>(15 * 60_000L)

    /** Offline-Verzeichnis zuerst, Photon (online) ergänzt – ohne Netz bleiben die Offline-Treffer */
    suspend fun search(q: String, near: LatLon?): List<Place> {
        val local = runCatching { OfflineGeo.search(q, near) }.getOrDefault(emptyList())
        val online = runCatching { searchOnline(q, near) }.getOrDefault(emptyList())
        return OfflineGeo.merge(local, online)
    }

    /** Nur Photon (online) */
    suspend fun searchOnline(q: String, near: LatLon?): List<Place> {
        // Standort auf ~1 km gerundet: dieselbe Suche in der Nähe nutzt das gespeicherte Ergebnis
        val ck = q.trim().lowercase() + "|" + (near?.let { "%.2f,%.2f".format(java.util.Locale.US, it.lat, it.lon) } ?: "")
        cache.get(ck)?.let { return it }
        return searchRaw(q, near).also { if (it.isNotEmpty()) cache.put(ck, it) }
    }

    private suspend fun searchRaw(q: String, near: LatLon?): List<Place> {
        val bias = if (near != null) "&lat=${near.lat.f6()}&lon=${near.lon.f6()}" else ""
        val url = "https://photon.komoot.io/api/?limit=7&lang=de$bias&q=" + URLEncoder.encode(q, "UTF-8")
        return json.parseToJsonElement(Http.get(url)).jsonObject.arr("features").mapNotNull { f ->
            val p = f.jsonObject.obj("properties") ?: return@mapNotNull null
            val c = f.jsonObject.obj("geometry")?.arr("coordinates") ?: return@mapNotNull null
            val street = listOf(p.str("street"), p.str("housenumber")).filter { it.isNotBlank() }.joinToString(" ")
            val first = p.str("name").ifBlank { street }
            val parts = listOf(first, if (first == street) "" else street, p.str("city"), p.str("country"))
                .filter { it.isNotBlank() }.distinct()
            val type = p.str("osm_type")
            val id = (p["osm_id"] as? JsonPrimitive)?.contentOrNull ?: ""
            Place(
                parts.joinToString(", "), LatLon(c[1].d, c[0].d),
                osm = if (type.isNotBlank() && id.isNotBlank()) "$type$id" else null,
                kind = listOf(p.str("osm_key"), p.str("osm_value")).filter { it.isNotBlank() }.joinToString("="),
            )
        }
    }
}

/** Adresse zu einem Kartenpunkt (für langes Drücken) */
object Reverse {
    suspend fun name(p: LatLon): String {
        // zuerst offline aus dem Adressverzeichnis (nächste Hausnummer bis 150 m)
        runCatching { OfflineGeo.reverse(p) }.getOrNull()?.let { return it }
        val url = "https://photon.komoot.io/reverse?lang=de&lat=${p.lat.f6()}&lon=${p.lon.f6()}"
        val f = runCatching { json.parseToJsonElement(Http.get(url)).jsonObject.arr("features").firstOrNull()?.jsonObject }.getOrNull()
        val pr = f?.obj("properties") ?: return "Markierter Ort"
        val street = listOf(pr.str("street"), pr.str("housenumber")).filter { it.isNotBlank() }.joinToString(" ")
        val first = pr.str("name").ifBlank { street }.ifBlank { "Markierter Ort" }
        return listOf(first, if (first == street) "" else street, pr.str("city")).filter { it.isNotBlank() }.distinct().joinToString(", ")
    }
}

// ---------------- Wetter entlang der Strecke (Open-Meteo) ----------------

object Weather {
    /** Temperatur, Gegenwind und Regen an 5 Punkten zur voraussichtlichen Durchfahrtszeit */
    suspend fun along(from: LatLon, to: LatLon): WeatherInfo {
        val n = 5
        val pts = (0 until n).map { lerp(from, to, it / (n - 1.0)) }
        val km = haversine(from, to) / 1000 * 1.25
        val lat = pts.joinToString(",") { String.format(Locale.US, "%.4f", it.lat) }
        val lon = pts.joinToString(",") { String.format(Locale.US, "%.4f", it.lon) }
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&hourly=temperature_2m,precipitation,wind_speed_10m,wind_direction_10m&forecast_days=3&timezone=GMT"
        val root = json.parseToJsonElement(Http.get(url))
        val list = (root as? JsonArray)?.map { it.jsonObject } ?: listOf(root.jsonObject)
        val now = ZonedDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:00"))
        val travel = bearing(from, to)
        var tSum = 0.0
        var hSum = 0.0
        var uSum = 0.0
        var vSum = 0.0
        var rainy = 0
        var count = 0
        list.forEachIndexed { i, o ->
            val h = o.obj("hourly") ?: return@forEachIndexed
            val times = h.arr("time").map { it.jsonPrimitive.content }
            if (times.isEmpty()) return@forEachIndexed
            val base = times.indexOf(now).coerceAtLeast(0)
            val eta = (km * i / (n - 1) / 85.0).roundToInt()
            val k = (base + eta).coerceAtMost(times.lastIndex)
            val temp = h.arr("temperature_2m").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: return@forEachIndexed
            val ws = h.arr("wind_speed_10m").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: 0.0
            val wd = h.arr("wind_direction_10m").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: 0.0
            val pr = h.arr("precipitation").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: 0.0
            tSum += temp
            hSum += ws * cos(Math.toRadians(wd - travel)) // Wind „aus“ Fahrtrichtung = Gegenwind
            uSum += ws * sin(Math.toRadians(wd))
            vSum += ws * cos(Math.toRadians(wd))
            if (pr > 0.3) rainy++
            count++
        }
        if (count == 0) throw IOException("Keine Wetterdaten")
        // Wind als Vektor mitteln, damit die Ladeplanung ihn je Abschnitt zur Fahrtrichtung rechnen kann
        val u = uSum / count
        val v = vSum / count
        val dir = (Math.toDegrees(kotlin.math.atan2(u, v)) + 360) % 360
        return WeatherInfo(tSum / count, hSum / count, rainy * 2 >= count, kotlin.math.sqrt(u * u + v * v), dir)
    }
}

// ---------------- Verbrauchsmodell (Grundlage ë-C4 2022, je Fahrzeug skaliert) ----------------

object EvModel {
    private val SPEEDS = intArrayOf(20, 40, 60, 80, 100, 120, 140)

    private fun styleFactor(s: AppSettings) = when (s.style) {
        0 -> 0.94
        2 -> 1.08
        else -> 1.0
    }

    /** Grundmodell ohne Wind, Regen, Fahrweise und Gelerntes (für das Lernen) */
    fun basePer100(v: Double, tempC: Double): Double {
        val base = (8.5 + 0.00082 * v * v) * Vehicles.current().eff
        val cold = 1.0 + 0.007 * max(0.0, 15.0 - tempC)
        return base * cold
    }

    /** kWh/100 km bei konstantem Tempo, inkl. Wind, Kälte, Regen, Fahrweise bzw. gelerntem Verhalten (ohne Heizung/Klima) */
    fun kwhPer100(v: Double, s: AppSettings, w: WeatherInfo?): Double {
        val air = (v + (w?.headwindKmh ?: 0.0)).coerceAtLeast(0.0)
        val temp = w?.tempC ?: 15.0
        val base = (8.5 + 0.00082 * air * air) * Vehicles.byId(s.vehicleId).eff
        val cold = 1.0 + 0.007 * max(0.0, 15.0 - temp)
        val rain = if (w?.rain == true) 1.06 else 1.0
        // Gelerntes ersetzt die Fahrweise, je nachdem wie viele Kilometer schon gelernt sind
        val (learned, conf) = if (s.useLearned) Learner.factor(v, temp) else (1.0 to 0.0)
        val behaviour = styleFactor(s) * (1 - conf) + learned * conf
        // gelernt aus Fahrten ohne OBD (Akkustand bei Ankunft eingetragen) – tritt zurück, sobald OBD-Daten da sind
        val manual = if (s.useLearned) 1 + (ManualLearn.factor(temp) - 1) * (1 - conf) else 1.0
        val ref = s.refConsumptionPct / 100.0
        val weight = 1.0 + 0.0002 * s.extraWeightKg
        return base * cold * rain * behaviour * ref * weight * manual
    }

    /**
     * Aufheizen bei Fahrtbeginn (kWh): Innenraum und Batterie brauchen in den ersten Minuten deutlich mehr als später.
     * Gilt nur für eine neue Fahrt, nicht für Neuberechnungen unterwegs (dann ist das Auto schon warm).
     */
    /** wird von der Navigation gesetzt: true während der Fahrt (Neuberechnungen ohne Aufheizen) */
    @Volatile var carWarm = false

    fun warmupKwh(w: WeatherInfo?): Double {
        if (carWarm) return 0.0
        val t = w?.tempC ?: 15.0
        return (0.06 * (12.0 - t)).coerceIn(0.0, 1.2) // z. B. 0 °C → 0,7 kWh, 10 °C → 0,1 kWh
    }

    /** Heizung bzw. Klimaanlage in kW */
    fun auxKw(w: WeatherInfo?): Double {
        val t = w?.tempC ?: 15.0
        return when {
            t < 0 -> 2.5
            t < 8 -> 1.8
            t < 15 -> 1.0
            t < 24 -> 0.4
            t < 30 -> 0.9
            else -> 1.4
        }
    }

    fun curveParam(s: AppSettings, w: WeatherInfo?): String =
        SPEEDS.joinToString(":") { v -> String.format(Locale.US, "%d,%.2f", v, kwhPer100(v.toDouble(), s, w)) }

    /** Ladekurve des gewählten Fahrzeugs (Startwerte) als (Akku kWh, max. kW); Gelerntes hat Vorrang */
    fun batteryCurve(usable: Double): List<Pair<Double, Double>> {
        val set = Settings.state.value
        val useLearned = set.useLearned
        val v = Vehicles.byId(set.vehicleId)
        val shape = when (v.curve) {
            // Ladekurve aus Open EV Data (gewähltes Fahrzeug)
            "evdata" -> EvDatabase.curve(v.id) ?: Vehicles.maxDc(set).let { p ->
                listOf(0.0 to 0.8, 0.10 to 1.0, 0.30 to 0.95, 0.50 to 0.8, 0.70 to 0.6, 0.80 to 0.45, 0.90 to 0.25, 1.0 to 0.08).map { it.first to it.second * p }
            }
            "ecmp1" -> listOf(0.0 to 80.0, 0.10 to 100.0, 0.30 to 85.0, 0.50 to 65.0, 0.70 to 48.0, 0.80 to 36.0, 0.90 to 22.0, 1.0 to 7.0)
            "ecmp2" -> listOf(0.0 to 85.0, 0.10 to 100.0, 0.30 to 95.0, 0.50 to 75.0, 0.70 to 55.0, 0.80 to 40.0, 0.90 to 22.0, 1.0 to 7.0)
            else -> {
                val p = Vehicles.maxDc(set)
                listOf(0.0 to 0.8, 0.10 to 1.0, 0.30 to 0.95, 0.50 to 0.8, 0.70 to 0.6, 0.80 to 0.45, 0.90 to 0.25, 1.0 to 0.08).map { it.first to it.second * p }
            }
        }
        return shape.map { (f, kw) ->
            val learned = if (useLearned) Learner.chargeAt(f * 100 - if (f >= 1.0) 1.0 else 0.0) else null
            f * usable to (learned ?: kw)
        }
    }

    /** Schätzung ohne Ladeplanung (Rückfall ohne TomTom) */
    fun estimateSimple(r: Route, s: AppSettings, startSoc: Double, w: WeatherInfo?): Route {
        val hours = max(r.driveS, 1.0) / 3600
        val avgKmh = (r.distanceM / 1000) / hours
        // Höhenmeter (nur wenn die Route sie liefert)
        val kwh = r.distanceM / 1000 * kwhPer100(avgKmh * 1.1, s, w) / 100 + auxKw(w) * hours + climbKwh(r) + warmupKwh(w)
        val arrival = startSoc - kwh / s.usableKwh * 100
        val ok = arrival >= s.minSocDest
        return r.copy(
            socProfile = listOf(0.0 to startSoc, r.cumM.lastOrNull().orZero() to arrival),
            arrivalSoc = arrival,
            feasible = ok,
            reason = if (ok) null else "Akku reicht nicht bis zum Ziel.",
            weather = w,
        )
    }

    /** Energie für Höhenmeter (kWh): bergauf mit Antriebsverlusten, bergab mit Rekuperation */
    fun climbKwh(r: Route): Double {
        if (r.ascentM <= 0 && r.descentM <= 0) return 0.0
        val mg = 1650.0 * 9.81
        return mg * r.ascentM / 3.6e6 / 0.88 - mg * r.descentM / 3.6e6 * 0.62
    }

    private fun Double?.orZero() = this ?: 0.0
}

// ---------------- TomTom ----------------

/** TomTom wird nur noch für Verkehr genutzt: Kachel-Adresse der Verkehrslage (Störungsmeldungen siehe Traffic.kt) */
object TomTom {
    private const val BASE = "https://api.tomtom.com"

    fun trafficTileUrl(key: String, dark: Boolean): String =
        "$BASE/traffic/map/4/tile/flow/${if (dark) "relative0-dark" else "relative0"}/{z}/{x}/{y}.png?key=$key&tileSize=256&thickness=8"

    /** Position entlang der Route und Abstand zu ihr */
    fun locateOnRoute(r: Route, p: LatLon): Pair<Double, Double> {
        val pts = r.points
        if (pts.size < 2) return 0.0 to Double.MAX_VALUE
        // grob über jeden 10. Punkt, dann fein in der Umgebung
        var coarse = 0
        var cd = Double.MAX_VALUE
        for (i in pts.indices step 10) { val d = haversine(pts[i], p); if (d < cd) { cd = d; coarse = i } }
        val from = (coarse - 12).coerceAtLeast(0)
        val to = (coarse + 12).coerceAtMost(pts.size - 2)
        var best = from
        var bd = Double.MAX_VALUE
        for (i in from..to) { val d = distToSeg(p, pts[i], pts[i + 1]); if (d < bd) { bd = d; best = i } }
        val t = projectT(p, pts[best], pts[best + 1])
        val along = r.cumM[best] + t * (r.cumM[best + 1] - r.cumM[best])
        return along to bd
    }
}
