package de.evroute

import okhttp3.Request
import java.net.URLEncoder

/** Prüft eingegebene Schlüssel mit einer einzigen, kleinen Anfrage (grüner Haken in Einstellungen/Ersteinrichtung) */
object KeyCheck {
    /** true = gültig, false = abgelehnt, null = keine Verbindung / unklar */
    suspend fun tomtom(key: String): Boolean? {
        if (key.isBlank()) return null
        val url = "https://api.tomtom.com/traffic/services/5/incidentDetails?bbox=7.40,51.40,7.50,51.50" +
            "&fields=" + URLEncoder.encode("{incidents{type}}", "UTF-8") + "&key=" + URLEncoder.encode(key.trim(), "UTF-8")
        val r = runCatching { Http.call(Request.Builder().url(url).build()) }.getOrNull() ?: return null
        return when (r.code) {
            200 -> true
            401, 403 -> false
            else -> null
        }
    }

    suspend fun ocm(key: String): Boolean? {
        if (key.isBlank()) return null
        val url = "https://api.openchargemap.io/v3/poi?output=json&compact=true&verbose=false&maxresults=1" +
            "&latitude=51.45&longitude=7.45&distance=5&distanceunit=km&key=" + URLEncoder.encode(key.trim(), "UTF-8")
        val req = Request.Builder().url(url).header("User-Agent", "ELdoroado/${BuildConfigLite.version}").header("X-API-Key", key.trim()).build()
        val r = runCatching { Http.call(req) }.getOrNull() ?: return null
        return when (r.code) {
            200 -> true
            401, 403 -> false
            else -> null
        }
    }
}
