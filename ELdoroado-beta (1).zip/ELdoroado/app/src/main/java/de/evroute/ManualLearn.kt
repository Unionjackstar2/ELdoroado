package de.evroute

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

/**
 * Lernen ohne OBD: Nach der Ankunft trägt man ein, was das Auto anzeigt. Aus „geplant verbraucht“ gegen
 * „tatsächlich verbraucht“ entsteht je Temperaturbereich ein Korrekturfaktor.
 * Die Anzeige im Auto rundet auf ganze Prozent – deshalb wiegt eine einzelne (vor allem kurze) Fahrt nur wenig.
 */
object ManualLearn {
    /** Temperaturbereiche: kalt (< 5 °C), kühl (5–15 °C), mild (≥ 15 °C) */
    private val BUCKETS = listOf("cold", "cool", "mild")

    data class Bucket(val factor: Double, val trips: Int)

    /** Was nach der Ankunft abgefragt wird (null = nichts zu fragen) */
    data class Pending(val startSoc: Double, val plannedArrival: Double, val km: Double, val tempC: Double)

    private lateinit var prefs: SharedPreferences
    private val _buckets = MutableStateFlow<Map<String, Bucket>>(emptyMap())
    val buckets: StateFlow<Map<String, Bucket>> = _buckets.asStateFlow()
    private val _pending = MutableStateFlow<Pending?>(null)
    val pending: StateFlow<Pending?> = _pending.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("manual_learn", Context.MODE_PRIVATE)
        _buckets.value = BUCKETS.associateWith { b ->
            Bucket(prefs.getFloat("f_$b", 1f).toDouble(), prefs.getInt("n_$b", 0))
        }
    }

    private fun bucketOf(t: Double) = when {
        t < 5 -> "cold"
        t < 15 -> "cool"
        else -> "mild"
    }

    /** Korrekturfaktor für den Verbrauch bei dieser Temperatur (1,0 = keine Korrektur) */
    fun factor(tempC: Double): Double = _buckets.value[bucketOf(tempC)]?.factor ?: 1.0

    /** Bei Ankunft ohne OBD: Abfrage vorbereiten (nur bei Fahrten, die genug Akku gekostet haben) */
    fun offer(startSoc: Double, plannedArrival: Double, km: Double, tempC: Double) {
        if (km < 5 || startSoc - plannedArrival < 2.0) { _pending.value = null; return }
        _pending.value = Pending(startSoc, plannedArrival, km, tempC)
        NavLog.ev("manual_offer", "startSoc" to NavLog.rd(startSoc, 1), "plannedArrival" to NavLog.rd(plannedArrival, 1), "km" to NavLog.rd(km, 1), "tempC" to NavLog.rd(tempC, 1))
    }

    fun skip() { _pending.value = null }

    /** Angezeigten Akkustand übernehmen und lernen */
    fun record(shownSoc: Double) {
        val p = _pending.value ?: return
        _pending.value = null
        val planned = p.startSoc - p.plannedArrival
        val actual = p.startSoc - shownSoc
        if (planned < 2.0 || actual < 0.5) return
        val ratio = (actual / planned).coerceIn(0.6, 1.6)
        // Gewicht: Rundung der Anzeige (±1 Punkt) wiegt bei kurzen Fahrten schwer → kleine Schritte;
        // je mehr Prozentpunkte die Fahrt gekostet hat, desto verlässlicher ist sie
        val w = (0.06 + 0.012 * planned).coerceAtMost(0.35)
        val b = bucketOf(p.tempC)
        val old = _buckets.value[b] ?: Bucket(1.0, 0)
        val nf = (old.factor * (1 - w) + ratio * w).coerceIn(0.75, 1.45)
        val nb = Bucket(nf, old.trips + 1)
        NavLog.ev(
            "manual_record", "shownSoc" to NavLog.rd(shownSoc, 1), "plannedDropPct" to NavLog.rd(planned, 1), "actualDropPct" to NavLog.rd(actual, 1),
            "ratio" to NavLog.rd(ratio, 4), "weight" to NavLog.rd(w, 3), "bucket" to b, "factorOld" to NavLog.rd(old.factor, 4), "factorNew" to NavLog.rd(nf, 4),
        )
        _buckets.value = _buckets.value + (b to nb)
        prefs.edit().putFloat("f_$b", nf.toFloat()).putInt("n_$b", nb.trips).apply()
    }

    fun reset() {
        prefs.edit().clear().apply()
        _buckets.value = BUCKETS.associateWith { Bucket(1.0, 0) }
    }

    /** Für die Anzeige: „kalt +8 % (4 Fahrten)“ */
    fun describe(): String = BUCKETS.mapNotNull { b ->
        val x = _buckets.value[b] ?: return@mapNotNull null
        if (x.trips == 0) return@mapNotNull null
        val name = when (b) { "cold" -> "unter 5 °C"; "cool" -> "5–15 °C"; else -> "ab 15 °C" }
        val pct = ((x.factor - 1) * 100).let { if (abs(it) < 0.5) "±0" else (if (it > 0) "+" else "") + "%.0f".format(it) }
        "$name: $pct % (${x.trips} Fahrt${if (x.trips == 1) "" else "en"})"
    }.joinToString(" · ")
}
