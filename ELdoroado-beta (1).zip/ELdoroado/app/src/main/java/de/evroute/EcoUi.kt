package de.evroute

import androidx.compose.material3.Surface
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

fun scoreColor(score: Int): Color = when {
    score >= 80 -> Color(0xFF1F9D55)
    score >= 60 -> Color(0xFFE0A100)
    else -> Color(0xFFE5332A)
}

/** Inhalt eines Resümees (für Ankunft und Fahrtenliste) */
@Composable
fun SummaryView(s: TripSummary) {
    val pal = LocalPal.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(scoreColor(s.score).copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Text("${s.score}", color = scoreColor(s.score), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Eco-Score", color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("${fmtKm(s.km * 1000)} · ${fmtDuration(s.durationS)} · Ø ${s.avgKmh.roundToInt()} km/h", color = pal.sub, fontSize = 13.sp)
            s.per100?.let { Text("Verbrauch ${"%.1f".format(it)} kWh/100 km", color = pal.sub, fontSize = 13.sp) }
        }
    }
    // Teilwerte als kleine Balken
    val subs = listOfNotNull(
        s.subConsumption?.let { "Verbrauch" to it }, s.subSmooth?.let { "Gleichmäßigkeit" to it },
        s.subSpeed?.let { "Tempo" to it }, s.subCorner?.let { "Kurven" to it }, s.subAnticipation?.let { "Vorausschau" to it },
    )
    if (subs.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        subs.forEach { (label, value) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = pal.sub, fontSize = 13.sp, modifier = Modifier.width(118.dp))
                Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.sub.copy(alpha = 0.18f))) {
                    Box(Modifier.fillMaxWidth(value / 100f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(scoreColor(value)))
                }
                Text("$value", color = pal.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(34.dp).padding(start = 8.dp))
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    if (s.socPlanEnd != null && s.socActualEnd != null) {
        val d = s.socActualEnd - s.socPlanEnd
        Line("Akku am Ziel", "${s.socActualEnd.roundToInt()} % statt geplant ${s.socPlanEnd.roundToInt()} % (${if (d >= 0) "+" else ""}${d.roundToInt()})", if (d >= -3) pal.green else pal.red)
    }
    s.stopDiffs.forEach { (n, d) -> Line("Ladestopp $n", "${if (d >= 0) "+" else ""}${d.roundToInt()} Prozentpunkte gegenüber Plan", if (d >= -3) pal.green else pal.red) }
    s.speedingShare?.let {
        val parts = listOfNotNull(
            s.speedingCity?.let { v -> "Stadt ${(v * 100).roundToInt()} %" },
            s.speedingRural?.let { v -> "Land ${(v * 100).roundToInt()} %" },
            s.speedingMotorway?.let { v -> "Autobahn ${(v * 100).roundToInt()} %" },
        ).joinToString(" · ")
        Line("Über dem Limit", "${(it * 100).roundToInt()} % der Zeit" + if (parts.isNotBlank()) " ($parts)" else "", if (it < 0.1) pal.green else pal.red)
    }
    Line("Anfahren / Bremsen", "${s.accelEvents}× kräftig beschleunigt · ${s.brakeEvents}× stark gebremst", if (s.accelEvents + s.brakeEvents <= 3) pal.green else pal.text)
    s.regenShare?.let { Line("Rekuperation", "${(it * 100).roundToInt()} % der Energie zurückgewonnen", pal.text) }
    Spacer(Modifier.height(6.dp))
    s.tips.forEach { Text("• $it", color = pal.text, fontSize = 14.sp, modifier = Modifier.padding(top = 3.dp)) }
}

@Composable
private fun Line(label: String, value: String, color: Color) {
    val pal = LocalPal.current
    Column(Modifier.padding(vertical = 3.dp)) {
        Text(label, color = pal.sub, fontSize = 12.sp)
        Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Nach der Ankunft: „Ziel erreicht“ plus Resümee */
@Composable
fun ArrivedWithSummary(dest: Place?, maxH: Dp, onDone: () -> Unit) {
    val pal = LocalPal.current
    val computing by EcoRecorder.computing.collectAsState()
    val last by EcoRecorder.last.collectAsState()
    GlassCard(Modifier.fillMaxWidth(), corner = 28.dp) {
        Column(Modifier.heightIn(max = maxH * 0.7f).verticalScroll(rememberScrollState()).padding(18.dp)) {
            Text("Ziel erreicht", color = pal.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            dest?.let { Text(it.name, color = pal.sub, fontSize = 15.sp, maxLines = 2) }
            Spacer(Modifier.height(12.dp))
            if (computing) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Werte die Fahrt aus …", color = pal.sub, fontSize = 14.sp)
                }
                Spacer(Modifier.height(12.dp))
            }
            ManualSocAsk()
            last?.let { SummaryView(it); Spacer(Modifier.height(12.dp)) }
            ElButton("Fertig", onClick = { ManualLearn.skip(); EcoRecorder.dismiss(); onDone() }, modifier = Modifier.fillMaxWidth(), height = 50.dp)
        }
    }
}

/** Liste der ausgewerteten Routen (Einstellungen → Fahrten & Lernen) */
@Composable
fun EcoSummariesSection() {
    val pal = LocalPal.current
    val list by EcoStore.items.collectAsState()
    var open by remember { mutableStateOf<TripSummary?>(null) }
    Section("Ausgewertete Routen (Eco-Score)") {
        if (list.isEmpty()) Text("Noch keine navigierte Fahrt ausgewertet.", color = pal.sub, fontSize = 14.sp)
        val fmt = SimpleDateFormat("dd.MM. HH:mm", Locale.GERMANY)
        list.take(30).forEach { s ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { open = s }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${s.score}", color = scoreColor(s.score), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(44.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.dest.substringBefore(","), color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text("${fmt.format(Date(s.start))} · ${fmtKm(s.km * 1000)}" + (s.per100?.let { " · ${"%.1f".format(it)} kWh/100 km" } ?: ""), color = pal.sub, fontSize = 12.sp)
                }
                Text("›", color = pal.sub, fontSize = 20.sp)
            }
        }
        if (list.isNotEmpty()) TextButton(onClick = { EcoStore.clear() }) { Text("Auswertungen löschen", color = pal.red) }
    }
    open?.let { s ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { open = null },
            shape = RoundedCornerShape(28.dp),
            title = { Text(s.dest.substringBefore(","), fontWeight = FontWeight.Bold) },
            text = { Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState())) { SummaryView(s) } },
            confirmButton = { TextButton(onClick = { open = null }) { Text("Schließen") } },
            dismissButton = { TextButton(onClick = { EcoStore.remove(s.start); open = null }) { Text("Löschen", color = pal.red) } },
        )
    }
}

/** Einstellungen: Resümee an/aus und Fahrsimulation */
@Composable
fun EcoAndSimulationSections(s: AppSettings, showEco: Boolean = true, showSim: Boolean = true, onStarted: () -> Unit) {
    val pal = LocalPal.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    if (showEco) Section("Fahrt-Resümee") {
        ToggleRow("Nach jeder navigierten Fahrt auswerten", s.ecoSummary) { v -> Settings.update { it.copy(ecoSummary = v) } }
        Text("Strecke, Ø-Tempo, Verbrauch, Akku Plan gegen Ist, Tempolimits, Anfahren und Bremsen – als Eco-Score von 0 bis 100. Nur bei Fahrten mit Navigation.", color = pal.sub, fontSize = 13.sp)
    }
    if (showSim) Section("Test: Fahrt simulieren") {
        val running by Simulator.running.collectAsState()
        var tunnel by remember { mutableStateOf(true) }
        var detour by remember { mutableStateOf(true) }
        val hasRoute = NavSession.state.collectAsState().value.route != null
        Text("Fährt die geplante Route virtuell ab, um Ansagen, Neuberechnung, Tunnel-Modus und Ankunft ohne Auto zu prüfen.", color = pal.sub, fontSize = 13.sp)
        ToggleRow("GPS-Ausfall wie im Tunnel (30 s)", tunnel) { tunnel = it }
        ToggleRow("Von der Route abweichen", detour) { detour = it }
        Row {
            TextButton(enabled = hasRoute && !running, onClick = { Simulator.start(ctx, 1.0, tunnel, detour); onStarted() }) { Text("Starten (echtes Tempo)") }
            TextButton(enabled = hasRoute && !running, onClick = { Simulator.start(ctx, 4.0, tunnel, detour); onStarted() }) { Text("Schnell ×4") }
        }
        if (running) TextButton(onClick = { Simulator.stop() }) { Text("Simulation beenden", color = pal.red) }
        if (!hasRoute) Text("Zuerst eine Route planen.", color = pal.sub, fontSize = 12.sp)
    }
}


/** Ohne OBD: angezeigten Akku eintragen – daraus lernt die App deinen Verbrauch */
@Composable
private fun ManualSocAsk() {
    val pal = LocalPal.current
    val p by ManualLearn.pending.collectAsState()
    val ask = p ?: return
    var v by remember(ask) { mutableStateOf(ask.plannedArrival.roundToInt().toFloat()) }
    var done by remember(ask) { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth().plastic(El.corner, elevation = 4.dp, tint = pal.blue.copy(alpha = 0.05f))) {
        Column(Modifier.padding(14.dp)) {
            Text("Wie viel Akku zeigt dein Auto?", color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("Geplant waren ${ask.plannedArrival.roundToInt()} %. Daraus lernt die App deinen Verbrauch – auch ohne OBD-Adapter.", color = pal.sub, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                Text("${v.roundToInt()} %", color = pal.text, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(80.dp))
                androidx.compose.material3.Slider(
                    value = v, onValueChange = { v = it.roundToInt().toFloat() },
                    valueRange = (ask.plannedArrival - 15).coerceAtLeast(0.0).toFloat()..(ask.plannedArrival + 15).coerceAtMost(100.0).toFloat(),
                    modifier = Modifier.weight(1f),
                )
            }
            Row {
                TextButton(onClick = { ManualLearn.skip() }) { Text("Überspringen", color = pal.sub) }
                Spacer(Modifier.weight(1f))
                ElButton("Übernehmen", onClick = { ManualLearn.record(v.toDouble()); done = true }, height = 42.dp, fontSize = 15.sp)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
}
