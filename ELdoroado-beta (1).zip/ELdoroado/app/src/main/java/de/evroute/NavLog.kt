package de.evroute

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max

/**
 * Navigations-Log (Entwickleroption): schreibt während einer Navigation alles in eine Textdatei (eine JSON-Zeile je Ereignis):
 * GPS, Tempo, Tempolimit, jede OBD2-Antwort, Planung samt Energiebilanz, Lernen, Fahrtauswertung.
 * Aus der Datei lässt sich nachrechnen, woher falsche kWh-Werte oder falsch gelernte Faktoren kommen.
 * Ohne eingeschaltete Option (und ohne laufende Aufzeichnung) tut jeder Aufruf hier nichts.
 */
object NavLog {
    private const val MAX_FILES = 12
    private const val MAX_BYTES = 150L * 1024 * 1024
    private const val TAIL_MS = 20_000L

    private class Session(val file: File, val startElapsed: Long) {
        val ch = Channel<String>(Channel.UNLIMITED)
        val bytes = AtomicLong(0)
        @Volatile var ending = false
        @Volatile var kwh0: Double? = null
        @Volatile var planSoc0: Double? = null
        @Volatile var lastPos: LatLon? = null
        @Volatile var cumM = 0.0
        @Volatile var samples = 0L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var dir: File
    private var ready = false
    @Volatile private var cur: Session? = null
    private val throttle = ConcurrentHashMap<String, Long>()
    @Volatile private var lastPlan: Map<String, Any?>? = null
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    /** true, solange eine Aufzeichnung läuft (auch in den letzten Sekunden nach dem Ende) */
    val active: Boolean get() = cur != null
    val currentFile: File? get() = cur?.file

    fun init(ctx: Context) {
        dir = File(ctx.filesDir, "navlog").also { it.mkdirs() }
        ready = true
    }

    fun refresh() { _version.value++ }

    // ---------------- Hilfen ----------------

    /** Runden; nicht endliche Werte werden zu null */
    fun rd(v: Double?, n: Int = 3): Double? {
        if (v == null || v.isNaN() || v.isInfinite()) return null
        val m = Math.pow(10.0, n.toDouble())
        return Math.round(v * m) / m
    }

    private fun esc(s: String, sb: StringBuilder) {
        sb.append('"')
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append(String.format(Locale.US, "\\u%04x", c.code))
                else -> sb.append(c)
            }
        }
        sb.append('"')
    }

    private fun put(v: Any?, sb: StringBuilder) {
        when (v) {
            null -> sb.append("null")
            is Boolean -> sb.append(if (v) "true" else "false")
            is Double -> if (v.isNaN() || v.isInfinite()) sb.append("null") else sb.append(v.toString())
            is Float -> if (v.isNaN() || v.isInfinite()) sb.append("null") else sb.append(v.toString())
            is Number -> sb.append(v.toString())
            is String -> esc(v, sb)
            is LatLon -> {
                sb.append('[').append(rd(v.lat, 6)).append(',').append(rd(v.lon, 6)).append(']')
            }
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                for ((k, x) in v) {
                    if (!first) sb.append(',')
                    first = false
                    esc(k.toString(), sb)
                    sb.append(':')
                    put(x, sb)
                }
                sb.append('}')
            }
            is DoubleArray -> {
                sb.append('[')
                v.forEachIndexed { i, x -> if (i > 0) sb.append(','); put(x, sb) }
                sb.append(']')
            }
            is Iterable<*> -> {
                sb.append('[')
                var first = true
                for (x in v) {
                    if (!first) sb.append(',')
                    first = false
                    put(x, sb)
                }
                sb.append(']')
            }
            else -> esc(v.toString(), sb)
        }
    }

    private fun write(s: Session, type: String, kv: List<Pair<String, Any?>>) {
        val sb = StringBuilder(256)
        val rel = (SystemClock.elapsedRealtime() - s.startElapsed) / 1000.0
        sb.append("{\"t\":").append(System.currentTimeMillis()).append(",\"r\":").append(rd(rel, 3)).append(",\"e\":")
        esc(type, sb)
        for ((k, v) in kv) {
            sb.append(',')
            esc(k, sb)
            sb.append(':')
            put(v, sb)
        }
        sb.append('}')
        val line = sb.toString()
        if (s.bytes.addAndGet(line.length + 1L) > MAX_BYTES) {
            s.ch.close() // Dateigröße erreicht: weitere Zeilen werden verworfen
            return
        }
        s.ch.trySend(line)
    }

    // ---------------- Ereignisse ----------------

    /** Ein Ereignis in die Aufzeichnung schreiben (tut nichts, wenn keine läuft) */
    fun ev(type: String, vararg kv: Pair<String, Any?>) {
        val s = cur ?: return
        write(s, type, kv.asList())
    }

    fun evMap(type: String, m: Map<String, Any?>) {
        val s = cur ?: return
        write(s, type, m.entries.map { it.key to it.value })
    }

    /** Wie [ev], aber höchstens alle [ms] Millisekunden je [key] (gegen Zeilenflut bei Dauerzuständen) */
    fun evEvery(key: String, ms: Long, type: String, vararg kv: Pair<String, Any?>) {
        val s = cur ?: return
        val now = SystemClock.elapsedRealtime()
        val last = throttle[key]
        if (last != null && now - last < ms) return
        throttle[key] = now
        write(s, type, kv.asList())
    }

    /** Eingaben der letzten Planung merken (auch ohne laufende Aufzeichnung); sie landen beim Start der Navigation im Log */
    fun notePlan(m: Map<String, Any?>) { lastPlan = m }

    // ---------------- Sitzung ----------------

    fun begin(reason: String) {
        if (!ready || !Settings.state.value.navLog) return
        closeNow()
        throttle.clear()
        runCatching {
            dir.mkdirs()
            prune()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val s = Session(File(dir, "navlog_$stamp.txt"), SystemClock.elapsedRealtime())
            cur = s
            startWriter(s)
            _version.value++
            header(reason)
        }.onFailure {
            cur = null
            CrashLog.note("Navigations-Log konnte nicht gestartet werden: ${it.message}")
        }
    }

    /** Navigation beendet: die Datei bleibt noch kurz offen, damit die Auswertung der Fahrt noch hineinkommt */
    fun end(reason: String) {
        val s = cur ?: return
        if (s.ending) return
        ev(
            "nav_end", "reason" to reason, "samples" to s.samples, "gpsKm" to rd(s.cumM / 1000, 3),
            "kwhFirst" to rd(s.kwh0, 2), "kwhNow" to rd(Obd.values.value["kwh"]?.value, 2), "bytes" to s.bytes.get(),
        )
        s.ending = true
        scope.launch {
            delay(TAIL_MS)
            if (cur === s) cur = null
            s.ch.close()
            _version.value++
        }
    }

    private fun closeNow() {
        val s = cur ?: return
        cur = null
        s.ch.close()
        _version.value++
    }

    private fun startWriter(s: Session) {
        scope.launch {
            runCatching {
                s.file.bufferedWriter(Charsets.UTF_8).use { w ->
                    while (true) {
                        val first = s.ch.receiveCatching().getOrNull() ?: break
                        w.write(first)
                        w.write("\n")
                        while (true) {
                            val next = s.ch.tryReceive().getOrNull() ?: break
                            w.write(next)
                            w.write("\n")
                        }
                        w.flush()
                    }
                }
            }
            s.ch.close()
        }
    }

    private fun prune() {
        val old = files()
        if (old.size >= MAX_FILES) old.drop(MAX_FILES - 1).forEach { runCatching { it.delete() } }
    }

    fun files(): List<File> {
        if (!ready) return emptyList()
        val list = dir.listFiles { f -> f.isFile && f.name.startsWith("navlog_") } ?: return emptyList()
        return list.sortedByDescending { it.lastModified() }
    }

    fun delete(f: File) {
        if (currentFile?.absolutePath == f.absolutePath) return
        runCatching { f.delete() }
        _version.value++
    }

    // ---------------- Kopfzeilen zu Beginn ----------------

    private fun header(reason: String) {
        val set = Settings.state.value
        val veh = Vehicles.byId(set.vehicleId)
        ev(
            "legend",
            "format" to "JSON-Zeilen; t = Uhrzeit (ms seit 1970), r = Sekunden seit Start",
            "s" to "Messpunkt je GPS-Fix: kmh (GPS), along/remM (m auf der Route), off (m neben der Route), lim (Tempolimit), planSoc (Plan-Akku %), " +
                "mdl100 (Modell kWh/100 km bei diesem Tempo), lf/lfConf (gelernter Faktor, Vertrauen), soc/socCal (OBD-Akkustand %), " +
                "kwh (OBD Energie im Akku), *Age (ms seit der letzten OBD-Antwort), usedKwh (kwh zu Beginn minus jetzt), gpsKm, planUsedPct",
            "obd" to "jede OBD-Antwort: k (Wert), hex (Rohdaten), v (umgerechnet), rtt (ms), raw nur bei Fehlern",
            "rec" to "Zustand der Fahrtaufzeichnung alle 2 s (was das Lernen sieht)",
            "learn" to "seg_close = Abschnitt abgeschlossen, learn_block = Gegenprobe gegen den Akkustand (trusted), learn_segment = Faktor angepasst, learn_skip = nicht gelernt, trip_finish = Fahrt gespeichert",
            "stops" to "charge_watch = Abstand zum Ladepunkt beim Anhalten, charge_arrive/charge_finish = Ladestopp, via_stop/via_stop_end = Zwischenstopp, route_chargers = Ladestationen auf der Route geladen",
            "eco_eval" to "Auswertung am Ende der Navigation mit Prüfwerten zur kWh-Berechnung",
            "plan" to "plan_inputs, nav_start, reroute, offer_accepted: Route mit Energiebilanz (energy) und Modellkurve (model)",
        )
        ev(
            "session", "reason" to reason, "app" to BuildConfigLite.version,
            "device" to (Build.MANUFACTURER + " " + Build.MODEL), "android" to Build.VERSION.SDK_INT,
            "clock" to SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US).format(Date()),
            "obdState" to Obd.conn.value.name, "obdName" to set.obdName,
        )
        ev(
            "settings",
            "usableKwh" to set.usableKwh, "socStart" to set.socStart, "minSocStop" to set.minSocStop, "minSocDest" to set.minSocDest,
            "style" to set.style, "learnEnabled" to set.learnEnabled, "useLearned" to set.useLearned,
            "refConsumptionPct" to set.refConsumptionPct, "maxSpeedKmh" to set.maxSpeedKmh, "extraWeightKg" to set.extraWeightKg,
            "socFloor" to set.socFloor, "corridorKm" to set.corridorKm, "searchMinKw" to set.searchMinKw,
            "avoidToll" to set.avoidToll, "avoidMotorway" to set.avoidMotorway, "avoidFerry" to set.avoidFerry,
            "obdSocSource" to set.obdSocSource, "obdVoltFactor" to set.obdVoltFactor, "obdCurrFactor" to set.obdCurrFactor,
            "obdCurrOffset" to set.obdCurrOffset, "obdCurrSigned" to set.obdCurrSigned, "obdPowerEnabled" to set.obdPowerEnabled,
            "obdReplan" to set.obdReplan, "ecoSummary" to set.ecoSummary,
        )
        ev(
            "vehicle", "id" to veh.id, "name" to veh.name, "eff" to veh.eff, "grossKwh" to veh.grossKwh, "usableKwh" to veh.usableKwh,
            "obd" to veh.obd.name,
        )
        ev("learner", "table" to learnerSnapshot(), "manual" to ManualLearn.buckets.value.map { (k, b) -> mapOf("bucket" to k, "factor" to rd(b.factor, 4), "trips" to b.trips) })
        ev(
            "history",
            "trips" to TripRecorder.trips.value.takeLast(20).map {
                mapOf("start" to it.start, "km" to rd(it.km, 2), "kwh" to rd(it.kwh, 2), "per100" to rd(it.per100, 2), "avgKmh" to rd(it.avgKmh, 1), "tempC" to rd(it.tempC, 1))
            },
            "eco" to EcoStore.items.value.takeLast(10).map {
                mapOf("start" to it.start, "dest" to it.dest, "km" to rd(it.km, 2), "kwhUsed" to rd(it.kwhUsed, 2), "expectedKwh" to rd(it.expectedKwh, 2), "per100" to rd(it.per100, 2))
            },
        )
        lastPlan?.let { evMap("plan_inputs", it) }
    }

    private fun learnerSnapshot(): Map<String, Any?> {
        val cells = ArrayList<Map<String, Any?>>()
        for (si in Learner.SPEED_LABELS.indices) {
            for (ti in Learner.TEMP_LABELS.indices) {
                val (ratio, km) = Learner.cell(si, ti)
                cells += mapOf("speed" to Learner.SPEED_LABELS[si], "temp" to Learner.TEMP_LABELS[ti], "ratio" to rd(ratio, 4), "km" to rd(km, 2))
            }
        }
        return mapOf(
            "cells" to cells, "totalKm" to rd(Learner.totalKm(), 1),
            "charge" to Learner.chargeBins().filter { it.third > 0 }.map { mapOf("soc" to it.first, "maxKw" to rd(it.second, 1), "n" to it.third) },
        )
    }

    /** Verbrauchsmodell bei ein paar Tempi: mit und ohne gelernten Faktor, dazu Grundmodell */
    private fun modelTable(w: WeatherInfo?): List<Map<String, Any?>> {
        val set = Settings.state.value
        val temp = w?.tempC ?: 15.0
        return listOf(30, 50, 80, 100, 120, 130).map { v ->
            val lf = Learner.factor(v.toDouble(), temp)
            mapOf(
                "kmh" to v,
                "withLearned" to rd(EvModel.kwhPer100(v.toDouble(), set, w), 2),
                "withoutLearned" to rd(EvModel.kwhPer100(v.toDouble(), set.copy(useLearned = false), w), 2),
                "base" to rd(EvModel.basePer100(v.toDouble(), temp), 2),
                "lf" to rd(lf.first, 4), "lfConf" to rd(lf.second, 3),
            )
        }
    }

    /** Eine geplante Route mit Energiebilanz ins Log schreiben (Start, Neuberechnung, angenommene Umfahrung) */
    fun routeInfo(type: String, r: Route, vararg extra: Pair<String, Any?>) {
        if (cur == null) return
        val set = Settings.state.value
        val m = LinkedHashMap<String, Any?>()
        for ((k, v) in extra) m[k] = v
        m["id"] = System.identityHashCode(r)
        m["tag"] = r.tag
        m["source"] = r.source
        m["distKm"] = rd(r.distanceM / 1000, 2)
        m["driveMin"] = rd(r.driveS / 60, 1)
        m["durationMin"] = rd(r.durationS / 60, 1)
        m["chargeMin"] = rd(r.chargeS / 60, 1)
        m["avgPlannedKmh"] = rd(r.distanceM / 1000 / (max(r.driveS, 1.0) / 3600), 1)
        m["ascentM"] = rd(r.ascentM, 0)
        m["descentM"] = rd(r.descentM, 0)
        m["arrivalSoc"] = rd(r.arrivalSoc, 1)
        m["feasible"] = r.feasible
        m["reason"] = r.reason
        m["trafficDelayMin"] = rd(r.trafficDelayS / 60, 1)
        m["carWarm"] = EvModel.carWarm
        r.weather?.let { w ->
            m["weather"] = mapOf("tempC" to rd(w.tempC, 1), "headwindKmh" to rd(w.headwindKmh, 1), "rain" to w.rain, "windKmh" to rd(w.windKmh, 1), "windFromDeg" to rd(w.windFromDeg, 0))
        }
        m["stops"] = r.stops.map {
            mapOf(
                "name" to it.name, "alongKm" to rd(it.alongM / 1000, 2), "powerKw" to rd(it.powerKw, 0), "arriveSoc" to rd(it.arriveSoc, 1),
                "targetSoc" to rd(it.targetSoc, 1), "chargeMin" to rd(it.chargeS / 60, 1), "why" to it.why,
            )
        }
        val sp = r.socProfile
        val stride = max(1, sp.size / 80)
        m["socProfile"] = sp.filterIndexed { i, _ -> i % stride == 0 || i == sp.lastIndex }.map { listOf(rd(it.first / 1000, 2), rd(it.second, 1)) }
        // Tempolimits der Route: Kilometer je Limit (0 = unbekannt)
        r.speedLimits?.let { lim ->
            val byLimit = java.util.TreeMap<Int, Double>()
            for (i in lim.indices) {
                if (i + 1 > r.cumM.lastIndex) break
                val d = r.cumM[i + 1] - r.cumM[i]
                byLimit[lim[i]] = (byLimit[lim[i]] ?: 0.0) + d
            }
            m["limitsKm"] = byLimit.entries.associate { it.key.toString() to rd(it.value / 1000, 2) }
        }
        runCatching {
            val p = LocalCharging.profile(r, set, r.weather)
            val total = p.e.lastOrNull() ?: 0.0
            val km = r.distanceM / 1000
            m["energy"] = mapOf(
                "totalKwh" to rd(total, 2), "rollKwh" to rd(p.rollKwh, 2), "auxKwh" to rd(p.auxKwh, 2),
                "climbKwh" to rd(p.climbKwh, 2), "warmupKwh" to rd(p.warmKwh, 2),
                "per100" to rd(if (km > 0.1) total / km * 100 else null, 2), "dropPct" to rd(total / set.usableKwh * 100, 1),
            )
        }
        m["model"] = modelTable(r.weather)
        evMap(type, m)
    }

    // ---------------- Laufende Messwerte ----------------

    /** Ein Messpunkt je GPS-Fix während der Navigation */
    fun sample(f: Fix, p: NavProgress, r: Route?, charging: Boolean, rerouting: Boolean) {
        val s = cur ?: return
        if (s.ending) return
        val set = Settings.state.value
        val now = System.currentTimeMillis()
        val vals = Obd.values.value
        fun ov(k: String): Double? = vals[k]?.value
        fun oa(k: String): Long? = vals[k]?.let { now - it.time }
        val kmh = f.speed * 3.6
        val prev = s.lastPos
        if (prev != null && f.accuracy < 35) {
            val d = haversine(prev, f.pos)
            if (d < 250) s.cumM += d
        }
        s.lastPos = f.pos
        val kwhNow = ov("kwh")
        if (s.kwh0 == null && kwhNow != null && (oa("kwh") ?: Long.MAX_VALUE) < 20_000) s.kwh0 = kwhNow
        val plan = r?.socAt(p.alongM)
        if (s.planSoc0 == null && plan != null) s.planSoc0 = plan
        val kwh0 = s.kwh0
        val soc0 = s.planSoc0
        val limit = if (r != null) runCatching { SpeedLimits.at(r, p.alongM).first }.getOrNull() else null
        val temp = r?.weather?.tempC ?: 15.0
        val v = kmh.coerceAtLeast(5.0)
        val lf = Learner.factor(v, temp)
        val fixAge = if (f.elapsedNs > 0) (SystemClock.elapsedRealtimeNanos() - f.elapsedNs) / 1_000_000 else now - f.time
        s.samples++
        write(
            s, "s",
            listOf(
                "lat" to rd(f.pos.lat, 6), "lon" to rd(f.pos.lon, 6), "kmh" to rd(kmh, 1),
                "brg" to f.bearing?.let { rd(it.toDouble(), 0) }, "acc" to rd(f.accuracy, 1), "alt" to rd(f.alt, 1), "fixAgeMs" to fixAge,
                "along" to rd(p.alongM, 1), "remM" to rd(p.remainingM, 0), "off" to rd(p.offRouteM, 1),
                "seg" to p.segIdx, "step" to p.stepIdx, "toStep" to rd(p.distToStepM, 0),
                "lim" to limit, "planSoc" to rd(plan, 2),
                "mdl100" to rd(EvModel.kwhPer100(v, set, r?.weather), 2), "lf" to rd(lf.first, 4), "lfConf" to rd(lf.second, 3),
                "soc" to rd(ov("soc"), 2), "socAge" to oa("soc"), "socCal" to rd(ov("socCal"), 2),
                "kwh" to rd(kwhNow, 2), "kwhAge" to oa("kwh"),
                "volt" to rd(ov("volt"), 1), "curr" to rd(ov("curr"), 1), "power" to rd(ov("power"), 2),
                "cap" to rd(ov("capacity"), 2), "soh" to rd(ov("soh"), 1),
                "cellMin" to rd(ov("cellMin"), 3), "cellMax" to rd(ov("cellMax"), 3),
                "battT" to rd(ov("battTemp"), 0), "ambObd" to rd(ov("ambient"), 0), "ambWeather" to rd(AmbientTemp.weatherC, 1),
                "obdKmh" to rd(ov("speed"), 1),
                "usedKwh" to (if (kwh0 != null && kwhNow != null) rd(kwh0 - kwhNow, 2) else null),
                "gpsKm" to rd(s.cumM / 1000, 3),
                "planUsedPct" to (if (soc0 != null && plan != null) rd(soc0 - plan, 2) else null),
                "chg" to charging, "rr" to rerouting,
            ),
        )
    }

    /** Eine OBD-Antwort (oder Fehlantwort) des Steuergeräts */
    fun obd(key: String, did: String, ecu: String, raw: String, hex: String?, value: Double?, ms: Long) {
        val s = cur ?: return
        write(
            s, "obd",
            listOf(
                "k" to key, "did" to did, "ecu" to ecu, "ok" to (hex != null), "hex" to hex, "v" to rd(value, 4), "rtt" to ms,
                "raw" to (if (hex == null) raw.replace("\r", " | ").replace("\n", "").take(160) else null),
            ),
        )
    }

    // ---------------- Herunterladen und Teilen ----------------

    /** Datei in den Download-Ordner des Handys kopieren; liefert eine Meldung für die Anzeige */
    fun save(ctx: Context, f: File): String {
        if (Build.VERSION.SDK_INT < 29) return "Auf diesem Android bitte „Teilen“ verwenden und die Datei dort speichern."
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, f.name)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ELdoroado")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                "Speichern fehlgeschlagen."
            } else {
                ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
                "Gespeichert unter Downloads/ELdoroado/${f.name}"
            }
        } catch (e: Exception) {
            "Speichern fehlgeschlagen: ${e.message}"
        }
    }

    fun share(ctx: Context, f: File) {
        runCatching {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, f.name)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(send, "Navigations-Log teilen").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { CrashLog.note("Navigations-Log teilen: ${it.message}") }
    }

    fun sizeText(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(Locale.GERMANY, "%.0f KB", bytes / 1024.0)
        else -> String.format(Locale.GERMANY, "%.1f MB", bytes / 1048576.0)
    }
}

/** Entwickleroptionen: Schalter und Liste der aufgezeichneten Navigationen */
@Composable
fun NavLogSection(s: AppSettings) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val ver by NavLog.version.collectAsState()
    val files = remember(ver) { NavLog.files() }
    var msg by remember { mutableStateOf<String?>(null) }
    Section("Navigations-Log") {
        Text(
            "Zeichnet die nächste Navigation vollständig auf: GPS, Tempo, Tempolimit, alle OBD2-Antworten, die Planung mit Energiebilanz, " +
                "das Lernen und die Auswertung am Ende. Gedacht zur Fehlersuche, z. B. bei falschen kWh nach der Fahrt.",
            color = pal.sub, fontSize = 13.sp,
        )
        ToggleRow("Navigation aufzeichnen", s.navLog) { v -> Settings.update { it.copy(navLog = v) } }
        Text(
            "Die Aufzeichnung beginnt, wenn du die Navigation startest, und endet mit „Beenden“ bzw. nach der Ankunft. " +
                "Die Datei enthält deine Fahrstrecke (GPS) – nur weitergeben, wenn das für dich in Ordnung ist.",
            color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
        )
        if (files.isEmpty()) {
            Text("Noch keine Aufzeichnung.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }
        files.forEach { f ->
            val running = NavLog.currentFile?.absolutePath == f.absolutePath
            Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                Text(f.name, color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(NavLog.sizeText(f.length()) + if (running) " · läuft gerade" else "", color = pal.sub, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { msg = NavLog.save(ctx, f) }) { Text("In Downloads") }
                    TextButton(onClick = { NavLog.share(ctx, f) }) { Text("Teilen") }
                    TextButton(onClick = { NavLog.delete(f) }, enabled = !running) { Text("Löschen", color = pal.red) }
                }
            }
        }
        if (files.isNotEmpty()) {
            TextButton(onClick = { NavLog.refresh() }) { Text("Größen aktualisieren") }
        }
        msg?.let { Text(it, color = pal.text, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
    }
}
