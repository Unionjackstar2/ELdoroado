package de.evroute

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * ELdoroado-Gestaltung „aus einem Guss“, abgeleitet vom Startbildschirm (Akku, Fahrzeugkarte, Favoriten).
 *
 * Farben mit fester Bedeutung: Blau = Bedienung · Grün = Energie/Laden · Bernstein = Warnung · Rot = Gefahr/Löschen.
 * Flächen: plastisch für Inhalte, Glas nur für Schwebendes direkt über der Karte (Abbiegehinweis, Kartenknöpfe).
 * Ecken: 12 klein · 20 Karte · 26 Pille · 28 großes Fenster. Abstände: 4 · 8 · 12 · 16 · 24.
 */
object El {
    val cornerS = 12.dp
    val corner = 20.dp
    val pill = 26.dp
    val cornerL = 28.dp
    val amber = Color(0xFFFFB300)
}

/**
 * Plastische Fläche: heller Verlauf von oben nach unten, weicher Schatten, feine Lichtkante oben.
 * [tint] färbt die Fläche leicht ein (z. B. ausgewählte Route), [elevation] 0 = ohne Schatten.
 */
@Composable
fun Modifier.plastic(corner: Dp = El.corner, elevation: Dp = 6.dp, tint: Color? = null): Modifier {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(corner)
    var top = if (pal.dark) Color(0xFF2B3038) else Color.White
    var bottom = if (pal.dark) Color(0xFF1F232A) else Color(0xFFF0F3F7)
    if (tint != null) {
        top = lerp(top, tint.copy(alpha = 1f), tint.alpha)
        bottom = lerp(bottom, tint.copy(alpha = 1f), tint.alpha)
    }
    val m = if (elevation > 0.dp) {
        this.shadow(elevation, shape, ambientColor = Color.Black.copy(alpha = 0.15f), spotColor = Color.Black.copy(alpha = 0.18f))
    } else {
        this
    }
    return m.clip(shape)
        .background(Brush.verticalGradient(listOf(top, bottom)))
        .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = if (pal.dark) 0.10f else 0.9f), Color.Transparent)), shape)
}

/** Plastische Karte (Standardfläche für Inhalte) */
@Composable
fun PlasticCard(modifier: Modifier = Modifier, corner: Dp = El.corner + 2.dp, content: @Composable () -> Unit) {
    Box(modifier.plastic(corner)) { content() }
}

/** Symbol in einer plastischen, runden Mulde mit farbigem Schimmer */
@Composable
fun PlasticIcon(icon: ImageVector, tint: Color, size: Dp, glow: Color? = null) {
    val pal = LocalPal.current
    val g = glow ?: tint
    Box(
        Modifier.size(size).shadow(3.dp, CircleShape).clip(CircleShape)
            .background(Brush.radialGradient(listOf(g.copy(alpha = if (pal.dark) 0.28f else 0.16f), if (pal.dark) Color(0xFF2B3038) else Color.White))),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.55f)) }
}

/**
 * Hauptknopf als plastische Pille: Blau (Bedienung) oder Grün (Laden). Weißer, fetter Text.
 */
@Composable
fun ElButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = LocalPal.current.blue,
    enabled: Boolean = true,
    height: Dp = 46.dp,
    fontSize: TextUnit = 17.sp,
    icon: ImageVector? = null,
) {
    val shape = RoundedCornerShape(height / 2)
    Box(
        modifier.height(height).alpha(if (enabled) 1f else 0.45f)
            .shadow(if (enabled) 4.dp else 0.dp, shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(lerp(color, Color.White, 0.22f), color)))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.45f), Color.Transparent)), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
            }
            Text(text, color = Color.White, fontSize = fontSize, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

/** Zweitknopf als plastische Pille in Flächenfarbe (z. B. „Als Stopp“) */
@Composable
fun ElButtonSoft(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, height: Dp = 46.dp, fontSize: TextUnit = 16.sp) {
    val pal = LocalPal.current
    Box(
        modifier.height(height).plastic(height / 2, elevation = 3.dp).clickable(onClick = onClick).padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = pal.blue, fontSize = fontSize, fontWeight = FontWeight.SemiBold, maxLines = 1) }
}
