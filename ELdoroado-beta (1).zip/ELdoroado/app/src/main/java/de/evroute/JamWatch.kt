package de.evroute

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Stau-Erkennung auf der Autobahn: länger als 10 s unter 20 km/h auf einem Autobahn-Abschnitt der Route
 * → Hinweis „Rettungsgasse bilden, am Stauende kurz Warnblinker“ mit Frage „Stau?“.
 * Die Antworten und die Dauer werden lokal gespeichert (für spätere Auswertungen).
 */
object JamWatch {
    data class Prompt(val road: String, val pos: LatLon, val since: Long, val shownAt: Long, val reported: Boolean)
    data class Event(val t: Long, val lat: Double, val lon: Double, val road: String, val answer: String, val durS: Long)

    private const val SLOW_MS = 20 / 3.6
    private const val FAST_MS = 40 / 3.6
    private val MOTORWAY = Regex("\\bA\\s?\\d{1,3}\\b")

    private lateinit var prefs: SharedPreferences
    private val _prompt = MutableStateFlow<Prompt?>(null)
    val prompt: StateFlow<Prompt?> = _prompt.asStateFlow()
    private val _events = MutableStateFlow<List<Event>>(emptyList())
    val events: StateFlow<List<Event>> = _events.asStateFlow()

    private var slowSince = 0L
    private var fastSince = 0L
    private var lastPrompt = 0L
    private var jam: Prompt? = null
    private var answer = "offen"

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("jams", Context.MODE_PRIVATE)
        _events.value = (prefs.getString("events", "") ?: "").lines().mapNotNull { l ->
            val p = l.split('|')
            if (p.size < 6) null else runCatching { Event(p[0].toLong(), p[1].toDouble(), p[2].toDouble(), p[3], p[4], p[5].toLong()) }.getOrNull()
        }
    }

    fun isMotorway(road: String) = MOTORWAY.containsMatchIn(road)

    /**
     * Bei jeder GPS-Position während der Navigation.
     * [offRouteM]: Abstand zur Route – wer auf einen Rastplatz abfährt, entfernt sich davon (dann kein Hinweis).
     * [reported]: an dieser Stelle ist ein Stau gemeldet (TomTom/Autobahn GmbH) – gilt dann als bestätigt.
     */
    fun onFix(speedMs: Double, motorway: Boolean, offRouteM: Double, reported: Boolean, pos: LatLon, road: String, say: (String) -> Unit) {
        val now = System.currentTimeMillis()
        if (!Settings.state.value.jamAssist) { if (jam != null) reset(); return }
        val onRoad = offRouteM < 20
        if (motorway && onRoad && speedMs < SLOW_MS) {
            fastSince = 0
            if (slowSince == 0L) slowSince = now
            if (jam == null && now - slowSince >= 10_000 && now - lastPrompt > 10 * 60_000) {
                val p = Prompt(MOTORWAY.find(road)?.value ?: road, pos, slowSince, now, reported)
                jam = p
                answer = if (reported) "gemeldet" else "offen"
                lastPrompt = now
                _prompt.value = p
                say("Stau. Bitte Rettungsgasse bilden.")
            }
        } else {
            slowSince = 0
            val j = jam ?: return
            // neben der Route langsam (Rastplatz, Abfahrt): kein Stau – Hinweis verwerfen
            if (!onRoad && now - j.shownAt < 60_000 && answer == "offen") { notJam(); return }
            if (speedMs > FAST_MS) {
                if (fastSince == 0L) fastSince = now
                // eine Minute zügig: Stau vorbei
                if (now - fastSince > 60_000) end(j, fastSince)
            } else {
                fastSince = 0
            }
        }
        // Hinweis nach 12 s von selbst ausblenden (der Stau wird weiter erfasst)
        _prompt.value?.let { if (now - it.shownAt > 12_000) _prompt.value = null }
    }

    /** „Kein Stau“ (Fehlalarm) */
    fun notJam() {
        val j = jam ?: run { _prompt.value = null; return }
        answer = "kein Stau"
        end(j, System.currentTimeMillis())
    }

    /** Navigation beendet: laufenden Stau abschließen */
    fun reset() {
        jam?.let { end(it, System.currentTimeMillis()) }
        slowSince = 0; fastSince = 0
        _prompt.value = null
    }

    private fun end(j: Prompt, until: Long) {
        jam = null
        fastSince = 0
        _prompt.value = null
        val ev = Event(j.since, j.pos.lat, j.pos.lon, j.road, answer, ((until - j.since) / 1000).coerceAtLeast(0))
        val list = (listOf(ev) + _events.value).take(300)
        _events.value = list
        if (::prefs.isInitialized) {
            prefs.edit().putString("events", list.joinToString("\n") { "${it.t}|${it.lat}|${it.lon}|${it.road}|${it.answer}|${it.durS}" }).apply()
        }
    }

    fun clear() {
        _events.value = emptyList()
        if (::prefs.isInitialized) prefs.edit().clear().apply()
    }
}
