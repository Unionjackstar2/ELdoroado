package de.evroute

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Eigene Ladestopps (z. B. eine selbst gewählte Tesla-Station):
 * Die Route wird an jeder dieser Stationen geteilt, jeder Teil von TomTom geplant,
 * das Laden an der Station selbst berechnet und alles wieder zu einer Route zusammengefügt.
 */
object UserCharging {
    private const val TARGET = 80.0 // höchstens bis hierhin an eigenen Stopps laden

    /** Ladezeit (s) von→bis Prozent mit der (ggf. gelernten) Ladekurve und der Stationsleistung */
    fun chargeSeconds(fromPct: Double, toPct: Double, stationKw: Double, usable: Double): Double {
        if (toPct <= fromPct) return 0.0
        val curve = EvModel.batteryCurve(usable).map { (kwh, kw) -> kwh / usable * 100 to kw }
        fun curveAt(soc: Double): Double {
            val i = curve.indexOfFirst { it.first >= soc }
            if (i <= 0) return curve.first().second
            val (a, pa) = curve[i - 1]
            val (b, pb) = curve[i]
            return pa + (pb - pa) * ((soc - a) / (b - a).coerceAtLeast(0.01))
        }
        val station = if (stationKw > 0) stationKw else 50.0
        var s = fromPct
        var sec = 0.0
        while (s < toPct) {
            val step = min(1.0, toPct - s)
            val p = (min(curveAt(s), station) * 0.92).coerceAtLeast(3.0)
            sec += usable * step / 100 / p * 3600
            s += step
        }
        return sec + 120 // An- und Abstecken
    }
}
