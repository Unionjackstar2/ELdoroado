package de.evroute

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import java.time.DayOfWeek
import java.time.LocalDateTime
import kotlin.math.roundToInt

/** Zusatzdaten eines Ortes aus OpenStreetMap */
data class PlaceDetails(
    val name: String,
    val category: String,
    val address: String,
    val phone: String?,
    val website: String?,
    val openingHours: String?,
    val extras: List<String>,
)

/** Abfrage bei Nominatim (offizieller Suchdienst von OpenStreetMap) */
object Nominatim {
    private const val BASE = "https://nominatim.openstreetmap.org"

    suspend fun details(p: Place): PlaceDetails? {
        val osm = p.osm
        if (osm == null && p.title.isNotBlank() && p.title != "Markierter Ort" && p.kind.isNotBlank()) {
            // Ort aus der Karte: Namen in einem kleinen Kasten um den Punkt suchen (findet den Laden, nicht das Haus daneben)
            val d = 0.0025
            val box = "${(p.pos.lon - d).f6()},${(p.pos.lat + d).f6()},${(p.pos.lon + d).f6()},${(p.pos.lat - d).f6()}"
            val url = "$BASE/search?q=" + java.net.URLEncoder.encode(p.title, "UTF-8") +
                "&viewbox=$box&bounded=1&format=jsonv2&extratags=1&addressdetails=1&limit=1&accept-language=de"
            val hit = runCatching { (json.parseToJsonElement(Http.get(url)) as? JsonArray)?.firstOrNull() as? JsonObject }.getOrNull()
            if (hit != null) return parse(hit, p)
        }
        val url = if (osm != null) {
            "$BASE/lookup?osm_ids=$osm&format=jsonv2&extratags=1&addressdetails=1&accept-language=de"
        } else {
            "$BASE/reverse?lat=${p.pos.lat.f6()}&lon=${p.pos.lon.f6()}&format=jsonv2&extratags=1&addressdetails=1&zoom=18&accept-language=de"
        }
        val root = json.parseToJsonElement(Http.get(url))
        val o = (root as? JsonArray)?.firstOrNull() as? JsonObject ?: root as? JsonObject ?: return null
        if (o.containsKey("error")) return null
        return parse(o, p)
    }

    private fun JsonObject.s(k: String): String = (this[k] as? JsonPrimitive)?.contentOrNull ?: ""

    private fun parse(o: JsonObject, p: Place): PlaceDetails {
        val ex = o["extratags"] as? JsonObject ?: JsonObject(emptyMap())
        val ad = o["address"] as? JsonObject ?: JsonObject(emptyMap())
        val street = listOf(ad.s("road").ifBlank { ad.s("pedestrian") }, ad.s("house_number")).filter { it.isNotBlank() }.joinToString(" ")
        val city = listOf(ad.s("postcode"), ad.s("city").ifBlank { ad.s("town") }.ifBlank { ad.s("village") }.ifBlank { ad.s("municipality") })
            .filter { it.isNotBlank() }.joinToString(" ")
        val address = listOf(street, city, if (ad.s("country_code") != "de") ad.s("country") else "").filter { it.isNotBlank() }.joinToString(", ")
        val kind = p.kind.ifBlank { "${o.s("category")}=${o.s("type")}" }
        val extras = buildList {
            ex.s("brand").takeIf { it.isNotBlank() && !o.s("name").contains(it, true) }?.let { add("Marke: $it") }
            ex.s("cuisine").takeIf { it.isNotBlank() }?.let { add("Küche: ${it.replace(';', ',').replace('_', ' ')}") }
            when (ex.s("wheelchair")) {
                "yes" -> add("Rollstuhlgerecht")
                "limited" -> add("Eingeschränkt rollstuhlgerecht")
            }
            ex.s("operator").takeIf { it.isNotBlank() && it != ex.s("brand") }?.let { add("Betreiber: $it") }
            ex.s("capacity").takeIf { it.isNotBlank() }?.let { add("Plätze: $it") }
            ex.s("fee").takeIf { it == "no" }?.let { add("kostenlos") }
        }
        return PlaceDetails(
            name = o.s("name").ifBlank { p.title },
            category = categoryLabel(kind),
            address = address.ifBlank { o.s("display_name") },
            phone = ex.s("phone").ifBlank { ex.s("contact:phone") }.ifBlank { null },
            website = ex.s("website").ifBlank { ex.s("contact:website") }.ifBlank { ex.s("url") }.ifBlank { null },
            openingHours = ex.s("opening_hours").ifBlank { null },
            extras = extras,
        )
    }

    private val LABELS = mapOf(
        "shop=supermarket" to "Supermarkt", "shop=bakery" to "Bäckerei", "shop=butcher" to "Metzgerei",
        "shop=convenience" to "Kiosk", "shop=doityourself" to "Baumarkt", "shop=hardware" to "Baumarkt",
        "shop=clothes" to "Bekleidung", "shop=shoes" to "Schuhe", "shop=electronics" to "Elektronik",
        "shop=chemist" to "Drogerie", "shop=furniture" to "Möbel", "shop=car" to "Autohaus", "shop=car_repair" to "Autowerkstatt",
        "shop=mall" to "Einkaufszentrum", "shop=department_store" to "Kaufhaus", "shop=garden_centre" to "Gartencenter",
        "shop=beverages" to "Getränkemarkt", "shop=kiosk" to "Kiosk", "shop=books" to "Buchhandlung",
        "amenity=restaurant" to "Restaurant", "amenity=cafe" to "Café", "amenity=fast_food" to "Imbiss",
        "amenity=bar" to "Bar", "amenity=pub" to "Kneipe", "amenity=fuel" to "Tankstelle",
        "amenity=charging_station" to "Ladestation", "amenity=pharmacy" to "Apotheke", "amenity=hospital" to "Krankenhaus",
        "amenity=doctors" to "Arztpraxis", "amenity=dentist" to "Zahnarzt", "amenity=parking" to "Parkplatz",
        "amenity=bank" to "Bank", "amenity=atm" to "Geldautomat", "amenity=post_office" to "Post",
        "amenity=school" to "Schule", "amenity=kindergarten" to "Kindergarten", "amenity=townhall" to "Rathaus",
        "amenity=police" to "Polizei", "amenity=place_of_worship" to "Kirche / Gotteshaus", "amenity=cinema" to "Kino",
        "amenity=theatre" to "Theater", "amenity=library" to "Bibliothek", "amenity=car_wash" to "Waschanlage",
        "tourism=hotel" to "Hotel", "tourism=guest_house" to "Pension", "tourism=museum" to "Museum",
        "tourism=attraction" to "Sehenswürdigkeit", "tourism=viewpoint" to "Aussichtspunkt", "tourism=camp_site" to "Campingplatz",
        "leisure=sports_centre" to "Sportzentrum", "leisure=park" to "Park", "leisure=swimming_pool" to "Schwimmbad",
        "leisure=fitness_centre" to "Fitnessstudio", "highway=services" to "Raststätte", "highway=rest_area" to "Rastplatz",
        "railway=station" to "Bahnhof", "public_transport=station" to "Bahnhof",
        "place=city" to "Stadt", "place=town" to "Stadt", "place=village" to "Ort", "place=suburb" to "Stadtteil",
        "place=hamlet" to "Ortsteil",
    )

    fun categoryLabel(kind: String): String = LABELS[kind] ?: when {
        kind.startsWith("highway") || kind.startsWith("building") || kind.startsWith("place=house") -> "Adresse"
        kind.contains("=") -> kind.substringAfter("=").replace('_', ' ').cap()
        else -> ""
    }
}

/** Einfache Auswertung des OSM-Formats für Öffnungszeiten (die häufigsten Schreibweisen) */
object OpeningHours {
    private val DAYS = listOf("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su")
    val DE = listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")

    /** je Wochentag (0 = Montag) die Zeitspannen in Minuten; leere Liste = geschlossen; null = nicht auswertbar */
    fun parse(s: String): List<List<IntRange>>? = runCatching {
        val t = s.trim()
        if (t == "24/7") return List(7) { listOf(0..1440) }
        val week = MutableList<List<IntRange>>(7) { emptyList() }
        var any = false
        for (rule0 in t.split(';')) {
            val rule = rule0.trim()
            if (rule.isEmpty()) continue
            if (rule.startsWith("PH") || rule.startsWith("SH")) continue
            val m = Regex("^((?:(?:Mo|Tu|We|Th|Fr|Sa|Su)(?:-(?:Mo|Tu|We|Th|Fr|Sa|Su))?)(?:,(?:Mo|Tu|We|Th|Fr|Sa|Su)(?:-(?:Mo|Tu|We|Th|Fr|Sa|Su))?)*)?(?:,PH)?\\s*(.*)$").find(rule) ?: return null
            val dayPart = m.groupValues[1]
            val timePart = m.groupValues[2].trim()
            val days = if (dayPart.isEmpty()) (0..6).toList() else dayPart.split(',').flatMap { d ->
                if (d.contains('-')) {
                    val a = DAYS.indexOf(d.substringBefore('-'))
                    val b = DAYS.indexOf(d.substringAfter('-'))
                    if (a <= b) (a..b).toList() else (a..6).toList() + (0..b).toList()
                } else {
                    listOf(DAYS.indexOf(d))
                }
            }
            val ranges = if (timePart == "off" || timePart == "closed") {
                emptyList()
            } else if (timePart.isEmpty()) {
                return null
            } else {
                timePart.split(',').map { r ->
                    val (a, b) = r.trim().split('-').map { hm ->
                        val (h, mi) = hm.trim().removeSuffix("+").split(':').map { it.toInt() }
                        h * 60 + mi
                    }
                    a..(if (b <= a) b + 1440 else b)
                }
            }
            days.forEach { if (it in 0..6) week[it] = ranges }
            any = true
        }
        if (any) week else null
    }.getOrNull()

    /** true = geöffnet, false = geschlossen, null = unbekannt */
    fun isOpen(week: List<List<IntRange>>, now: LocalDateTime = LocalDateTime.now()): Boolean {
        val d = now.dayOfWeek.value - 1
        val minute = now.hour * 60 + now.minute
        if (week[d].any { minute in it }) return true
        val prev = (d + 6) % 7
        return week[prev].any { it.last > 1440 && minute + 1440 in it }
    }

    fun fmt(r: IntRange): String {
        fun hm(m: Int) = String.format("%02d:%02d", (m / 60) % 24, m % 60)
        return if (r.first == 0 && r.last >= 1440) "24 Stunden" else "${hm(r.first)}–${hm(r.last)}"
    }

    @Suppress("unused")
    private val today: DayOfWeek get() = LocalDateTime.now().dayOfWeek
}

/** Ortsfenster wie bei Google Maps: Daten zum Ort, dann „Route“ */
@Composable
fun PlaceCard(vm: MainViewModel, ui: MainViewModel.Ui, nav: NavSession.State, me: LatLon?, maxH: Dp) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val p = ui.card ?: return
    val d = ui.cardDetails
    val favs by Favorites.items.collectAsState()
    val isFav = favs.any { haversine(it.place.pos, p.pos) < 30 }
    GlassCard(Modifier.fillMaxWidth(), corner = 26.dp) {
        Column(Modifier.heightIn(max = maxH * 0.6f).verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(
                        d?.name ?: p.title, color = pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                    val sub = listOfNotNull(
                        (d?.category ?: Nominatim.categoryLabel(p.kind)).ifBlank { null },
                        me?.let { fmtKm(haversine(it, p.pos)) },
                    ).joinToString(" · ")
                    if (sub.isNotBlank()) Text(sub, color = pal.sub, fontSize = 14.sp)
                }
                CloseDot(vm::closeCard)
            }
            // Öffnungszeiten-Status direkt unter dem Namen
            val week = d?.openingHours?.let { OpeningHours.parse(it) }
            if (week != null) {
                val open = OpeningHours.isOpen(week)
                Text(
                    if (open) "Jetzt geöffnet" else "Jetzt geschlossen",
                    color = if (open) pal.green else pal.red, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (!nav.navigating) {
                    ElButton("Route", onClick = vm::routeToCard, height = 48.dp)
                }
                if (nav.navigating) {
                    ElButton("Hierhin fahren", onClick = { val pl = p; vm.closeCard(restore = false); NavSession.setDestination(pl) }, height = 48.dp, fontSize = 16.sp)
                }
                if (nav.dest != null || nav.navigating) {
                    ElButtonSoft("Als Stopp", onClick = vm::cardAsStop, height = 48.dp)
                }
                Spacer(Modifier.weight(1f))
                d?.phone?.let { ph ->
                    RoundAction(Icons.Filled.Call, "Anrufen") {
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + ph.split(';').first().replace(" ", "")))) }
                    }
                }
                d?.website?.let { w ->
                    RoundAction(Icons.Filled.Language, "Webseite") {
                        val u = if (w.startsWith("http")) w else "https://$w"
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
                    }
                }
                RoundAction(if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder, "Favorit", if (isFav) Color(0xFFFF9F0A) else pal.blue) {
                    if (isFav) favs.filter { haversine(it.place.pos, p.pos) < 30 }.forEach { Favorites.remove(it.id) }
                    else Favorites.set(FavKind.OTHER, Place(d?.name ?: p.title, p.pos, p.osm, p.kind), d?.name ?: p.title)
                }
            }
            Spacer(Modifier.height(12.dp))
            if (ui.cardLoading) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Lade Details …", color = pal.sub, fontSize = 14.sp)
                }
            }
            // Adresse
            val address = d?.address?.ifBlank { null } ?: p.subtitle.ifBlank { null }
            address?.let { InfoLine("Adresse", it) }
            // Öffnungszeiten je Wochentag
            d?.openingHours?.let { raw ->
                Text("Öffnungszeiten", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                if (week == null) {
                    Text(raw.replace("; ", "\n"), color = pal.text, fontSize = 15.sp)
                } else {
                    val today = java.time.LocalDate.now().dayOfWeek.value - 1
                    week.forEachIndexed { i, ranges ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
                            Text(
                                OpeningHours.DE[i], color = pal.text, fontSize = 15.sp,
                                fontWeight = if (i == today) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.width(40.dp),
                            )
                            Text(
                                if (ranges.isEmpty()) "geschlossen" else ranges.joinToString(", ") { OpeningHours.fmt(it) },
                                color = if (ranges.isEmpty()) pal.sub else pal.text, fontSize = 15.sp,
                                fontWeight = if (i == today) FontWeight.Bold else FontWeight.Normal,
                            )
                        }
                    }
                }
            }
            d?.phone?.let { InfoLine("Telefon", it.split(';').first()) }
            d?.website?.let { InfoLine("Webseite", it.removePrefix("https://").removePrefix("http://").removeSuffix("/")) }
            d?.extras?.takeIf { it.isNotEmpty() }?.let { InfoLine("Weitere Angaben", it.joinToString(" · ")) }
            if (!ui.cardLoading && d == null) {
                Text("Keine weiteren Angaben in OpenStreetMap.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    val pal = LocalPal.current
    Column(Modifier.padding(top = 10.dp)) {
        Text(label, color = pal.sub, fontSize = 13.sp)
        Text(value, color = pal.text, fontSize = 15.sp)
    }
}

@Composable
private fun RoundAction(icon: ImageVector, desc: String, tint: Color = LocalPal.current.blue, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(pal.field).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = tint, modifier = Modifier.size(22.dp)) }
}


/** Am Ziel: Ladestationen und Parkplätze (Liste) */
@Composable
fun DestInfoList(nav: NavSession.State, kind: String?, onPlace: (Place) -> Unit, onCharger: (ChargerHit) -> Unit, me: LatLon?) {
    val pal = LocalPal.current
    val dest = nav.dest ?: return
    if (nav.destLoading) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
            CircularProgressIndicator(Modifier.size(14.dp), color = pal.blue, strokeWidth = 2.dp)
            Spacer(Modifier.width(8.dp))
            Text("Suche Laden und Parken am Ziel …", color = pal.sub, fontSize = 14.sp)
        }
        return
    }
    if (kind == null || kind == "charge") {
        if (nav.destChargers.isNotEmpty()) Text("Laden am Ziel", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        nav.destChargers.forEach { h ->
            val a = h.availId?.let { nav.hitAvailability[it] }
            DestRow(
                Color(operatorColor(h.operator.ifBlank { h.name })), "⚡", h.name,
                listOfNotNull(
                    h.operator.ifBlank { null }, if (h.powerKw > 0) "${h.powerKw.roundToInt()} kW" else null,
                    "${fmtKm(haversine(h.pos, dest.pos))} vom Ziel", if (a != null && a.known) "${a.available}/${a.total} frei" else null,
                ).joinToString(" · "),
            ) { onCharger(h) }
        }
    }
    if (kind == null || kind == "park") {
        if (nav.destParking.isNotEmpty()) Text("🅿 Parken am Ziel", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
        nav.destParking.forEach { p ->
            DestRow(Color(0xFF1E5AA8), "P", p.title, listOf(p.subtitle.ifBlank { null }, "${fmtKm(haversine(p.pos, dest.pos))} vom Ziel").filterNotNull().joinToString(" · ")) { onPlace(p) }
        }
    }
    if (nav.destChargers.isEmpty() && nav.destParking.isEmpty()) {
        Text("Keine Lade- oder Parkmöglichkeiten in der Nähe des Ziels gefunden.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun DestRow(color: Color, symbol: String, title: String, sub: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            Text(symbol, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotBlank()) Text(sub, color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("›", color = pal.sub, fontSize = 20.sp)
    }
}

/** Während der Fahrt: Liste „Parken am Ziel“ bzw. „Laden am Ziel“ */
@Composable
fun DestInfoSheet(vm: MainViewModel, ui: MainViewModel.Ui, nav: NavSession.State, me: LatLon?, maxH: Dp) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 26.dp) {
        Column(Modifier.heightIn(max = maxH * 0.55f).verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (ui.destInfo == "park") "Parken am Ziel" else "Laden am Ziel",
                    color = pal.text, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                )
                CloseDot(vm::closeDestInfo)
            }
            Text("Antippen zeigt Details; dort „Hierhin fahren“ wählen.", color = pal.sub, fontSize = 13.sp)
            DestInfoList(
                nav, ui.destInfo,
                onPlace = { p -> vm.closeDestInfo(); vm.openCard(p) },
                onCharger = { h -> vm.closeDestInfo(); MapChargers.show(h) },
                me = me,
            )
        }
    }
}
