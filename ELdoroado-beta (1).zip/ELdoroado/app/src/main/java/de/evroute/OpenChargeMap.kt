package de.evroute

import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import okhttp3.Request
import java.io.IOException
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Ladesäulen über Open Charge Map (frei, eigener Schlüssel nötig).
 * Daten: © Open Charge Map Mitwirkende, Lizenz je Datensatz (meist CC BY 4.0).
 * Sparsam: Ergebnisse werden 20 Minuten zwischengespeichert, Routen-Korridore mit wenigen Anfragen abgefragt.
 */
object OpenChargeMap {
    private const val BASE = "https://api.openchargemap.io/v3/poi"
    private const val CACHE_MS = 20 * 60_000L
    private val cache = HashMap<String, Pair<Long, List<ChargerHit>>>()

    private fun cached(k: String): List<ChargerHit>? = synchronized(cache) {
        cache[k]?.takeIf { System.currentTimeMillis() - it.first < CACHE_MS }?.second
    }

    private fun store(k: String, v: List<ChargerHit>) = synchronized(cache) {
        if (cache.size > 80) cache.clear()
        cache[k] = System.currentTimeMillis() to v
    }

    private fun f5(d: Double) = String.format(Locale.US, "%.5f", d)

    private suspend fun fetch(key: String, params: String): List<ChargerHit> {
        val url = "$BASE?output=json&compact=false&verbose=false&key=$key&$params"
        val req = Request.Builder().url(url)
            .header("User-Agent", "ELdoroado/${BuildConfigLite.version} (private EV navigation app)")
            .header("X-API-Key", key)
            .build()
        val r = Http.call(req)
        if (r.code == 401 || r.code == 403) throw IOException("Open Charge Map: Schlüssel ungültig (Einstellungen → Ladesäulen).")
        if (r.code != 200) throw IOException("Open Charge Map antwortet nicht (Fehler ${r.code}).")
        val arr = runCatching { json.parseToJsonElement(r.body).jsonArray }.getOrNull() ?: return emptyList()
        val hits = arr.mapNotNull { (it as? JsonObject)?.let(::parse) }
        KnownOperators.note(hits.map { it.operator })
        return hits
    }

    private fun JsonObject.o(k: String) = this[k] as? JsonObject
    private fun JsonObject.s(k: String) = (this[k] as? kotlinx.serialization.json.JsonPrimitive)?.takeIf { it.isString }?.content ?: ""
    private fun JsonObject.d(k: String) = (this[k] as? kotlinx.serialization.json.JsonPrimitive)?.doubleOrNull
    private fun JsonObject.i(k: String) = (this[k] as? kotlinx.serialization.json.JsonPrimitive)?.intOrNull

    private fun label(t: String) = when {
        t.contains("CCS", true) -> "CCS"
        t.contains("Tesla", true) || t.contains("NACS", true) -> "Tesla"
        t.contains("CHAdeMO", true) -> "CHAdeMO"
        t.contains("Type 2", true) -> "Typ 2"
        t.contains("Schuko", true) || t.contains("CEE 7/4", true) -> "Schuko"
        else -> t.substringBefore(" (").ifBlank { "Stecker" }
    }

    private fun cleanOperator(t: String): String {
        if (t.isBlank() || t.contains("Unknown", true) || t.contains("Business Owner", true)) return ""
        return t.replace(Regex("\\s*\\((D|DE|NL|BE|AT|CH|FR|LU)\\)$"), "").replace(Regex("\\s*\\(including destination\\)", RegexOption.IGNORE_CASE), "").trim()
    }

    private fun parse(o: JsonObject): ChargerHit? {
        // Nicht betriebsbereite Stationen weglassen
        if (o.o("StatusType")?.let { (it["IsOperational"] as? kotlinx.serialization.json.JsonPrimitive)?.booleanOrNull } == false) return null
        val a = o.o("AddressInfo") ?: return null
        val lat = a.d("Latitude") ?: return null
        val lon = a.d("Longitude") ?: return null
        val conns = (o["Connections"] as? JsonArray)?.mapNotNull { it as? JsonObject } ?: emptyList()
        data class C(val type: String, val kw: Double, val qty: Int)
        val cs = conns.mapNotNull { c ->
            if (c.o("StatusType")?.let { (it["IsOperational"] as? kotlinx.serialization.json.JsonPrimitive)?.booleanOrNull } == false) return@mapNotNull null
            C(label(c.o("ConnectionType")?.s("Title") ?: ""), c.d("PowerKW") ?: 0.0, (c.i("Quantity") ?: 1).coerceAtLeast(1))
        }
        val kw = cs.maxOfOrNull { it.kw } ?: 0.0
        val ccs = cs.filter { it.type == "CCS" }.sumOf { it.qty }
        val tesla = cs.filter { it.type == "Tesla" }.sumOf { it.qty }
        val groups = cs.groupBy { it.type to it.kw }.entries.sortedByDescending { it.key.second }
            .map { (k, v) -> "${v.sumOf { it.qty }}× ${k.first}" + if (k.second > 0) " · ${k.second.roundToInt()} kW" else "" }
        val desc = cs.groupBy { it.type }.entries.sortedByDescending { e -> e.value.maxOf { it.kw } }
            .joinToString(" · ") { (t, v) -> "${v.sumOf { it.qty }}× $t" }
        val operator = cleanOperator(o.o("OperatorInfo")?.s("Title") ?: "")
        val title = a.s("Title").ifBlank { operator.ifBlank { "Ladestation" } }
        val address = listOf(a.s("AddressLine1"), listOf(a.s("Postcode"), a.s("Town")).filter { it.isNotBlank() }.joinToString(" "))
            .filter { it.isNotBlank() }.joinToString(", ")
        val access = a.s("AccessComments").takeIf { it.isNotBlank() && it.length < 80 }
        val usage = o.o("UsageType")?.s("Title") ?: ""
        val lines = listOfNotNull(
            access,
            when {
                usage.contains("Membership", true) -> "Mit Ladekarte oder Registrierung"
                usage.contains("Pay at Location", true) -> "Bezahlen vor Ort"
                usage.contains("Private", true) -> "Eingeschränkter Zugang"
                else -> null
            },
        )
        return ChargerHit(
            name = title,
            operator = operator.ifBlank { if (title.contains("Tesla", true)) "Tesla" else "" },
            pos = LatLon(lat, lon),
            powerKw = kw,
            detourS = 0.0,
            alongM = 0.0,
            availId = null, // Open Charge Map hat keine Live-Belegung
            id = "ocm:" + (o.i("ID")?.toString() ?: "${f5(lat)},${f5(lon)}"),
            connectors = desc,
            teslaOnly = tesla > 0 && ccs == 0,
            address = address,
            connectorGroups = groups,
            openingLines = lines,
        )
    }

    private fun filterParams(minKw: Int, fastOnly: Boolean) = buildString {
        if (minKw > 0) append("&minpowerkw=").append(minKw)
        // 33 = CCS (Typ 2), 27 = Tesla Supercharger, 30 = Tesla (Model S/X)
        if (fastOnly) append("&connectiontypeid=33,27,30")
    }

    /** Ladestationen im Umkreis */
    suspend fun nearby(key: String, c: LatLon, radiusM: Int, minKw: Int, fastOnly: Boolean): List<ChargerHit> {
        val km = (radiusM.coerceIn(500, 60_000) / 1000.0)
        val ck = "n:${f5(c.lat).dropLast(2)}:${f5(c.lon).dropLast(2)}:${km.roundToInt()}:$minKw:$fastOnly"
        cached(ck)?.let { return it }
        val res = fetch(
            key,
            "latitude=${f5(c.lat)}&longitude=${f5(c.lon)}&distance=${String.format(Locale.US, "%.1f", km)}&distanceunit=km&maxresults=250" +
                filterParams(minKw, fastOnly),
        ).filter { haversine(it.pos, c) <= radiusM * 1.05 }
        store(ck, res)
        return res
    }

    /** Google-Polyline-Kodierung (Genauigkeit 5) für die Korridorsuche */
    private fun encode(pts: List<LatLon>): String {
        val sb = StringBuilder()
        var pLat = 0
        var pLon = 0
        fun put(v: Int) {
            var x = if (v < 0) (v shl 1).inv() else v shl 1
            while (x >= 0x20) { sb.append(((0x20 or (x and 0x1f)) + 63).toChar()); x = x shr 5 }
            sb.append((x + 63).toChar())
        }
        for (p in pts) {
            val la = (p.lat * 1e5).roundToInt()
            val lo = (p.lon * 1e5).roundToInt()
            put(la - pLat); put(lo - pLon)
            pLat = la; pLon = lo
        }
        return sb.toString()
    }

    /** Route in Abschnitte teilen und je Abschnitt eine Korridorsuche (ein 500-km-Trip ≈ 4 Anfragen) */
    suspend fun corridor(key: String, r: Route, fromM: Double, toM: Double, widthKm: Int, minKw: Int): List<ChargerHit> = coroutineScope {
        val end = minOf(toM, r.cumM.lastOrNull() ?: 0.0)
        val start = max(0.0, fromM)
        if (end <= start) return@coroutineScope emptyList()
        val chunk = 150_000.0
        val parts = mutableListOf<List<LatLon>>()
        var a = start
        while (a < end) {
            val b = minOf(end, a + chunk)
            val idx = r.cumM.indices.filter { r.cumM[it] in a..b }
            if (idx.isNotEmpty()) {
                val step = max(1, idx.size / 60)
                val pts = idx.filterIndexed { i, _ -> i % step == 0 }.map { r.points[it] } + r.points[idx.last()]
                parts += pts
            }
            a = b
        }
        val results = mutableListOf<ChargerHit>()
        // nacheinander, damit Open Charge Map nicht mit parallelen Anfragen belastet wird
        for (pts in parts) {
            val enc = java.net.URLEncoder.encode(encode(pts), "UTF-8")
            val got = runCatching {
                fetch(key, "polyline=$enc&distance=${widthKm.coerceIn(1, 30)}&distanceunit=km&maxresults=500" + filterParams(minKw, true))
            }.getOrElse {
                // Rückfall: einzelne Suchkreise entlang des Abschnitts
                pts.filterIndexed { i, _ -> i % 15 == 0 }.flatMap { c ->
                    runCatching { nearby(key, c, (widthKm * 1000 + 12_000), minKw, true) }.getOrDefault(emptyList())
                }
            }
            results += got
        }
        results.distinctBy { it.id }.mapNotNull { h ->
            val (along, off) = TomTom.locateOnRoute(r, h.pos)
            if (off > widthKm * 1000.0 || along < start - 1000 || along > end + 1000) null
            else h.copy(alongM = along, offsetM = off)
        }.sortedBy { it.alongM }
    }

    private val FILLER = Regex("\\b(ladestation|ladestationen|ladesäule|ladesäulen|ladepark|lader|laden|schnelllader|in|bei|am|an|im|der|die|das|nähe|nächste)\\b")

    /** Freitext-Suche: Ort aus dem Text suchen (Photon), dort Lader im Umkreis, nach Anbieter/Name filtern */
    suspend fun searchSmart(key: String, q: String, near: LatLon?): List<ChargerHit> {
        val lower = q.trim().lowercase()
        val brands = (KNOWN + KnownOperators.items.value.map { it.lowercase() }).distinct().sortedByDescending { it.length }
        val brand = brands.firstOrNull { b -> Regex("(^|\\s)" + Regex.escape(b) + "($|\\s)").containsMatchIn(lower) }
        var rest = lower
        if (brand != null) rest = rest.replace(Regex("(^|\\s)" + Regex.escape(brand) + "($|\\s)"), " ")
        rest = rest.replace(FILLER, " ").replace(Regex("\\s+"), " ").trim(' ', ',')
        val place = if (rest.length >= 3) runCatching { Geocode.search(rest, near).firstOrNull() }.getOrNull() else null
        val center = place?.pos ?: near ?: return emptyList()
        val all = nearby(key, center, if (place != null) 15_000 else 30_000, 0, false)
        val b2 = if (brand?.contains("supercharger") == true) "tesla" else brand
        val list = if (b2 != null) {
            all.filter { it.operator.contains(b2, true) || it.name.contains(b2, true) }
        } else if (place == null && rest.length >= 3) {
            // kein Ort erkannt: im Namen/Adresse nach dem Text suchen
            all.filter { it.name.contains(rest, true) || it.address.contains(rest, true) || it.operator.contains(rest, true) }.ifEmpty { all }
        } else {
            all
        }
        return list.sortedBy { haversine(it.pos, center) }.take(25)
    }

    private val KNOWN = listOf(
        "tesla supercharger", "supercharger", "tesla", "enbw", "ionity", "fastned", "aral pulse", "aral", "shell recharge", "shell",
        "ewe go", "allego", "electra", "e.on", "atlante", "pfalzwerke", "totalenergies", "total", "maingau", "lidl", "kaufland", "aldi",
        "mer", "zunder", "eviny", "be charge", "stadtwerke", "dew21",
    )
}

/**
 * Ladesäulen-Quelle wählen:
 * Deutschland → Ladesäulenregister der Bundesnetzagentur (offline auf dem Handy),
 * Ausland → Open Charge Map (falls Schlüssel).
 * (TomToms eigene Ladestopp-Planung bei der Routenberechnung bleibt davon unberührt.)
 */
object Chargers {
    fun inGermany(p: LatLon) = p.lat in 47.25..55.1 && p.lon in 5.85..15.05

    private fun reg() = ChargerRegistry.ready()

    fun available(s: AppSettings) = reg() || s.ocmKey.isNotBlank() || s.hasTomTom

    private fun need(s: AppSettings) {
        if (!available(s)) {
            throw IOException(
                if (ChargerRegistry.loading.value) "Das Ladesäulen-Verzeichnis wird gerade geladen …"
                else "Noch kein Ladesäulen-Verzeichnis – bitte einmal mit dem Internet verbinden (Einstellungen → Ladesäulen).",
            )
        }
    }

    /** Quelle außerhalb des Registers (Ausland oder Register noch nicht geladen) */
    private suspend fun remoteNearby(s: AppSettings, c: LatLon, radiusM: Int, minKw: Int, fastOnly: Boolean): List<ChargerHit> = when {
        s.ocmKey.isNotBlank() -> OpenChargeMap.nearby(s.ocmKey.trim(), c, radiusM, minKw, fastOnly)
        else -> emptyList()
    }

    suspend fun nearby(s: AppSettings, c: LatLon, radiusM: Int, minKw: Int, fastOnly: Boolean): List<ChargerHit> {
        need(s)
        if (reg() && inGermany(c)) {
            val local = ChargerRegistry.nearby(c, radiusM, minKw, fastOnly)
            // Grenznähe: Treffer jenseits der Grenze ergänzen
            val border = !inGermany(LatLon(c.lat + radiusM / 111_000.0, c.lon)) || !inGermany(LatLon(c.lat - radiusM / 111_000.0, c.lon)) ||
                !inGermany(LatLon(c.lat, c.lon + radiusM / 70_000.0)) || !inGermany(LatLon(c.lat, c.lon - radiusM / 70_000.0))
            if (!border || s.ocmKey.isBlank()) return local
            val far = runCatching { remoteNearby(s, c, radiusM, minKw, fastOnly) }.getOrDefault(emptyList()).filter { !inGermany(it.pos) }
            return (local + far).sortedBy { haversine(it.pos, c) }
        }
        val remote = remoteNearby(s, c, radiusM, minKw, fastOnly)
        return if (remote.isEmpty() && reg()) ChargerRegistry.nearby(c, radiusM, minKw, fastOnly) else remote
    }

    suspend fun corridor(s: AppSettings, r: Route, fromM: Double, toM: Double, widthKm: Int, minKw: Int): List<ChargerHit> {
        need(s)
        if (!reg()) {
            return if (s.ocmKey.isNotBlank()) OpenChargeMap.corridor(s.ocmKey.trim(), r, fromM, toM, widthKm, minKw)
            else emptyList()
        }
        val local = ChargerRegistry.corridor(r, fromM, toM, widthKm, minKw)
        val step = max(1, r.points.size / 200)
        val leaves = r.points.filterIndexed { i, _ -> i % step == 0 }.any { !inGermany(it) }
        if (!leaves || s.ocmKey.isBlank()) return local
        val abroad = runCatching { OpenChargeMap.corridor(s.ocmKey.trim(), r, fromM, toM, widthKm, minKw) }.getOrDefault(emptyList())
            .filter { !inGermany(it.pos) }
        return (local + abroad).sortedBy { it.alongM }
    }

    private val FILLER = Regex("\\b(ladestation|ladestationen|ladesäule|ladesäulen|ladepark|lader|laden|schnelllader|in|bei|am|an|im|der|die|das|nähe|nächste)\\b")
    private val KNOWN = listOf(
        "tesla supercharger", "supercharger", "tesla", "enbw", "ionity", "fastned", "aral pulse", "aral", "shell recharge", "shell",
        "ewe go", "allego", "electra", "e.on", "atlante", "pfalzwerke", "totalenergies", "total", "maingau", "lidl", "kaufland", "aldi",
        "mer", "zunder", "eviny", "stadtwerke", "dew21", "mark-e", "westenergie", "avu", "vattenfall",
    )

    /** Freitext wie „EnBW Hagen“: Ort über Photon suchen, dort Lader im Umkreis, nach Anbieter/Name filtern */
    suspend fun searchSmart(s: AppSettings, q: String, near: LatLon?): List<ChargerHit> {
        need(s)
        val lower = q.trim().lowercase()
        val brands = (KNOWN + KnownOperators.items.value.map { it.lowercase() }).distinct().sortedByDescending { it.length }
        val brand = brands.firstOrNull { b -> Regex("(^|\\s)" + Regex.escape(b) + "($|\\s)").containsMatchIn(lower) }
        var rest = lower
        if (brand != null) rest = rest.replace(Regex("(^|\\s)" + Regex.escape(brand) + "($|\\s)"), " ")
        rest = rest.replace(FILLER, " ").replace(Regex("\\s+"), " ").trim(' ', ',')
        val place = if (rest.length >= 3) runCatching { Geocode.search(rest, near).firstOrNull() }.getOrNull() else null
        val center = place?.pos ?: near ?: return emptyList()
        val all = nearby(s, center, if (place != null) 15_000 else 30_000, 0, false)
        val b2 = if (brand?.contains("supercharger") == true) "tesla" else brand
        val list = when {
            b2 != null -> all.filter { it.operator.contains(b2, true) || it.name.contains(b2, true) }
            place == null && rest.length >= 3 ->
                all.filter { it.name.contains(rest, true) || it.address.contains(rest, true) || it.operator.contains(rest, true) }.ifEmpty { all }
            else -> all
        }
        return list.sortedBy { haversine(it.pos, center) }.take(25)
    }

    suspend fun near(s: AppSettings, q: String, near: LatLon, radiusM: Int): List<ChargerHit> {
        val all = nearby(s, near, radiusM, 0, false)
        val t = q.trim()
        return if (t.equals("Ladestation", true) || t.isBlank()) all else all.filter { it.operator.contains(t, true) || it.name.contains(t, true) }
    }
}
