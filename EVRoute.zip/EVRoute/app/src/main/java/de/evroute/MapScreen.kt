package de.evroute

import android.content.Context
import android.view.Gravity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.isActive
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.Layer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap
import org.maplibre.android.style.layers.PropertyFactory.iconAnchor
import org.maplibre.android.style.layers.PropertyFactory.iconSize
import org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement
import org.maplibre.android.style.layers.PropertyFactory.iconImage
import org.maplibre.android.style.layers.PropertyFactory.iconPitchAlignment
import org.maplibre.android.style.layers.PropertyFactory.iconRotate
import org.maplibre.android.style.layers.PropertyFactory.iconRotationAlignment
import org.maplibre.android.style.layers.PropertyFactory.lineCap
import org.maplibre.android.style.layers.PropertyFactory.lineColor
import org.maplibre.android.style.layers.PropertyFactory.lineGradient
import org.maplibre.android.style.layers.PropertyFactory.lineJoin
import org.maplibre.android.style.layers.PropertyFactory.lineWidth
import org.maplibre.android.style.layers.PropertyFactory.rasterOpacity
import org.maplibre.android.style.layers.RasterLayer
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonOptions
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.android.style.sources.TileSet
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point

private const val DAY_STYLE = "https://tiles.openfreemap.org/styles/liberty"
private const val NIGHT_STYLE = "https://tiles.openfreemap.org/styles/dark"

/** Farben der Fahrtlinie (Tag/Nacht) */
private class LineColors(dark: Boolean) {
    val route = if (dark) 0xFF2E8BFF.toInt() else 0xFF0A84FF.toInt()
    val casing = if (dark) 0xFF0B3D91.toInt() else 0xFF0057B8.toInt()
    val done = if (dark) 0xFF5A5F69.toInt() else 0xFFA3AAB5.toInt()
    val alt = if (dark) 0xFF3C5F8F.toInt() else 0xFFA9CBF5.toInt()
    val altCasing = if (dark) 0xFF27405F.toInt() else 0xFF7DA6DB.toInt()
}

/**
 * Fahrzeugposition vorausberechnen: aus der letzten GPS-Messung, dem Tempo und der seither vergangenen Zeit
 * (inkl. Alter der Messung) wird geschätzt, wo das Auto *jetzt* ist – in der Navigation entlang der Route.
 * Die Anzeige folgt dieser Schätzung mit einer sehr kurzen Glättung (~0,12 s), damit nichts springt.
 */
private class Predictor {
    var route: Route? = null
    var onRoute = false
    var fixPos = LatLon(0.0, 0.0)
    var fixBearing = 0.0
    var speed = 0.0
    var fixNs = 0L
    var fixAlong = 0.0
    var ready = false
        private set
    private var shown: LatLon? = null
    private var shownBearing = 0.0
    private var lastFrameNs = 0L

    fun set(pos: LatLon, bearingDeg: Double, speedMs: Double, ns: Long, r: Route?, along: Double?, routeMode: Boolean) {
        fixPos = pos
        fixBearing = bearingDeg
        speed = speedMs
        fixNs = if (ns > 0) ns else android.os.SystemClock.elapsedRealtimeNanos()
        route = r
        onRoute = routeMode && r != null && along != null
        fixAlong = along ?: 0.0
        ready = true
    }

    private fun target(now: Long): Pair<LatLon, Double> {
        val r = route
        val dt = ((now - fixNs) / 1e9).coerceIn(0.0, if (onRoute) 3.0 else 1.5)
        val moving = speed > 1.0
        if (onRoute && r != null) {
            val end = r.cumM.lastOrNull() ?: 0.0
            val a = (fixAlong + (if (moving) speed * dt else 0.0)).coerceIn(0.0, end)
            val pos = pointAt(r, a)
            val brg = if (moving) bearing(pointAt(r, a - 8.0), pointAt(r, a + 12.0)) else fixBearing
            return pos to brg
        }
        if (!moving) return fixPos to fixBearing
        val d = speed * dt
        val rad = Math.toRadians(fixBearing)
        val lat = fixPos.lat + kotlin.math.cos(rad) * d / 110540.0
        val lon = fixPos.lon + kotlin.math.sin(rad) * d / (111320.0 * kotlin.math.cos(Math.toRadians(fixPos.lat)))
        return LatLon(lat, lon) to fixBearing
    }

    /** Position und Richtung für dieses Bild; false = keine sichtbare Änderung */
    fun frame(now: Long): Triple<LatLon, Double, Boolean> {
        val (t, tb) = target(now)
        val cur = shown
        val dtF = if (lastFrameNs == 0L) 1.0 else ((now - lastFrameNs) / 1e9).coerceIn(0.0, 1.0)
        lastFrameNs = now
        if (cur == null || haversine(cur, t) > 150.0) {
            shown = t; shownBearing = tb
            return Triple(t, tb, true)
        }
        val a = 1.0 - kotlin.math.exp(-dtF / 0.12)
        val ab = 1.0 - kotlin.math.exp(-dtF / 0.25)
        val next = lerp(cur, t, a)
        val diff = ((tb - shownBearing + 540.0) % 360.0) - 180.0
        val nb = (shownBearing + diff * ab + 360.0) % 360.0
        val changed = haversine(cur, next) > 0.05 || kotlin.math.abs(diff) > 0.3
        shown = next
        shownBearing = nb
        return Triple(next, nb, changed)
    }

    val bearingNow: Double get() = shownBearing
}

/** Punkt auf der Route bei Strecke m (Meter ab Start) */
private fun pointAt(r: Route, m: Double): LatLon {
    val pts = r.points
    val cum = r.cumM
    if (pts.isEmpty()) return LatLon(0.0, 0.0)
    var i = cum.binarySearch(m)
    if (i >= 0) return pts[i]
    i = -i - 1
    if (i <= 0) return pts.first()
    if (i >= pts.size) return pts.last()
    val span = cum[i] - cum[i - 1]
    return if (span <= 0) pts[i] else lerp(pts[i - 1], pts[i], (m - cum[i - 1]) / span)
}

private fun widthExpr(base: Float): Expression = Expression.interpolate(
    Expression.exponential(1.4f), Expression.zoom(),
    Expression.stop(4, base * 0.45f),
    Expression.stop(10, base * 0.8f),
    Expression.stop(16, base * 1.6f),
    Expression.stop(19, base * 2.6f),
)

private fun progressGradient(frac: Double, c: LineColors): Expression = Expression.step(
    Expression.lineProgress(),
    Expression.color(c.done),
    Expression.stop(frac.coerceIn(0.0, 1.0), Expression.color(c.route)),
)

private fun lineFeature(r: Route): Feature =
    Feature.fromGeometry(LineString.fromLngLats(r.points.map { Point.fromLngLat(it.lon, it.lat) }))

private fun emptyFc(): FeatureCollection = FeatureCollection.fromFeatures(emptyList<Feature>())

private fun iconId(v: VehicleIcon) = when (v) {
    VehicleIcon.ARROW -> "veh-arrow"
    VehicleIcon.CAR -> "veh-car"
    VehicleIcon.DOT -> "veh-dot"
}

private fun setupStyle(ctx: Context, s: Style, dark: Boolean, carColor: Long) {
    val c = LineColors(dark)
    s.addImage("veh-arrow", VehicleIcons.arrow(ctx))
    s.addImage("veh-dot", VehicleIcons.dot(ctx))
    s.addImage("veh-car", VehicleIcons.car(ctx, carColor.toInt()))
    s.addImage("stop-icon", VehicleIcons.charger(ctx))
    s.addImage("turn-head", VehicleIcons.arrowHead(ctx))
    s.addSource(GeoJsonSource("turn-line", emptyFc()))
    s.addSource(GeoJsonSource("turn-head", emptyFc()))
    s.addSource(GeoJsonSource("alts", emptyFc()))
    s.addSource(GeoJsonSource("jams", emptyFc()))
    s.addSource(GeoJsonSource("stops", emptyFc()))
    s.addSource(GeoJsonSource("route", emptyFc(), GeoJsonOptions().withLineMetrics(true)))
    s.addSource(GeoJsonSource("me", emptyFc()))

    // Linien unter die Beschriftungen legen, damit Straßennamen lesbar bleiben
    val labelId = s.layers.firstOrNull { it is SymbolLayer }?.id
    fun add(l: Layer) { if (labelId != null) s.addLayerBelow(l, labelId) else s.addLayer(l) }

    add(LineLayer("alt-casing", "alts").withProperties(lineColor(c.altCasing), lineWidth(widthExpr(9f)), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
    add(LineLayer("alt-line", "alts").withProperties(lineColor(c.alt), lineWidth(widthExpr(6f)), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
    add(LineLayer("route-casing", "route").withProperties(lineColor(c.casing), lineWidth(widthExpr(11f)), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
    add(
        LineLayer("route-line", "route").withProperties(
            lineGradient(progressGradient(0.0, c)), lineWidth(widthExpr(7.5f)),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND),
        ),
    )
    add(
        LineLayer("jams", "jams").withProperties(
            lineColor(Expression.toColor(Expression.get("c"))), lineWidth(widthExpr(5f)),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND),
        ),
    )
    // Abbiegepfeil auf der Route (wie bei ABRP)
    add(
        LineLayer("turn-casing", "turn-line").withProperties(
            lineColor("#0B1E3F"), lineWidth(widthExpr(8.5f)),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND),
        ),
    )
    add(
        LineLayer("turn-line", "turn-line").withProperties(
            lineColor("#FFFFFF"), lineWidth(widthExpr(5f)),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND),
        ),
    )
    s.addLayer(
        SymbolLayer("turn-head", "turn-head").withProperties(
            iconImage("turn-head"),
            iconRotate(Expression.get("bearing")),
            iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
            iconAnchor(Property.ICON_ANCHOR_BOTTOM),
            iconAllowOverlap(true),
            iconIgnorePlacement(true),
            iconSize(
                Expression.interpolate(
                    Expression.linear(), Expression.zoom(),
                    Expression.stop(12, 0.5f), Expression.stop(16, 0.9f), Expression.stop(19, 1.4f),
                ),
            ),
        ),
    )
    s.addLayer(
        SymbolLayer("stops", "stops").withProperties(
            iconImage("stop-icon"),
            iconAllowOverlap(true),
            iconIgnorePlacement(true),
        ),
    )
    s.addLayer(
        SymbolLayer("me", "me").withProperties(
            iconImage("veh-arrow"),
            iconRotate(Expression.get("bearing")),
            iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
            iconAllowOverlap(true),
            iconIgnorePlacement(true),
        ),
    )
}

/** Punkte der Route zwischen Strecke a und b (in Metern ab Start) */
private fun slice(r: Route, a: Double, b: Double): List<LatLon> {
    val pts = r.points
    val cum = r.cumM
    if (pts.size < 2) return emptyList()
    fun at(m: Double): LatLon = pointAt(r, m)
    val from = a.coerceIn(0.0, cum.last())
    val to = b.coerceIn(0.0, cum.last())
    val out = mutableListOf(at(from))
    for (i in pts.indices) if (cum[i] > from && cum[i] < to) out += pts[i]
    out += at(to)
    return out
}

private fun autoZoom(kmh: Double, distToStep: Double): Double {
    var z = when {
        kmh < 25 -> 17.3
        kmh < 50 -> 16.7
        kmh < 80 -> 16.0
        kmh < 110 -> 15.3
        else -> 14.7
    }
    if (distToStep < 250 && kmh < 90) z += 0.6
    return z
}

@Composable
fun EvMap(
    routes: List<Route>,
    selected: Int,
    navigating: Boolean,
    progress: NavProgress?,
    fix: Fix?,
    vehicle: VehicleIcon,
    carColor: Long,
    dark: Boolean,
    follow: Boolean,
    recenterTick: Int,
    topPadPx: Double,
    bottomPadPx: Double,
    sheetPadPx: Int,
    onGesture: () -> Unit,
    onTap: (LatLon, Double) -> Unit,
    trafficUrl: String?,
    onLongPress: (LatLon) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val mapView = remember { MapView(ctx) }
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    var style by remember { mutableStateOf<Style?>(null) }
    val pred = remember { Predictor() }
    val followNow = rememberUpdatedState(navigating && follow)
    val zoomTarget = remember { doubleArrayOf(16.0) }
    val padTop = rememberUpdatedState(topPadPx)
    val padBottom = rememberUpdatedState(bottomPadPx)
    var centered by remember { mutableStateOf(false) }
    val gestureCb = rememberUpdatedState(onGesture)
    val tapCb = rememberUpdatedState(onTap)
    val longCb = rememberUpdatedState(onLongPress)
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_CREATE -> mapView.onCreate(null)
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(Unit) {
        mapView.getMapAsync { m ->
            m.uiSettings.isLogoEnabled = false
            m.uiSettings.isCompassEnabled = true
            m.uiSettings.compassGravity = Gravity.TOP or Gravity.START
            m.uiSettings.setCompassMargins(36, (ctx.resources.displayMetrics.density * 150).toInt(), 0, 0)
            m.uiSettings.attributionGravity = Gravity.TOP or Gravity.END
            m.uiSettings.setAttributionMargins(0, (ctx.resources.displayMetrics.density * 140).toInt(), 24, 0)
            m.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) gestureCb.value()
            }
            m.addOnMapClickListener { ll ->
                tapCb.value(LatLon(ll.latitude, ll.longitude), m.projection.getMetersPerPixelAtLatitude(ll.latitude))
                false
            }
            m.addOnMapLongClickListener { ll ->
                longCb.value(LatLon(ll.latitude, ll.longitude))
                true
            }
            map = m
        }
    }

    // Kartenstil laden (Tag/Nacht), bei Fehler auf den Tagstil zurückfallen
    LaunchedEffect(map, dark) {
        val m = map ?: return@LaunchedEffect
        var fellBack = false
        fun load(url: String) {
            style = null
            m.setStyle(Style.Builder().fromUri(url)) { s ->
                setupStyle(ctx, s, dark, carColor)
                style = s
            }
        }
        val fail = MapView.OnDidFailLoadingMapListener {
            if (!fellBack && dark) { fellBack = true; load(DAY_STYLE) }
        }
        mapView.addOnDidFailLoadingMapListener(fail)
        load(if (dark) NIGHT_STYLE else DAY_STYLE)
        try { awaitCancellation() } finally { mapView.removeOnDidFailLoadingMapListener(fail) }
    }

    // Fahrzeugsymbol und Autofarbe
    LaunchedEffect(style, vehicle, carColor) {
        val s = style ?: return@LaunchedEffect
        s.addImage("veh-car", VehicleIcons.car(ctx, carColor.toInt()))
        s.getLayerAs<SymbolLayer>("me")?.setProperties(iconImage(iconId(vehicle)))
    }

    // Routen zeichnen
    LaunchedEffect(style, routes, selected, navigating) {
        val s = style ?: return@LaunchedEffect
        val sel = routes.getOrNull(selected)
        val alts = if (navigating) emptyList() else routes.filterIndexed { i, _ -> i != selected }.map { lineFeature(it) }
        s.getSourceAs<GeoJsonSource>("alts")?.setGeoJson(FeatureCollection.fromFeatures(alts))
        s.getSourceAs<GeoJsonSource>("route")?.setGeoJson(sel?.let { FeatureCollection.fromFeature(lineFeature(it)) } ?: emptyFc())
        if (!navigating) s.getLayerAs<LineLayer>("route-line")?.setProperties(lineGradient(progressGradient(0.0, LineColors(dark))))
    }

    // Verkehrslage (TomTom-Kacheln) unter den Routenlinien
    LaunchedEffect(style, trafficUrl) {
        val s = style ?: return@LaunchedEffect
        s.getLayer("traffic-layer")?.let { s.removeLayer(it) }
        s.getSource("traffic")?.let { s.removeSource(it) }
        if (trafficUrl != null) {
            s.addSource(RasterSource("traffic", TileSet("2.2.0", trafficUrl), 256))
            val layer = RasterLayer("traffic-layer", "traffic").withProperties(rasterOpacity(0.9f))
            if (s.getLayer("alt-casing") != null) s.addLayerBelow(layer, "alt-casing") else s.addLayer(layer)
        }
    }

    // Abbiegepfeil am nächsten Manöver (nur in der Navigation)
    LaunchedEffect(style, routes, selected, navigating, progress?.stepIdx) {
        val s = style ?: return@LaunchedEffect
        val lineSrc = s.getSourceAs<GeoJsonSource>("turn-line") ?: return@LaunchedEffect
        val headSrc = s.getSourceAs<GeoJsonSource>("turn-head") ?: return@LaunchedEffect
        val r = routes.getOrNull(selected)
        val p = progress
        val step = if (r != null && p != null) r.steps.getOrNull(p.stepIdx) else null
        val show = navigating && r != null && p != null && step != null &&
            step.type !in listOf("arrive", "depart", "charge", "via") &&
            !(step.type == "continue" && (step.mod == null || step.mod == "straight"))
        if (!show || r == null || p == null) {
            lineSrc.setGeoJson(emptyFc())
            headSrc.setGeoJson(emptyFc())
            return@LaunchedEffect
        }
        val at = r.stepAlongM[p.stepIdx]
        val pts = slice(r, at - 35.0, at + 28.0)
        if (pts.size < 2) return@LaunchedEffect
        lineSrc.setGeoJson(Feature.fromGeometry(LineString.fromLngLats(pts.map { Point.fromLngLat(it.lon, it.lat) })))
        // Pfeilspitze am Ende, ausgerichtet am letzten Stück
        val end = pts.last()
        var k = pts.lastIndex - 1
        while (k > 0 && haversine(pts[k], end) < 3.0) k--
        val head = Feature.fromGeometry(Point.fromLngLat(end.lon, end.lat))
        head.addNumberProperty("bearing", bearing(pts[k], end))
        headSrc.setGeoJson(head)
    }

    // Ladestopps und Staus der gewählten Route
    LaunchedEffect(style, routes, selected) {
        val s = style ?: return@LaunchedEffect
        val r = routes.getOrNull(selected)
        val stops = r?.stops.orEmpty().map { Feature.fromGeometry(Point.fromLngLat(it.pos.lon, it.pos.lat)) }
        s.getSourceAs<GeoJsonSource>("stops")?.setGeoJson(FeatureCollection.fromFeatures(stops))
        val jams = r?.jams.orEmpty().mapNotNull { j ->
            if (r == null || j.magnitude <= 0) return@mapNotNull null
            val a = j.startIdx.coerceIn(0, r.points.lastIndex)
            val b = j.endIdx.coerceIn(0, r.points.lastIndex)
            if (b - a < 1) return@mapNotNull null
            val f = Feature.fromGeometry(LineString.fromLngLats(r.points.subList(a, b + 1).map { Point.fromLngLat(it.lon, it.lat) }))
            f.addStringProperty(
                "c",
                when {
                    j.category == "ROAD_CLOSURE" || j.magnitude >= 4 -> "#8E1B1B"
                    j.magnitude == 3 -> "#FF3B30"
                    j.magnitude == 2 -> "#FF9500"
                    else -> "#FFCC00"
                },
            )
            f
        }
        s.getSourceAs<GeoJsonSource>("jams")?.setGeoJson(FeatureCollection.fromFeatures(jams))
    }

    // Übersicht über alle Routen
    LaunchedEffect(map, routes, sheetPadPx) {
        val m = map ?: return@LaunchedEffect
        if (navigating || routes.isEmpty()) return@LaunchedEffect
        val b = LatLngBounds.Builder()
        var count = 0
        routes.forEach { r ->
            val stepN = (r.points.size / 300).coerceAtLeast(1)
            r.points.forEachIndexed { i, p -> if (i % stepN == 0 || i == r.points.lastIndex) { b.include(LatLng(p.lat, p.lon)); count++ } }
        }
        if (count >= 2) {
            val d = ctx.resources.displayMetrics.density
            m.easeCamera(CameraUpdateFactory.newLatLngBounds(b.build(), (40 * d).toInt(), (120 * d).toInt(), (40 * d).toInt(), sheetPadPx), 900)
        }
    }

    // Gefahrener Teil der Route grau
    LaunchedEffect(style, progress?.alongM, navigating) {
        val s = style ?: return@LaunchedEffect
        val r = routes.getOrNull(selected) ?: return@LaunchedEffect
        if (!navigating || progress == null) return@LaunchedEffect
        val frac = progress.alongM / r.cumM.last().coerceAtLeast(1.0)
        s.getLayerAs<LineLayer>("route-line")?.setProperties(lineGradient(progressGradient(frac, LineColors(dark))))
    }

    // Neue GPS-Messung oder neue Position auf der Route: Vorausberechnung aktualisieren
    LaunchedEffect(fix, progress, navigating) {
        val f = fix ?: return@LaunchedEffect
        val r = routes.getOrNull(selected)
        val onRoute = navigating && progress != null && progress.offRouteM < 30 && r != null
        val b = when {
            onRoute && f.speed > 1.5 -> progress!!.routeBearing
            f.bearing != null && f.speed > 1.5 -> f.bearing.toDouble()
            else -> pred.bearingNow
        }
        pred.set(
            pos = if (onRoute) progress!!.snapped else f.pos,
            bearingDeg = b,
            speedMs = f.speed,
            ns = f.elapsedNs,
            r = if (onRoute) r else null,
            along = if (onRoute) progress!!.alongM else null,
            routeMode = onRoute,
        )
        zoomTarget[0] = autoZoom(f.speed * 3.6, progress?.distToStepM ?: 1e9)
        val m = map ?: return@LaunchedEffect
        if (!navigating && !centered && routes.isEmpty()) {
            centered = true
            m.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(f.pos.lat, f.pos.lon), 14.0))
        }
    }

    // „Zentrieren“-Knopf außerhalb der Navigation
    LaunchedEffect(recenterTick) {
        if (recenterTick == 0 || navigating) return@LaunchedEffect
        val f = fix ?: return@LaunchedEffect
        val cam = CameraPosition.Builder().target(LatLng(f.pos.lat, f.pos.lon)).zoom(15.5).tilt(0.0).bearing(0.0)
            .padding(0.0, 0.0, 0.0, 0.0).build()
        map?.easeCamera(CameraUpdateFactory.newCameraPosition(cam), 700)
    }

    // Bildschleife (~30 fps): Fahrzeugsymbol und – in der Navigation – Kamera auf die vorausberechnete Position
    LaunchedEffect(style) {
        val s = style ?: return@LaunchedEffect
        val src = s.getSourceAs<GeoJsonSource>("me") ?: return@LaunchedEffect
        var last = 0L
        var zoom = 16.0
        while (isActive) {
            withFrameNanos { }
            val wall = System.nanoTime()
            if (!pred.ready || wall - last < 33_000_000L) continue
            last = wall
            val (p, b, changed) = pred.frame(android.os.SystemClock.elapsedRealtimeNanos())
            val follow = followNow.value
            if (changed || follow) {
                val feat = Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat))
                feat.addNumberProperty("bearing", b)
                src.setGeoJson(feat)
            }
            if (follow) {
                zoom += (zoomTarget[0] - zoom) * 0.03
                val cam = CameraPosition.Builder()
                    .target(LatLng(p.lat, p.lon))
                    .zoom(zoom)
                    .tilt(58.0)
                    .bearing(b)
                    .padding(0.0, padTop.value, 0.0, padBottom.value)
                    .build()
                map?.moveCamera(CameraUpdateFactory.newCameraPosition(cam))
            } else {
                zoom = map?.cameraPosition?.zoom ?: zoom
            }
        }
    }

    AndroidView(factory = { mapView }, modifier = modifier)
}
