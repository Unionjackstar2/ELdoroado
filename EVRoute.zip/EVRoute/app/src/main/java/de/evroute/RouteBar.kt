package de.evroute

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Ein Ereignis auf der Streckenleiste */
data class BarItem(
    val alongM: Double,
    val endM: Double,
    val symbol: String,
    val color: Long,
    val title: String,
    val detail: String,
    val pos: LatLon,
    val endPos: LatLon,
)

object RouteBarData {
    /** Text zur TPEG-Ursache */
    fun causeText(c: Int?, category: String): Pair<String, String> = when {
        category == "ROAD_CLOSURE" -> "⛔" to "Sperrung"
        c == 2 -> "💥" to "Unfall"
        c == 3 || category == "ROAD_WORK" -> "🚧" to "Baustelle"
        c == 10 -> "⚠" to "Gegenstand auf der Fahrbahn"
        c == 11 -> "⚠" to "Tiere auf der Fahrbahn"
        c == 12 -> "⚠" to "Personen auf der Fahrbahn"
        c == 13 -> "⚠" to "Pannenfahrzeug"
        c == 14 -> "⚠" to "Falschfahrer"
        c == 6 || c == 7 -> "⚠" to "Glätte bzw. Aquaplaning"
        c == 15 -> "🚑" to "Rettungsarbeiten"
        c == 27 -> "⚠" to "Gefährliches Stauende"
        c == 17 || c == 18 || c == 19 -> "🌧" to "Wetter"
        else -> "" to "Stau"
    }

    fun items(r: Route, along: Double, rangeM: Double): List<BarItem> {
        val out = mutableListOf<BarItem>()
        val until = along + rangeM
        r.jams.forEach { j ->
            val a = r.cumM.getOrNull(j.startIdx) ?: return@forEach
            val b = r.cumM.getOrNull(j.endIdx) ?: return@forEach
            if (b < along || a > until) return@forEach
            if (j.magnitude <= 0 && j.category != "ROAD_CLOSURE" && j.category != "ROAD_WORK") return@forEach
            val (sym, what) = causeText(j.cause, j.category)
            val color = when {
                j.category == "ROAD_CLOSURE" || j.magnitude >= 4 -> 0xFF7A1010
                j.magnitude == 3 -> 0xFFE5332A
                j.magnitude == 2 -> 0xFFFF8A00
                j.magnitude == 1 -> 0xFFFFB800
                else -> 0xFF8E8E93
            }
            val len = b - a
            val parts = listOfNotNull(
                if (len > 300) "${fmtKm(len)} lang" else null,
                if (j.delayS >= 60) "ca. +${(j.delayS / 60).roundToInt()} min" else null,
                j.speedKmh?.takeIf { it > 0 && it < 80 }?.let { "${it.roundToInt()} km/h" },
            )
            out += BarItem(a, b, sym, color, what, parts.joinToString(" · "), r.points[j.startIdx], r.points[j.endIdx.coerceAtMost(r.points.lastIndex)])
        }
        r.stops.filter { it.alongM in along..until }.forEach { st ->
            out += BarItem(st.alongM, st.alongM, "⚡", 0xFF30D158, st.name, "Laden ${fmtPct(st.arriveSoc)} → ${fmtPct(st.targetSoc)} · ${(st.chargeS / 60).roundToInt()} min", st.pos, st.pos)
        }
        r.steps.forEachIndexed { i, st ->
            val m = r.stepAlongM[i]
            if (m < along || m > until) return@forEachIndexed
            if (st.type == "via") out += BarItem(m, m, "📍", 0xFF0A84FF, "Zwischenstopp", st.road, r.points[nearestIdx(r, m)], r.points[nearestIdx(r, m)])
        }
        val end = r.cumM.last()
        if (end <= until) out += BarItem(end, end, "🏁", 0xFF1C1C1E, "Ziel", "", r.points.last(), r.points.last())
        return out.sortedBy { it.alongM }
    }

    fun nearestIdx(r: Route, m: Double): Int {
        var i = r.cumM.binarySearch(m)
        if (i < 0) i = -i - 1
        return i.coerceIn(0, r.points.lastIndex)
    }

    /** Punkte eines Streckenabschnitts (für die Übersicht) */
    fun slice(r: Route, from: Double, to: Double): List<LatLon> {
        val a = nearestIdx(r, from)
        val b = nearestIdx(r, to).coerceAtLeast(a + 1).coerceAtMost(r.points.lastIndex)
        val step = ((b - a) / 300).coerceAtLeast(1)
        return (a..b step step).map { r.points[it] } + r.points[b]
    }
}

/** Senkrechte Streckenleiste: unten du, oben die nächsten x km */
@Composable
fun RouteBar(r: Route, alongFix: Double, rangeKm: Int, onTap: (BarItem) -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    // flüssig mitlaufen (vorausberechnete Position), nur die Leiste wird dafür neu gezeichnet
    val live by NavSession.liveAlong.collectAsState()
    val along = live ?: alongFix
    val rangeM = rangeKm * 1000.0
    val items = RouteBarData.items(r, along, rangeM)
    val end = r.cumM.last()
    Surface(modifier.width(58.dp), shape = RoundedCornerShape(16.dp), color = pal.card.copy(alpha = 0.92f), shadowElevation = 8.dp) {
        BoxWithConstraints(Modifier.fillMaxHeight().padding(vertical = 10.dp)) {
            val h = maxHeight
            fun y(m: Double) = h * (1f - ((m - along) / rangeM).toFloat().coerceIn(0f, 1f))
            // Spur: grau, Staus farbig, Ende der Route bei Ziel
            Canvas(Modifier.fillMaxHeight().width(58.dp)) {
                val cx = size.width - 12.dp.toPx()
                val tw = 7.dp.toPx()
                val topM = minOf(along + rangeM, end)
                val yTop = size.height * (1f - ((topM - along) / rangeM).toFloat())
                drawRoundRect(Color(0xFF8E8E93).copy(alpha = 0.35f), Offset(cx - tw / 2, yTop), Size(tw, size.height - yTop), CornerRadius(tw / 2))
                items.filter { it.endM > it.alongM }.forEach { it2 ->
                    val y1 = size.height * (1f - ((minOf(it2.endM, along + rangeM) - along) / rangeM).toFloat().coerceIn(0f, 1f))
                    val y2 = size.height * (1f - ((maxOf(it2.alongM, along) - along) / rangeM).toFloat().coerceIn(0f, 1f))
                    drawRoundRect(Color(it2.color), Offset(cx - tw / 2, y1), Size(tw, (y2 - y1).coerceAtLeast(4.dp.toPx())), CornerRadius(tw / 2))
                }
                // du (unten)
                drawCircle(Color(0xFF0A84FF), 6.dp.toPx(), Offset(cx, size.height - 3.dp.toPx()))
                drawCircle(Color.White, 2.5.dp.toPx(), Offset(cx, size.height - 3.dp.toPx()))
            }
            // Symbole mit Entfernung (überlappende zusammenrücken)
            var lastY = Float.MAX_VALUE
            items.forEach { it2 ->
                val yy = y(it2.alongM)
                val yPx = yy.value
                if (lastY - yPx < 34f && lastY != Float.MAX_VALUE) return@forEach
                lastY = yPx
                val sym = it2.symbol.ifBlank { "●" }
                Column(
                    Modifier.offset(x = 0.dp, y = yy - 30.dp).width(40.dp).clip(RoundedCornerShape(8.dp)).clickable { onTap(it2) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier.size(24.dp).clip(CircleShape).background(if (it2.symbol.isBlank()) Color(it2.color) else Color.White),
                        contentAlignment = Alignment.Center,
                    ) { Text(if (it2.symbol.isBlank()) "" else sym, fontSize = 13.sp) }
                    Text(
                        fmtKmShort(it2.alongM - along), color = pal.text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            Text("${rangeKm} km", color = pal.sub, fontSize = 9.sp, modifier = Modifier.align(Alignment.TopEnd).padding(end = 2.dp).offset(y = (-8).dp))
        }
    }
}

private fun fmtKmShort(m: Double): String = when {
    m < 950 -> "${((m / 100).roundToInt() * 100).coerceAtLeast(100)} m"
    m < 10_000 -> String.format(java.util.Locale.GERMANY, "%.1f km", m / 1000)
    else -> "${(m / 1000).roundToInt()} km"
}

/** Infokarte zu einem angetippten Ereignis */
@Composable
fun BarItemCard(it2: BarItem, along: Double, onClose: () -> Unit) {
    val pal = LocalPal.current
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = pal.card, shadowElevation = 10.dp) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(it2.color)), contentAlignment = Alignment.Center) {
                Text(it2.symbol.ifBlank { "!" }, fontSize = 16.sp, color = Color.White)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("${it2.title} · in ${fmtKm(it2.alongM - along)}", color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                if (it2.detail.isNotBlank()) Text(it2.detail, color = pal.sub, fontSize = 13.sp)
            }
            Text("✕", color = pal.sub, fontSize = 18.sp, modifier = Modifier.clip(CircleShape).clickable(onClick = onClose).padding(6.dp))
        }
    }
}
