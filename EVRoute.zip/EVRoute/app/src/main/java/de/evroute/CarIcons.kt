package de.evroute

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Abbiegepfeile und Spurbilder als Bitmaps für Android Auto */
object CarIcons {
    private fun angleOf(mod: String?): Double = when (mod) {
        "slight right" -> 40.0
        "right" -> 90.0
        "sharp right" -> 135.0
        "slight left" -> -40.0
        "left" -> -90.0
        "sharp left" -> -135.0
        "uturn" -> 180.0
        else -> 0.0
    }

    private fun laneAngle(d: String): Double = when (d) {
        "SLIGHT_RIGHT" -> 40.0
        "RIGHT" -> 90.0
        "SHARP_RIGHT" -> 135.0
        "SLIGHT_LEFT" -> -40.0
        "LEFT" -> -90.0
        "SHARP_LEFT" -> -135.0
        "U_TURN" -> 180.0
        else -> 0.0
    }

    private fun stroke(w: Float, color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = w
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        this.color = color
    }

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }

    /** Pfeil von unten Mitte nach oben, dann in Richtung deg; Ursprung (ox, oy), Größe s */
    private fun arrow(c: Canvas, ox: Float, oy: Float, w: Float, h: Float, deg: Double, color: Int, sw: Float) {
        if (deg == 180.0) {
            val p = Path().apply {
                moveTo(ox + w * 0.64f, oy + h * 0.92f); lineTo(ox + w * 0.64f, oy + h * 0.42f)
                cubicTo(ox + w * 0.64f, oy + h * 0.12f, ox + w * 0.30f, oy + h * 0.12f, ox + w * 0.30f, oy + h * 0.42f)
                lineTo(ox + w * 0.30f, oy + h * 0.55f)
            }
            c.drawPath(p, stroke(sw, color))
            head(c, ox + w * 0.30f, oy + h * 0.55f, 180.0, h * 0.16f, color)
            return
        }
        val a = deg * PI / 180
        val dx = sin(a).toFloat()
        val dy = -cos(a).toFloat()
        val mx = ox + w * 0.5f
        val my = oy + h * 0.56f
        val ex = mx + dx * h * 0.28f
        val ey = my + dy * h * 0.28f
        val p = Path().apply { moveTo(ox + w * 0.5f, oy + h * 0.94f); lineTo(mx, my); lineTo(ex, ey) }
        c.drawPath(p, stroke(sw, color))
        head(c, ex, ey, deg, h * 0.17f, color)
    }

    private fun head(c: Canvas, ex: Float, ey: Float, deg: Double, size: Float, color: Int) {
        val a = deg * PI / 180
        val dx = sin(a).toFloat()
        val dy = -cos(a).toFloat()
        val nx = -dy
        val ny = dx
        val p = Path().apply {
            moveTo(ex + dx * size, ey + dy * size)
            lineTo(ex + nx * size * 0.85f, ey + ny * size * 0.85f)
            lineTo(ex - nx * size * 0.85f, ey - ny * size * 0.85f)
            close()
        }
        c.drawPath(p, fill(color))
    }

    fun maneuver(type: String, mod: String?, px: Int = 128): Bitmap {
        val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val s = px.toFloat()
        val sw = s * 0.11f
        when {
            type == "arrive" || type == "via" -> {
                c.drawCircle(s * 0.5f, s * 0.36f, s * 0.2f, stroke(sw * 0.9f, Color.WHITE))
                c.drawCircle(s * 0.5f, s * 0.36f, s * 0.07f, fill(Color.WHITE))
                c.drawLine(s * 0.5f, s * 0.58f, s * 0.5f, s * 0.92f, stroke(sw, Color.WHITE))
            }
            type == "charge" -> {
                val p = Path().apply {
                    moveTo(s * 0.58f, s * 0.06f); lineTo(s * 0.24f, s * 0.56f); lineTo(s * 0.47f, s * 0.56f)
                    lineTo(s * 0.40f, s * 0.94f); lineTo(s * 0.77f, s * 0.40f); lineTo(s * 0.53f, s * 0.40f); close()
                }
                c.drawPath(p, fill(Color.WHITE))
            }
            type == "roundabout" || type == "rotary" || type == "roundabout turn" -> {
                val cx = s * 0.5f
                val cy = s * 0.46f
                val r = s * 0.17f
                c.drawCircle(cx, cy, r, stroke(sw * 0.7f, Color.argb(140, 255, 255, 255)))
                c.drawLine(cx, s * 0.95f, cx, cy + r, stroke(sw, Color.WHITE))
                val a = angleOf(mod) * PI / 180
                val dx = sin(a).toFloat()
                val dy = -cos(a).toFloat()
                val ex = cx + dx * (r + s * 0.2f)
                val ey = cy + dy * (r + s * 0.2f)
                c.drawLine(cx + dx * r, cy + dy * r, ex, ey, stroke(sw, Color.WHITE))
                head(c, ex, ey, angleOf(mod), s * 0.17f, Color.WHITE)
            }
            else -> arrow(c, 0f, 0f, s, s, angleOf(mod), Color.WHITE, sw)
        }
        return b
    }

    /** Spurbild: alle Spuren nebeneinander, empfohlene weiß, andere grau */
    fun lanes(lanes: List<Lane>, h: Int = 96): Bitmap {
        val lw = (h * 0.8f).toInt()
        val b = Bitmap.createBitmap(lw * lanes.size, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        lanes.forEachIndexed { i, lane ->
            val ox = (i * lw).toFloat()
            if (lane.follow != null) c.drawRoundRect(RectF(ox + 2, 2f, ox + lw - 2, h - 2f), 10f, 10f, fill(Color.argb(40, 255, 255, 255)))
            val sw = lw * 0.12f
            lane.directions.filter { it != lane.follow }.forEach { arrow(c, ox, 0f, lw.toFloat(), h.toFloat(), laneAngle(it), Color.argb(90, 255, 255, 255), sw) }
            lane.follow?.let { arrow(c, ox, 0f, lw.toFloat(), h.toFloat(), laneAngle(it), Color.WHITE, sw * 1.15f) }
            if (i > 0) c.drawLine(ox, h * 0.1f, ox, h * 0.9f, stroke(3f, Color.argb(110, 255, 255, 255)))
        }
        return b
    }
}
