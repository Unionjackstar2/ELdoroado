package de.evroute

import android.app.Presentation
import android.content.Intent
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.SystemClock
import android.view.Choreographer
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.DateTimeWithZone
import androidx.car.app.model.Distance
import androidx.car.app.model.ItemList
import androidx.car.app.model.Row
import androidx.car.app.model.SearchTemplate
import androidx.car.app.model.Template
import androidx.car.app.navigation.NavigationManager
import androidx.car.app.navigation.NavigationManagerCallback
import androidx.car.app.navigation.model.LaneDirection
import androidx.car.app.navigation.model.Maneuver
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.navigation.model.PlaceListNavigationTemplate
import androidx.car.app.navigation.model.RoutePreviewNavigationTemplate
import androidx.car.app.navigation.model.RoutingInfo
import androidx.car.app.navigation.model.Step
import androidx.car.app.navigation.model.TravelEstimate
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.PropertyFactory.iconImage
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.Point
import java.util.TimeZone
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.roundToInt

// ---------------- Einstieg für Android Auto ----------------

class EvCarAppService : CarAppService() {
    // Private App: jeden Host zulassen (für den Play Store müsste man die Hosts einschränken)
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = EvCarSession()
}

class EvCarSession : Session(), DefaultLifecycleObserver {
    lateinit var map: CarMap
        private set
    private var navStarted = false
    private val scope = MainScope()

    override fun onCreateScreen(intent: Intent): Screen {
        lifecycle.addObserver(this)
        map = CarMap(carContext)
        LocationHub.acquire(carContext, "car")
        if (Settings.state.value.obdAuto) Obd.acquire("car")

        // Navigation mit dem Auto abstimmen (Start/Ende, „Navigation beenden“ vom Auto aus)
        val nm = carContext.getCarService(NavigationManager::class.java)
        nm.setNavigationManagerCallback(object : NavigationManagerCallback {
            override fun onStopNavigation() { NavSession.stop(carContext) }
        })
        scope.launch {
            NavSession.state.collect { s ->
                if (s.navigating && !navStarted) { runCatching { nm.navigationStarted() }; navStarted = true }
                if (!s.navigating && navStarted) { runCatching { nm.navigationEnded() }; navStarted = false }
            }
        }
        return CarHomeScreen(carContext, this)
    }

    override fun onDestroy(owner: LifecycleOwner) {
        scope.cancel()
        LocationHub.release("car")
        Obd.release("car")
        map.teardown()
    }
}

// ---------------- Karte auf dem Autodisplay ----------------

/**
 * Zeichnet die MapLibre-Karte auf die Fläche, die Android Auto bereitstellt:
 * eine virtuelle Anzeige mit einer „Presentation“, in der die Karte läuft.
 */
class CarMap(private val ctx: CarContext) : SurfaceCallback {
    private var vd: VirtualDisplay? = null
    private var pres: Presentation? = null
    private var mapView: MapView? = null
    private var map: MapLibreMap? = null
    private var style: Style? = null
    private var dark = false
    private var w = 0
    private var h = 0
    private var visible = Rect()
    private val pred = Predictor()
    private var zoom = 15.5
    var follow = true
    private var lastRoutesId = 0
    private var job: Job? = null
    private var darkJob: Job? = null
    private val scope = MainScope()
    private var frameOn = false
    private var lastFrame = 0L

    init {
        ctx.getCarService(AppManager::class.java).setSurfaceCallback(this)
    }

    override fun onSurfaceAvailable(c: SurfaceContainer) {
        val surface = c.surface ?: return
        teardownView()
        w = c.width
        h = c.height
        visible = Rect(0, 0, w, h)
        val dm = ctx.getSystemService(DisplayManager::class.java)
        val display = dm.createVirtualDisplay("EVRouteCar", w, h, c.dpi, surface, DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY)
        vd = display
        val p = Presentation(ctx, display.display)
        pres = p
        val mv = MapView(p.context, MapLibreMapOptions.createFromAttributes(p.context).textureMode(true))
        mapView = mv
        mv.onCreate(null)
        p.setContentView(mv)
        p.show()
        mv.onStart()
        mv.onResume()
        mv.getMapAsync { m ->
            map = m
            m.uiSettings.isLogoEnabled = false
            m.uiSettings.isCompassEnabled = false
            m.uiSettings.isAttributionEnabled = true
            loadStyle()
        }
        startUpdates()
    }

    override fun onVisibleAreaChanged(r: Rect) { visible = Rect(r) }

    override fun onStableAreaChanged(r: Rect) {}

    override fun onSurfaceDestroyed(c: SurfaceContainer) { teardownView() }

    override fun onScroll(distanceX: Float, distanceY: Float) {
        follow = false
        map?.scrollBy(-distanceX, -distanceY)
    }

    override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {
        follow = false
        map?.moveCamera(CameraUpdateFactory.zoomBy(ln(scaleFactor.toDouble()) / ln(2.0)))
    }

    fun zoomBy(d: Double) {
        follow = false
        map?.easeCamera(CameraUpdateFactory.zoomBy(d), 300)
    }

    fun recenter() { follow = true; lastRoutesId = 0 }

    private fun loadStyle() {
        val m = map ?: return
        dark = ctx.isDarkMode
        style = null
        val set = Settings.state.value
        m.setStyle(Style.Builder().fromUri(if (dark) NIGHT_STYLE else DAY_STYLE)) { s ->
            setupStyle(ctx, s, dark, set.carColor)
            s.getLayerAs<SymbolLayer>("me")?.setProperties(iconImage(iconId(set.vehicle)))
            style = s
            lastRoutesId = 0
            refresh()
        }
    }

    private fun startUpdates() {
        job?.cancel()
        job = scope.launch {
            combine(NavSession.state, LocationHub.fix, Settings.state) { a, b, c -> Triple(a, b, c) }.collect { refresh() }
        }
        darkJob?.cancel()
        darkJob = scope.launch {
            while (true) {
                delay(2000)
                if (map != null && ctx.isDarkMode != dark) loadStyle()
            }
        }
        if (!frameOn) {
            frameOn = true
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    /** Route, Stopps, Staus, Abbiegepfeil, Verkehr und Vorausberechnung aktualisieren */
    private fun refresh() {
        val s = style ?: return
        val nav = NavSession.state.value
        val set = Settings.state.value
        val r = nav.route
        val p = nav.progress
        applyRoutes(s, nav.routes, nav.selected, nav.navigating, dark)
        applyStopsAndJams(s, r)
        applyTurnArrow(s, r, p, nav.navigating)
        applyProgress(s, r, p, nav.navigating, dark)
        val traffic = if (set.hasTomTom && set.showTraffic) TomTom.trafficTileUrl(set.tomtomKey.trim(), dark) else null
        if ((s.getSource("traffic") != null) != (traffic != null)) applyTraffic(s, traffic)

        val f = LocationHub.fix.value
        if (f != null) {
            val onRoute = nav.navigating && p != null && p.offRouteM < 30 && r != null
            val b = when {
                onRoute && f.speed > 1.5 -> p!!.routeBearing
                f.bearing != null && f.speed > 1.5 -> f.bearing.toDouble()
                else -> pred.bearingNow
            }
            pred.set(if (onRoute) p!!.snapped else f.pos, b, f.speed, f.elapsedNs, if (onRoute) r else null, if (onRoute) p!!.alongM else null, onRoute)
        }

        // Routenübersicht vor dem Start
        val id = System.identityHashCode(nav.routes)
        if (!nav.navigating && nav.routes.isNotEmpty() && id != lastRoutesId) {
            lastRoutesId = id
            follow = false
            fitRoutes(nav.routes)
        }
        if (nav.navigating && lastRoutesId != -1) { lastRoutesId = -1; follow = true }
    }

    private fun fitRoutes(routes: List<Route>) {
        val m = map ?: return
        val bb = LatLngBounds.Builder()
        var n = 0
        routes.forEach { r ->
            val step = (r.points.size / 200).coerceAtLeast(1)
            r.points.forEachIndexed { i, q -> if (i % step == 0 || i == r.points.lastIndex) { bb.include(LatLng(q.lat, q.lon)); n++ } }
        }
        if (n < 2) return
        m.easeCamera(
            CameraUpdateFactory.newLatLngBounds(bb.build(), visible.left + 40, visible.top + 40, (w - visible.right) + 40, (h - visible.bottom) + 40),
            700,
        )
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!frameOn) return
            Choreographer.getInstance().postFrameCallback(this)
            val now = System.nanoTime()
            if (now - lastFrame < 40_000_000L) return
            lastFrame = now
            val s = style ?: return
            val m = map ?: return
            if (!pred.ready) return
            val (pos, b, changed) = pred.frame(SystemClock.elapsedRealtimeNanos())
            if (changed || follow) {
                val feat = Feature.fromGeometry(Point.fromLngLat(pos.lon, pos.lat))
                feat.addNumberProperty("bearing", b)
                s.getSourceAs<GeoJsonSource>("me")?.setGeoJson(feat)
            }
            if (!follow) return
            val nav = NavSession.state.value
            val f = LocationHub.fix.value
            val navigating = nav.navigating
            val target = if (navigating) autoZoom((f?.speed ?: 0.0) * 3.6, nav.progress?.distToStepM ?: 1e9) else 15.5
            zoom += (target - zoom) * 0.04
            val vh = max(1, visible.height())
            val cam = CameraPosition.Builder()
                .target(LatLng(pos.lat, pos.lon))
                .zoom(zoom)
                .tilt(if (navigating) 50.0 else 0.0)
                .bearing(if (navigating) b else 0.0)
                .padding(
                    visible.left.toDouble(),
                    visible.top + if (navigating) vh * 0.38 else 0.0,
                    (w - visible.right).toDouble(),
                    (h - visible.bottom).toDouble(),
                )
                .build()
            m.moveCamera(CameraUpdateFactory.newCameraPosition(cam))
        }
    }

    private fun teardownView() {
        frameOn = false
        job?.cancel()
        darkJob?.cancel()
        runCatching { mapView?.onPause(); mapView?.onStop(); mapView?.onDestroy() }
        runCatching { pres?.dismiss() }
        runCatching { vd?.release() }
        mapView = null; pres = null; vd = null; map = null; style = null
    }

    fun teardown() {
        teardownView()
        scope.cancel()
    }
}

// ---------------- Hilfen für Vorlagen ----------------

private fun CarContext.icon(res: Int) = CarIcon.Builder(IconCompat.createWithResource(this, res)).build()

private fun bitmapIcon(b: android.graphics.Bitmap) = CarIcon.Builder(IconCompat.createWithBitmap(b)).build()

private fun distance(m: Double): Distance = when {
    m < 1000 -> Distance.create(((m / 10).roundToInt() * 10).toDouble(), Distance.UNIT_METERS)
    m < 10_000 -> Distance.create(m / 1000, Distance.UNIT_KILOMETERS_P1)
    else -> Distance.create((m / 1000).roundToInt().toDouble(), Distance.UNIT_KILOMETERS)
}

private fun maneuverType(st: Step0): Int {
    val m = st.mod
    return when (st.type) {
        "depart" -> Maneuver.TYPE_DEPART
        "arrive", "via", "charge" -> Maneuver.TYPE_DESTINATION
        "ferry" -> Maneuver.TYPE_FERRY_BOAT
        "roundabout", "rotary", "roundabout turn" -> Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CCW
        "on ramp" -> if (m?.contains("left") == true) Maneuver.TYPE_ON_RAMP_SLIGHT_LEFT else Maneuver.TYPE_ON_RAMP_SLIGHT_RIGHT
        "off ramp" -> if (m?.contains("left") == true) Maneuver.TYPE_OFF_RAMP_SLIGHT_LEFT else Maneuver.TYPE_OFF_RAMP_SLIGHT_RIGHT
        "fork" -> if (m?.contains("left") == true) Maneuver.TYPE_FORK_LEFT else Maneuver.TYPE_FORK_RIGHT
        "merge" -> Maneuver.TYPE_MERGE_SIDE_UNSPECIFIED
        else -> when (m) {
            "slight right" -> Maneuver.TYPE_TURN_SLIGHT_RIGHT
            "right" -> Maneuver.TYPE_TURN_NORMAL_RIGHT
            "sharp right" -> Maneuver.TYPE_TURN_SHARP_RIGHT
            "slight left" -> Maneuver.TYPE_TURN_SLIGHT_LEFT
            "left" -> Maneuver.TYPE_TURN_NORMAL_LEFT
            "sharp left" -> Maneuver.TYPE_TURN_SHARP_LEFT
            "uturn" -> Maneuver.TYPE_U_TURN_LEFT
            else -> Maneuver.TYPE_STRAIGHT
        }
    }
}

private typealias Step0 = de.evroute.Step

private fun laneShape(d: String): Int = when (d) {
    "SLIGHT_RIGHT" -> LaneDirection.SHAPE_SLIGHT_RIGHT
    "RIGHT" -> LaneDirection.SHAPE_NORMAL_RIGHT
    "SHARP_RIGHT" -> LaneDirection.SHAPE_SHARP_RIGHT
    "SLIGHT_LEFT" -> LaneDirection.SHAPE_SLIGHT_LEFT
    "LEFT" -> LaneDirection.SHAPE_NORMAL_LEFT
    "SHARP_LEFT" -> LaneDirection.SHAPE_SHARP_LEFT
    "U_TURN" -> LaneDirection.SHAPE_U_TURN_LEFT
    else -> LaneDirection.SHAPE_STRAIGHT
}

private fun carStep(ctx: CarContext, st: Step0, lanes: LaneSection?): Step {
    val man = Maneuver.Builder(maneuverType(st)).setIcon(bitmapIcon(CarIcons.maneuver(st.type, st.mod)))
    if (st.isRoundabout) man.setRoundaboutExitNumber((st.exit ?: 1).coerceAtLeast(1))
    val b = Step.Builder(st.bannerText()).setManeuver(man.build())
    if (st.road.isNotBlank()) b.setRoad(st.road)
    if (lanes != null) {
        lanes.lanes.forEach { l ->
            val lb = androidx.car.app.navigation.model.Lane.Builder()
            val dirs = l.directions.ifEmpty { listOf("STRAIGHT") }
            dirs.forEach { d -> lb.addDirection(LaneDirection.create(laneShape(d), d == l.follow)) }
            b.addLane(lb.build())
        }
        b.setLanesImage(bitmapIcon(CarIcons.lanes(lanes.lanes)))
    }
    return b.build()
}

private fun estimate(remainingM: Double, remainingS: Double): TravelEstimate =
    TravelEstimate.Builder(
        distance(remainingM),
        DateTimeWithZone.create(System.currentTimeMillis() + (remainingS * 1000).toLong(), TimeZone.getDefault()),
    ).setRemainingTimeSeconds(remainingS.toLong().coerceAtLeast(0)).build()

// ---------------- Startbild und Navigation ----------------

class CarHomeScreen(ctx: CarContext, private val session: EvCarSession) : Screen(ctx) {
    private var previewOpen = false
    private var lastWarn = ""
    private var lastOffer = false

    init {
        lifecycleScope.launch {
            var last = 0L
            combine(NavSession.state, NavSession.liveAlong) { s, a -> s to a }.collect { (s, _) ->
                // Vom Handy geplante Route: im Auto die Routenauswahl öffnen
                if (s.dest != null && !s.navigating && !previewOpen && (s.loading || s.routes.isNotEmpty())) {
                    previewOpen = true
                    screenManager.pushForResult(RoutePreviewScreen(carContext)) { previewOpen = false }
                }
                s.warning?.let { w ->
                    val key = "${w.title}${(w.distM / 1000).roundToInt()}"
                    if (!w.inside && w.distM < 1600 && key != lastWarn) {
                        lastWarn = key
                        CarToast.makeText(carContext, "${w.title} in ${fmtDistShort(w.distM)}", CarToast.LENGTH_LONG).show()
                    }
                }
                val now = System.currentTimeMillis()
                if (s.offer != null != lastOffer || now - last > 900) {
                    lastOffer = s.offer != null
                    last = now
                    invalidate()
                }
            }
        }
    }

    override fun onGetTemplate(): Template {
        val s = NavSession.state.value
        val map = session.map
        val strip = ActionStrip.Builder()
        if (s.navigating) {
            s.offer?.let { o ->
                strip.addAction(Action.Builder().setTitle("−${(o.savedS / 60).roundToInt()} min").setOnClickListener { NavSession.acceptOffer() }.build())
            }
            strip.addAction(
                Action.Builder().setTitle("Laden").setIcon(carContext.icon(R.drawable.ic_bolt))
                    .setOnClickListener { NavSession.openChargerSearch(); screenManager.push(ChargerScreen(carContext)) }.build(),
            )
            strip.addAction(Action.Builder().setTitle("Ende").setOnClickListener { NavSession.stop(carContext) }.build())
        } else {
            strip.addAction(
                Action.Builder().setTitle("Suche").setIcon(carContext.icon(R.drawable.ic_search))
                    .setOnClickListener { screenManager.push(CarSearchScreen(carContext)) }.build(),
            )
            strip.addAction(
                Action.Builder().setTitle("Ziele").setIcon(carContext.icon(R.drawable.ic_star))
                    .setOnClickListener { screenManager.push(CarPlacesScreen(carContext)) }.build(),
            )
        }
        val mapStrip = ActionStrip.Builder()
            .addAction(Action.Builder().setIcon(carContext.icon(R.drawable.ic_plus)).setOnClickListener { map.zoomBy(0.7) }.build())
            .addAction(Action.Builder().setIcon(carContext.icon(R.drawable.ic_minus)).setOnClickListener { map.zoomBy(-0.7) }.build())
            .addAction(Action.Builder().setIcon(carContext.icon(R.drawable.ic_locate)).setOnClickListener { map.recenter() }.build())
            .addAction(Action.PAN)
            .build()

        val b = NavigationTemplate.Builder().setActionStrip(strip.build()).setMapActionStrip(mapStrip)
            .setPanModeListener { inPan -> if (inPan) map.follow = false }
        val r = s.route
        val p = s.progress
        if (s.navigating) {
            if (r != null && p != null && !s.rerouting && !s.arrived) {
                val st = r.steps.getOrNull(p.stepIdx)
                if (st != null) {
                    val along = NavSession.liveAlong.value ?: p.alongM
                    val dist = ((r.stepAlongM.getOrNull(p.stepIdx) ?: along) - along).coerceAtLeast(0.0)
                    val lanes = findLaneSection(r, p, along, LocationHub.fix.value?.speed ?: 0.0)
                    val ri = RoutingInfo.Builder().setCurrentStep(carStep(carContext, st, lanes), distance(dist))
                    r.steps.getOrNull(p.stepIdx + 1)?.let { nx -> if (st.distanceM < 300) ri.setNextStep(carStep(carContext, nx, null)) }
                    b.setNavigationInfo(ri.build())
                }
                b.setDestinationTravelEstimate(estimate(p.remainingM, p.remainingS))
            } else {
                b.setNavigationInfo(RoutingInfo.Builder().setLoading(true).build())
            }
        }
        b.setBackgroundColor(CarColor.SECONDARY)
        return b.build()
    }
}

// ---------------- Ziele: Favoriten und Zuletzt ----------------

class CarPlacesScreen(ctx: CarContext) : Screen(ctx) {
    override fun onGetTemplate(): Template {
        val list = ItemList.Builder()
        val favs = Favorites.items.value
        val items = buildList {
            favs.firstOrNull { it.kind == FavKind.HOME }?.let { add("Zuhause" to it.place) }
            favs.firstOrNull { it.kind == FavKind.WORK }?.let { add("Arbeit" to it.place) }
            favs.filter { it.kind == FavKind.OTHER }.forEach { add(it.label to it.place) }
            Recents.items.value.forEach { p -> if (none { it.second.name == p.name }) add(p.title to p) }
        }.take(6)
        items.forEach { (label, place) ->
            list.addItem(
                Row.Builder().setTitle(label).addText(place.subtitle.ifBlank { place.name })
                    .setOnClickListener { NavSession.plan(place); screenManager.pop() }.build(),
            )
        }
        if (items.isEmpty()) list.setNoItemsMessage("Noch keine Favoriten – am Handy anlegen")
        return PlaceListNavigationTemplate.Builder()
            .setTitle("Ziele")
            .setHeaderAction(Action.BACK)
            .setItemList(list.build())
            .build()
    }
}

// ---------------- Suche ----------------

class CarSearchScreen(ctx: CarContext) : Screen(ctx) {
    private var results: List<Place> = emptyList()
    private var loading = false
    private var job: Job? = null

    override fun onGetTemplate(): Template {
        val list = ItemList.Builder()
        results.take(6).forEach { p ->
            list.addItem(
                Row.Builder().setTitle(p.title).addText(p.subtitle.ifBlank { " " })
                    .setOnClickListener { Recents.add(p); NavSession.plan(p); screenManager.pop() }.build(),
            )
        }
        if (results.isEmpty()) list.setNoItemsMessage("Ort oder Adresse eingeben")
        val b = SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
            override fun onSearchTextChanged(text: String) { search(text, 500) }
            override fun onSearchSubmitted(text: String) { search(text, 0) }
        }).setHeaderAction(Action.BACK).setSearchHint("Ziel suchen").setShowKeyboardByDefault(true)
        if (loading) b.setLoading(true) else b.setItemList(list.build())
        return b.build()
    }

    private fun search(q: String, wait: Long) {
        job?.cancel()
        if (q.trim().length < 3) return
        job = lifecycleScope.launch {
            delay(wait)
            loading = true
            invalidate()
            results = runCatching { Geocode.search(q.trim(), LocationHub.fix.value?.pos) }.getOrDefault(emptyList())
            loading = false
            invalidate()
        }
    }
}

// ---------------- Routenauswahl ----------------

class RoutePreviewScreen(ctx: CarContext) : Screen(ctx) {
    init {
        lifecycleScope.launch {
            NavSession.state.collect { s ->
                if (s.navigating || s.dest == null) { setResult(true); screenManager.pop() } else invalidate()
            }
        }
    }

    override fun onGetTemplate(): Template {
        val s = NavSession.state.value
        val b = RoutePreviewNavigationTemplate.Builder()
            .setTitle(s.dest?.title ?: "Route")
            .setHeaderAction(Action.BACK)
        if (s.loading || s.routes.isEmpty()) {
            b.setLoading(true)
        } else {
            val list = ItemList.Builder().setOnSelectedListener { i -> NavSession.select(i) }.setSelectedIndex(s.selected.coerceIn(0, s.routes.lastIndex))
            s.routes.forEach { r ->
                val ev = buildList {
                    if (r.stops.isNotEmpty()) add("${r.stops.size} Ladestopp" + if (r.stops.size > 1) "s" else "")
                    r.arrivalSoc?.let { add("Ziel ${fmtPct(it)}") }
                    if (r.trafficDelayS > 120) add("Stau +${fmtDuration(r.trafficDelayS)}")
                }.joinToString(" · ")
                val row = Row.Builder().setTitle("${fmtDuration(r.durationS)}" + if (r.tag.isNotBlank()) " · ${r.tag}" else "")
                    .addText("${fmtKm(r.distanceM)} · Ankunft ${fmtEta(r.durationS)}")
                if (ev.isNotBlank()) row.addText(ev)
                list.addItem(row.build())
            }
            b.setItemList(list.build())
            b.setNavigateAction(
                Action.Builder().setTitle("Los").setBackgroundColor(CarColor.GREEN)
                    .setOnClickListener { NavSession.start(carContext) }.build(),
            )
        }
        return b.build()
    }
}

// ---------------- Ladestationen unterwegs ----------------

class ChargerScreen(ctx: CarContext) : Screen(ctx) {
    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                if (NavSession.state.value.chargerSearch != null) NavSession.closeChargerSearch()
            }
        })
        lifecycleScope.launch {
            NavSession.state.collect { s -> if (s.chargerSearch == null) screenManager.pop() else invalidate() }
        }
    }

    override fun onGetTemplate(): Template {
        val s = NavSession.state.value
        val cs = s.chargerSearch
        val here = s.progress?.alongM ?: 0.0
        val b = PlaceListNavigationTemplate.Builder().setTitle("Ladestationen voraus").setHeaderAction(Action.BACK)
        if (cs == null || cs.loading) {
            b.setLoading(true)
        } else {
            val list = ItemList.Builder()
            cs.hits.take(6).forEach { hit ->
                val a = hit.availId?.let { s.hitAvailability[it] }
                val free = if (a != null && a.known) " · ${a.available}/${a.total} frei" else ""
                list.addItem(
                    Row.Builder().setTitle(hit.name)
                        .addText("in ${fmtKm(hit.alongM - here)} · ${hit.powerKw.roundToInt()} kW$free")
                        .setOnClickListener { NavSession.pickCharger(hit) }.build(),
                )
            }
            if (cs.hits.isEmpty()) list.setNoItemsMessage(cs.error ?: "Keine Ladestationen gefunden")
            b.setItemList(list.build())
        }
        return b.build()
    }
}
