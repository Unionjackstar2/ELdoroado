package de.evroute

import android.Manifest
import android.app.Application
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.maplibre.android.MapLibre

class EvRouteApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.init(this)
        BuildConfigLite.version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: "?"
        MapLibre.getInstance(this)
        // Anfragen der Karte an TomTom bekommen automatisch den Key angehängt (Kacheln, Schriften, Symbole)
        runCatching {
            val client = okhttp3.OkHttpClient.Builder().addInterceptor { chain ->
                var req = chain.request()
                val url = req.url
                if (url.host == "api.tomtom.com" && url.queryParameter("key") == null) {
                    val k = Settings.state.value.tomtomKey.trim()
                    if (k.isNotBlank()) req = req.newBuilder().url(url.newBuilder().addQueryParameter("key", k).build()).build()
                }
                chain.proceed(req)
            }.build()
            org.maplibre.android.module.http.HttpRequestUtil.setOkHttpClient(client)
        }
        Settings.init(this)
        Recents.init(this)
        ApiCounter.init(this)
        Favorites.init(this)
        KnownOperators.init(this)
        Obd.init(this)
        Learner.init(this)
        TripRecorder.init(this)
        NavSession.init(this)
    }
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        LocationHub.acquire(this, "ui")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { EvRouteApp(vm) }
        val list = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(list.toTypedArray())
    }

    override fun onStart() {
        super.onStart()
        LocationHub.acquire(this, "ui")
        if (Settings.state.value.obdAuto) Obd.acquire("ui")
    }

    override fun onStop() {
        LocationHub.release("ui")
        Obd.release("ui")
        super.onStop()
    }
}

enum class SearchMode { DEST, HOME, WORK, FAV, VIA }

class MainViewModel : ViewModel() {
    data class LongPress(val pos: LatLon, val name: String? = null)

    data class Ui(
        val query: String = "",
        val suggestions: List<Place> = emptyList(),
        val searching: Boolean = false,
        val searchActive: Boolean = false,
        val showSettings: Boolean = false,
        val follow: Boolean = true,
        val recenter: Int = 0,
        val mode: SearchMode = SearchMode.DEST,
        val longPress: LongPress? = null,
        val editFav: Favorite? = null,
        val sheetPx: Int = 0,
        val showObd: Boolean = false,
        val showTrips: Boolean = false,
    )

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()
    private var searchJob: Job? = null

    fun onQuery(q: String) {
        _ui.update { it.copy(query = q) }
        searchJob?.cancel()
        if (q.trim().length < 3) {
            _ui.update { it.copy(suggestions = emptyList(), searching = false) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(350)
            _ui.update { it.copy(searching = true) }
            val r = runCatching { Geocode.search(q.trim(), LocationHub.fix.value?.pos) }.getOrDefault(emptyList())
            _ui.update { it.copy(suggestions = r, searching = false) }
        }
    }

    fun setSearchActive(b: Boolean) { _ui.update { it.copy(searchActive = b) } }

    fun pick(p: Place) {
        val mode = _ui.value.mode
        searchJob?.cancel()
        _ui.update { it.copy(query = "", suggestions = emptyList(), searchActive = false, searching = false, mode = SearchMode.DEST, longPress = null) }
        when (mode) {
            SearchMode.DEST -> { Recents.add(p); NavSession.plan(p) }
            SearchMode.HOME -> Favorites.set(FavKind.HOME, p)
            SearchMode.WORK -> Favorites.set(FavKind.WORK, p)
            SearchMode.FAV -> Favorites.set(FavKind.OTHER, p)
            SearchMode.VIA -> { Recents.add(p); NavSession.addVia(p) }
        }
    }

    fun startSearch(mode: SearchMode) {
        _ui.update { it.copy(mode = mode, query = "", suggestions = emptyList(), searchActive = true, longPress = null) }
    }

    fun cancelSearch() {
        searchJob?.cancel()
        _ui.update { it.copy(mode = SearchMode.DEST, query = "", suggestions = emptyList(), searchActive = false, searching = false) }
    }

    // ----- Langes Drücken auf die Karte -----

    fun onLongPress(ll: LatLon) {
        _ui.update { it.copy(longPress = LongPress(ll)) }
        viewModelScope.launch {
            val name = runCatching { Reverse.name(ll) }.getOrDefault("Markierter Ort")
            _ui.update { s -> if (s.longPress?.pos == ll) s.copy(longPress = LongPress(ll, name)) else s }
        }
    }

    fun closeLongPress() { _ui.update { it.copy(longPress = null) } }

    private fun longPressPlace(): Place? = _ui.value.longPress?.let { Place(it.name ?: "Markierter Ort", it.pos) }

    fun longPressRoute() { longPressPlace()?.let { closeLongPress(); NavSession.plan(it) } }

    fun longPressVia() { longPressPlace()?.let { closeLongPress(); NavSession.addVia(it) } }

    fun longPressFavorite() { longPressPlace()?.let { closeLongPress(); Favorites.set(FavKind.OTHER, it) } }

    // ----- Favoriten bearbeiten -----

    fun editFavorite(f: Favorite?) { _ui.update { it.copy(editFav = f) } }

    fun setSheetPx(px: Int) { _ui.update { it.copy(sheetPx = px) } }

    fun openObd() { Obd.acquire("screen"); _ui.update { it.copy(showObd = true) } }

    fun closeObd() { Obd.release("screen"); _ui.update { it.copy(showObd = false) } }

    fun openTrips() { _ui.update { it.copy(showTrips = true) } }

    fun closeTrips() { _ui.update { it.copy(showTrips = false) } }

    fun onGesture() { _ui.update { it.copy(follow = false) } }

    fun recenter() { _ui.update { it.copy(follow = true, recenter = it.recenter + 1) } }

    fun openSettings() { _ui.update { it.copy(showSettings = true) } }

    fun closeSettings() { _ui.update { it.copy(showSettings = false) } }

    /** Tippen auf eine graue Alternativroute wählt sie aus */
    fun onMapTap(ll: LatLon, metersPerPx: Double) {
        if (_ui.value.longPress != null) closeLongPress()
        val s = NavSession.state.value
        if (s.navigating || s.routes.size < 2) return
        var best = -1
        var bd = Double.MAX_VALUE
        s.routes.forEachIndexed { i, r ->
            if (i == s.selected) return@forEachIndexed
            for (k in 0 until r.points.size - 1) {
                val d = distToSeg(ll, r.points[k], r.points[k + 1])
                if (d < bd) { bd = d; best = i }
            }
        }
        if (best >= 0 && bd < 28 * metersPerPx) NavSession.select(best)
    }
}
