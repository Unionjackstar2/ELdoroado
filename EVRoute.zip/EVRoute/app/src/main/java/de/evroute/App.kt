package de.evroute

import android.Manifest
import android.app.Application
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.maplibre.android.MapLibre

class EvRouteApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        MapLibre.getInstance(this)
        Settings.init(this)
        Recents.init(this)
        NavSession.init(this)
    }
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        LocationHub.acquire(this, "ui")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { EvRouteApp(vm) }
        val list = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(list.toTypedArray())
    }

    override fun onStart() {
        super.onStart()
        LocationHub.acquire(this, "ui")
    }

    override fun onStop() {
        LocationHub.release("ui")
        super.onStop()
    }
}

class MainViewModel : ViewModel() {
    data class Ui(
        val query: String = "",
        val suggestions: List<Place> = emptyList(),
        val searching: Boolean = false,
        val searchActive: Boolean = false,
        val showSettings: Boolean = false,
        val follow: Boolean = true,
        val recenter: Int = 0,
    )

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()
    private var searchJob: Job? = null

    fun onQuery(q: String) {
        _ui.update { it.copy(query = q) }
        searchJob?.cancel()
        if (q.trim().length < 3) {
            _ui.update { it.copy(suggestions = emptyList(), searching = false) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(350)
            _ui.update { it.copy(searching = true) }
            val r = runCatching { Geocode.search(q.trim(), LocationHub.fix.value?.pos) }.getOrDefault(emptyList())
            _ui.update { it.copy(suggestions = r, searching = false) }
        }
    }

    fun setSearchActive(b: Boolean) { _ui.update { it.copy(searchActive = b) } }

    fun pick(p: Place) {
        Recents.add(p)
        searchJob?.cancel()
        _ui.update { it.copy(query = "", suggestions = emptyList(), searchActive = false, searching = false) }
        NavSession.plan(p)
    }

    fun onGesture() { _ui.update { it.copy(follow = false) } }

    fun recenter() { _ui.update { it.copy(follow = true, recenter = it.recenter + 1) } }

    fun openSettings() { _ui.update { it.copy(showSettings = true) } }

    fun closeSettings() { _ui.update { it.copy(showSettings = false) } }

    /** Tippen auf eine graue Alternativroute wählt sie aus */
    fun onMapTap(ll: LatLon, metersPerPx: Double) {
        val s = NavSession.state.value
        if (s.navigating || s.routes.size < 2) return
        var best = -1
        var bd = Double.MAX_VALUE
        s.routes.forEachIndexed { i, r ->
            if (i == s.selected) return@forEachIndexed
            for (k in 0 until r.points.size - 1) {
                val d = distToSeg(ll, r.points[k], r.points[k + 1])
                if (d < bd) { bd = d; best = i }
            }
        }
        if (best >= 0 && bd < 28 * metersPerPx) NavSession.select(best)
    }
}
