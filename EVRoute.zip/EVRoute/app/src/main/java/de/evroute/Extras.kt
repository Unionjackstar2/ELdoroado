@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package de.evroute

import androidx.compose.animation.core.animate
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt

// ---------------- Favoriten-Leiste in der Suche ----------------

@Composable
fun FavoritesRow(vm: MainViewModel) {
    val pal = LocalPal.current
    val favs by Favorites.items.collectAsState()
    val home = favs.firstOrNull { it.kind == FavKind.HOME }
    val work = favs.firstOrNull { it.kind == FavKind.WORK }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        FavChip(Icons.Filled.Home, pal.blue, "Zuhause", if (home == null) "Festlegen" else null,
            onClick = { if (home != null) vm.pick(home.place) else vm.startSearch(SearchMode.HOME) },
            onLong = { home?.let { vm.editFavorite(it) } })
        FavChip(Icons.Filled.Work, Color(0xFF8E5A2B), "Arbeit", if (work == null) "Festlegen" else null,
            onClick = { if (work != null) vm.pick(work.place) else vm.startSearch(SearchMode.WORK) },
            onLong = { work?.let { vm.editFavorite(it) } })
        favs.filter { it.kind == FavKind.OTHER }.forEach { f ->
            FavChip(Icons.Filled.Star, Color(0xFFFF9F0A), f.label, null, onClick = { vm.pick(f.place) }, onLong = { vm.editFavorite(f) })
        }
        FavChip(Icons.Filled.Add, pal.sub, "Hinzufügen", null, onClick = { vm.startSearch(SearchMode.FAV) }, onLong = {})
    }
}

@Composable
private fun FavChip(icon: ImageVector, color: Color, label: String, sub: String?, onClick: () -> Unit, onLong: () -> Unit) {
    val pal = LocalPal.current
    Column(
        Modifier.width(68.dp).clip(RoundedCornerShape(12.dp)).combinedClickable(onClick = onClick, onLongClick = onLong).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = color, modifier = Modifier.size(24.dp))
        }
        Text(label, color = pal.text, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(sub ?: " ", color = pal.sub, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun FavEditDialog(f: Favorite, onClose: () -> Unit) {
    var name by remember(f.id) { mutableStateOf(f.label) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Favorit bearbeiten") },
        text = {
            Column {
                Text(f.place.name, fontSize = 13.sp, maxLines = 2)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = { Favorites.rename(f.id, name.ifBlank { f.label }); onClose() }) { Text("Speichern") }
        },
        dismissButton = {
            TextButton(onClick = { Favorites.remove(f.id); onClose() }) { Text("Löschen", color = Color(0xFFFF3B30)) }
        },
    )
}

// ---------------- Langes Drücken auf die Karte ----------------

@Composable
fun LongPressCard(lp: MainViewModel.LongPress, canAddStop: Boolean, vm: MainViewModel) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 24.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Place, null, tint = pal.red)
                Spacer(Modifier.width(8.dp))
                Text(
                    lp.name ?: "Adresse wird gesucht …", color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                )
                CloseDot(vm::closeLongPress)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = vm::longPressRoute, shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                ) { Text("Route", fontWeight = FontWeight.Bold) }
                if (canAddStop) {
                    Button(
                        onClick = vm::longPressVia, shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = pal.field, contentColor = pal.text),
                    ) { Text("Als Stopp") }
                }
                Button(
                    onClick = vm::longPressFavorite, shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.field, contentColor = pal.text),
                ) { Text("Favorit") }
            }
        }
    }
}

@Composable
fun CloseDot(onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(32.dp).clip(CircleShape).background(pal.field).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(Icons.Filled.Close, "Schließen", tint = pal.sub, modifier = Modifier.size(18.dp)) }
}

// ---------------- Ziehbares Routenfenster (3 Stufen wie bei Apple Maps) ----------------

@Composable
fun RouteSheet(nav: NavSession.State, settings: AppSettings, screenH: Dp, vm: MainViewModel, onGo: () -> Unit) {
    val pal = LocalPal.current
    val density = LocalDensity.current
    val peek = with(density) { 150.dp.toPx() }
    val half = with(density) { (screenH * 0.50f).toPx() }
    val full = with(density) { (screenH * 0.86f).toPx() }
    var h by remember { mutableFloatStateOf(half) }
    LaunchedEffect(Unit) { vm.setSheetPx(half.toInt()) }
    val dragState = rememberDraggableState { delta -> h = (h - delta).coerceIn(peek, full) }
    val favs by Favorites.items.collectAsState()
    val dest = nav.dest
    val isFav = dest != null && favs.any { haversine(it.place.pos, dest.pos) < 30 }
    val r = nav.route

    GlassCard(Modifier.fillMaxWidth().height(with(density) { h.toDp() }), corner = 26.dp) {
        // Griff + Kopf: hier wird gezogen
        Column(
            Modifier.fillMaxWidth()
                .draggable(
                    state = dragState,
                    orientation = Orientation.Vertical,
                    onDragStopped = { v ->
                        val stops = listOf(peek, half, full)
                        val target = when {
                            v < -1200f -> stops.firstOrNull { it > h + 1 } ?: full
                            v > 1200f -> stops.lastOrNull { it < h - 1 } ?: peek
                            else -> stops.minByOrNull { abs(it - h) } ?: half
                        }
                        animate(h, target, initialVelocity = -v) { value, _ -> h = value }
                        vm.setSheetPx(target.toInt())
                    },
                )
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 6.dp),
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(pal.sub.copy(alpha = 0.5f)))
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    dest?.title ?: "", color = pal.text, fontSize = 21.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                )
                Box(
                    Modifier.size(32.dp).clip(CircleShape).background(pal.field).clickable {
                        if (dest == null) return@clickable
                        if (isFav) favs.filter { haversine(it.place.pos, dest.pos) < 30 }.forEach { Favorites.remove(it.id) }
                        else Favorites.set(FavKind.OTHER, dest)
                    },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder, "Favorit",
                        tint = if (isFav) Color(0xFFFF9F0A) else pal.sub, modifier = Modifier.size(18.dp),
                    )
                }
                Spacer(Modifier.width(8.dp))
                CloseDot { NavSession.clear() }
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    if (nav.loading) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Berechne …", color = pal.sub, fontSize = 15.sp)
                        }
                    } else if (r != null) {
                        Text(fmtDuration(r.durationS), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        val extra = buildList {
                            add("Ankunft ${fmtEta(r.durationS)}")
                            if (r.stops.isNotEmpty()) add("⚡ ${r.stops.size}")
                            r.arrivalSoc?.let { add("Ziel ${fmtPct(it)}") }
                        }.joinToString(" · ")
                        Text(extra, color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } else {
                        Text(nav.error ?: "", color = pal.red, fontSize = 14.sp, maxLines = 2)
                    }
                }
                Button(
                    onClick = onGo,
                    enabled = r != null && !nav.loading,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.green, contentColor = Color.White),
                    modifier = Modifier.height(46.dp),
                ) { Text("Los", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            }
        }
        // Inhalt: scrollt
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
            Spacer(Modifier.height(6.dp))
            SocStartRow(settings)
            Spacer(Modifier.height(10.dp))
            StopsList(nav, vm)
            Spacer(Modifier.height(10.dp))
            nav.error?.let { Text(it, color = pal.red, modifier = Modifier.padding(vertical = 6.dp)) }
            nav.note?.let { Text(it, color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp)) }
            r?.note?.let { Text(it, color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp)) }
            val fastest = nav.routes.minOfOrNull { it.durationS } ?: 0.0
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                nav.routes.forEachIndexed { i, rt ->
                    RouteRow(rt, selected = i == nav.selected, deltaS = rt.durationS - fastest) { NavSession.select(i) }
                }
            }
            if (nav.routes.size == 1 && !nav.loading && nav.vias.isEmpty()) {
                Text("Keine weiteren Alternativen gefunden", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
            r?.let { RouteDetails(it, nav.availability) }
            val off by OfflineMaps.state.collectAsState()
            if (r != null) {
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when {
                            off.running -> "Offline-Karte: ${off.percent} %"
                            off.done -> "Offline-Karte gespeichert"
                            else -> "Offline-Karte: nicht gespeichert"
                        },
                        color = pal.sub, fontSize = 13.sp, modifier = Modifier.weight(1f),
                    )
                    if (!off.running && !off.done) TextButton(onClick = { NavSession.saveOffline() }) { Text("Jetzt speichern") }
                }
            }
            if (r != null && settings.hasTomTom) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { NavSession.openChargerSearch() }) {
                    Icon(Icons.Filled.EvStation, null, tint = pal.green)
                    Spacer(Modifier.width(6.dp))
                    Text("Ladestation selbst wählen", color = pal.green, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** Start, Zwischenstopps und Ziel */
@Composable
private fun StopsList(nav: NavSession.State, vm: MainViewModel) {
    val pal = LocalPal.current
    Text("Stopps", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    StopLine(pal.blue, "●", "Mein Standort", null)
    nav.vias.forEachIndexed { i, v ->
        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(24.dp).clip(CircleShape).background(if (v.isCharger) pal.green else pal.blue),
                contentAlignment = Alignment.Center,
            ) { Text(if (v.isCharger) "⚡" else "${i + 1}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(v.place.title, color = pal.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (!v.isCharger) {
                    Text(
                        if (v.pauseMin > 0) "Pause ${v.pauseMin} min" else "Pause hinzufügen",
                        color = pal.blue, fontSize = 13.sp,
                        modifier = Modifier.clickable { NavSession.cyclePause(i) },
                    )
                } else {
                    Text("Fester Ladestopp · ${v.powerKw.roundToInt()} kW", color = pal.green, fontSize = 13.sp)
                }
            }
            if (i > 0) SmallIcon(Icons.Filled.KeyboardArrowUp) { NavSession.moveVia(i, -1) }
            if (i < nav.vias.lastIndex) SmallIcon(Icons.Filled.KeyboardArrowDown) { NavSession.moveVia(i, 1) }
            SmallIcon(Icons.Filled.Close) { NavSession.removeVia(i) }
        }
    }
    StopLine(pal.red, "◆", nav.dest?.title ?: "Ziel", null)
    TextButton(onClick = { vm.startSearch(SearchMode.VIA) }) {
        Icon(Icons.Filled.Add, null, tint = pal.blue)
        Spacer(Modifier.width(4.dp))
        Text("Stopp hinzufügen", color = pal.blue, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun StopLine(color: Color, symbol: String, text: String, sub: String?) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) { Text(symbol, color = color, fontSize = 14.sp) }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(text, color = pal.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            sub?.let { Text(it, color = pal.sub, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun SmallIcon(icon: ImageVector, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = pal.sub, modifier = Modifier.size(20.dp))
    }
}

// ---------------- Ladestationen entlang der Route ----------------

@Composable
fun ChargerSheet(nav: NavSession.State, settings: AppSettings, screenH: Dp) {
    val pal = LocalPal.current
    val cs = nav.chargerSearch ?: return
    val r = nav.route
    val here = if (nav.navigating) nav.progress?.alongM ?: 0.0 else 0.0
    GlassCard(Modifier.fillMaxWidth().height(screenH * 0.72f), corner = 26.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (cs.replaceUuid != null) "Anderen Ladestopp wählen" else "Ladestationen entlang der Route",
                        color = pal.text, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                    )
                    Text(
                        (if (nav.navigating) "Nächste 250 km" else "Ganze Route") + " · ${cs.hits.size} gefunden",
                        color = pal.sub, fontSize = 13.sp,
                    )
                }
                CloseDot { NavSession.closeChargerSearch() }
            }
            Spacer(Modifier.height(10.dp))
            Segmented(listOf("ab 50 kW", "ab 100 kW", "ab 150 kW"), listOf(50, 100, 150).indexOf(settings.searchMinKw).coerceAtLeast(0)) { i ->
                Settings.update { it.copy(searchMinKw = listOf(50, 100, 150)[i]) }
                NavSession.openChargerSearch(cs.replaceUuid)
            }
            Spacer(Modifier.height(8.dp))
            Segmented(listOf("bis 5 km abseits", "bis 10 km", "bis 15 km"), listOf(5, 10, 15).indexOf(settings.corridorKm).coerceAtLeast(1)) { i ->
                Settings.update { it.copy(corridorKm = listOf(5, 10, 15)[i]) }
                NavSession.openChargerSearch(cs.replaceUuid)
            }
            Spacer(Modifier.height(8.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
            if (cs.loading) {
                Row(Modifier.padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), color = pal.blue, strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Suche Ladestationen …", color = pal.sub)
                }
            }
            cs.error?.let { Text(it, color = pal.red, modifier = Modifier.padding(vertical = 8.dp)) }
            if (!cs.loading && cs.error == null && cs.hits.isEmpty()) {
                Text("Keine passenden Ladestationen gefunden.", color = pal.sub, modifier = Modifier.padding(vertical = 8.dp))
            }
            cs.hits.forEach { h ->
                val soc = r?.socAt(h.alongM)
                val a = h.availId?.let { nav.hitAvailability[it] }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(14.dp))
                        .background(pal.field.copy(alpha = 0.6f)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(h.name, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val op = if (h.operator.isNotBlank()) "${h.operator} · " else ""
                        Text(
                            "$op${h.powerKw.roundToInt()} kW · in ${fmtKm(h.alongM - here)} · " +
                                if (h.offsetM < 400) "direkt an der Route" else "${fmtKm(h.offsetM)} abseits",
                            color = pal.sub, fontSize = 13.sp, maxLines = 2,
                        )
                        if (h.teslaOnly || h.operator.contains("Tesla", true)) {
                            Text("Tesla – Freigabe für andere Autos prüfen", color = Color(0xFFFF9500), fontSize = 12.sp)
                        }
                        Row {
                            if (soc != null) {
                                Text(
                                    if (soc < 0) "nicht erreichbar" else "Ankunft ca. ${fmtPct(soc)}",
                                    color = if (soc < settings.minSocStop) pal.red else pal.text, fontSize = 13.sp,
                                )
                            }
                            if (a != null && a.known) {
                                Text(
                                    "  ·  ${a.available}/${a.total} frei",
                                    color = if (a.available > 0) pal.green else pal.red, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                )
                            }
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { NavSession.pickCharger(h) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = pal.green, contentColor = Color.White),
                    ) { Text(if (nav.navigating) "Hier laden" else "Wählen", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

// ---------------- Einstellungen: Ladeanbieter ----------------

@Composable
fun OperatorSettings(s: AppSettings) {
    val pal = LocalPal.current
    val seen by KnownOperators.items.collectAsState()
    var custom by remember { mutableStateOf("") }
    val all = (KnownOperators.PRESET + seen.sorted() + s.preferOperators + s.avoidOperators).distinctBy { it.lowercase() }

    Label("Betreiber der Ladesäulen")
    Text("Antippen wechselt: neutral → bevorzugt → meiden", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
    all.forEach { name ->
        val state = when (name) {
            in s.preferOperators -> 1
            in s.avoidOperators -> 2
            else -> 0
        }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                Settings.update {
                    when (state) {
                        0 -> it.copy(preferOperators = it.preferOperators + name)
                        1 -> it.copy(preferOperators = it.preferOperators - name, avoidOperators = it.avoidOperators + name)
                        else -> it.copy(avoidOperators = it.avoidOperators - name)
                    }
                }
            }.padding(vertical = 8.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(name, color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            val (label, color) = when (state) {
                1 -> "bevorzugt" to pal.green
                2 -> "meiden" to pal.red
                else -> "–" to pal.sub
            }
            Text(
                label, color = if (state == 0) pal.sub else Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (state == 0) Color.Transparent else color)
                    .border(1.dp, color, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
        OutlinedTextField(
            value = custom, onValueChange = { custom = it }, singleLine = true,
            label = { Text("Weiterer Betreiber") }, modifier = Modifier.weight(1f),
        )
        TextButton(onClick = {
            val n = custom.trim()
            if (n.isNotEmpty()) Settings.update { it.copy(preferOperators = it.preferOperators + n) }
            custom = ""
        }) { Text("Bevorzugen") }
    }

    Spacer(Modifier.height(16.dp))
    Label("Meine Ladekarten und Apps")
    Text("Säulen, an denen diese Karten funktionieren, werden bevorzugt.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
    (KnownOperators.MSPS + s.preferredMsps).distinct().forEach { m ->
        ToggleRow(m, m in s.preferredMsps) { on ->
            Settings.update { if (on) it.copy(preferredMsps = it.preferredMsps + m) else it.copy(preferredMsps = it.preferredMsps - m) }
        }
    }
    Text(
        "Hinweis: TomTom erkennt Namen nur, wenn sie wie in seinen Daten geschrieben sind. Betreiber aus deinen Routen erscheinen automatisch in der Liste.",
        color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
    )
}
