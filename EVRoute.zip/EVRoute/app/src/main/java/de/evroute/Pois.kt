package de.evroute

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import okhttp3.FormBody
import okhttp3.Request
import java.util.Locale

/** Ein antippbarer Ort auf der Karte */
data class Poi(val osm: String, val name: String, val kind: String, val cat: String, val pos: LatLon)

/** Kategorie für die Einstellungen und die Karte */
data class PoiCat(val id: String, val label: String, val emoji: String, val color: Int, val filter: String)

/** Orte aus OpenStreetMap (über Overpass) im sichtbaren Kartenausschnitt */
object Pois {
    val CATS = listOf(
        PoiCat("food", "Essen und Trinken", "🍴", 0xFFFF9500.toInt(), "[\"amenity\"~\"^(restaurant|cafe|fast_food|bar|pub|ice_cream|biergarten)$\"]"),
        PoiCat("shop", "Einkaufen", "🛒", 0xFF0A84FF.toInt(), "[\"shop\"~\"^(supermarket|convenience|bakery|mall|department_store|doityourself|hardware|chemist|butcher|beverages)$\"]"),
        PoiCat("wc", "Toiletten", "🚻", 0xFF5E5CE6.toInt(), "[\"amenity\"=\"toilets\"]"),
        PoiCat("fuel", "Tankstellen", "⛽", 0xFF8E8E93.toInt(), "[\"amenity\"=\"fuel\"]"),
        PoiCat("parking", "Parkplätze", "🅿", 0xFF1E5AA8.toInt(), "[\"amenity\"=\"parking\"][\"access\"!~\"private|customers\"]"),
        PoiCat("hotel", "Hotels", "🛏", 0xFFAF52DE.toInt(), "[\"tourism\"~\"^(hotel|motel|guest_house|hostel)$\"]"),
        PoiCat("sight", "Sehenswürdigkeiten", "📷", 0xFF30B0C7.toInt(), "[\"tourism\"~\"^(attraction|museum|viewpoint|zoo|theme_park)$\"]"),
        PoiCat("health", "Apotheken und Ärzte", "➕", 0xFFFF3B30.toInt(), "[\"amenity\"~\"^(pharmacy|hospital|doctors|dentist)$\"]"),
        PoiCat("money", "Geldautomaten und Banken", "€", 0xFF34C759.toInt(), "[\"amenity\"~\"^(atm|bank)$\"]"),
    )

    private val scope = MainScope()
    private val _items = MutableStateFlow<List<Poi>>(emptyList())
    val items: StateFlow<List<Poi>> = _items.asStateFlow()
    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status.asStateFlow()

    // Mehrere öffentliche Overpass-Server: ist einer überlastet, wird der nächste versucht
    private val SERVERS = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass.private.coffee/api/interpreter",
    )
    private var job: Job? = null
    private var lastKey = ""

    fun iconId(cat: String) = "poi-$cat"

    fun addIcons(ctx: Context, s: org.maplibre.android.maps.Style) {
        CATS.forEach { s.addImage(iconId(it.id), icon(ctx, it)) }
    }

    private fun icon(ctx: Context, c: PoiCat): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val size = (26 * d).toInt()
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val cx = size / 2f
        cv.drawCircle(cx, cx, size * 0.48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE })
        cv.drawCircle(cx, cx, size * 0.41f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c.color })
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = size * 0.46f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        cv.drawText(c.emoji, cx, cx - (tp.descent() + tp.ascent()) / 2, tp)
        return b
    }

    /** Nach dem Verschieben der Karte: Orte im Ausschnitt laden (ab Zoom 14, mit kurzer Pause) */
    private var lastArgs: DoubleArray? = null
    private var lastNav = false

    fun onCameraIdle(s: Double, w: Double, n: Double, e: Double, zoom: Double, navigating: Boolean) {
        lastArgs = doubleArrayOf(s, w, n, e, zoom)
        lastNav = navigating
        val set = Settings.state.value
        val active = set.poiEnabled && set.poiCats.isNotEmpty() && (!navigating || set.poiInNav)
        if (!active || zoom < 13.0) {
            if (_items.value.isNotEmpty()) _items.value = emptyList()
            lastKey = ""
            return
        }
        // etwas größer laden, damit kleines Verschieben keine neue Abfrage braucht
        val padLat = (n - s) * 0.3
        val padLon = (e - w) * 0.3
        val key = String.format(Locale.US, "%.3f,%.3f,%.3f,%.3f|%s", s, w, n, e, set.poiCats.sorted().joinToString())
        if (key == lastKey) return
        lastKey = key
        job?.cancel()
        job = scope.launch {
            delay(700)
            val res = runCatching { load(s - padLat, w - padLon, n + padLat, e + padLon, set.poiCats) }
            res.onSuccess { list ->
                _items.value = list
                _status.value = null
            }.onFailure { err ->
                if (err is kotlinx.coroutines.CancellationException) throw err
                lastKey = ""
                _status.value = "Orte konnten nicht geladen werden"
                CrashLog.note("POI-Abfrage fehlgeschlagen: ${err.message}")
            }
        }
    }

    /** Nach einer Änderung der Einstellungen sofort neu laden */
    fun refresh() {
        lastKey = ""
        _items.value = emptyList()
        lastArgs?.let { a -> onCameraIdle(a[0], a[1], a[2], a[3], a[4], lastNav) }
    }

    private suspend fun load(s: Double, w: Double, n: Double, e: Double, cats: Set<String>): List<Poi> = withContext(Dispatchers.IO) {
        val bbox = String.format(Locale.US, "%.5f,%.5f,%.5f,%.5f", s, w, n, e)
        val parts = CATS.filter { it.id in cats }.joinToString("\n") { "nwr${it.filter}($bbox);" }
        val q = "[out:json][timeout:25];\n(\n$parts\n);\nout center 250;"
        var body: String? = null
        var lastErr = ""
        for (server in SERVERS) {
            val req = Request.Builder().url(server).header("User-Agent", "EVRoute/0.16 (privat)")
                .post(FormBody.Builder().add("data", q).build()).build()
            val r = runCatching { Http.call(req) }.getOrNull()
            if (r != null && r.code == 200 && r.body.trimStart().startsWith("{")) { body = r.body; break }
            lastErr = "${server.substringAfter("//").substringBefore('/')}: ${r?.code ?: "keine Verbindung"}"
        }
        val text = body ?: throw java.io.IOException("Overpass nicht erreichbar ($lastErr)")
        val root = json.parseToJsonElement(text).jsonObject
        (root["remark"] as? JsonPrimitive)?.contentOrNull?.let { if (it.contains("error", true)) CrashLog.note("POI-Hinweis von Overpass: $it") }
        val els = root["elements"]?.jsonArray?.mapNotNull { it as? JsonObject } ?: emptyList()
        els.mapNotNull { o ->
            val tags = o["tags"] as? JsonObject ?: return@mapNotNull null
            fun t(k: String) = (tags[k] as? JsonPrimitive)?.contentOrNull ?: ""
            val lat = (o["lat"] as? JsonPrimitive)?.doubleOrNull ?: ((o["center"] as? JsonObject)?.get("lat") as? JsonPrimitive)?.doubleOrNull ?: return@mapNotNull null
            val lon = (o["lon"] as? JsonPrimitive)?.doubleOrNull ?: ((o["center"] as? JsonObject)?.get("lon") as? JsonPrimitive)?.doubleOrNull ?: return@mapNotNull null
            val type = when ((o["type"] as? JsonPrimitive)?.contentOrNull) { "node" -> "N"; "way" -> "W"; else -> "R" }
            val id = (o["id"] as? JsonPrimitive)?.contentOrNull ?: return@mapNotNull null
            val kind = when {
                t("amenity").isNotBlank() -> "amenity=${t("amenity")}"
                t("shop").isNotBlank() -> "shop=${t("shop")}"
                t("tourism").isNotBlank() -> "tourism=${t("tourism")}"
                else -> ""
            }
            val cat = CATS.firstOrNull { c -> matches(c.id, kind) }?.id ?: return@mapNotNull null
            val name = t("name").ifBlank { t("brand") }.ifBlank { Nominatim.categoryLabel(kind) }
            Poi("$type$id", name, kind, cat, LatLon(lat, lon))
        }
    }

    private fun matches(cat: String, kind: String): Boolean = when (cat) {
        "food" -> kind.substringAfter("=") in setOf("restaurant", "cafe", "fast_food", "bar", "pub", "ice_cream", "biergarten")
        "shop" -> kind.startsWith("shop=")
        "wc" -> kind == "amenity=toilets"
        "fuel" -> kind == "amenity=fuel"
        "parking" -> kind == "amenity=parking"
        "hotel" -> kind.startsWith("tourism=") && kind.substringAfter("=") in setOf("hotel", "motel", "guest_house", "hostel")
        "sight" -> kind.startsWith("tourism=") && kind.substringAfter("=") in setOf("attraction", "museum", "viewpoint", "zoo", "theme_park")
        "health" -> kind.substringAfter("=") in setOf("pharmacy", "hospital", "doctors", "dentist")
        "money" -> kind.substringAfter("=") in setOf("atm", "bank")
        else -> false
    }
}
