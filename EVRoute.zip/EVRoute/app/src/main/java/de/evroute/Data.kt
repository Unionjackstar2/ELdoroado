package de.evroute

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt

// ---------------- HTTP ----------------

object Http {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    data class Resp(val code: Int, val body: String)

    suspend fun call(req: Request): Resp = withContext(Dispatchers.IO) {
        client.newCall(req).execute().use { r -> Resp(r.code, r.body?.string() ?: "") }
    }

    /** Liefert den Text auch bei 4xx (Fehlermeldung des Servers), wirft bei 5xx */
    suspend fun get(url: String): String {
        val r = call(Request.Builder().url(url).header("User-Agent", "EVRoute/0.3 (privat)").build())
        if (r.code >= 500) throw IOException("Server-Fehler ${r.code}")
        return r.body
    }
}

val json = Json { ignoreUnknownKeys = true }

// kleine Helfer für JSON
private fun JsonObject.obj(k: String): JsonObject? = (this[k] as? JsonObject)
private fun JsonObject.arr(k: String): JsonArray = (this[k] as? JsonArray) ?: JsonArray(emptyList())
private fun JsonObject.num(k: String): Double? = (this[k] as? JsonPrimitive)?.doubleOrNull
private fun JsonObject.int(k: String): Int? = (this[k] as? JsonPrimitive)?.let { it.intOrNull ?: it.contentOrNull?.toIntOrNull() }
private fun JsonObject.str(k: String): String = (this[k] as? JsonPrimitive)?.contentOrNull ?: ""
private val JsonElement.d: Double get() = jsonPrimitive.doubleOrNull ?: 0.0

private fun cumulative(pts: List<LatLon>): DoubleArray {
    val cum = DoubleArray(pts.size)
    for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
    return cum
}

// ---------------- Routing ohne Schlüssel (OSRM, Rückfall) ----------------

object Routing {
    private const val BASE = "https://router.project-osrm.org/route/v1/driving/"

    suspend fun routes(
        from: LatLon,
        bearing: Float?,
        to: LatLon,
        exclude: List<String>,
        alternatives: Int,
        vias: List<LatLon> = emptyList(),
    ): List<Route> {
        val coords = listOf(from) + vias + listOf(to)
        val url = buildString {
            append(BASE)
            append(coords.joinToString(";") { "${it.lon.f6()},${it.lat.f6()}" })
            append("?overview=full&geometries=geojson&steps=true")
            append("&alternatives=").append(if (alternatives > 0 && vias.isEmpty()) alternatives.toString() else "false")
            if (bearing != null) append("&bearings=${bearing.roundToInt().mod(360)},45" + ";0,180".repeat(coords.size - 1))
            if (exclude.isNotEmpty()) append("&exclude=").append(exclude.joinToString(","))
        }
        val root = json.parseToJsonElement(Http.get(url)).jsonObject
        val code = root.str("code")
        if (code != "Ok") throw IOException(root.str("message").ifBlank { "Routing-Fehler ($code)" })
        return root.arr("routes").map { parse(it.jsonObject) }
    }

    private fun parse(r: JsonObject): Route {
        val pts = r.obj("geometry")?.arr("coordinates")?.map { c ->
            val a = c.jsonArray
            LatLon(a[1].d, a[0].d)
        } ?: emptyList()
        val steps = mutableListOf<Step>()
        var summary = ""
        val legsArr = r.arr("legs")
        legsArr.forEachIndexed { li, lg ->
            val leg = lg.jsonObject
            if (summary.isEmpty()) summary = leg.str("summary")
            leg.arr("steps").forEach { st ->
                var step = parseStep(st.jsonObject)
                // Zwischenstopps: „Ankunft“ mitten in der Route ist ein Zwischenziel, „Abfahrt“ danach ein Weiterfahren
                if (li < legsArr.size - 1 && step.type == "arrive") step = step.copy(type = "via", mod = null, phrase = Phrases.build("via", null, null))
                if (li > 0 && step.type == "depart") step = step.copy(type = "continue", mod = "straight", phrase = Phrases.build("continue", "straight", null))
                steps += step
            }
        }
        val cum = cumulative(pts)
        val osrmDist = r.num("distance") ?: 0.0
        val dur = r.num("duration") ?: 0.0
        val scale = if (osrmDist > 0 && cum.isNotEmpty()) cum.last() / osrmDist else 1.0
        val stepAlong = DoubleArray(steps.size)
        val stepTime = DoubleArray(steps.size)
        var acc = 0.0
        var t = 0.0
        steps.forEachIndexed { i, s ->
            stepAlong[i] = acc * scale
            stepTime[i] = t
            acc += s.distanceM
            t += s.durationS
        }
        return Route(pts, cum, stepAlong, stepTime, osrmDist, dur, dur, steps, summary, source = "OSRM")
    }

    private fun parseStep(s: JsonObject): Step {
        val m = s.obj("maneuver") ?: JsonObject(emptyMap())
        val type = m.str("type")
        val mod = (m["modifier"] as? JsonPrimitive)?.contentOrNull
        val exit = m.int("exit")
        val ref = s.str("ref").split(';').firstOrNull()?.trim() ?: ""
        val road = listOf(ref, s.str("name")).filter { it.isNotBlank() }.distinct().joinToString(" · ")
        val dest = s.str("destinations")
        val towards = if (dest.contains(": ")) dest.substringAfter(": ") else dest
        return Step(type, mod, exit, road, towards, s.num("distance") ?: 0.0, s.num("duration") ?: 0.0, Phrases.build(type, mod, exit))
    }
}

/** Deutsche Manöver-Texte */
object Phrases {
    private fun dir(mod: String?) = when (mod) {
        "left" -> "links"
        "right" -> "rechts"
        "slight left" -> "leicht links"
        "slight right" -> "leicht rechts"
        "sharp left" -> "scharf links"
        "sharp right" -> "scharf rechts"
        else -> "geradeaus"
    }

    fun build(type: String, mod: String?, exit: Int?): String = when (type) {
        "depart" -> "losfahren"
        "arrive" -> "Ziel erreichen"
        "charge" -> "Ladestopp erreichen"
        "via" -> "Zwischenziel erreichen"
        "ferry" -> "die Fähre nehmen"
        "roundabout", "rotary", "roundabout turn" ->
            if (exit != null) "im Kreisverkehr die $exit. Ausfahrt nehmen" else "in den Kreisverkehr fahren"
        "merge" -> if (mod == null || mod == "straight") "einfädeln" else "${dir(mod)} einfädeln"
        "on ramp" -> "die Auffahrt nehmen"
        "off ramp" -> if (mod == null || mod == "straight") "die Ausfahrt nehmen" else "${dir(mod)} die Ausfahrt nehmen"
        "fork" -> "an der Gabelung ${dir(mod)} halten"
        "end of road" -> "am Ende der Straße ${dir(mod)} abbiegen"
        "continue", "new name" -> when (mod) {
            null, "straight" -> "geradeaus weiterfahren"
            "uturn" -> "wenden"
            else -> "${dir(mod)} halten"
        }
        else -> when (mod) {
            null, "straight" -> "geradeaus weiterfahren"
            "uturn" -> "wenden"
            else -> "${dir(mod)} abbiegen"
        }
    }
}

// ---------------- Suche (Photon / OpenStreetMap) ----------------

object Geocode {
    suspend fun search(q: String, near: LatLon?): List<Place> {
        val bias = if (near != null) "&lat=${near.lat.f6()}&lon=${near.lon.f6()}" else ""
        val url = "https://photon.komoot.io/api/?limit=7&lang=de$bias&q=" + URLEncoder.encode(q, "UTF-8")
        return json.parseToJsonElement(Http.get(url)).jsonObject.arr("features").mapNotNull { f ->
            val p = f.jsonObject.obj("properties") ?: return@mapNotNull null
            val c = f.jsonObject.obj("geometry")?.arr("coordinates") ?: return@mapNotNull null
            val street = listOf(p.str("street"), p.str("housenumber")).filter { it.isNotBlank() }.joinToString(" ")
            val first = p.str("name").ifBlank { street }
            val parts = listOf(first, if (first == street) "" else street, p.str("city"), p.str("country"))
                .filter { it.isNotBlank() }.distinct()
            Place(parts.joinToString(", "), LatLon(c[1].d, c[0].d))
        }
    }
}

/** Adresse zu einem Kartenpunkt (für langes Drücken) */
object Reverse {
    suspend fun name(p: LatLon): String {
        val url = "https://photon.komoot.io/reverse?lang=de&lat=${p.lat.f6()}&lon=${p.lon.f6()}"
        val f = runCatching { json.parseToJsonElement(Http.get(url)).jsonObject.arr("features").firstOrNull()?.jsonObject }.getOrNull()
        val pr = f?.obj("properties") ?: return "Markierter Ort"
        val street = listOf(pr.str("street"), pr.str("housenumber")).filter { it.isNotBlank() }.joinToString(" ")
        val first = pr.str("name").ifBlank { street }.ifBlank { "Markierter Ort" }
        return listOf(first, if (first == street) "" else street, pr.str("city")).filter { it.isNotBlank() }.distinct().joinToString(", ")
    }
}

// ---------------- Wetter entlang der Strecke (Open-Meteo) ----------------

object Weather {
    /** Temperatur, Gegenwind und Regen an 5 Punkten zur voraussichtlichen Durchfahrtszeit */
    suspend fun along(from: LatLon, to: LatLon): WeatherInfo {
        val n = 5
        val pts = (0 until n).map { lerp(from, to, it / (n - 1.0)) }
        val km = haversine(from, to) / 1000 * 1.25
        val lat = pts.joinToString(",") { String.format(Locale.US, "%.4f", it.lat) }
        val lon = pts.joinToString(",") { String.format(Locale.US, "%.4f", it.lon) }
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&hourly=temperature_2m,precipitation,wind_speed_10m,wind_direction_10m&forecast_days=3&timezone=GMT"
        val root = json.parseToJsonElement(Http.get(url))
        val list = (root as? JsonArray)?.map { it.jsonObject } ?: listOf(root.jsonObject)
        val now = ZonedDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:00"))
        val travel = bearing(from, to)
        var tSum = 0.0
        var hSum = 0.0
        var rainy = 0
        var count = 0
        list.forEachIndexed { i, o ->
            val h = o.obj("hourly") ?: return@forEachIndexed
            val times = h.arr("time").map { it.jsonPrimitive.content }
            if (times.isEmpty()) return@forEachIndexed
            val base = times.indexOf(now).coerceAtLeast(0)
            val eta = (km * i / (n - 1) / 85.0).roundToInt()
            val k = (base + eta).coerceAtMost(times.lastIndex)
            val temp = h.arr("temperature_2m").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: return@forEachIndexed
            val ws = h.arr("wind_speed_10m").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: 0.0
            val wd = h.arr("wind_direction_10m").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: 0.0
            val pr = h.arr("precipitation").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: 0.0
            tSum += temp
            hSum += ws * cos(Math.toRadians(wd - travel)) // Wind „aus“ Fahrtrichtung = Gegenwind
            if (pr > 0.3) rainy++
            count++
        }
        if (count == 0) throw IOException("Keine Wetterdaten")
        return WeatherInfo(tSum / count, hSum / count, rainy * 2 >= count)
    }
}

// ---------------- Verbrauchsmodell ë-C4 ----------------

object EvModel {
    private val SPEEDS = intArrayOf(20, 40, 60, 80, 100, 120, 140)

    private fun styleFactor(s: AppSettings) = when (s.style) {
        0 -> 0.94
        2 -> 1.08
        else -> 1.0
    }

    /** kWh/100 km bei konstantem Tempo, inkl. Wind, Kälte, Regen, Fahrweise (ohne Heizung/Klima) */
    fun kwhPer100(v: Double, s: AppSettings, w: WeatherInfo?): Double {
        val air = (v + (w?.headwindKmh ?: 0.0)).coerceAtLeast(0.0)
        val base = 8.5 + 0.00082 * air * air
        val cold = 1.0 + 0.007 * max(0.0, 15.0 - (w?.tempC ?: 15.0))
        val rain = if (w?.rain == true) 1.06 else 1.0
        return base * cold * rain * styleFactor(s)
    }

    /** Heizung bzw. Klimaanlage in kW */
    fun auxKw(w: WeatherInfo?): Double {
        val t = w?.tempC ?: 15.0
        return when {
            t < 0 -> 2.5
            t < 8 -> 1.8
            t < 15 -> 1.0
            t < 24 -> 0.4
            t < 30 -> 0.9
            else -> 1.4
        }
    }

    fun curveParam(s: AppSettings, w: WeatherInfo?): String =
        SPEEDS.joinToString(":") { v -> String.format(Locale.US, "%d,%.2f", v, kwhPer100(v.toDouble(), s, w)) }

    /** Ladekurve ë-C4 (Startwerte, ~100 kW Spitze) als (Akku kWh, max. kW) */
    fun batteryCurve(usable: Double): List<Pair<Double, Double>> = listOf(
        0.0 to 80.0, 0.10 to 100.0, 0.30 to 85.0, 0.50 to 65.0,
        0.70 to 48.0, 0.80 to 36.0, 0.90 to 22.0, 1.0 to 7.0,
    ).map { (f, kw) -> f * usable to kw }

    /** Schätzung ohne Ladeplanung (Rückfall ohne TomTom) */
    fun estimateSimple(r: Route, s: AppSettings, startSoc: Double, w: WeatherInfo?): Route {
        val hours = max(r.driveS, 1.0) / 3600
        val avgKmh = (r.distanceM / 1000) / hours
        val kwh = r.distanceM / 1000 * kwhPer100(avgKmh * 1.1, s, w) / 100 + auxKw(w) * hours
        val arrival = startSoc - kwh / s.usableKwh * 100
        val ok = arrival >= s.minSocDest
        return r.copy(
            socProfile = listOf(0.0 to startSoc, r.cumM.lastOrNull().orZero() to arrival),
            arrivalSoc = arrival,
            feasible = ok,
            reason = if (ok) null else "Akku reicht nicht bis zum Ziel. Für automatische Ladestopps TomTom-Key in den Einstellungen eintragen.",
            weather = w,
        )
    }

    private fun Double?.orZero() = this ?: 0.0
}

// ---------------- TomTom ----------------

object TomTom {
    private const val BASE = "https://api.tomtom.com"
    private val JSON_TYPE = "application/json".toMediaType()

    fun trafficTileUrl(key: String, dark: Boolean): String =
        "$BASE/traffic/map/4/tile/flow/${if (dark) "relative0-dark" else "relative0"}/{z}/{x}/{y}.png?key=$key&tileSize=256&thickness=8"

    fun avoids(s: AppSettings, noToll: Boolean): List<String> = buildList {
        if (s.avoidToll || noToll) add("tollRoads")
        if (s.avoidMotorway) add("motorways")
        if (s.avoidFerry) add("ferries")
    }

    private fun errorText(r: Http.Resp): String {
        val o = runCatching { json.parseToJsonElement(r.body).jsonObject }.getOrNull()
        val msg = o?.obj("detailedError")?.str("message")?.ifBlank { null }
            ?: o?.obj("error")?.str("description")?.ifBlank { null }
        return when {
            r.code == 403 -> "TomTom-Key ungültig oder Tageslimit erreicht (403)"
            msg != null -> "TomTom: $msg"
            else -> "TomTom-Fehler ${r.code}"
        }
    }

    /** Langstrecken-Routing mit automatischen Ladestopps, Verkehr und Abbiegehinweisen */
    suspend fun ldev(
        s: AppSettings,
        from: LatLon,
        heading: Float?,
        to: LatLon,
        socPct: Double,
        w: WeatherInfo?,
        avoid: List<String>,
        alternatives: Int,
        avoidParks: List<String>,
        vias: List<Via> = emptyList(),
        chargeIndexMode: Int = 0, // 0 = Index unter den Zwischenstopps, 1 = Index in allen Orten, 2 = Ladestationen als normale Stopps
    ): List<Route> {
        val usable = s.usableKwh
        val locs = listOf(from) + vias.map { it.place.pos } + listOf(to)
        val cur = (socPct.coerceIn(1.0, 100.0) / 100 * usable).coerceAtMost(usable)
        val url = buildString {
            append("$BASE/routing/1/calculateLongDistanceEVRoute/")
            append(locs.joinToString(":") { "${it.lat.f6()},${it.lon.f6()}" }).append("/json")
            append("?key=").append(s.tomtomKey.trim())
            append("&vehicleEngineType=electric")
            append("&constantSpeedConsumptionInkWhPerHundredkm=").append(EvModel.curveParam(s, w))
            append("&currentChargeInkWh=").append(String.format(Locale.US, "%.2f", cur))
            append("&maxChargeInkWh=").append(String.format(Locale.US, "%.2f", usable))
            append("&minChargeAtDestinationInkWh=").append(String.format(Locale.US, "%.2f", s.minSocDest / 100 * usable))
            append("&minChargeAtChargingStopsInkWh=").append(String.format(Locale.US, "%.2f", s.minSocStop / 100 * usable))
            append("&auxiliaryPowerInkW=").append(String.format(Locale.US, "%.2f", EvModel.auxKw(w)))
            append("&consumptionInkWhPerkmAltitudeGain=5.0&recuperationInkWhPerkmAltitudeLoss=3.0")
            append("&traffic=true&routeType=fastest&travelMode=car")
            append("&instructionsType=text&language=de-DE&sectionType=traffic")
            append("&chargingStopsStrategy=automaticFastestWithFallbackToManual")
            append("&maxAlternatives=").append(if (vias.isEmpty()) alternatives else 0)
            if (heading != null) append("&vehicleHeading=").append(heading.roundToInt().mod(360))
            avoid.forEach { append("&avoid=").append(it) }
        }
        val body = buildJsonObject {
            putJsonObject("chargingParameters") {
                put("batteryCurveInterpolation", "piecewiseLinear")
                putJsonArray("batteryCurve") {
                    EvModel.batteryCurve(usable).forEach { (kwh, kw) ->
                        addJsonObject {
                            put("stateOfChargeInkWh", kwh)
                            put("maxPowerInkW", kw)
                        }
                    }
                }
                putJsonArray("chargingConnectors") {
                    addJsonObject {
                        put("currentType", "DC")
                        putJsonArray("plugTypes") { add("Combo_to_IEC_62196_Type_2_Base") }
                        put("efficiency", 0.92)
                        put("maxPowerInkW", 100.0)
                    }
                }
                put("chargingTimeOffsetInSec", 120)
            }
            if (avoidParks.isNotEmpty()) putJsonArray("avoidChargingParks") { avoidParks.take(40).forEach { add(it) } }
            if (s.preferOperators.isNotEmpty()) putJsonArray("preferChargingParkOperators") { s.preferOperators.take(20).forEach { add(it) } }
            if (s.avoidOperators.isNotEmpty()) putJsonArray("avoidChargingParkOperators") { s.avoidOperators.take(40).forEach { add(it) } }
            if (s.preferredMsps.isNotEmpty()) putJsonArray("preferredMSPs") { s.preferredMsps.take(20).forEach { add(it) } }
            if (vias.isNotEmpty()) {
                val chargers = vias.withIndex().filter { it.value.isCharger && it.value.chargeParkId != null }
                if (chargeIndexMode < 2 && chargers.isNotEmpty()) {
                    putJsonArray("chargingWaypoints") {
                        chargers.forEach { (i, v) ->
                            addJsonObject {
                                put("waypointIndex", if (chargeIndexMode == 0) i else i + 1)
                                put("chargingParkId", v.chargeParkId)
                            }
                        }
                    }
                }
                putJsonArray("legs") {
                    vias.forEach { v ->
                        addJsonObject {
                            val pause = if (v.isCharger && chargeIndexMode < 2) 0 else v.pauseMin * 60 + if (v.isCharger) 1500 else 0
                            if (pause > 0) putJsonObject("routeStop") { put("pauseTimeInSeconds", pause) }
                        }
                    }
                    addJsonObject { }
                }
            }
        }
        ApiCounter.hit()
        val req = Request.Builder().url(url).post(body.toString().toRequestBody(JSON_TYPE)).build()
        val r = Http.call(req)
        if (r.code != 200) {
            // Feste Ladestopps: falls die Zählweise oder die Ladepark-ID nicht passt, schrittweise zurückfallen
            if (r.code == 400 && chargeIndexMode < 2 && vias.any { it.isCharger }) {
                return ldev(s, from, heading, to, socPct, w, avoid, alternatives, avoidParks, vias, chargeIndexMode + 1)
            }
            throw IOException(errorText(r))
        }
        val root = json.parseToJsonElement(r.body).jsonObject
        val routes = root.arr("routes")
        if (routes.isEmpty()) throw IOException("TomTom hat keine Route gefunden")
        val out = routes.map { parseRoute(it.jsonObject, s, socPct, w, vias) }
        KnownOperators.note(out.flatMap { rt -> rt.stops.map { it.operator } })
        return if (chargeIndexMode == 2) out.map { it.copy(note = "Gewählte Ladestation als normaler Stopp eingeplant (TomTom kannte die Ladepark-ID nicht).") } else out
    }

    private fun maneuver(m: String): Pair<String, String?> = when (m) {
        "DEPART" -> "depart" to null
        "ARRIVE", "ARRIVE_LEFT", "ARRIVE_RIGHT" -> "arrive" to null
        "WAYPOINT_REACHED", "WAYPOINT_LEFT", "WAYPOINT_RIGHT" -> "charge" to null
        "KEEP_RIGHT" -> "fork" to "slight right"
        "KEEP_LEFT" -> "fork" to "slight left"
        "BEAR_RIGHT" -> "turn" to "slight right"
        "BEAR_LEFT" -> "turn" to "slight left"
        "TURN_RIGHT" -> "turn" to "right"
        "TURN_LEFT" -> "turn" to "left"
        "SHARP_RIGHT" -> "turn" to "sharp right"
        "SHARP_LEFT" -> "turn" to "sharp left"
        "MAKE_UTURN", "TRY_MAKE_UTURN" -> "turn" to "uturn"
        "ENTER_MOTORWAY", "ENTER_FREEWAY", "ENTER_HIGHWAY", "ENTRANCE_RAMP" -> "on ramp" to "slight right"
        "TAKE_EXIT", "MOTORWAY_EXIT_RIGHT" -> "off ramp" to "slight right"
        "MOTORWAY_EXIT_LEFT" -> "off ramp" to "slight left"
        "TAKE_FERRY" -> "ferry" to null
        "ROUNDABOUT_CROSS" -> "roundabout" to "straight"
        "ROUNDABOUT_RIGHT" -> "roundabout" to "right"
        "ROUNDABOUT_LEFT" -> "roundabout" to "left"
        "ROUNDABOUT_BACK" -> "roundabout" to "uturn"
        else -> "continue" to "straight"
    }

    private fun parseRoute(r: JsonObject, s: AppSettings, startSoc: Double, w: WeatherInfo?, vias: List<Via>): Route {
        val usable = s.usableKwh
        val sum = r.obj("summary") ?: JsonObject(emptyMap())
        val legs = r.arr("legs").map { it.jsonObject }

        // Punkte aller Abschnitte hintereinander (Indizes passen so zu den TomTom-Sections)
        val pts = mutableListOf<LatLon>()
        val legEndIdx = mutableListOf<Int>()
        legs.forEach { leg ->
            leg.arr("points").forEach { p ->
                val o = p.jsonObject
                pts += LatLon(o.num("latitude") ?: 0.0, o.num("longitude") ?: 0.0)
            }
            legEndIdx += pts.lastIndex
        }
        val cum = cumulative(pts)
        val length = sum.num("lengthInMeters") ?: cum.lastOrNull() ?: 0.0
        val scale = if (length > 0 && cum.isNotEmpty()) cum.last() / length else 1.0

        // Ladestopps
        val stops = mutableListOf<ChargeStop>()
        val legEnds = mutableListOf<Pair<String, ChargeStop?>>() // (Name, Ladestopp) für jedes Abschnittsende außer dem Ziel
        var viaNo = 0
        var pauses = 0.0
        var legTravel = 0.0
        var chargeTotal = 0.0
        val profile = mutableListOf(0.0 to startSoc)
        var ok = true
        legs.forEachIndexed { i, leg ->
            val ls = leg.obj("summary") ?: JsonObject(emptyMap())
            legTravel += ls.num("travelTimeInSeconds") ?: 0.0
            val arrive = (ls.num("remainingChargeAtArrivalInkWh") ?: 0.0) / usable * 100
            if (arrive < 0) ok = false
            val idx = legEndIdx.getOrElse(i) { pts.lastIndex }.coerceAtLeast(0)
            val along = cum.getOrElse(idx) { 0.0 }
            profile += along to arrive
            val ci = ls.obj("chargingInformationAtEndOfLeg")
            val userStop = ci == null || ci.str("chargingStopType").equals("User_Defined", ignoreCase = true)
            if (i < legs.lastIndex && userStop) {
                val v = vias.getOrNull(viaNo)
                viaNo++
                if (v != null && (ci == null || !v.isCharger)) pauses += v.pauseMin * 60.0
                if (ci == null) legEnds += (v?.place?.title ?: "Zwischenziel") to null
            }
            if (ci != null) {
                val target = (ci.num("targetChargeInkWh") ?: 0.0) / usable * 100
                val cs = ci.num("chargingTimeInSeconds") ?: 0.0
                chargeTotal += cs
                val conn = ci.obj("chargingConnectionInfo")
                stops += ChargeStop(
                    name = ci.str("chargingParkName").ifBlank { "Ladepark" },
                    operator = ci.str("chargingParkOperatorName"),
                    pos = pts.getOrElse(idx) { LatLon(0.0, 0.0) },
                    alongM = along,
                    powerKw = conn?.num("chargingPowerInkW") ?: ci.num("chargingParkPowerInkW") ?: 0.0,
                    arriveSoc = arrive,
                    targetSoc = target,
                    chargeS = cs,
                    uuid = ci.str("chargingParkUuid").ifBlank { null },
                )
                legEnds += stops.last().name to stops.last()
                profile += along to target
            }
        }
        val arrival = (sum.num("remainingChargeAtArrivalInkWh") ?: 0.0) / usable * 100
        if (arrival < 0) ok = false

        // Abbiegehinweise
        val instr = r.obj("guidance")?.arr("instructions")?.map { it.jsonObject } ?: emptyList()
        val steps = mutableListOf<Step>()
        val stepAlong = DoubleArray(instr.size)
        val stepTime = DoubleArray(instr.size)
        var endIdx = 0
        instr.forEachIndexed { i, o ->
            val off = o.num("routeOffsetInMeters") ?: 0.0
            val t = o.num("travelTimeInSeconds") ?: 0.0
            val nextOff = instr.getOrNull(i + 1)?.num("routeOffsetInMeters") ?: off
            val nextT = instr.getOrNull(i + 1)?.num("travelTimeInSeconds") ?: t
            var (type, mod) = maneuver(o.str("maneuver"))
            val numbers = o.arr("roadNumbers").mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
            var road = (numbers.take(1) + listOf(o.str("street"))).filter { it.isNotBlank() }.distinct().joinToString(" · ")
            var note = ""
            if (type == "charge") {
                val end = legEnds.getOrNull(endIdx)
                endIdx++
                val st = end?.second
                if (st != null) {
                    road = st.name
                    note = "Laden auf ${st.targetSoc.roundToInt()} Prozent, etwa ${(st.chargeS / 60).roundToInt()} Minuten."
                } else {
                    type = "via"
                    mod = null
                    road = end?.first ?: "Zwischenziel"
                }
            }
            val exit = o.int("roundaboutExitNumber")
            val exitNo = o.str("exitNumber")
            val towards = listOf(if (exitNo.isNotBlank()) "Ausfahrt $exitNo" else "", o.str("signpostText"))
                .filter { it.isNotBlank() }.joinToString(" · ")
            steps += Step(
                type, mod, exit, road, towards,
                max(0.0, nextOff - off), max(0.0, nextT - t),
                Phrases.build(type, mod, exit), note,
            )
            stepAlong[i] = off * scale
            stepTime[i] = t
        }

        // Staus
        val jams = r.arr("sections").mapNotNull { e ->
            val o = e.jsonObject
            if (o.str("sectionType") != "TRAFFIC") return@mapNotNull null
            Jam(
                startIdx = o.int("startPointIndex") ?: 0,
                endIdx = o.int("endPointIndex") ?: 0,
                delayS = o.num("delayInSeconds") ?: 0.0,
                magnitude = o.int("magnitudeOfDelay") ?: 1,
                category = o.str("simpleCategory"),
            )
        }

        // Fahrstrecken-Zusammenfassung „über A 1, A 61“
        val via = steps.filter { it.distanceM > 20_000 }.mapNotNull { st ->
            st.road.split(" · ").firstOrNull()?.takeIf { it.isNotBlank() && it.any(Char::isDigit) }
        }.distinct().take(3).joinToString(", ")

        val lastT = stepTime.lastOrNull() ?: legTravel
        val includes = chargeTotal > 0 && lastT > legTravel + chargeTotal * 0.5
        val reason = when {
            ok -> null
            stops.isEmpty() -> "Mit dem aktuellen Akkustand nicht erreichbar und keine passende Schnellladesäule gefunden."
            else -> "Ein Abschnitt ist mit dem Akku nicht erreichbar – zu wenige Schnellladesäulen auf der Strecke."
        }
        return Route(
            points = pts,
            cumM = cum,
            stepAlongM = stepAlong,
            stepTimeS = stepTime,
            distanceM = length,
            durationS = legTravel + chargeTotal + pauses,
            driveS = legTravel,
            steps = steps,
            summary = via,
            source = "TomTom",
            stops = stops,
            socProfile = profile,
            arrivalSoc = arrival,
            chargeS = chargeTotal,
            trafficDelayS = sum.num("trafficDelayInSeconds") ?: 0.0,
            jams = jams,
            timesIncludeCharging = includes,
            feasible = ok,
            reason = reason,
            weather = w,
        )
    }

    /** Schnelllader entlang einer Strecke (CCS, ab minKw), sortiert nach Umweg */
    suspend fun searchAlongRoute(key: String, pts: List<LatLon>, minKw: Int, maxDetourS: Int = 900): List<ChargerHit> {
        if (pts.size < 2) return emptyList()
        val stepN = (pts.size / 800).coerceAtLeast(1)
        val sample = pts.filterIndexed { i, _ -> i % stepN == 0 || i == pts.lastIndex }
        val url = "$BASE/search/2/searchAlongRoute/" + URLEncoder.encode("charging station", "UTF-8").replace("+", "%20") +
            ".json?key=$key&maxDetourTime=$maxDetourS&limit=20&categorySet=7309&connectorSet=IEC62196Type2CCS" +
            "&minPowerKW=$minKw&sortBy=detourTime&spreadingMode=auto&language=de-DE"
        val body = buildJsonObject {
            putJsonObject("route") {
                putJsonArray("points") {
                    sample.forEach { p ->
                        addJsonObject {
                            put("lat", p.lat)
                            put("lon", p.lon)
                        }
                    }
                }
            }
        }
        ApiCounter.hit()
        val r = Http.call(Request.Builder().url(url).post(body.toString().toRequestBody(JSON_TYPE)).build())
        if (r.code != 200) throw IOException(errorText(r))
        val root = json.parseToJsonElement(r.body).jsonObject
        val hits = root.arr("results").mapNotNull { e ->
            val o = e.jsonObject
            val poi = o.obj("poi") ?: return@mapNotNull null
            val pos = o.obj("position") ?: return@mapNotNull null
            val brand = poi.arr("brands").firstOrNull()?.let { (it as? JsonObject)?.str("name") } ?: ""
            val kw = o.obj("chargingPark")?.arr("connectors")?.mapNotNull { c -> (c as? JsonObject)?.num("ratedPowerKW") }?.maxOrNull() ?: 0.0
            ChargerHit(
                name = poi.str("name").ifBlank { "Ladestation" },
                operator = brand,
                pos = LatLon(pos.num("lat") ?: 0.0, pos.num("lon") ?: 0.0),
                powerKw = kw,
                detourS = o.num("detourTime") ?: 0.0,
                alongM = 0.0,
                availId = o.obj("dataSources")?.obj("chargingAvailability")?.str("id")?.ifBlank { null },
            )
        }
        KnownOperators.note(hits.map { it.operator })
        return hits
    }

    /** Live-Belegung eines Ladeparks (nicht jeder Betreiber liefert Daten) */
    suspend fun availability(key: String, uuid: String): Availability {
        ApiCounter.hit()
        val url = "$BASE/search/2/chargingAvailability.json?key=$key&chargingAvailability=$uuid"
        val r = Http.call(Request.Builder().url(url).build())
        if (r.code != 200) return Availability(0, 0, false)
        val o = runCatching { json.parseToJsonElement(r.body).jsonObject }.getOrNull() ?: return Availability(0, 0, false)
        var avail = 0
        var total = 0
        var known = false
        o.arr("connectors").forEach { c ->
            val cur = c.jsonObject.obj("availability")?.obj("current") ?: return@forEach
            val a = cur.int("available") ?: 0
            val sumAll = a + (cur.int("occupied") ?: 0) + (cur.int("reserved") ?: 0) +
                (cur.int("outOfService") ?: 0) + (cur.int("unknown") ?: 0)
            avail += a
            total += sumAll
            if (sumAll > (cur.int("unknown") ?: 0)) known = true
        }
        return Availability(avail, total, known)
    }
}
