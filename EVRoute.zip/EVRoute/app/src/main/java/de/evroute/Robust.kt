package de.evroute

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.maplibre.android.offline.OfflineGeometryRegionDefinition
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionError
import org.maplibre.android.offline.OfflineRegionStatus
import org.maplibre.geojson.LineString
import org.maplibre.geojson.MultiLineString
import org.maplibre.geojson.Point
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/** Absturz-Protokoll: schreibt unerwartete Fehler in eine Datei, die man teilen kann */
object CrashLog {
    private lateinit var file: File
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "crash.log")
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                write("ABSTURZ im Thread ${t.name}\n$sw")
            }
            previous?.uncaughtException(t, e)
        }
    }

    /** Auch nicht tödliche Fehler festhalten */
    fun note(msg: String) { runCatching { write(msg) } }

    @Synchronized
    private fun write(text: String) {
        val stamp = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.GERMANY).format(Date())
        val old = if (file.exists()) file.readText() else ""
        val all = ("$old\n=== $stamp · EVRoute ${BuildConfigLite.version} ===\n$text\n").takeLast(60_000)
        file.writeText(all)
        _version.value++
    }

    fun text(): String = runCatching { if (file.exists()) file.readText() else "" }.getOrDefault("")

    fun clear() { runCatching { file.delete() }; _version.value++ }
}

/** Versionsangabe ohne BuildConfig-Generierung */
object BuildConfigLite {
    var version: String = "?"
}

/**
 * Offline-Karte: lädt die Kartenkacheln entlang der Route (Route plus ein Streifen links und rechts)
 * in den Speicher der Karte, damit sie auch im Funkloch sichtbar bleibt.
 */
object OfflineMaps {
    data class State(
        val running: Boolean = false,
        val percent: Int = 0,
        val sizeMb: Double = 0.0,
        val label: String = "",
        val done: Boolean = false,
        val error: String? = null,
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private var current: OfflineRegion? = null
    private var lastRouteId = 0

    fun isWifi(ctx: Context): Boolean = runCatching {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true || caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true
    }.getOrDefault(false)

    /** Automatisch laden, wenn eingeschaltet (und ggf. nur im WLAN) */
    fun auto(ctx: Context, r: Route, label: String, dark: Boolean) {
        val s = Settings.state.value
        if (!s.offlineAuto) return
        if (s.offlineWifiOnly && !isWifi(ctx)) return
        download(ctx, r, label, dark)
    }

    fun download(ctx: Context, r: Route, label: String, dark: Boolean) {
        val id = System.identityHashCode(r)
        if (id == lastRouteId && (_state.value.running || _state.value.done)) return
        lastRouteId = id
        val om = OfflineManager.getInstance(ctx)
        current?.let { runCatching { it.setDownloadState(OfflineRegion.STATE_INACTIVE) } }
        deleteAll(ctx) {
            val geometry = corridor(r, 1200.0)
            val maxZoom = if (Settings.state.value.offlineDetail) 14.0 else 12.0
            val def = OfflineGeometryRegionDefinition(
                offlineStyleUrl(dark), geometry, 5.0, maxZoom, ctx.resources.displayMetrics.density,
            )
            _state.value = State(running = true, label = label)
            om.createOfflineRegion(
                def, "evroute-route".toByteArray(),
                object : OfflineManager.CreateOfflineRegionCallback {
                    override fun onCreate(offlineRegion: OfflineRegion) {
                        current = offlineRegion
                        offlineRegion.setObserver(object : OfflineRegion.OfflineRegionObserver {
                            override fun onStatusChanged(status: OfflineRegionStatus) {
                                val req = status.requiredResourceCount.coerceAtLeast(1)
                                val pct = (status.completedResourceCount * 100 / req).toInt().coerceIn(0, 100)
                                val mb = status.completedResourceSize / 1_048_576.0
                                val complete = status.isComplete
                                _state.value = State(running = !complete, percent = pct, sizeMb = mb, label = label, done = complete)
                                if (complete) offlineRegion.setDownloadState(OfflineRegion.STATE_INACTIVE)
                            }

                            override fun onError(error: OfflineRegionError) {
                                _state.value = _state.value.copy(error = error.message)
                            }

                            override fun mapboxTileCountLimitExceeded(limit: Long) {
                                _state.value = _state.value.copy(running = false, error = "Zu viele Kacheln ($limit)")
                            }
                        })
                        offlineRegion.setDownloadState(OfflineRegion.STATE_ACTIVE)
                    }

                    override fun onError(error: String) {
                        _state.value = State(error = error, label = label)
                    }
                },
            )
        }
    }

    /** Alle gespeicherten Offline-Bereiche löschen */
    fun deleteAll(ctx: Context, then: () -> Unit = {}) {
        val om = OfflineManager.getInstance(ctx)
        om.listOfflineRegions(object : OfflineManager.ListOfflineRegionsCallback {
            override fun onList(offlineRegions: Array<OfflineRegion>?) {
                val list = offlineRegions.orEmpty()
                if (list.isEmpty()) { then(); return }
                var left = list.size
                list.forEach { reg ->
                    reg.delete(object : OfflineRegion.OfflineRegionDeleteCallback {
                        override fun onDelete() { left--; if (left == 0) then() }
                        override fun onError(error: String) { left--; if (left == 0) then() }
                    })
                }
            }

            override fun onError(error: String) { then() }
        })
    }

    fun clear(ctx: Context) {
        current?.let { runCatching { it.setDownloadState(OfflineRegion.STATE_INACTIVE) } }
        current = null
        lastRouteId = 0
        deleteAll(ctx) { _state.value = State() }
    }

    /** Route plus parallele Linien links und rechts (ca. ±1,2 km), damit auch der Rand geladen wird */
    private fun corridor(r: Route, offsetM: Double): MultiLineString {
        val pts = r.points
        val step = (pts.size / 1500).coerceAtLeast(1)
        val sample = pts.filterIndexed { i, _ -> i % step == 0 || i == pts.lastIndex }
        fun shifted(sign: Double): List<Point> = sample.mapIndexed { i, p ->
            val a = sample[(i - 1).coerceAtLeast(0)]
            val b = sample[(i + 1).coerceAtMost(sample.lastIndex)]
            val brg = Math.toRadians(bearing(a, b) + 90.0 * sign)
            val dLat = cos(brg) * offsetM / 110540.0
            val dLon = sin(brg) * offsetM / (111320.0 * cos(Math.toRadians(p.lat)))
            Point.fromLngLat(p.lon + dLon, p.lat + dLat)
        }
        val center = sample.map { Point.fromLngLat(it.lon, it.lat) }
        return MultiLineString.fromLineStrings(
            listOf(LineString.fromLngLats(center), LineString.fromLngLats(shifted(1.0)), LineString.fromLngLats(shifted(-1.0))),
        )
    }
}
