package de.evroute

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Ladestationen direkt auf der Karte (im sichtbaren Ausschnitt) */
object MapChargers {
    data class State(
        val active: Boolean = false,
        val loading: Boolean = false,
        val hits: List<ChargerHit> = emptyList(),
        val error: String? = null,
        val selected: ChargerHit? = null,
        val availability: Map<String, Availability> = emptyMap(),
        val searchedAt: LatLon? = null,
        val searchedRadius: Int = 0,
        val tooFar: Boolean = false,
    )

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    // letzter Kartenausschnitt (Mitte und Radius bis zur Ecke)
    @Volatile var viewCenter: LatLon? = null
    @Volatile var viewRadius: Int = 5000
    private val _moved = MutableStateFlow(false)
    val moved: StateFlow<Boolean> = _moved.asStateFlow()

    fun onCameraIdle(center: LatLon, radiusM: Int) {
        viewCenter = center
        viewRadius = radiusM
        val s = _state.value
        val at = s.searchedAt
        _moved.value = s.active && at != null && (haversine(at, center) > s.searchedRadius * 0.35 || radiusM > s.searchedRadius * 1.6)
    }

    fun toggle() {
        if (_state.value.active) {
            _state.value = State()
            _moved.value = false
        } else {
            _state.value = State(active = true)
            searchHere()
        }
    }

    /** Im aktuellen Ausschnitt suchen */
    fun searchHere() {
        val set = Settings.state.value
        val c = viewCenter ?: LocationHub.fix.value?.pos ?: return
        if (!set.hasTomTom) {
            _state.update { it.copy(active = true, loading = false, error = "Dafür wird der TomTom-Key benötigt (Einstellungen → TomTom).") }
            return
        }
        val radius = viewRadius.coerceAtLeast(1000)
        if (radius > 40_000) {
            _state.update { it.copy(active = true, loading = false, tooFar = true, hits = emptyList(), searchedAt = c, searchedRadius = radius) }
            _moved.value = false
            return
        }
        _state.update { it.copy(active = true, loading = true, error = null, tooFar = false) }
        _moved.value = false
        scope.launch {
            val minKw = if (set.mapFastOnly) 50 else 0
            val res = runCatching { TomTom.nearby(set.tomtomKey.trim(), c, radius, minKw, set.mapFastOnly) }
            _state.update { s ->
                res.fold(
                    { hits -> s.copy(loading = false, hits = hits.sortedByDescending { it.powerKw }, searchedAt = c, searchedRadius = radius) },
                    { e -> s.copy(loading = false, error = e.message, searchedAt = c, searchedRadius = radius) },
                )
            }
        }
    }

    fun setFastOnly(b: Boolean) {
        Settings.update { it.copy(mapFastOnly = b) }
        if (_state.value.active) searchHere()
    }

    fun select(id: String) {
        val h = _state.value.hits.firstOrNull { it.id == id } ?: return
        _state.update { it.copy(selected = h) }
        val key = Settings.state.value.tomtomKey.trim()
        val av = h.availId ?: return
        if (key.isBlank() || av in _state.value.availability) return
        scope.launch {
            val a = runCatching { TomTom.availability(key, av) }.getOrNull() ?: return@launch
            _state.update { it.copy(availability = it.availability + (av to a)) }
        }
    }

    fun closeInfo() { _state.update { it.copy(selected = null) } }

    /** Farbe nach Leistung: grün ab 150 kW, blau ab 50 kW, grau darunter */
    fun iconFor(kw: Double) = when {
        kw >= 150 -> "mc-fast"
        kw >= 50 -> "mc-mid"
        else -> "mc-slow"
    }

    fun addIcons(ctx: Context, s: org.maplibre.android.maps.Style) {
        s.addImage("mc-fast", VehicleIcons.chargerColored(ctx, 0xFF30D158.toInt()))
        s.addImage("mc-mid", VehicleIcons.chargerColored(ctx, 0xFF0A84FF.toInt()))
        s.addImage("mc-slow", VehicleIcons.chargerColored(ctx, 0xFF8E8E93.toInt()))
    }
}

/** Hinweis oben: „In diesem Bereich suchen“, Filter, Ladeanzeige */
@Composable
fun MapChargerPill(st: MapChargers.State, moved: Boolean, fastOnly: Boolean) {
    val pal = LocalPal.current
    Surface(shape = RoundedCornerShape(18.dp), color = pal.card, shadowElevation = 8.dp) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            when {
                st.loading -> {
                    CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Suche Ladestationen …", color = pal.text, fontSize = 14.sp)
                }
                st.tooFar -> Text("Weiter hineinzoomen", color = pal.text, fontSize = 14.sp)
                moved -> Text(
                    "In diesem Bereich suchen", color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { MapChargers.searchHere() },
                )
                st.error != null -> Text(st.error, color = pal.red, fontSize = 13.sp, maxLines = 2)
                else -> Text("${st.hits.size} Ladestationen", color = pal.text, fontSize = 14.sp)
            }
            Spacer(Modifier.width(10.dp))
            Text(
                if (fastOnly) "Schnelllader" else "Alle",
                color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(pal.blue)
                    .clickable { MapChargers.setFastOnly(!fastOnly) }.padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

/** Infokarte einer angetippten Ladestation */
@Composable
fun ChargerInfoCard(h: ChargerHit, a: Availability?, me: LatLon?, nav: NavSession.State) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 24.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(h.name, color = pal.text, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (h.operator.isNotBlank()) Text(h.operator, color = pal.sub, fontSize = 14.sp)
                }
                CloseDot { MapChargers.closeInfo() }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoChip(if (h.powerKw > 0) "${h.powerKw.roundToInt()} kW" else "kW unbekannt", if (h.powerKw >= 150) pal.green else pal.blue)
                if (a != null && a.known) InfoChip("${a.available}/${a.total} frei", if (a.available > 0) pal.green else pal.red)
                me?.let { InfoChip(fmtKm(haversine(it, h.pos)), pal.sub) }
            }
            if (h.connectors.isNotBlank()) Text(h.connectors, color = pal.text, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            if (h.address.isNotBlank()) Text(h.address, color = pal.sub, fontSize = 13.sp, maxLines = 2)
            if (h.teslaOnly || h.operator.contains("Tesla", true)) {
                Text(
                    "Tesla: vor Ort bzw. in der Tesla-App prüfen, ob der Standort für andere Autos freigegeben ist.",
                    color = Color(0xFFFF9500), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { MapChargers.closeInfo(); NavSession.plan(Place(h.name + if (h.address.isNotBlank()) ", ${h.address}" else "", h.pos)) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                ) { Text("Route hierhin", fontWeight = FontWeight.Bold) }
                if (nav.dest != null || nav.navigating) {
                    Button(
                        onClick = { MapChargers.closeInfo(); NavSession.pickCharger(h) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = pal.green, contentColor = Color.White),
                    ) { Text(if (nav.navigating) "Hier laden" else "Als Ladestopp", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun InfoChip(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.14f)).padding(horizontal = 8.dp, vertical = 4.dp),
    )
}
