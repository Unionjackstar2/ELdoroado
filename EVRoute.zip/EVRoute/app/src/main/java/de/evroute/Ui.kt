@file:OptIn(ExperimentalMaterial3Api::class)

package de.evroute

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.animation.core.animate
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.speech.RecognizerIntent
import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.material.icons.filled.Mic
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.roundToInt

// ---------------- Farben im Apple-Stil ----------------

class Pal(val dark: Boolean) {
    val card = if (dark) Color(0xF21C1C1E) else Color(0xF7FFFFFF)
    val cardSolid = if (dark) Color(0xFF1C1C1E) else Color.White
    val screen = if (dark) Color.Black else Color(0xFFF2F2F7)
    val field = if (dark) Color(0xFF2C2C2E) else Color(0xFFEDEDF0)
    val text = if (dark) Color.White else Color(0xFF1C1C1E)
    val sub = Color(0xFF8E8E93)
    val blue = Color(0xFF0A84FF)
    val green = if (dark) Color(0xFF30D158) else Color(0xFF34C759)
    val red = Color(0xFFFF3B30)
    val banner = Color(0xFF1F2A24)
    val divider = if (dark) Color(0x26FFFFFF) else Color(0x1A000000)
    val selectedSeg = if (dark) Color(0xFF636366) else Color.White
}

val LocalPal = staticCompositionLocalOf { Pal(false) }

private val CAR_COLORS = listOf(
    0xFF0A84FF, 0xFFF2F2F7, 0xFFFF3B30, 0xFF8E8E93, 0xFF1C1C1E, 0xFF30D158, 0xFFFF9F0A,
)

// ---------------- Hauptbildschirm ----------------

@Composable
fun EvRouteApp(vm: MainViewModel) {
    val settings by Settings.state.collectAsState()
    val nav by NavSession.state.collectAsState()
    val fix by LocationHub.fix.collectAsState()
    val ui by vm.ui.collectAsState()
    val recents by Recents.items.collectAsState()
    val mc by MapChargers.state.collectAsState()
    val view = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.DisposableEffect(nav.navigating) {
        view.keepScreenOn = nav.navigating
        onDispose { view.keepScreenOn = false }
    }
    val mcMoved by MapChargers.moved.collectAsState()
    val ctx = LocalContext.current
    val dark = when (settings.mapMode) {
        MapMode.AUTO -> isSystemInDarkTheme()
        MapMode.DAY -> false
        MapMode.NIGHT -> true
    }
    val pal = remember(dark) { Pal(dark) }

    BackHandler(enabled = ui.showSettings && !ui.showObd && !ui.showTrips) { vm.closeSettings() }
    BackHandler(enabled = ui.showTrips) { vm.closeTrips() }
    BackHandler(enabled = ui.showObd) { vm.closeObd() }
    BackHandler(enabled = !ui.showSettings && !ui.showObd && ui.mode != SearchMode.DEST) { vm.cancelSearch() }
    BackHandler(enabled = !ui.showSettings && nav.chargerSearch != null) { NavSession.closeChargerSearch() }
    BackHandler(enabled = !ui.showSettings && ui.longPress != null) { vm.closeLongPress() }
    BackHandler(enabled = !ui.showSettings && mc.selected != null) { MapChargers.closeInfo() }
    BackHandler(enabled = !ui.showSettings && !nav.navigating && nav.dest != null) { NavSession.clear() }

    CompositionLocalProvider(LocalPal provides pal) {
        MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = pal.blue) else lightColorScheme(primary = pal.blue)) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val hPx = with(LocalDensity.current) { maxHeight.toPx() }.toDouble()
                val sheetMax = maxHeight
                val route = nav.route
                val progress = nav.progress

                EvMap(
                    routes = nav.routes,
                    selected = nav.selected,
                    navigating = nav.navigating,
                    progress = progress,
                    fix = fix,
                    vehicle = settings.vehicle,
                    carColor = settings.carColor,
                    dark = dark,
                    follow = ui.follow,
                    recenterTick = ui.recenter,
                    topPadPx = hPx * 0.40,
                    bottomPadPx = hPx * 0.12,
                    sheetPadPx = if (ui.sheetPx > 0 && nav.dest != null) ui.sheetPx + with(LocalDensity.current) { 40.dp.roundToPx() } else (hPx * 0.50).toInt(),
                    onGesture = vm::onGesture,
                    onTap = vm::onMapTap,
                    mapStyleChoice = settings.mapStyle * 10 + if (settings.hasTomTom) 1 else 0,
                    nightStyleChoice = settings.nightStyle,
                    onLongPress = vm::onLongPress,
                    mapChargers = if (mc.active) mc.hits else emptyList(),
                    onChargerTap = { id -> MapChargers.select(id) },
                    trafficUrl = if (settings.hasTomTom && settings.showTraffic) TomTom.trafficTileUrl(settings.tomtomKey.trim(), dark) else null,
                    modifier = Modifier.fillMaxSize(),
                )

                // ----- Fahrzeug als festes Bild über der Karte (Kamera folgt, daher immer gleiche Stelle) -----
                if (nav.navigating && ui.follow && progress != null && !nav.arrived) {
                    val vctx = LocalContext.current
                    val bmp = remember(settings.vehicle, settings.carColor) {
                        when (settings.vehicle) {
                            VehicleIcon.ARROW -> VehicleIcons.arrow(vctx)
                            VehicleIcon.CAR -> VehicleIcons.car(vctx, settings.carColor.toInt())
                            VehicleIcon.DOT -> VehicleIcons.dot(vctx)
                        }.asImageBitmap()
                    }
                    val size = when (settings.vehicle) {
                        VehicleIcon.ARROW -> 50.dp
                        VehicleIcon.CAR -> 54.dp
                        VehicleIcon.DOT -> 34.dp
                    }
                    // Mitte des freien Kartenbereichs (oben 40 %, unten 12 % Abstand, wie bei der Kamera)
                    val cy = maxHeight * 0.64f
                    Image(
                        bmp, null,
                        Modifier.offset(x = maxWidth / 2 - size / 2, y = cy - size / 2).size(size)
                            .graphicsLayer {
                                if (settings.vehicle != VehicleIcon.DOT) {
                                    rotationX = 45f
                                    cameraDistance = 14f * density
                                }
                            },
                    )
                }

                // ----- oben -----
                Column(
                    Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (ui.mode == SearchMode.DEST && nav.navigating && route != null && progress != null && !nav.arrived) {
                        NavBanner(route, progress)
                        LanePanel(route, progress, fix?.speed ?: 0.0)
                        nav.warning?.let { WarningCard(it) }
                        if (nav.gpsLost) InfoPill("Kein GPS (Tunnel?) – Position wird geschätzt", spinner = false)
                    }
                    if (mc.active && !nav.navigating && ui.mode == SearchMode.DEST) {
                        Box(Modifier.fillMaxWidth().padding(end = 64.dp), contentAlignment = Alignment.CenterStart) { MapChargerPill(mc, mcMoved, settings.mapFastOnly) }
                    }
                    if (nav.rerouting) InfoPill("Route wird neu berechnet …", spinner = true)
                    nav.offer?.let { o ->
                        ActionCard(
                            "Schnellere Route: ${fmtDuration(o.savedS)} gespart",
                            "Übernehmen", NavSession::acceptOffer, NavSession::dismissOffer,
                        )
                    }
                    nav.fullPark?.let { p ->
                        ActionCard(
                            "Ladepark „${p.name}“ ist gerade voll belegt",
                            "Anderen suchen", NavSession::avoidFullPark, NavSession::dismissFullPark,
                        )
                    }
                    if (nav.navigating && progress != null && progress.offRouteM > 60 && !nav.rerouting) {
                        InfoPill("Abseits der Route", spinner = false)
                    }
                }

                // ----- rechts: Kartenknöpfe -----
                Column(
                    if (nav.navigating) Modifier.align(Alignment.CenterEnd).padding(end = 12.dp)
                    else Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 8.dp, end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (!nav.navigating) MapButton(Icons.Filled.Settings, "Einstellungen") { vm.openSettings() }
                    if (!nav.navigating) {
                        MapButton(Icons.Filled.EvStation, "Ladestationen auf der Karte", tint = if (mc.active) pal.green else pal.blue) { MapChargers.toggle() }
                    }
                    if (!ui.follow || !nav.navigating) MapButton(Icons.Filled.NearMe, "Zentrieren") { vm.recenter() }
                    if (nav.navigating) {
                        MapButton(
                            if (settings.voice) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                            "Sprachansagen",
                            tint = if (settings.voice) pal.blue else pal.sub,
                        ) { Settings.update { it.copy(voice = !it.voice) } }
                        MapButton(Icons.Filled.Refresh, "Route neu berechnen") { NavSession.rerouteNow() }
                        if (settings.hasTomTom) MapButton(Icons.Filled.EvStation, "Ladestationen suchen", tint = pal.green) { NavSession.openChargerSearch() }
                        MapButton(Icons.Filled.AddLocationAlt, "Stopp hinzufügen") { vm.startSearch(SearchMode.VIA) }
                    }
                }

                // ----- unten -----
                Column(
                    Modifier.align(Alignment.BottomCenter).navigationBarsPadding().imePadding().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    val lp = ui.longPress
                    val sel = mc.selected
                    when {
                        nav.chargerSearch != null -> ChargerSheet(nav, settings, sheetMax)
                        ui.mode != SearchMode.DEST -> SearchSheet(ui, recents, vm, sheetMax)
                        sel != null -> ChargerInfoCard(sel, sel.availId?.let { mc.availability[it] }, fix?.pos, nav)
                        lp != null && ui.mode == SearchMode.DEST -> LongPressCard(lp, nav.dest != null || nav.navigating, vm)
                        nav.arrived -> ArrivedCard(nav.dest) { NavSession.stop(ctx) }
                        nav.navigating && route != null && progress != null -> {
                            SpeedRow(fix, route, progress)
                            NavFooter(route, progress, nav.availability) { NavSession.stop(ctx) }
                        }
                        nav.navigating -> GlassCard { Text("Warte auf GPS …", Modifier.padding(18.dp), color = pal.text) }
                        nav.dest != null -> RouteSheet(nav, settings, sheetMax, vm, onGo = {
                            vm.recenter()
                            NavSession.start(ctx)
                        })
                        else -> SearchSheet(ui, recents, vm, sheetMax)
                    }
                }
            }
            if (ui.showSettings) SettingsScreen(settings, vm::closeSettings, vm::openObd, vm::openTrips)
            if (ui.showObd) ObdScreen(vm)
            if (ui.showTrips) TripsScreen(vm)
            ui.editFav?.let { f -> FavEditDialog(f) { vm.editFavorite(null) } }
        }
    }
}

// ---------------- Bausteine ----------------

@Composable
fun GlassCard(modifier: Modifier = Modifier, corner: Dp = 22.dp, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(corner),
        color = LocalPal.current.card,
        shadowElevation = 12.dp,
    ) { Column(content = content) }
}

@Composable
fun MapButton(icon: ImageVector, desc: String, tint: Color = LocalPal.current.blue, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = LocalPal.current.card,
        shadowElevation = 8.dp,
        modifier = Modifier.size(50.dp),
    ) { Box(contentAlignment = Alignment.Center) { Icon(icon, desc, tint = tint) } }
}

@Composable
fun InfoPill(text: String, spinner: Boolean) {
    val pal = LocalPal.current
    Surface(shape = RoundedCornerShape(16.dp), color = pal.card, shadowElevation = 6.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (spinner) {
                CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
            }
            Text(text, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ---------------- Suche ----------------

/** Suche als Fenster am unteren Rand: zu sieht man nur die Suchleiste, hochgezogen Favoriten und Zuletzt */
@Composable
fun SearchSheet(ui: MainViewModel.Ui, recents: List<Place>, vm: MainViewModel, screenH: Dp) {
    val pal = LocalPal.current
    val focus = LocalFocusManager.current
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val peek = with(density) { (if (ui.mode == SearchMode.DEST) 92.dp else 132.dp).toPx() }
    val full = with(density) { (screenH * 0.62f).toPx() }
    var h by remember { mutableFloatStateOf(peek) }
    val open = ui.searchActive || ui.query.isNotEmpty() || ui.mode != SearchMode.DEST
    LaunchedEffect(open) {
        if (open && h < full * 0.9f) animate(h, full) { v, _ -> h = v }
        if (!open && h > peek + 1f) animate(h, peek) { v, _ -> h = v }
    }
    LaunchedEffect(peek) { if (!open) h = peek }
    val drag = rememberDraggableState { d -> h = (h - d).coerceIn(peek, full) }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) { vm.setSearchActive(true); vm.onQuery(text) }
    }

    GlassCard(Modifier.fillMaxWidth().height(with(density) { h.toDp() }), corner = 26.dp) {
        Column(
            Modifier.fillMaxWidth().draggable(
                state = drag,
                orientation = Orientation.Vertical,
                onDragStopped = { v ->
                    val target = when {
                        v < -1000f -> full
                        v > 1000f -> peek
                        else -> if (h > (peek + full) / 2) full else peek
                    }
                    if (target == peek) { focus.clearFocus(); vm.setSearchActive(false) }
                    animate(h, target, initialVelocity = -v) { value, _ -> h = value }
                },
            ).padding(top = 8.dp),
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(pal.sub.copy(alpha = 0.5f)))
            }
            if (ui.mode != SearchMode.DEST) {
                Row(Modifier.padding(start = 16.dp, end = 10.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when (ui.mode) {
                            SearchMode.HOME -> "Zuhause festlegen"
                            SearchMode.WORK -> "Arbeit festlegen"
                            SearchMode.FAV -> "Favorit hinzufügen"
                            else -> "Stopp hinzufügen"
                        },
                        color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                    )
                    CloseDot(vm::cancelSearch)
                }
            }
            Row(
                Modifier.padding(horizontal = 12.dp, vertical = 10.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.field)
                    .padding(start = 12.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Search, null, tint = pal.sub, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f).padding(vertical = 6.dp)) {
                    if (ui.query.isEmpty()) Text("Suche nach Ort oder Adresse", color = pal.sub, fontSize = 17.sp)
                    BasicTextField(
                        value = ui.query,
                        onValueChange = vm::onQuery,
                        singleLine = true,
                        textStyle = TextStyle(color = pal.text, fontSize = 17.sp),
                        cursorBrush = SolidColor(pal.blue),
                        modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) vm.setSearchActive(true) },
                    )
                }
                if (ui.query.isNotEmpty()) {
                    Box(Modifier.size(36.dp).clip(CircleShape).clickable { vm.onQuery("") }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Close, "Löschen", tint = pal.sub, modifier = Modifier.size(20.dp))
                    }
                }
                Box(
                    Modifier.size(36.dp).clip(CircleShape).clickable {
                        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
                            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Wohin möchtest du?")
                        try {
                            speech.launch(i)
                        } catch (e: ActivityNotFoundException) {
                            android.widget.Toast.makeText(ctx, "Spracheingabe ist auf diesem Gerät nicht verfügbar", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Mic, "Spracheingabe", tint = pal.blue, modifier = Modifier.size(22.dp)) }
            }
        }
        // Inhalt beim Hochziehen
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 10.dp)) {
            val showSuggestions = ui.query.trim().length >= 3
            if (ui.mode == SearchMode.DEST && !showSuggestions) FavoritesRow(vm)
            val items = if (showSuggestions) ui.suggestions else recents
            Text(
                if (showSuggestions) "Vorschläge" else "Zuletzt",
                color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 4.dp),
            )
            if (ui.searching && items.isEmpty()) {
                Text("Suche …", color = pal.sub, modifier = Modifier.padding(16.dp))
            } else if (items.isEmpty()) {
                Text(if (showSuggestions) "Nichts gefunden" else "Noch keine Ziele", color = pal.sub, modifier = Modifier.padding(16.dp))
            }
            items.forEach { p ->
                PlaceRow(p, recent = !showSuggestions) {
                    focus.clearFocus()
                    vm.pick(p)
                }
            }
        }
    }
}

@Composable
private fun PlaceRow(p: Place, recent: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(if (recent) pal.field else pal.red),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (recent) Icons.Filled.History else Icons.Filled.Place, null,
                tint = if (recent) pal.sub else Color.White, modifier = Modifier.size(20.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.title, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (p.subtitle.isNotBlank()) {
                Text(p.subtitle, color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ---------------- Routenauswahl ----------------

/** Akkustand beim Start (bis OBD in Runde 3 kommt, manuell) */
@Composable
fun SocStartRow(settings: AppSettings) {
    val pal = LocalPal.current
    val obd = obdSocState()
    if (obd != null) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Akku jetzt", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(fmtSoc(obd), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("  OBD", color = pal.green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        return
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Akku jetzt", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        StepButton("−") { changeSoc(settings, -5.0) }
        Text(fmtPct(settings.socStart), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
        StepButton("+") { changeSoc(settings, 5.0) }
    }
}

private fun changeSoc(s: AppSettings, delta: Double) {
    val v = (s.socStart + delta).coerceIn(5.0, 100.0)
    if (v == s.socStart) return
    Settings.update { it.copy(socStart = v) }
    NavSession.replan()
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(pal.cardSolid).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = pal.blue, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun RouteRow(r: Route, selected: Boolean, deltaS: Double, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (selected) pal.blue.copy(alpha = 0.12f) else pal.field.copy(alpha = 0.6f))
            .border(2.dp, if (selected) pal.blue else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fmtDuration(r.durationS), color = pal.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                if (deltaS > 60) {
                    Spacer(Modifier.width(8.dp))
                    Text("+${fmtDuration(deltaS)}", color = pal.sub, fontSize = 14.sp)
                }
            }
            Text(
                "${fmtKm(r.distanceM)} · Ankunft ${fmtEta(r.durationS)}" + if (r.summary.isNotBlank()) " · über ${r.summary}" else "",
                color = pal.sub, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            val ev = buildList {
                if (r.stops.isNotEmpty()) add("⚡ ${r.stops.size} × laden · ${fmtDuration(r.chargeS)}")
                r.arrivalSoc?.let { add("Ziel ${fmtPct(it)}") }
            }.joinToString(" · ")
            if (ev.isNotBlank()) Text(ev, color = if (r.feasible) pal.green else pal.red, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            if (r.trafficDelayS > 120) {
                Text("Verkehr: +${fmtDuration(r.trafficDelayS)}", color = Color(0xFFFF9500), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (r.tag.isNotBlank()) {
            Spacer(Modifier.width(8.dp))
            Text(
                r.tag,
                color = if (selected) Color.White else pal.text,
                fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (selected) pal.blue else pal.field)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

/** Details der gewählten Route: Wetter, Akku-Verlauf, Ladestopps */
@Composable
fun RouteDetails(r: Route, avail: Map<String, Availability>) {
    val pal = LocalPal.current
    Spacer(Modifier.height(12.dp))
    r.reason?.let { Text(it, color = pal.red, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp)) }
    r.weather?.let { w ->
        val wind = when {
            w.headwindKmh > 5 -> " · Gegenwind ${w.headwindKmh.roundToInt()} km/h"
            w.headwindKmh < -5 -> " · Rückenwind ${(-w.headwindKmh).roundToInt()} km/h"
            else -> ""
        }
        Text(
            "Wetter unterwegs: ${w.tempC.roundToInt()} °C$wind" + if (w.rain) " · Regen" else "",
            color = pal.sub, fontSize = 13.sp,
        )
    }
    if (r.socProfile.size >= 2) {
        Spacer(Modifier.height(8.dp))
        Text("Akku-Verlauf", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        SocChart(r)
    }
    if (r.stops.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        Text("Ladestopps", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        r.stops.forEachIndexed { i, st -> StopRow(i + 1, st, st.uuid?.let { avail[it] }) }
    }
}

@Composable
private fun StopRow(no: Int, st: ChargeStop, a: Availability?) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(pal.green), contentAlignment = Alignment.Center) {
            Text("$no", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(st.name, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val op = if (st.operator.isNotBlank() && st.operator != st.name) "${st.operator} · " else ""
            Text(
                "${op}km ${(st.alongM / 1000).roundToInt()} · ${st.powerKw.roundToInt()} kW",
                color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                "${fmtPct(st.arriveSoc)} → ${fmtPct(st.targetSoc)} · ${fmtDuration(st.chargeS)}",
                color = pal.text, fontSize = 13.sp,
            )
            if (Settings.state.value.hasTomTom && !NavSession.state.value.navigating) {
                Text(
                    "Anderen wählen", color = pal.blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 2.dp).clickable { NavSession.openChargerSearch(st.uuid) },
                )
            }
        }
        if (a != null && a.known) {
            Text(
                "${a.available}/${a.total} frei",
                color = if (a.available > 0) pal.green else pal.red, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

/** Akkustand über die Strecke, mit Reserve-Linie */
@Composable
private fun SocChart(r: Route) {
    val pal = LocalPal.current
    val total = max(1.0, r.cumM.lastOrNull() ?: 1.0)
    val minSoc = Settings.state.value.minSocStop
    Canvas(Modifier.fillMaxWidth().height(90.dp).padding(vertical = 6.dp)) {
        val w = size.width
        val h = size.height
        fun x(m: Double) = (m / total * w).toFloat()
        fun y(p: Double) = (h - (p.coerceIn(0.0, 100.0) / 100.0) * h).toFloat()
        // Reserve
        drawLine(pal.red.copy(alpha = 0.5f), Offset(0f, y(minSoc)), Offset(w, y(minSoc)), 2f)
        val line = Path()
        val fill = Path()
        r.socProfile.forEachIndexed { i, (m, p) ->
            if (i == 0) { line.moveTo(x(m), y(p)); fill.moveTo(x(m), h); fill.lineTo(x(m), y(p)) } else { line.lineTo(x(m), y(p)); fill.lineTo(x(m), y(p)) }
        }
        val last = r.socProfile.last()
        fill.lineTo(x(last.first), h)
        fill.close()
        drawPath(fill, pal.green.copy(alpha = 0.18f))
        drawPath(line, pal.green, style = Stroke(width = 5f))
        r.stops.forEach { st -> drawCircle(pal.green, 7f, Offset(x(st.alongM), y(st.targetSoc))) }
    }
}

@Composable
private fun ActionCard(text: String, action: String, onAction: () -> Unit, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 18.dp) {
        Column(Modifier.padding(14.dp)) {
            Text(text, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                ) { Text(action, fontWeight = FontWeight.Bold) }
                TextButton(onClick = onDismiss) { Text("Ignorieren", color = pal.sub) }
            }
        }
    }
}

// ---------------- Navigation ----------------

@Composable
fun NavBanner(r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val step = r.steps.getOrNull(p.stepIdx) ?: return
    val next = r.steps.getOrNull(p.stepIdx + 1)
    val live by NavSession.liveAlong.collectAsState()
    val dist = live?.let { a -> ((r.stepAlongM.getOrNull(p.stepIdx) ?: a) - a).coerceAtLeast(0.0) } ?: p.distToStepM
    Column {
        Surface(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = pal.banner,
            shadowElevation = 12.dp,
        ) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                ManeuverIcon(step.type, step.mod, Color.White, 64.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(fmtDistShort(dist), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                    Text(
                        step.bannerText(), color = Color.White.copy(alpha = 0.92f), fontSize = 21.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (next != null && step.distanceM < 300 && step.type != "arrive") {
            Surface(
                Modifier.padding(start = 16.dp),
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                color = pal.banner.copy(alpha = 0.94f),
            ) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Dann", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp))
                    ManeuverIcon(next.type, next.mod, Color.White, 26.dp)
                }
            }
        }
    }
}

@Composable
fun SpeedRow(fix: Fix?, r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val live by NavSession.liveAlong.collectAsState()
    val limit = r.limitAt(live ?: p.alongM)
    val kmh = ((fix?.speed ?: 0.0) * 3.6).roundToInt()
    val tooFast = limit != null && kmh > limit + 3
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
            shape = CircleShape, color = if (tooFast) pal.red else pal.card, shadowElevation = 8.dp, modifier = Modifier.size(64.dp),
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("$kmh", color = if (tooFast) Color.White else pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("km/h", color = if (tooFast) Color.White else pal.sub, fontSize = 11.sp)
            }
        }
        if (limit != null) {
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(60.dp).clip(CircleShape).background(Color.White).border(7.dp, Color(0xFFE30613), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text("$limit", color = Color.Black, fontSize = if (limit >= 100) 19.sp else 22.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun NavFooter(r: Route, p: NavProgress, avail: Map<String, Availability>, onEnd: () -> Unit) {
    val pal = LocalPal.current
    val next = r.stops.firstOrNull { it.alongM > p.alongM + 50 }
    GlassCard(Modifier.fillMaxWidth(), corner = 26.dp) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Stat(fmtEta(p.remainingS), "Ankunft", Modifier.weight(1f))
                Stat(fmtDuration(p.remainingS), "Restzeit", Modifier.weight(1f))
                Stat(fmtKm(p.remainingM), "Strecke", Modifier.weight(1f))
                Button(
                    onClick = onEnd,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.red, contentColor = Color.White),
                ) { Text("Ende", fontWeight = FontWeight.Bold) }
            }
            val nowSoc = r.socAt(p.alongM)
            val real = obdSocState()
            if (nowSoc != null || real != null) {
                Spacer(Modifier.height(10.dp))
                val dest = r.arrivalSoc
                val text = if (real != null) {
                    "🔋 ${fmtSoc(real)}" + (nowSoc?.let { " (Plan ${fmtPct(it)})" } ?: "")
                } else {
                    "🔋 jetzt ca. ${fmtPct(nowSoc ?: 0.0)}"
                }
                val diff = if (real != null && nowSoc != null) real - nowSoc else 0.0
                Text(
                    text + if (dest != null) " · am Ziel ${fmtPct(dest + diff)}" else "",
                    color = if (diff < -4) pal.red else pal.text, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                )
            }
            next?.let { st ->
                val a = st.uuid?.let { avail[it] }
                val free = if (a != null && a.known) " · ${a.available}/${a.total} frei" else ""
                Text(
                    "⚡ ${st.name} in ${fmtKm(st.alongM - p.alongM)} · Ankunft ${fmtPct(st.arriveSoc)} → ${fmtPct(st.targetSoc)}$free",
                    color = pal.green, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier) {
    val pal = LocalPal.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = pal.text, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = pal.sub, fontSize = 12.sp)
    }
}

@Composable
fun ArrivedCard(dest: Place?, onDone: () -> Unit) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 26.dp) {
        Column(Modifier.padding(18.dp)) {
            Text("Ziel erreicht", color = pal.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            dest?.let { Text(it.name, color = pal.sub, fontSize = 15.sp, maxLines = 2) }
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onDone,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(50.dp),
            ) { Text("Fertig", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

// ---------------- Einstellungen ----------------

enum class SettingsPage(val title: String) {
    MAIN("Einstellungen"), DISPLAY("Darstellung"), NAV("Navigation"), VEHICLE("Fahrzeug"),
    CHARGING("Ladeplanung"), OBD("OBD2-Adapter"), LEARN("Fahrten & Lernen"), TOMTOM("TomTom"),
    BACKUP("Sichern"), INFO("Info"),
}

@Composable
fun SettingsScreen(s: AppSettings, onClose: () -> Unit, onOpenObd: () -> Unit, onOpenTrips: () -> Unit) {
    val pal = LocalPal.current
    var page by remember { mutableStateOf(SettingsPage.MAIN) }
    BackHandler(enabled = page != SettingsPage.MAIN) { page = SettingsPage.MAIN }

    Surface(Modifier.fillMaxSize(), color = pal.screen) {
        Column(
            Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            // Kopfzeile
            if (page == SettingsPage.MAIN) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Einstellungen", color = pal.text, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onClose) { Text("Fertig", color = pal.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.clip(RoundedCornerShape(10.dp)).clickable { page = SettingsPage.MAIN }.padding(vertical = 6.dp, horizontal = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = pal.blue)
                        Text("Einstellungen", color = pal.blue, fontSize = 17.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onClose) { Text("Fertig", color = pal.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
                }
                Text(page.title, color = pal.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }

            when (page) {
                SettingsPage.MAIN -> SettingsMain(s) { page = it }
                SettingsPage.DISPLAY -> DisplayPage(s)
                SettingsPage.NAV -> NavPage(s)
                SettingsPage.VEHICLE -> VehiclePage(s)
                SettingsPage.CHARGING -> ChargingPage(s)
                SettingsPage.OBD -> Section("Adapter") { ObdSettingsSection(s, onOpenObd) }
                SettingsPage.LEARN -> Section("Aufzeichnung") { LearnSettingsSection(s, onOpenTrips) }
                SettingsPage.TOMTOM -> TomTomPage(s)
                SettingsPage.BACKUP -> Section("Sicherung") { BackupSection() }
                SettingsPage.INFO -> InfoPage()
            }
        }
    }
}

// ---------------- Übersicht ----------------

@Composable
private fun SettingsMain(s: AppSettings, open: (SettingsPage) -> Unit) {
    val conn by Obd.conn.collectAsState()
    val trips by TripRecorder.trips.collectAsState()
    val count by ApiCounter.today.collectAsState()

    MenuGroup("Karte und Fahrt") {
        MenuRow(Icons.Filled.Palette, Color(0xFFAF52DE), "Darstellung",
            "${listOf("Liberty", "Positron", "TomTom")[s.mapStyle.coerceIn(0, 2)]} · ${listOf("Automatisch", "Hell", "Dunkel")[s.mapMode.ordinal]} · ${listOf("Pfeil", "Auto", "Punkt")[s.vehicle.ordinal]}") { open(SettingsPage.DISPLAY) }
        MenuDivider()
        MenuRow(Icons.Filled.Navigation, Color(0xFF0A84FF), "Navigation",
            (if (s.voice) "Ansagen an" else "Ansagen aus") + if (s.avoidToll || s.avoidMotorway || s.avoidFerry) " · Vermeiden aktiv" else "") { open(SettingsPage.NAV) }
    }
    MenuGroup("Auto und Laden") {
        MenuRow(Icons.Filled.DirectionsCar, Color(0xFF5E5CE6), "Fahrzeug",
            "${String.format(java.util.Locale.GERMANY, "%.1f", s.usableKwh)} kWh · ${listOf("Sparsam", "Normal", "Zügig")[s.style.coerceIn(0, 2)]}") { open(SettingsPage.VEHICLE) }
        MenuDivider()
        MenuRow(Icons.Filled.EvStation, Color(0xFF30D158), "Ladeplanung",
            "Reserve ${fmtPct(s.minSocStop)} / Ziel ${fmtPct(s.minSocDest)}" +
                if (s.preferOperators.isNotEmpty()) " · ${s.preferOperators.size} bevorzugt" else "") { open(SettingsPage.CHARGING) }
        MenuDivider()
        MenuRow(Icons.Filled.Bluetooth, Color(0xFF0A84FF), "OBD2-Adapter",
            if (s.obdName.isBlank()) "Kein Adapter" else s.obdName + if (conn == Obd.Conn.READY) " · verbunden" else "") { open(SettingsPage.OBD) }
        MenuDivider()
        MenuRow(Icons.Filled.Insights, Color(0xFFFF9F0A), "Fahrten & Lernen",
            "${trips.size} Fahrten · ${Learner.totalKm().roundToInt()} km gelernt") { open(SettingsPage.LEARN) }
    }
    MenuGroup("Dienste") {
        MenuRow(Icons.Filled.Traffic, Color(0xFFFF3B30), "TomTom",
            if (s.hasTomTom) "Key hinterlegt · heute $count Anfragen" else "Kein Key – ohne Verkehr und Ladestopps") { open(SettingsPage.TOMTOM) }
    }
    MenuGroup("Allgemein") {
        MenuRow(Icons.Filled.Backup, Color(0xFF8E8E93), "Sichern und Wiederherstellen", "Einstellungen, Favoriten, Gelerntes") { open(SettingsPage.BACKUP) }
        MenuDivider()
        MenuRow(Icons.Filled.Info, Color(0xFF8E8E93), "Info", "Version, Datenquellen, Signatur") { open(SettingsPage.INFO) }
    }
}

@Composable
private fun MenuGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column {
        Text(title.uppercase(), color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 14.dp, bottom = 6.dp))
        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid) { Column(Modifier.fillMaxWidth(), content = content) }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, color: Color, title: String, summary: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(color), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = pal.text, fontSize = 16.sp)
            Text(summary, color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = pal.sub)
    }
}

@Composable
private fun MenuDivider() {
    Box(Modifier.fillMaxWidth().padding(start = 58.dp).height(1.dp).background(LocalPal.current.divider))
}

// ---------------- Unterseiten ----------------

@Composable
private fun DisplayPage(s: AppSettings) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    Section("Karte") {
        Label("Kartenstil")
        Segmented(listOf("Liberty", "Positron", "TomTom"), s.mapStyle.coerceIn(0, 2)) { i ->
            Settings.update { it.copy(mapStyle = i) }
        }
        Text(
            when (s.mapStyle) {
                1 -> "Positron: hell und zurückhaltend, ähnlich wie Apple Maps (OpenStreetMap)."
                2 -> if (s.hasTomTom) "TomTom: gleiches Kartenwerk wie die Route – die Linie liegt exakt auf der Straße. Tag und Nacht automatisch."
                else "TomTom braucht den TomTom-Key (Einstellungen → TomTom). Bis dahin wird Liberty angezeigt."
                else -> "Liberty: bunt und detailreich (OpenStreetMap)."
            },
            color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp),
        )
        if (s.mapStyle != 2) {
            Label("Kartenstil bei Nacht")
            Segmented(listOf("Dunkelblau (Fiord)", "Schwarz"), s.nightStyle.coerceIn(0, 1)) { i ->
                Settings.update { it.copy(nightStyle = i) }
            }
            Text("Fiord ist heller und besser lesbar, „Schwarz“ blendet nachts am wenigsten.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp))
        }
        Label("Hell oder dunkel")
        Segmented(listOf("Automatisch", "Hell", "Dunkel"), s.mapMode.ordinal) { i ->
            Settings.update { it.copy(mapMode = MapMode.entries[i]) }
        }
        Text("„Automatisch“ folgt dem Dunkelmodus des Handys.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
    Section("Fahrsymbol") {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            VehicleIcon.entries.forEach { v ->
                val bmp = remember(v, s.carColor) {
                    when (v) {
                        VehicleIcon.ARROW -> VehicleIcons.arrow(ctx)
                        VehicleIcon.CAR -> VehicleIcons.car(ctx, s.carColor.toInt())
                        VehicleIcon.DOT -> VehicleIcons.dot(ctx)
                    }.asImageBitmap()
                }
                val sel = s.vehicle == v
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(pal.field)
                        .border(2.dp, if (sel) pal.blue else Color.Transparent, RoundedCornerShape(14.dp))
                        .clickable { Settings.update { it.copy(vehicle = v) } }
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Image(bmp, null, Modifier.size(48.dp))
                    Text(listOf("Pfeil", "Auto", "Punkt")[v.ordinal], color = pal.text, fontSize = 14.sp)
                }
            }
        }
        if (s.vehicle == VehicleIcon.CAR) {
            Spacer(Modifier.height(16.dp))
            Label("Autofarbe")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CAR_COLORS.forEach { c ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                            .border(if (s.carColor == c) 3.dp else 1.dp, if (s.carColor == c) pal.blue else pal.divider, CircleShape)
                            .clickable { Settings.update { it.copy(carColor = c) } },
                    )
                }
            }
        }
    }
}

@Composable
private fun NavPage(s: AppSettings) {
    val pal = LocalPal.current
    Section("Ansagen") {
        ToggleRow("Sprachansagen", s.voice) { v -> Settings.update { it.copy(voice = v) } }
    }
    Section("Routen") {
        ToggleRow("Mautstraßen vermeiden", s.avoidToll) { v -> Settings.update { it.copy(avoidToll = v) } }
        ToggleRow("Autobahnen vermeiden", s.avoidMotorway) { v -> Settings.update { it.copy(avoidMotorway = v) } }
        ToggleRow("Fähren vermeiden", s.avoidFerry) { v -> Settings.update { it.copy(avoidFerry = v) } }
        Spacer(Modifier.height(10.dp))
        Label(if (s.maxSpeedKmh == 0) "Höchstgeschwindigkeit: keine Begrenzung" else "Höchstgeschwindigkeit: ${s.maxSpeedKmh} km/h")
        Slider(
            value = (if (s.maxSpeedKmh == 0) 170 else s.maxSpeedKmh).toFloat(),
            onValueChange = { v -> val k = (v / 10).roundToInt() * 10; Settings.update { it.copy(maxSpeedKmh = if (k >= 170) 0 else k) } },
            valueRange = 90f..170f,
        )
        Text("Gilt für neue Routen. Die Höchstgeschwindigkeit beeinflusst Fahrzeit und Verbrauch (nur mit TomTom).", color = pal.sub, fontSize = 13.sp)
    }
    Section("Verkehr") {
        ToggleRow("Verkehrslage auf der Karte", s.showTraffic) { v -> Settings.update { it.copy(showTraffic = v) } }
        if (!s.hasTomTom) Text("Braucht einen TomTom-Key.", color = pal.sub, fontSize = 13.sp)
    }
    Section("Offline-Karte") {
        val off by OfflineMaps.state.collectAsState()
        val ctx = LocalContext.current
        ToggleRow("Karte der Route automatisch speichern", s.offlineAuto) { v -> Settings.update { it.copy(offlineAuto = v) } }
        ToggleRow("Nur im WLAN", s.offlineWifiOnly) { v -> Settings.update { it.copy(offlineWifiOnly = v) } }
        Spacer(Modifier.height(6.dp))
        Label("Detailgrad")
        Segmented(listOf("Detailliert", "Sparsam"), if (s.offlineDetail) 0 else 1) { i -> Settings.update { it.copy(offlineDetail = i == 0) } }
        Text(
            "Gespeichert wird die Karte entlang der Route (etwa 1 km links und rechts). Detailliert braucht für 300 km grob 20–40 MB.",
            color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            when {
                off.error != null -> "Fehler: ${off.error}"
                off.running -> "Lädt „${off.label}“ … ${off.percent} % · ${String.format(java.util.Locale.GERMANY, "%.1f", off.sizeMb)} MB"
                off.done -> "Gespeichert: „${off.label}“ · ${String.format(java.util.Locale.GERMANY, "%.1f", off.sizeMb)} MB"
                else -> "Noch keine Route gespeichert."
            },
            color = if (off.error != null) pal.red else pal.text, fontSize = 14.sp,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
            if (NavSession.state.value.route != null) {
                TextButton(onClick = { NavSession.saveOffline() }) { Text("Aktuelle Route speichern") }
            }
            TextButton(onClick = { OfflineMaps.clear(ctx) }) { Text("Löschen", color = pal.red) }
        }
    }
}

@Composable
private fun VehiclePage(s: AppSettings) {
    val pal = LocalPal.current
    Section("Akku (Citroën ë-C4)") {
        Label("Nutzbare Kapazität: ${String.format(java.util.Locale.GERMANY, "%.1f", s.usableKwh)} kWh")
        Slider(
            value = s.usableKwh.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(usableKwh = (v * 2).roundToInt() / 2.0) } },
            valueRange = 40f..50f,
        )
        Text("Mit OBD kannst du den gemessenen Wert unter „OBD2-Adapter → Live & Rohdaten“ übernehmen.", color = pal.sub, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        ToggleRow("Akkustand abrunden wie im Auto", s.socFloor) { b -> Settings.update { it.copy(socFloor = b) } }
    }
    Section("Verbrauch") {
        Label("Fahrweise")
        Segmented(listOf("Sparsam", "Normal", "Zügig"), s.style) { i -> Settings.update { it.copy(style = i) } }
        Text("Wird nach und nach durch dein gelerntes Fahrverhalten ersetzt.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 12.dp))
        Label("Referenzverbrauch: ${s.refConsumptionPct} %")
        Slider(
            value = s.refConsumptionPct.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(refConsumptionPct = (v / 5).roundToInt() * 5) } },
            valueRange = 80f..130f,
        )
        Label("Zusatzgewicht (Personen, Gepäck): ${s.extraWeightKg} kg")
        Slider(
            value = s.extraWeightKg.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(extraWeightKg = (v / 25).roundToInt() * 25) } },
            valueRange = 0f..400f,
        )
    }
}

@Composable
private fun ChargingPage(s: AppSettings) {
    Section("Reserve") {
        Label("Mindest-Akku am Ladestopp: ${fmtPct(s.minSocStop)}")
        Slider(
            value = s.minSocStop.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(minSocStop = v.roundToInt().toDouble()) } },
            valueRange = 5f..30f,
        )
        Label("Mindest-Akku am Ziel: ${fmtPct(s.minSocDest)}")
        Slider(
            value = s.minSocDest.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(minSocDest = v.roundToInt().toDouble()) } },
            valueRange = 5f..50f,
        )
    }
    Section("Ladeanbieter und Ladekarten") { OperatorSettings(s) }
}

@Composable
private fun TomTomPage(s: AppSettings) {
    val pal = LocalPal.current
    Section("Zugang") {
        OutlinedTextField(
            value = s.tomtomKey,
            onValueChange = { v -> Settings.update { it.copy(tomtomKey = v.trim()) } },
            label = { Text("TomTom API-Key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Für Verkehr, Ladestopps, Spuren, Tempolimits und Ladesäulen-Belegung.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
    Section("Verbrauch heute") {
        val count by ApiCounter.today.collectAsState()
        Text("$count von 2.500 freien Anfragen", color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text("Karten-Kacheln für die Verkehrslage zählen extra (50.000 pro Tag).", color = pal.sub, fontSize = 13.sp)
    }
}

@Composable
private fun InfoPage() {
    val pal = LocalPal.current
    Section("Version") {
        Text("EVRoute 0.9 – Ladestationen auf der Karte", color = pal.text, fontSize = 16.sp)
        SigningInfo()
    }
    Section("Fehlerprotokoll") {
        val ver by CrashLog.version.collectAsState()
        val ctx = LocalContext.current
        val text = remember(ver) { CrashLog.text() }
        if (text.isBlank()) {
            Text("Keine Fehler aufgezeichnet.", color = pal.sub, fontSize = 14.sp)
        } else {
            val count = Regex("=== ").findAll(text).count()
            Text("$count Einträge, letzter:", color = pal.text, fontSize = 14.sp)
            Text(
                text.trim().substringAfterLast("=== ").take(600), color = pal.sub, fontSize = 12.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, maxLines = 12, overflow = TextOverflow.Ellipsis,
            )
            Row {
                TextButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "EVRoute Fehlerprotokoll")
                        putExtra(Intent.EXTRA_TEXT, CrashLog.text())
                    }
                    ctx.startActivity(Intent.createChooser(send, "Protokoll teilen"))
                }) { Text("Teilen") }
                TextButton(onClick = { CrashLog.clear() }) { Text("Löschen", color = pal.red) }
            }
        }
    }
    Section("Datenquellen") {
        Text(
            "Kartendaten © OpenStreetMap-Mitwirkende\nKartenstil: OpenFreeMap\nRouting ohne Key: OSRM\nSuche: Photon (Komoot)\n" +
                "Verkehr und Ladeplanung: TomTom\nWetter und Höhe: Open-Meteo",
            color = pal.sub, fontSize = 14.sp,
        )
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column {
        Text(title.uppercase(), color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 14.dp, bottom = 6.dp))
        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid) {
            Column(Modifier.fillMaxWidth().padding(14.dp), content = content)
        }
    }
}

@Composable
fun Label(t: String) {
    Text(t, color = LocalPal.current.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.field).padding(3.dp)) {
        options.forEachIndexed { i, o ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                    .background(if (i == selected) pal.selectedSeg else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    o, color = pal.text, fontSize = 14.sp,
                    fontWeight = if (i == selected) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

@Composable
fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = pal.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = value,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = pal.green, checkedThumbColor = Color.White),
        )
    }
}
