@file:OptIn(ExperimentalMaterial3Api::class)

package de.evroute

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.roundToInt

// ---------------- Farben im Apple-Stil ----------------

class Pal(val dark: Boolean) {
    val card = if (dark) Color(0xF21C1C1E) else Color(0xF7FFFFFF)
    val cardSolid = if (dark) Color(0xFF1C1C1E) else Color.White
    val screen = if (dark) Color.Black else Color(0xFFF2F2F7)
    val field = if (dark) Color(0xFF2C2C2E) else Color(0xFFEDEDF0)
    val text = if (dark) Color.White else Color(0xFF1C1C1E)
    val sub = Color(0xFF8E8E93)
    val blue = Color(0xFF0A84FF)
    val green = if (dark) Color(0xFF30D158) else Color(0xFF34C759)
    val red = Color(0xFFFF3B30)
    val banner = Color(0xFF1F2A24)
    val divider = if (dark) Color(0x26FFFFFF) else Color(0x1A000000)
    val selectedSeg = if (dark) Color(0xFF636366) else Color.White
}

val LocalPal = staticCompositionLocalOf { Pal(false) }

private val CAR_COLORS = listOf(
    0xFF0A84FF, 0xFFF2F2F7, 0xFFFF3B30, 0xFF8E8E93, 0xFF1C1C1E, 0xFF30D158, 0xFFFF9F0A,
)

// ---------------- Hauptbildschirm ----------------

@Composable
fun EvRouteApp(vm: MainViewModel) {
    val settings by Settings.state.collectAsState()
    val nav by NavSession.state.collectAsState()
    val fix by LocationHub.fix.collectAsState()
    val ui by vm.ui.collectAsState()
    val recents by Recents.items.collectAsState()
    val ctx = LocalContext.current
    val dark = when (settings.mapMode) {
        MapMode.AUTO -> isSystemInDarkTheme()
        MapMode.DAY -> false
        MapMode.NIGHT -> true
    }
    val pal = remember(dark) { Pal(dark) }

    BackHandler(enabled = ui.showSettings && !ui.showObd && !ui.showTrips) { vm.closeSettings() }
    BackHandler(enabled = ui.showTrips) { vm.closeTrips() }
    BackHandler(enabled = ui.showObd) { vm.closeObd() }
    BackHandler(enabled = !ui.showSettings && !ui.showObd && ui.mode != SearchMode.DEST) { vm.cancelSearch() }
    BackHandler(enabled = !ui.showSettings && nav.chargerSearch != null) { NavSession.closeChargerSearch() }
    BackHandler(enabled = !ui.showSettings && ui.longPress != null) { vm.closeLongPress() }
    BackHandler(enabled = !ui.showSettings && !nav.navigating && nav.dest != null) { NavSession.clear() }

    CompositionLocalProvider(LocalPal provides pal) {
        MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = pal.blue) else lightColorScheme(primary = pal.blue)) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val hPx = with(LocalDensity.current) { maxHeight.toPx() }.toDouble()
                val sheetMax = maxHeight
                val route = nav.route
                val progress = nav.progress

                EvMap(
                    routes = nav.routes,
                    selected = nav.selected,
                    navigating = nav.navigating,
                    progress = progress,
                    fix = fix,
                    vehicle = settings.vehicle,
                    carColor = settings.carColor,
                    dark = dark,
                    follow = ui.follow,
                    recenterTick = ui.recenter,
                    topPadPx = hPx * 0.40,
                    bottomPadPx = hPx * 0.12,
                    sheetPadPx = if (ui.sheetPx > 0 && nav.dest != null) ui.sheetPx + with(LocalDensity.current) { 40.dp.roundToPx() } else (hPx * 0.50).toInt(),
                    onGesture = vm::onGesture,
                    onTap = vm::onMapTap,
                    onLongPress = vm::onLongPress,
                    trafficUrl = if (settings.hasTomTom && settings.showTraffic) TomTom.trafficTileUrl(settings.tomtomKey.trim(), dark) else null,
                    modifier = Modifier.fillMaxSize(),
                )

                // ----- oben -----
                Column(
                    Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (ui.mode != SearchMode.DEST) {
                        SearchPanel(ui, recents, vm)
                    } else if (nav.navigating && route != null && progress != null && !nav.arrived) {
                        NavBanner(route, progress)
                        LanePanel(route, progress, fix?.speed ?: 0.0)
                        nav.warning?.let { WarningCard(it) }
                    } else if (!nav.navigating && nav.dest == null) {
                        SearchPanel(ui, recents, vm)
                    }
                    if (nav.rerouting) InfoPill("Route wird neu berechnet …", spinner = true)
                    nav.offer?.let { o ->
                        ActionCard(
                            "Schnellere Route: ${fmtDuration(o.savedS)} gespart",
                            "Übernehmen", NavSession::acceptOffer, NavSession::dismissOffer,
                        )
                    }
                    nav.fullPark?.let { p ->
                        ActionCard(
                            "Ladepark „${p.name}“ ist gerade voll belegt",
                            "Anderen suchen", NavSession::avoidFullPark, NavSession::dismissFullPark,
                        )
                    }
                    if (nav.navigating && progress != null && progress.offRouteM > 60 && !nav.rerouting) {
                        InfoPill("Abseits der Route", spinner = false)
                    }
                }

                // ----- rechts: Kartenknöpfe -----
                Column(
                    Modifier.align(Alignment.CenterEnd).padding(end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (!nav.navigating) MapButton(Icons.Filled.Settings, "Einstellungen") { vm.openSettings() }
                    if (!ui.follow || !nav.navigating) MapButton(Icons.Filled.NearMe, "Zentrieren") { vm.recenter() }
                    if (nav.navigating) {
                        MapButton(
                            if (settings.voice) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                            "Sprachansagen",
                            tint = if (settings.voice) pal.blue else pal.sub,
                        ) { Settings.update { it.copy(voice = !it.voice) } }
                        MapButton(Icons.Filled.Refresh, "Route neu berechnen") { NavSession.rerouteNow() }
                        if (settings.hasTomTom) MapButton(Icons.Filled.EvStation, "Ladestationen suchen", tint = pal.green) { NavSession.openChargerSearch() }
                        MapButton(Icons.Filled.AddLocationAlt, "Stopp hinzufügen") { vm.startSearch(SearchMode.VIA) }
                    }
                }

                // ----- unten -----
                Column(
                    Modifier.align(Alignment.BottomCenter).navigationBarsPadding().imePadding().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    val lp = ui.longPress
                    when {
                        nav.chargerSearch != null -> ChargerSheet(nav, settings, sheetMax)
                        lp != null && ui.mode == SearchMode.DEST -> LongPressCard(lp, nav.dest != null || nav.navigating, vm)
                        nav.arrived -> ArrivedCard(nav.dest) { NavSession.stop(ctx) }
                        nav.navigating && route != null && progress != null -> {
                            SpeedRow(fix, route, progress)
                            NavFooter(route, progress, nav.availability) { NavSession.stop(ctx) }
                        }
                        nav.navigating -> GlassCard { Text("Warte auf GPS …", Modifier.padding(18.dp), color = pal.text) }
                        nav.dest != null && ui.mode == SearchMode.DEST -> RouteSheet(nav, settings, sheetMax, vm, onGo = {
                            vm.recenter()
                            NavSession.start(ctx)
                        })
                    }
                }
            }
            if (ui.showSettings) SettingsScreen(settings, vm::closeSettings, vm::openObd, vm::openTrips)
            if (ui.showObd) ObdScreen(vm)
            if (ui.showTrips) TripsScreen(vm)
            ui.editFav?.let { f -> FavEditDialog(f) { vm.editFavorite(null) } }
        }
    }
}

// ---------------- Bausteine ----------------

@Composable
fun GlassCard(modifier: Modifier = Modifier, corner: Dp = 22.dp, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(corner),
        color = LocalPal.current.card,
        shadowElevation = 12.dp,
    ) { Column(content = content) }
}

@Composable
fun MapButton(icon: ImageVector, desc: String, tint: Color = LocalPal.current.blue, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = LocalPal.current.card,
        shadowElevation = 8.dp,
        modifier = Modifier.size(50.dp),
    ) { Box(contentAlignment = Alignment.Center) { Icon(icon, desc, tint = tint) } }
}

@Composable
fun InfoPill(text: String, spinner: Boolean) {
    val pal = LocalPal.current
    Surface(shape = RoundedCornerShape(16.dp), color = pal.card, shadowElevation = 6.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (spinner) {
                CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
            }
            Text(text, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ---------------- Suche ----------------

@Composable
fun SearchPanel(ui: MainViewModel.Ui, recents: List<Place>, vm: MainViewModel) {
    val pal = LocalPal.current
    val focus = LocalFocusManager.current
    GlassCard(Modifier.fillMaxWidth()) {
        if (ui.mode != SearchMode.DEST) {
            Row(Modifier.padding(start = 16.dp, end = 10.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    when (ui.mode) {
                        SearchMode.HOME -> "Zuhause festlegen"
                        SearchMode.WORK -> "Arbeit festlegen"
                        SearchMode.FAV -> "Favorit hinzufügen"
                        else -> "Stopp hinzufügen"
                    },
                    color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                )
                CloseDot(vm::cancelSearch)
            }
        }
        Row(
            Modifier.padding(10.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.field)
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Search, null, tint = pal.sub, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) {
                if (ui.query.isEmpty()) Text("Suche nach Ort oder Adresse", color = pal.sub, fontSize = 17.sp)
                BasicTextField(
                    value = ui.query,
                    onValueChange = vm::onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = pal.text, fontSize = 17.sp),
                    cursorBrush = SolidColor(pal.blue),
                    modifier = Modifier.fillMaxWidth().onFocusChanged { vm.setSearchActive(it.isFocused) },
                )
            }
            if (ui.query.isNotEmpty()) {
                Icon(
                    Icons.Filled.Close, "Löschen", tint = pal.sub,
                    modifier = Modifier.size(20.dp).clickable { vm.onQuery("") },
                )
            }
        }
        if (ui.mode == SearchMode.DEST && ui.query.isEmpty()) FavoritesRow(vm)
        val showSuggestions = ui.query.trim().length >= 3
        if (ui.searchActive || showSuggestions) {
            val items = if (showSuggestions) ui.suggestions else recents
            Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()).padding(bottom = 6.dp)) {
                Text(
                    if (showSuggestions) "Vorschläge" else "Zuletzt",
                    color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 16.dp, top = 2.dp, bottom = 4.dp),
                )
                if (ui.searching && items.isEmpty()) {
                    Text("Suche …", color = pal.sub, modifier = Modifier.padding(16.dp))
                } else if (items.isEmpty()) {
                    Text(
                        if (showSuggestions) "Nichts gefunden" else "Noch keine Ziele",
                        color = pal.sub, modifier = Modifier.padding(16.dp),
                    )
                }
                items.forEach { p ->
                    PlaceRow(p, recent = !showSuggestions) {
                        focus.clearFocus()
                        vm.pick(p)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaceRow(p: Place, recent: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(if (recent) pal.field else pal.red),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (recent) Icons.Filled.History else Icons.Filled.Place, null,
                tint = if (recent) pal.sub else Color.White, modifier = Modifier.size(20.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.title, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (p.subtitle.isNotBlank()) {
                Text(p.subtitle, color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ---------------- Routenauswahl ----------------

/** Akkustand beim Start (bis OBD in Runde 3 kommt, manuell) */
@Composable
fun SocStartRow(settings: AppSettings) {
    val pal = LocalPal.current
    val obd = obdSocState()
    if (obd != null) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Akku jetzt", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(fmtSoc(obd), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("  OBD", color = pal.green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        return
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Akku jetzt", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        StepButton("−") { changeSoc(settings, -5.0) }
        Text(fmtPct(settings.socStart), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
        StepButton("+") { changeSoc(settings, 5.0) }
    }
}

private fun changeSoc(s: AppSettings, delta: Double) {
    val v = (s.socStart + delta).coerceIn(5.0, 100.0)
    if (v == s.socStart) return
    Settings.update { it.copy(socStart = v) }
    NavSession.replan()
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(pal.cardSolid).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = pal.blue, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun RouteRow(r: Route, selected: Boolean, deltaS: Double, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (selected) pal.blue.copy(alpha = 0.12f) else pal.field.copy(alpha = 0.6f))
            .border(2.dp, if (selected) pal.blue else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fmtDuration(r.durationS), color = pal.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                if (deltaS > 60) {
                    Spacer(Modifier.width(8.dp))
                    Text("+${fmtDuration(deltaS)}", color = pal.sub, fontSize = 14.sp)
                }
            }
            Text(
                "${fmtKm(r.distanceM)} · Ankunft ${fmtEta(r.durationS)}" + if (r.summary.isNotBlank()) " · über ${r.summary}" else "",
                color = pal.sub, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            val ev = buildList {
                if (r.stops.isNotEmpty()) add("⚡ ${r.stops.size} × laden · ${fmtDuration(r.chargeS)}")
                r.arrivalSoc?.let { add("Ziel ${fmtPct(it)}") }
            }.joinToString(" · ")
            if (ev.isNotBlank()) Text(ev, color = if (r.feasible) pal.green else pal.red, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            if (r.trafficDelayS > 120) {
                Text("Verkehr: +${fmtDuration(r.trafficDelayS)}", color = Color(0xFFFF9500), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (r.tag.isNotBlank()) {
            Spacer(Modifier.width(8.dp))
            Text(
                r.tag,
                color = if (selected) Color.White else pal.text,
                fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (selected) pal.blue else pal.field)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

/** Details der gewählten Route: Wetter, Akku-Verlauf, Ladestopps */
@Composable
fun RouteDetails(r: Route, avail: Map<String, Availability>) {
    val pal = LocalPal.current
    Spacer(Modifier.height(12.dp))
    r.reason?.let { Text(it, color = pal.red, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp)) }
    r.weather?.let { w ->
        val wind = when {
            w.headwindKmh > 5 -> " · Gegenwind ${w.headwindKmh.roundToInt()} km/h"
            w.headwindKmh < -5 -> " · Rückenwind ${(-w.headwindKmh).roundToInt()} km/h"
            else -> ""
        }
        Text(
            "Wetter unterwegs: ${w.tempC.roundToInt()} °C$wind" + if (w.rain) " · Regen" else "",
            color = pal.sub, fontSize = 13.sp,
        )
    }
    if (r.socProfile.size >= 2) {
        Spacer(Modifier.height(8.dp))
        Text("Akku-Verlauf", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        SocChart(r)
    }
    if (r.stops.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        Text("Ladestopps", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        r.stops.forEachIndexed { i, st -> StopRow(i + 1, st, st.uuid?.let { avail[it] }) }
    }
}

@Composable
private fun StopRow(no: Int, st: ChargeStop, a: Availability?) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(pal.green), contentAlignment = Alignment.Center) {
            Text("$no", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(st.name, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val op = if (st.operator.isNotBlank() && st.operator != st.name) "${st.operator} · " else ""
            Text(
                "${op}km ${(st.alongM / 1000).roundToInt()} · ${st.powerKw.roundToInt()} kW",
                color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                "${fmtPct(st.arriveSoc)} → ${fmtPct(st.targetSoc)} · ${fmtDuration(st.chargeS)}",
                color = pal.text, fontSize = 13.sp,
            )
            if (Settings.state.value.hasTomTom && !NavSession.state.value.navigating) {
                Text(
                    "Anderen wählen", color = pal.blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 2.dp).clickable { NavSession.openChargerSearch(st.uuid) },
                )
            }
        }
        if (a != null && a.known) {
            Text(
                "${a.available}/${a.total} frei",
                color = if (a.available > 0) pal.green else pal.red, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

/** Akkustand über die Strecke, mit Reserve-Linie */
@Composable
private fun SocChart(r: Route) {
    val pal = LocalPal.current
    val total = max(1.0, r.cumM.lastOrNull() ?: 1.0)
    val minSoc = Settings.state.value.minSocStop
    Canvas(Modifier.fillMaxWidth().height(90.dp).padding(vertical = 6.dp)) {
        val w = size.width
        val h = size.height
        fun x(m: Double) = (m / total * w).toFloat()
        fun y(p: Double) = (h - (p.coerceIn(0.0, 100.0) / 100.0) * h).toFloat()
        // Reserve
        drawLine(pal.red.copy(alpha = 0.5f), Offset(0f, y(minSoc)), Offset(w, y(minSoc)), 2f)
        val line = Path()
        val fill = Path()
        r.socProfile.forEachIndexed { i, (m, p) ->
            if (i == 0) { line.moveTo(x(m), y(p)); fill.moveTo(x(m), h); fill.lineTo(x(m), y(p)) } else { line.lineTo(x(m), y(p)); fill.lineTo(x(m), y(p)) }
        }
        val last = r.socProfile.last()
        fill.lineTo(x(last.first), h)
        fill.close()
        drawPath(fill, pal.green.copy(alpha = 0.18f))
        drawPath(line, pal.green, style = Stroke(width = 5f))
        r.stops.forEach { st -> drawCircle(pal.green, 7f, Offset(x(st.alongM), y(st.targetSoc))) }
    }
}

@Composable
private fun ActionCard(text: String, action: String, onAction: () -> Unit, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 18.dp) {
        Column(Modifier.padding(14.dp)) {
            Text(text, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                ) { Text(action, fontWeight = FontWeight.Bold) }
                TextButton(onClick = onDismiss) { Text("Ignorieren", color = pal.sub) }
            }
        }
    }
}

// ---------------- Navigation ----------------

@Composable
fun NavBanner(r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val step = r.steps.getOrNull(p.stepIdx) ?: return
    val next = r.steps.getOrNull(p.stepIdx + 1)
    val live by NavSession.liveAlong.collectAsState()
    val dist = live?.let { a -> ((r.stepAlongM.getOrNull(p.stepIdx) ?: a) - a).coerceAtLeast(0.0) } ?: p.distToStepM
    Column {
        Surface(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = pal.banner,
            shadowElevation = 12.dp,
        ) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                ManeuverIcon(step.type, step.mod, Color.White, 64.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(fmtDistShort(dist), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                    Text(
                        step.bannerText(), color = Color.White.copy(alpha = 0.92f), fontSize = 21.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (next != null && step.distanceM < 300 && step.type != "arrive") {
            Surface(
                Modifier.padding(start = 16.dp),
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                color = pal.banner.copy(alpha = 0.94f),
            ) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Dann", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp))
                    ManeuverIcon(next.type, next.mod, Color.White, 26.dp)
                }
            }
        }
    }
}

@Composable
fun SpeedRow(fix: Fix?, r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val live by NavSession.liveAlong.collectAsState()
    val limit = r.limitAt(live ?: p.alongM)
    val kmh = ((fix?.speed ?: 0.0) * 3.6).roundToInt()
    val tooFast = limit != null && kmh > limit + 3
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
            shape = CircleShape, color = if (tooFast) pal.red else pal.card, shadowElevation = 8.dp, modifier = Modifier.size(64.dp),
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("$kmh", color = if (tooFast) Color.White else pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("km/h", color = if (tooFast) Color.White else pal.sub, fontSize = 11.sp)
            }
        }
        if (limit != null) {
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(60.dp).clip(CircleShape).background(Color.White).border(7.dp, Color(0xFFE30613), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text("$limit", color = Color.Black, fontSize = if (limit >= 100) 19.sp else 22.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun NavFooter(r: Route, p: NavProgress, avail: Map<String, Availability>, onEnd: () -> Unit) {
    val pal = LocalPal.current
    val next = r.stops.firstOrNull { it.alongM > p.alongM + 50 }
    GlassCard(Modifier.fillMaxWidth(), corner = 26.dp) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Stat(fmtEta(p.remainingS), "Ankunft", Modifier.weight(1f))
                Stat(fmtDuration(p.remainingS), "Restzeit", Modifier.weight(1f))
                Stat(fmtKm(p.remainingM), "Strecke", Modifier.weight(1f))
                Button(
                    onClick = onEnd,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.red, contentColor = Color.White),
                ) { Text("Ende", fontWeight = FontWeight.Bold) }
            }
            val nowSoc = r.socAt(p.alongM)
            val real = obdSocState()
            if (nowSoc != null || real != null) {
                Spacer(Modifier.height(10.dp))
                val dest = r.arrivalSoc
                val text = if (real != null) {
                    "🔋 ${fmtSoc(real)}" + (nowSoc?.let { " (Plan ${fmtPct(it)})" } ?: "")
                } else {
                    "🔋 jetzt ca. ${fmtPct(nowSoc ?: 0.0)}"
                }
                val diff = if (real != null && nowSoc != null) real - nowSoc else 0.0
                Text(
                    text + if (dest != null) " · am Ziel ${fmtPct(dest + diff)}" else "",
                    color = if (diff < -4) pal.red else pal.text, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                )
            }
            next?.let { st ->
                val a = st.uuid?.let { avail[it] }
                val free = if (a != null && a.known) " · ${a.available}/${a.total} frei" else ""
                Text(
                    "⚡ ${st.name} in ${fmtKm(st.alongM - p.alongM)} · Ankunft ${fmtPct(st.arriveSoc)} → ${fmtPct(st.targetSoc)}$free",
                    color = pal.green, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier) {
    val pal = LocalPal.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = pal.text, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = pal.sub, fontSize = 12.sp)
    }
}

@Composable
fun ArrivedCard(dest: Place?, onDone: () -> Unit) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 26.dp) {
        Column(Modifier.padding(18.dp)) {
            Text("Ziel erreicht", color = pal.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            dest?.let { Text(it.name, color = pal.sub, fontSize = 15.sp, maxLines = 2) }
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onDone,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(50.dp),
            ) { Text("Fertig", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

// ---------------- Einstellungen ----------------

@Composable
fun SettingsScreen(s: AppSettings, onClose: () -> Unit, onOpenObd: () -> Unit, onOpenTrips: () -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    Surface(Modifier.fillMaxSize(), color = pal.screen) {
        Column(
            Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Einstellungen", color = pal.text, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onClose) { Text("Fertig", color = pal.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
            }

            Section("Darstellung") {
                Label("Karte")
                Segmented(listOf("Automatisch", "Hell", "Dunkel"), s.mapMode.ordinal) { i ->
                    Settings.update { it.copy(mapMode = MapMode.entries[i]) }
                }
                Spacer(Modifier.height(16.dp))
                Label("Fahrsymbol")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    VehicleIcon.entries.forEach { v ->
                        val bmp = remember(v, s.carColor) {
                            when (v) {
                                VehicleIcon.ARROW -> VehicleIcons.arrow(ctx)
                                VehicleIcon.CAR -> VehicleIcons.car(ctx, s.carColor.toInt())
                                VehicleIcon.DOT -> VehicleIcons.dot(ctx)
                            }.asImageBitmap()
                        }
                        val sel = s.vehicle == v
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(pal.field)
                                .border(2.dp, if (sel) pal.blue else Color.Transparent, RoundedCornerShape(14.dp))
                                .clickable { Settings.update { it.copy(vehicle = v) } }
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Image(bmp, null, Modifier.size(48.dp))
                            Text(
                                when (v) {
                                    VehicleIcon.ARROW -> "Pfeil"
                                    VehicleIcon.CAR -> "Auto"
                                    VehicleIcon.DOT -> "Punkt"
                                },
                                color = pal.text, fontSize = 14.sp,
                            )
                        }
                    }
                }
                if (s.vehicle == VehicleIcon.CAR) {
                    Spacer(Modifier.height(16.dp))
                    Label("Autofarbe")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CAR_COLORS.forEach { c ->
                            Box(
                                Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                                    .border(if (s.carColor == c) 3.dp else 1.dp, if (s.carColor == c) pal.blue else pal.divider, CircleShape)
                                    .clickable { Settings.update { it.copy(carColor = c) } },
                            )
                        }
                    }
                }
            }

            Section("Navigation") {
                ToggleRow("Sprachansagen", s.voice) { v -> Settings.update { it.copy(voice = v) } }
                ToggleRow("Mautstraßen vermeiden", s.avoidToll) { v -> Settings.update { it.copy(avoidToll = v) } }
                ToggleRow("Autobahnen vermeiden", s.avoidMotorway) { v -> Settings.update { it.copy(avoidMotorway = v) } }
                ToggleRow("Fähren vermeiden", s.avoidFerry) { v -> Settings.update { it.copy(avoidFerry = v) } }
                Text(
                    "Gilt für neue Routen. Mehrere Vermeiden-Optionen gleichzeitig unterstützt der freie Routing-Server eventuell nicht.",
                    color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp),
                )
            }

            Section("OBD2-Adapter") { ObdSettingsSection(s, onOpenObd) }

            Section("Fahrzeug (Citroën ë-C4)") {
                Label("Nutzbare Akkukapazität: ${String.format(java.util.Locale.GERMANY, "%.1f", s.usableKwh)} kWh")
                Slider(
                    value = s.usableKwh.toFloat(),
                    onValueChange = { v -> Settings.update { it.copy(usableKwh = (v * 2).roundToInt() / 2.0) } },
                    valueRange = 40f..50f,
                )
                Label("Fahrweise")
                Segmented(listOf("Sparsam", "Normal", "Zügig"), s.style) { i -> Settings.update { it.copy(style = i) } }
                Spacer(Modifier.height(14.dp))
                Label("Mindest-Akku am Ladestopp: ${fmtPct(s.minSocStop)}")
                Slider(
                    value = s.minSocStop.toFloat(),
                    onValueChange = { v -> Settings.update { it.copy(minSocStop = v.roundToInt().toDouble()) } },
                    valueRange = 5f..30f,
                )
                Label("Mindest-Akku am Ziel: ${fmtPct(s.minSocDest)}")
                Slider(
                    value = s.minSocDest.toFloat(),
                    onValueChange = { v -> Settings.update { it.copy(minSocDest = v.roundToInt().toDouble()) } },
                    valueRange = 5f..50f,
                )
                Label("Referenzverbrauch: ${s.refConsumptionPct} %")
                Slider(
                    value = s.refConsumptionPct.toFloat(),
                    onValueChange = { v -> Settings.update { it.copy(refConsumptionPct = (v / 5).roundToInt() * 5) } },
                    valueRange = 80f..130f,
                )
                Label(if (s.maxSpeedKmh == 0) "Höchstgeschwindigkeit: keine Begrenzung" else "Höchstgeschwindigkeit: ${s.maxSpeedKmh} km/h")
                Slider(
                    value = (if (s.maxSpeedKmh == 0) 170 else s.maxSpeedKmh).toFloat(),
                    onValueChange = { v -> val k = (v / 10).roundToInt() * 10; Settings.update { it.copy(maxSpeedKmh = if (k >= 170) 0 else k) } },
                    valueRange = 90f..170f,
                )
                Label("Zusatzgewicht (Personen, Gepäck): ${s.extraWeightKg} kg")
                Slider(
                    value = s.extraWeightKg.toFloat(),
                    onValueChange = { v -> Settings.update { it.copy(extraWeightKg = (v / 25).roundToInt() * 25) } },
                    valueRange = 0f..400f,
                )
                ToggleRow("Akkustand abrunden wie im Auto", s.socFloor) { b -> Settings.update { it.copy(socFloor = b) } }
            }

            Section("Fahrten & Lernen") { LearnSettingsSection(s, onOpenTrips) }

            Section("Ladeanbieter") { OperatorSettings(s) }

            Section("TomTom (Verkehr und Ladeplanung)") {
                OutlinedTextField(
                    value = s.tomtomKey,
                    onValueChange = { v -> Settings.update { it.copy(tomtomKey = v.trim()) } },
                    label = { Text("TomTom API-Key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(6.dp))
                ToggleRow("Verkehrslage auf der Karte", s.showTraffic) { v -> Settings.update { it.copy(showTraffic = v) } }
                val count by ApiCounter.today.collectAsState()
                Text(
                    "Heute $count von 2.500 freien Anfragen genutzt (Karten-Kacheln zählen extra, 50.000 pro Tag).",
                    color = pal.sub, fontSize = 13.sp,
                )
            }

            Section("Sichern und Wiederherstellen") { BackupSection() }

            Section("Info") {
                Text(
                    "Kartendaten © OpenStreetMap-Mitwirkende · Kartenstil OpenFreeMap\n" +
                        "Routing: OSRM · Suche: Photon (Komoot)\n" +
                        "Verkehr und Ladeplanung: TomTom · Wetter: Open-Meteo\n" +
                        "EVRoute 0.8 – mit Android Auto",
                    color = pal.sub, fontSize = 14.sp,
                )
                SigningInfo()
            }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column {
        Text(title.uppercase(), color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 14.dp, bottom = 6.dp))
        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid) {
            Column(Modifier.fillMaxWidth().padding(14.dp), content = content)
        }
    }
}

@Composable
fun Label(t: String) {
    Text(t, color = LocalPal.current.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.field).padding(3.dp)) {
        options.forEachIndexed { i, o ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                    .background(if (i == selected) pal.selectedSeg else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    o, color = pal.text, fontSize = 14.sp,
                    fontWeight = if (i == selected) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

@Composable
fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = pal.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = value,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = pal.green, checkedThumbColor = Color.White),
        )
    }
}
