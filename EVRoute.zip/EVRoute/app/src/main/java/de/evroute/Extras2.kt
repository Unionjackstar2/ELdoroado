package de.evroute

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.float
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import java.io.File
import java.security.MessageDigest
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ---------------- Spurassistent ----------------

private fun laneAngle(d: String): Double = when (d) {
    "SLIGHT_RIGHT" -> 40.0
    "RIGHT" -> 90.0
    "SHARP_RIGHT" -> 135.0
    "SLIGHT_LEFT" -> -40.0
    "LEFT" -> -90.0
    "SHARP_LEFT" -> -135.0
    "U_TURN" -> 180.0
    else -> 0.0
}

private fun DrawScope.laneArrow(dir: String, color: Color, strokeW: Float) {
    val w = size.width
    val h = size.height
    val st = Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val deg = laneAngle(dir)
    if (deg == 180.0) {
        val p = Path().apply {
            moveTo(w * 0.62f, h * 0.92f); lineTo(w * 0.62f, h * 0.42f)
            cubicTo(w * 0.62f, h * 0.16f, w * 0.32f, h * 0.16f, w * 0.32f, h * 0.42f); lineTo(w * 0.32f, h * 0.55f)
        }
        drawPath(p, color, style = st)
        return
    }
    val a = deg * PI / 180
    val dv = Offset(sin(a).toFloat(), -cos(a).toFloat())
    val mid = Offset(w * 0.5f, h * 0.58f)
    val len = h * 0.30f
    val e = mid + dv * len
    val p = Path().apply { moveTo(w * 0.5f, h * 0.94f); lineTo(mid.x, mid.y); lineTo(e.x, e.y) }
    drawPath(p, color, style = st)
    val n = Offset(-dv.y, dv.x)
    val hh = h * 0.15f
    val head = Path().apply {
        moveTo((e + dv * hh).x, (e + dv * hh).y)
        lineTo((e + n * (hh * 0.8f)).x, (e + n * (hh * 0.8f)).y)
        lineTo((e - n * (hh * 0.8f)).x, (e - n * (hh * 0.8f)).y)
        close()
    }
    drawPath(head, color)
}

@Composable
private fun LaneIcon(lane: Lane, dp: Dp) {
    val active = lane.follow != null
    Box(
        Modifier.size(dp * 0.85f, dp).clip(RoundedCornerShape(8.dp))
            .background(if (active) Color.White.copy(alpha = 0.14f) else Color.Transparent),
    ) {
        Canvas(Modifier.size(dp * 0.85f, dp)) {
            val sw = size.width * 0.12f
            // nicht empfohlene Richtungen gedimmt, empfohlene kräftig weiß
            lane.directions.filter { it != lane.follow }.forEach { laneArrow(it, Color.White.copy(alpha = 0.28f), sw) }
            lane.follow?.let { laneArrow(it, Color.White, sw * 1.15f) }
            if (lane.directions.isEmpty() && lane.follow == null) laneArrow("STRAIGHT", Color.White.copy(alpha = 0.28f), sw)
        }
    }
}

/** Große Spuranzeige wie bei TomTom: vor Abzweigen auf der Autobahn ab 1,5 km, sonst ab 500 m */
@Composable
fun LanePanel(r: Route, p: NavProgress, speedMs: Double) {
    val pal = LocalPal.current
    val live by NavSession.liveAlong.collectAsState()
    val along = live ?: p.alongM
    val highway = speedMs * 3.6 > 75
    val range = if (highway) 1500.0 else 500.0
    val stepAlong = r.stepAlongM.getOrNull(p.stepIdx) ?: return
    fun at(i: Int) = r.cumM.getOrElse(i) { 0.0 }
    val sec = r.laneSections.firstOrNull { ls ->
        val a = at(ls.startIdx)
        val b = at(ls.endIdx)
        b >= along - 5 && a - along <= range && a <= stepAlong + 50 && ls.lanes.any { it.follow != null } &&
            ls.lanes.any { it.follow == null } // nur zeigen, wenn es wirklich falsche Spuren gibt
    } ?: return
    val dist = (at(sec.startIdx) - along).coerceAtLeast(0.0)
    val iconSize = if (highway) 58.dp else 46.dp
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = pal.banner.copy(alpha = 0.96f), shadowElevation = 10.dp) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                sec.lanes.forEachIndexed { i, lane ->
                    if (i > 0) Box(Modifier.width(2.dp).height(iconSize * 0.8f).background(Color.White.copy(alpha = 0.35f)))
                    LaneIcon(lane, iconSize)
                }
            }
            if (dist > 30) Text("Spur wählen · ${fmtDistShort(dist)}", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
        }
    }
}

// ---------------- Stauende, Baustelle, Sperrung ----------------

@Composable
fun WarningCard(w: NavSession.Warning) {
    val color = when (w.kind) {
        "ROAD_CLOSURE" -> Color(0xFF8E1B1B)
        "ROAD_WORK" -> Color(0xFFFF9500)
        else -> Color(0xFFE5332A)
    }
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = color, shadowElevation = 10.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Canvas(Modifier.size(34.dp)) {
                val s = size.width
                val tri = Path().apply { moveTo(s * 0.5f, s * 0.06f); lineTo(s * 0.96f, s * 0.9f); lineTo(s * 0.04f, s * 0.9f); close() }
                drawPath(tri, Color.White)
                drawLine(color, Offset(s * 0.5f, s * 0.36f), Offset(s * 0.5f, s * 0.64f), s * 0.1f, StrokeCap.Round)
                drawCircle(color, s * 0.055f, Offset(s * 0.5f, s * 0.77f))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (w.inside) "${w.title} · noch ${fmtKm(w.lengthM)}" else "${w.title} in ${fmtDistShort(w.distM)}",
                    color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                )
                if (w.delayS > 60) Text("+${fmtDuration(w.delayS)} Verzögerung", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
            }
        }
    }
}

// ---------------- Signatur der App anzeigen ----------------

@Suppress("DEPRECATION")
fun signingSha256(ctx: Context): String? = runCatching {
    val pm = ctx.packageManager
    val sigs = if (Build.VERSION.SDK_INT >= 28) {
        val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        info.signingInfo?.apkContentsSigners
    } else {
        pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures
    }
    val sig = sigs?.firstOrNull() ?: return null
    MessageDigest.getInstance("SHA-256").digest(sig.toByteArray()).joinToString(":") { String.format("%02X", it) }
}.getOrNull()

@Composable
fun SigningInfo() {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val fp = remember { signingSha256(ctx) }
    Spacer(Modifier.height(10.dp))
    Text("Signatur der App (SHA-256)", color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    Text(fp ?: "unbekannt", color = pal.sub, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    val release = fp?.startsWith("8E:70:07:FC") == true
    Text(
        if (release) "✓ Release-Schlüssel (bei Google registriert)" else "Debug-Schlüssel",
        color = if (release) pal.green else pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
    )
    if (fp != null) TextButton(onClick = { clip.setText(AnnotatedString(fp)) }) { Text("Kopieren") }
}

// ---------------- Sichern und Wiederherstellen ----------------

object Backup {
    private val FILES = listOf("settings", "favorites", "recents", "learn", "operators")

    fun export(ctx: Context): String = buildJsonObject {
        put("app", "EVRoute")
        put("format", 1)
        putJsonObject("prefs") {
            FILES.forEach { name ->
                val p = ctx.getSharedPreferences(name, Context.MODE_PRIVATE)
                putJsonObject(name) {
                    p.all.forEach { (k, v) ->
                        putJsonObject(k) {
                            when (v) {
                                is Boolean -> { put("t", "b"); put("v", v) }
                                is Int -> { put("t", "i"); put("v", v) }
                                is Long -> { put("t", "l"); put("v", v) }
                                is Float -> { put("t", "f"); put("v", v) }
                                is String -> { put("t", "s"); put("v", v) }
                                is Set<*> -> { put("t", "set"); putJsonArray("v") { v.forEach { add(it.toString()) } } }
                                else -> { put("t", "s"); put("v", v.toString()) }
                            }
                        }
                    }
                }
            }
        }
        put("trips", File(ctx.filesDir, "trips.csv").takeIf { it.exists() }?.readText() ?: "")
    }.toString()

    /** Sicherung einspielen; true bei Erfolg */
    fun import(ctx: Context, text: String): Boolean = runCatching {
        val root = json.parseToJsonElement(text).jsonObject
        if (root["app"]?.jsonPrimitive?.contentOrNull != "EVRoute") return false
        val prefs = root["prefs"]?.jsonObject ?: return false
        FILES.forEach { name ->
            val data = prefs[name] as? JsonObject ?: return@forEach
            val e = ctx.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
            data.forEach { (k, el) ->
                val o = el.jsonObject
                val v = o["v"] ?: return@forEach
                when (o["t"]?.jsonPrimitive?.contentOrNull) {
                    "b" -> e.putBoolean(k, v.jsonPrimitive.boolean)
                    "i" -> e.putInt(k, v.jsonPrimitive.int)
                    "l" -> e.putLong(k, v.jsonPrimitive.long)
                    "f" -> e.putFloat(k, v.jsonPrimitive.float)
                    "set" -> e.putStringSet(k, v.jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull }.toSet())
                    else -> e.putString(k, v.jsonPrimitive.contentOrNull ?: "")
                }
            }
            e.commit()
        }
        root["trips"]?.jsonPrimitive?.contentOrNull?.let { File(ctx.filesDir, "trips.csv").writeText(it) }
        Settings.init(ctx)
        Favorites.init(ctx)
        Recents.init(ctx)
        Learner.init(ctx)
        KnownOperators.init(ctx)
        TripRecorder.reload()
        true
    }.getOrDefault(false)
}

@Composable
fun BackupSection() {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf<String?>(null) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            msg = runCatching {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(Backup.export(ctx).toByteArray()) }
                "Gesichert."
            }.getOrElse { "Sichern fehlgeschlagen: ${it.message}" }
        }
    }
    val load = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching { ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } }.getOrNull()
            msg = if (text != null && Backup.import(ctx, text)) "Wiederhergestellt." else "Diese Datei ist keine EVRoute-Sicherung."
        }
    }
    Text(
        "Sichert Einstellungen, TomTom-Key, Favoriten, OBD-Adapter, gelernte Werte und Fahrten in eine Datei (z. B. in Google Drive).",
        color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp),
    )
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = { save.launch("EVRoute-Sicherung.json") }, shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
        ) { Text("Sichern") }
        Button(
            onClick = { load.launch(arrayOf("application/json", "text/plain", "*/*")) }, shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = pal.field, contentColor = pal.text),
        ) { Text("Wiederherstellen") }
    }
    msg?.let { Text(it, color = pal.text, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
    Text("Die Datei enthält deinen TomTom-Key – nicht weitergeben.", color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
}
