package de.evroute

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------- Modelle ----------------

data class LatLon(val lat: Double, val lon: Double)

data class Place(val name: String, val pos: LatLon) {
    val title: String get() = name.substringBefore(", ")
    val subtitle: String get() = if (name.contains(", ")) name.substringAfter(", ") else ""
}

/** GPS-Position */
data class Fix(val pos: LatLon, val bearing: Float?, val speed: Double, val accuracy: Double, val time: Long)

data class Step(
    val type: String,
    val mod: String?,
    val exit: Int?,
    val road: String,
    val towards: String,
    val distanceM: Double,   // Strecke von diesem Manöver bis zum nächsten
    val durationS: Double,
    val phrase: String,      // z. B. "rechts abbiegen" (klein, ohne Straße)
) {
    val isRamp: Boolean get() = type == "on ramp" || type == "off ramp" || type == "fork"
    val isRoundabout: Boolean get() = type == "roundabout" || type == "rotary" || type == "roundabout turn"

    /** Zeile im Banner (wie Apple Maps: Straße bzw. Richtung) */
    fun bannerText(): String = when {
        type == "arrive" -> "Ziel"
        isRoundabout && exit != null -> "$exit. Ausfahrt" + if (road.isNotBlank()) " · $road" else ""
        isRamp && towards.isNotBlank() -> "Richtung $towards"
        road.isNotBlank() -> road
        else -> phrase.cap()
    }

    /** Ansage-Ziel: "auf A 1" oder "Richtung Porto" */
    fun spokenTarget(): String = when {
        type == "arrive" -> ""
        isRamp && towards.isNotBlank() -> " Richtung $towards"
        road.isNotBlank() && !isRoundabout -> " auf $road"
        else -> ""
    }
}

data class Route(
    val points: List<LatLon>,
    val cumM: DoubleArray,        // kumulierte Strecke je Punkt
    val stepAlongM: DoubleArray,  // Position jedes Manövers entlang der Route
    val distanceM: Double,
    val durationS: Double,
    val steps: List<Step>,
    val maxSpeed: IntArray?,      // km/h je Segment, 0 = unbekannt
    val summary: String,
    val tag: String = "",
)

data class NavProgress(
    val segIdx: Int,
    val snapped: LatLon,
    val routeBearing: Double,
    val alongM: Double,
    val stepIdx: Int,
    val distToStepM: Double,
    val remainingM: Double,
    val remainingS: Double,
    val offRouteM: Double,
    val speedLimit: Int?,
)

// ---------------- Geometrie ----------------

fun haversine(a: LatLon, b: LatLon): Double {
    val r = 6371000.0
    val dLat = Math.toRadians(b.lat - a.lat)
    val dLon = Math.toRadians(b.lon - a.lon)
    val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
    return 2 * r * asin(sqrt(h.coerceIn(0.0, 1.0)))
}

/** Anteil t (0..1) der Projektion von p auf a–b */
fun projectT(p: LatLon, a: LatLon, b: LatLon): Double {
    val kx = 111320.0 * cos(Math.toRadians(p.lat))
    val ky = 110540.0
    val ax = (a.lon - p.lon) * kx
    val ay = (a.lat - p.lat) * ky
    val dx = (b.lon - a.lon) * kx
    val dy = (b.lat - a.lat) * ky
    val len2 = dx * dx + dy * dy
    return if (len2 == 0.0) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
}

fun lerp(a: LatLon, b: LatLon, t: Double) = LatLon(a.lat + (b.lat - a.lat) * t, a.lon + (b.lon - a.lon) * t)

fun distToSeg(p: LatLon, a: LatLon, b: LatLon): Double {
    val q = lerp(a, b, projectT(p, a, b))
    val kx = 111320.0 * cos(Math.toRadians(p.lat))
    return hypot((q.lon - p.lon) * kx, (q.lat - p.lat) * 110540.0)
}

fun bearing(a: LatLon, b: LatLon): Double {
    val la1 = Math.toRadians(a.lat)
    val la2 = Math.toRadians(b.lat)
    val dl = Math.toRadians(b.lon - a.lon)
    val y = sin(dl) * cos(la2)
    val x = cos(la1) * sin(la2) - sin(la1) * cos(la2) * cos(dl)
    return (atan2(y, x) * 180 / PI + 360) % 360
}

// ---------------- Formatierung ----------------

fun String.cap(): String = replaceFirstChar { it.titlecase(Locale.GERMANY) }

fun Double.f6(): String = String.format(Locale.US, "%.6f", this)

fun fmtDuration(sec: Double): String {
    val m = (sec / 60).roundToInt()
    return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
}

fun fmtKm(m: Double): String = when {
    m < 1000 -> "${((m / 10).roundToInt() * 10)} m"
    m < 100_000 -> String.format(Locale.GERMANY, "%.1f km", m / 1000)
    else -> "${(m / 1000).roundToInt()} km"
}

/** Distanz im Banner: "350 m", "1,2 km", "18 km" */
fun fmtDistShort(m: Double): String = when {
    m < 100 -> "${((m / 10).roundToInt() * 10)} m"
    m < 1000 -> "${((m / 50).roundToInt() * 50)} m"
    m < 10_000 -> String.format(Locale.GERMANY, "%.1f km", m / 1000)
    else -> "${(m / 1000).roundToInt()} km"
}

fun fmtEta(remainingS: Double): String =
    LocalTime.now().plusSeconds(remainingS.toLong()).format(DateTimeFormatter.ofPattern("HH:mm"))

// ---------------- Einstellungen ----------------

enum class MapMode { AUTO, DAY, NIGHT }
enum class VehicleIcon { ARROW, CAR, DOT }

data class AppSettings(
    val mapMode: MapMode = MapMode.AUTO,
    val vehicle: VehicleIcon = VehicleIcon.ARROW,
    val carColor: Long = 0xFF0A84FF,
    val voice: Boolean = true,
    val avoidToll: Boolean = false,
    val avoidMotorway: Boolean = false,
    val avoidFerry: Boolean = false,
)

object Settings {
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(AppSettings())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val d = AppSettings()
        _state.value = AppSettings(
            mapMode = runCatching { MapMode.valueOf(prefs.getString("mapMode", d.mapMode.name)!!) }.getOrDefault(d.mapMode),
            vehicle = runCatching { VehicleIcon.valueOf(prefs.getString("vehicle", d.vehicle.name)!!) }.getOrDefault(d.vehicle),
            carColor = prefs.getLong("carColor", d.carColor),
            voice = prefs.getBoolean("voice", d.voice),
            avoidToll = prefs.getBoolean("avoidToll", d.avoidToll),
            avoidMotorway = prefs.getBoolean("avoidMotorway", d.avoidMotorway),
            avoidFerry = prefs.getBoolean("avoidFerry", d.avoidFerry),
        )
    }

    fun update(f: (AppSettings) -> AppSettings) {
        val s = f(_state.value)
        _state.value = s
        prefs.edit()
            .putString("mapMode", s.mapMode.name)
            .putString("vehicle", s.vehicle.name)
            .putLong("carColor", s.carColor)
            .putBoolean("voice", s.voice)
            .putBoolean("avoidToll", s.avoidToll)
            .putBoolean("avoidMotorway", s.avoidMotorway)
            .putBoolean("avoidFerry", s.avoidFerry)
            .apply()
    }

    fun excludes(): List<String> {
        val s = _state.value
        return buildList {
            if (s.avoidToll) add("toll")
            if (s.avoidMotorway) add("motorway")
            if (s.avoidFerry) add("ferry")
        }
    }
}

/** Zuletzt gesuchte Ziele */
object Recents {
    private lateinit var prefs: SharedPreferences
    private val _items = MutableStateFlow<List<Place>>(emptyList())
    val items: StateFlow<List<Place>> = _items.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("recents", Context.MODE_PRIVATE)
        _items.value = (prefs.getString("list", "") ?: "").lines().mapNotNull { line ->
            val p = line.split(';', limit = 3)
            if (p.size < 3) null else runCatching { Place(p[2], LatLon(p[0].toDouble(), p[1].toDouble())) }.getOrNull()
        }
    }

    fun add(place: Place) {
        val list = (listOf(place) + _items.value.filter { it.name != place.name }).take(8)
        _items.value = list
        prefs.edit().putString("list", list.joinToString("\n") { "${it.pos.lat};${it.pos.lon};${it.name}" }).apply()
    }
}
