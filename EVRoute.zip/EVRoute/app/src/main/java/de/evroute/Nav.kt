package de.evroute

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------- Standort ----------------

object LocationHub {
    private val _fix = MutableStateFlow<Fix?>(null)
    val fix: StateFlow<Fix?> = _fix.asStateFlow()
    private var client: FusedLocationProviderClient? = null
    private val holders = mutableSetOf<String>()

    private val callback = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) {
            val l = r.lastLocation ?: return
            _fix.value = Fix(
                pos = LatLon(l.latitude, l.longitude),
                bearing = if (l.hasBearing()) l.bearing else null,
                speed = if (l.hasSpeed()) l.speed.toDouble() else 0.0,
                accuracy = if (l.hasAccuracy()) l.accuracy.toDouble() else 50.0,
                time = l.time,
                elapsedNs = l.elapsedRealtimeNanos,
                alt = if (l.hasAltitude()) l.altitude else null,
            )
        }
    }

    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Mehrere Nutzer (Bildschirm, Navigationsdienst) teilen sich ein Abo */
    @SuppressLint("MissingPermission")
    fun acquire(ctx: Context, tag: String) {
        if (!hasPermission(ctx) || tag in holders) return
        val first = holders.isEmpty()
        holders += tag
        if (first) {
            val c = client ?: LocationServices.getFusedLocationProviderClient(ctx.applicationContext).also { client = it }
            val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
                .setMinUpdateIntervalMillis(500L)
                .build()
            c.requestLocationUpdates(req, callback, Looper.getMainLooper())
        }
    }

    fun release(tag: String) {
        if (holders.remove(tag) && holders.isEmpty()) client?.removeLocationUpdates(callback)
    }
}

// ---------------- Position auf der Route ----------------

object NavEngine {
    fun update(r: Route, p: LatLon, lastSeg: Int, fullSearch: Boolean): NavProgress {
        val n = r.points.size
        if (n < 2) {
            return NavProgress(0, p, 0.0, 0.0, r.steps.lastIndex.coerceAtLeast(0), 0.0, 0.0, 0.0, 0.0)
        }
        val from = if (fullSearch) 0 else max(0, lastSeg - 5)
        val to = if (fullSearch) n - 2 else min(n - 2, lastSeg + 400)
        var best = from
        var bd = Double.MAX_VALUE
        for (i in from..max(from, to)) {
            val d = distToSeg(p, r.points[i], r.points[i + 1])
            if (d < bd) { bd = d; best = i }
        }
        val a = r.points[best]
        val b = r.points[best + 1]
        val t = projectT(p, a, b)
        val along = r.cumM[best] + t * (r.cumM[best + 1] - r.cumM[best])

        var s = r.steps.indices.firstOrNull { r.stepAlongM[it] > along + 2 } ?: r.steps.lastIndex
        if (s < 0) s = 0
        val toStep = if (r.steps.isEmpty()) 0.0 else max(0.0, r.stepAlongM[s] - along)

        // Restzeit aus den Zeiten an den Manövern, plus noch ausstehende Ladezeiten
        var remS = 0.0
        if (r.stepTimeS.isNotEmpty()) {
            val tNext = r.stepTimeS[s]
            val prevIdx = (s - 1).coerceAtLeast(0)
            val span = r.stepAlongM[s] - r.stepAlongM[prevIdx]
            val tNow = if (s == 0 || span <= 0) tNext
            else r.stepTimeS[prevIdx] + (tNext - r.stepTimeS[prevIdx]) * ((along - r.stepAlongM[prevIdx]) / span).coerceIn(0.0, 1.0)
            remS = max(0.0, r.stepTimeS.last() - tNow)
        }
        if (!r.timesIncludeCharging) remS += r.stops.filter { it.alongM > along + 50 }.sumOf { it.chargeS }

        return NavProgress(
            segIdx = best,
            snapped = lerp(a, b, t),
            routeBearing = bearing(a, b),
            alongM = along,
            stepIdx = s,
            distToStepM = toStep,
            remainingM = max(0.0, r.cumM.last() - along),
            remainingS = remS,
            offRouteM = bd,
        )
    }
}

// ---------------- Sprachansagen ----------------

class Voice(ctx: Context) : TextToSpeech.OnInitListener {
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(attrs)
        .build()
    private val done = mutableSetOf<Int>()
    @Volatile private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext, this)

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts.language = Locale.GERMANY
        tts.setAudioAttributes(attrs)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { audio.abandonAudioFocusRequest(focus) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { audio.abandonAudioFocusRequest(focus) }
        })
        ready = true
    }

    fun say(text: String) {
        if (!ready || !Settings.state.value.voice || text.isBlank()) return
        audio.requestAudioFocus(focus)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav-${System.nanoTime()}")
    }

    fun stop() { if (ready) tts.stop() }

    fun reset() { done.clear() }

    /** Nach einem stillen Routentausch: bereits fällige Vorankündigungen nicht wiederholen */
    fun prime(p: NavProgress, speedMs: Double) {
        val stages = if (speedMs * 3.6 > 80) listOf(2000.0, 800.0) else listOf(500.0, 150.0)
        val base = p.stepIdx * 10
        stages.forEachIndexed { i, st -> if (p.distToStepM <= st) done.add(base + i) }
    }

    /** Ansagen abhängig vom Tempo: Autobahn 2 km / 800 m, Stadt 500 m / 150 m, dann „Jetzt“ */
    fun onProgress(r: Route, p: NavProgress, speedMs: Double) {
        val step = r.steps.getOrNull(p.stepIdx) ?: return
        val d = p.distToStepM
        val kmh = speedMs * 3.6
        val stages = if (kmh > 80) listOf(2000.0, 800.0) else listOf(500.0, 150.0)
        val nowDist = max(35.0, speedMs * 4)
        val base = p.stepIdx * 10

        if (d <= nowDist) {
            if (done.add(base + 9)) {
                done.add(base); done.add(base + 1)
                when (step.type) {
                    "arrive" -> { say("Sie haben Ihr Ziel erreicht"); return }
                    "charge" -> { say("Sie haben den Ladestopp erreicht. ${step.note}"); return }
                    "via" -> { say("Sie haben Ihr Zwischenziel erreicht"); return }
                }
                val next = r.steps.getOrNull(p.stepIdx + 1)
                val then = if (next != null && step.distanceM < 150) {
                    when (next.type) {
                        "arrive" -> ", dann erreichen Sie Ihr Ziel"
                        "charge" -> ", dann erreichen Sie den Ladestopp"
                        "via" -> ", dann erreichen Sie Ihr Zwischenziel"
                        else -> ", dann ${next.phrase}"
                    }
                } else {
                    ""
                }
                say("Jetzt ${step.phrase}${step.spokenTarget()}$then")
            }
            return
        }
        stages.forEachIndexed { i, s ->
            if (d <= s && d > nowDist + 60 && done.add(base + i)) {
                if (i == 0 && d < stages[1] + 200) done.add(base + 1)
                val text = when (step.type) {
                    "arrive" -> "In ${spoken(d)} erreichen Sie Ihr Ziel"
                    "charge" -> "In ${spoken(d)} erreichen Sie den Ladestopp ${step.road}"
                    "via" -> "In ${spoken(d)} erreichen Sie Ihr Zwischenziel"
                    else -> "In ${spoken(d)} ${step.phrase}${step.spokenTarget()}"
                }
                say(text)
                return
            }
        }
    }

    private fun spoken(m: Double): String = when {
        m >= 950 -> {
            val km = (m / 500).roundToInt() / 2.0
            if (abs(km - 1.0) < 0.01) "einem Kilometer"
            else if (km % 1.0 == 0.0) "${km.toInt()} Kilometern"
            else "${km.toString().replace('.', ',')} Kilometern"
        }
        m >= 100 -> "${(m / 50).roundToInt() * 50} Metern"
        else -> "${(m / 10).roundToInt() * 10} Metern"
    }
}

// ---------------- Navigationssitzung ----------------

private suspend fun <T> safe(block: suspend () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    Result.failure(e)
}

object NavSession {
    data class Offer(val route: Route, val savedS: Double)

    /** Warnung vor Stauende, Baustelle oder Sperrung */
    data class Warning(val kind: String, val title: String, val distM: Double, val delayS: Double, val inside: Boolean, val lengthM: Double)

    /** Ladesäulen-Suche (vor oder während der Fahrt) */
    data class ChargerSearch(
        val loading: Boolean = true,
        val hits: List<ChargerHit> = emptyList(),
        val error: String? = null,
        val replaceUuid: String? = null,
    )

    data class State(
        val dest: Place? = null,
        val routes: List<Route> = emptyList(),
        val selected: Int = 0,
        val loading: Boolean = false,
        val error: String? = null,
        val note: String? = null,
        val navigating: Boolean = false,
        val progress: NavProgress? = null,
        val rerouting: Boolean = false,
        val arrived: Boolean = false,
        val availability: Map<String, Availability> = emptyMap(),
        val offer: Offer? = null,
        val fullPark: ChargeStop? = null,
        val vias: List<Via> = emptyList(),
        val chargerSearch: ChargerSearch? = null,
        val hitAvailability: Map<String, Availability> = emptyMap(),
        val warning: Warning? = null,
    ) {
        val route: Route? get() = routes.getOrNull(selected)
    }

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private lateinit var app: Context
    lateinit var voice: Voice
        private set

    private var planJob: Job? = null
    private var checkJob: Job? = null
    private var lastSeg = 0
    private var needFull = true
    private var offCount = 0
    private var lastReroute = 0L
    private val avoidedParks = mutableListOf<String>()
    private val announcedFull = mutableSetOf<String>()
    private var viasPassed = 0
    private val announcedJams = mutableSetOf<String>()
    private var primeVoice = false
    private var viaAlongs: List<Double> = emptyList()
    private var viaAlongsFor: Route? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        voice = Voice(app)
        scope.launch { LocationHub.fix.filterNotNull().collect { onFix(it) } }
        scope.launch { Obd.values.collect { checkPlanVsActual() } }
    }

    // ----- Vorausberechnung: wo ist das Auto *jetzt* (zwischen zwei GPS-Messungen)? -----
    private val _liveAlong = MutableStateFlow<Double?>(null)
    val liveAlong: StateFlow<Double?> = _liveAlong.asStateFlow()
    private var lastAlong = 0.0
    private var lastSpeed = 0.0
    private var lastFixNs = 0L
    private var liveJob: Job? = null

    private fun startLive() {
        liveJob?.cancel()
        liveJob = scope.launch {
            while (isActive) {
                if (lastFixNs > 0L) {
                    val dt = ((SystemClock.elapsedRealtimeNanos() - lastFixNs) / 1e9).coerceIn(0.0, 3.0)
                    _liveAlong.value = lastAlong + lastSpeed * dt
                } else {
                    _liveAlong.value = null
                }
                delay(200)
            }
        }
    }

    private fun stopLive() {
        liveJob?.cancel()
        lastFixNs = 0L
        _liveAlong.value = null
    }

    private var deviationSince = 0L
    private var lastSocReplan = 0L

    /** Weicht der echte Akkustand deutlich vom Plan ab, wird neu geplant (wie bei ABRP) */
    private fun checkPlanVsActual() {
        val s = _state.value
        if (!s.navigating || s.rerouting || s.arrived || !Settings.state.value.obdReplan) return
        val r = s.route ?: return
        val p = s.progress ?: return
        val actual = Obd.freshSoc() ?: return
        val planned = r.socAt(p.alongM) ?: return
        val now = System.currentTimeMillis()
        if (kotlin.math.abs(actual - planned) < 4.0) { deviationSince = 0L; return }
        if (deviationSince == 0L) { deviationSince = now; return }
        if (now - deviationSince < 60_000 || now - lastSocReplan < 180_000) return
        lastSocReplan = now
        deviationSince = 0L
        val f = LocationHub.fix.value ?: return
        voice.say(if (actual > planned) "Der Akku ist voller als geplant. Route wird angepasst." else "Der Akku leert sich schneller als geplant. Route wird angepasst.")
        reroute(f, manual = false)
    }

    /** Routen zum Ziel planen (mit TomTom inkl. Ladestopps und Verkehr) */
    fun plan(dest: Place, vias: List<Via> = emptyList(), keepAvoided: Boolean = false) {
        val fix = LocationHub.fix.value
        planJob?.cancel()
        if (!keepAvoided) avoidedParks.clear()
        if (fix == null) {
            _state.value = State(dest = dest, vias = vias, error = "Standort noch nicht verfügbar – GPS aktiv?")
            return
        }
        val keepAvail = _state.value.availability
        _state.value = State(dest = dest, vias = vias, loading = true, availability = keepAvail)
        planJob = scope.launch {
            val res = safe {
                computeOptions(fix.pos, if (fix.speed > 3) fix.bearing else null, dest.pos,
                    Obd.freshSoc() ?: Settings.state.value.socStart, alternatives = 2, withTollFree = vias.isEmpty(), noToll = false, vias = vias)
            }
            res.onSuccess { opts ->
                _state.update { it.copy(routes = opts, selected = 0, loading = false) }
                opts.firstOrNull()?.let { loadAvailability(it) }
            }.onFailure { e ->
                _state.update { it.copy(loading = false, error = "Keine Route gefunden: ${e.message}") }
            }
        }
    }

    /** Neu planen, z. B. nachdem der Akkustand geändert wurde */
    fun replan() { _state.value.dest?.let { plan(it, _state.value.vias, keepAvoided = true) } }

    // ----- Zwischenstopps -----

    fun addVia(p: Place) {
        val s = _state.value
        if (s.navigating) { insertViaDuringNav(Via(p)); return }
        val dest = s.dest ?: return
        plan(dest, s.vias + Via(p), keepAvoided = true)
    }

    fun removeVia(i: Int) {
        val s = _state.value
        val dest = s.dest ?: return
        if (i !in s.vias.indices) return
        plan(dest, s.vias.filterIndexed { k, _ -> k != i }, keepAvoided = true)
    }

    fun moveVia(i: Int, dir: Int) {
        val s = _state.value
        val dest = s.dest ?: return
        val j = i + dir
        if (i !in s.vias.indices || j !in s.vias.indices) return
        val list = s.vias.toMutableList()
        val tmp = list[i]; list[i] = list[j]; list[j] = tmp
        plan(dest, list, keepAvoided = true)
    }

    fun cyclePause(i: Int) {
        val s = _state.value
        val dest = s.dest ?: return
        val v = s.vias.getOrNull(i) ?: return
        val next = when (v.pauseMin) { 0 -> 15; 15 -> 30; 30 -> 45; 45 -> 60; else -> 0 }
        plan(dest, s.vias.mapIndexed { k, x -> if (k == i) x.copy(pauseMin = next) else x }, keepAvoided = true)
    }

    /** Position eines Ortes entlang der Route (Meter ab Start) */
    private fun alongOf(r: Route, p: LatLon): Double {
        var best = 0
        var bd = Double.MAX_VALUE
        r.points.forEachIndexed { i, q -> val d = haversine(p, q); if (d < bd) { bd = d; best = i } }
        return r.cumM.getOrElse(best) { 0.0 }
    }

    private fun insertSorted(r: Route?, list: List<Via>, v: Via): List<Via> {
        if (r == null) return list + v
        val a = alongOf(r, v.place.pos)
        val idx = list.indexOfFirst { alongOf(r, it.place.pos) > a }
        return if (idx < 0) list + v else list.toMutableList().apply { add(idx, v) }
    }

    private fun insertViaDuringNav(v: Via) {
        val s = _state.value
        val remaining = s.vias.drop(viasPassed)
        val list = insertSorted(s.route, remaining, v)
        viasPassed = 0
        _state.update { it.copy(vias = list) }
        rerouteNow()
    }

    // ----- Ladesäulen-Suche -----

    /** Ladesäulen entlang der Route suchen (vor der Fahrt: ganze Route, während der Fahrt: nächste 250 km) */
    fun openChargerSearch(replaceUuid: String? = null) {
        val s = _state.value
        val set = Settings.state.value
        val r = s.route ?: return
        if (!set.hasTomTom) {
            _state.update { it.copy(chargerSearch = ChargerSearch(loading = false, error = "Dafür wird der TomTom-Key benötigt (Einstellungen).")) }
            return
        }
        _state.update { it.copy(chargerSearch = ChargerSearch(replaceUuid = replaceUuid)) }
        val startAlong = if (s.navigating) s.progress?.alongM ?: 0.0 else 0.0
        val endAlong = if (s.navigating) startAlong + 250_000 else Double.MAX_VALUE
        scope.launch {
            val res = safe { TomTom.corridor(set.tomtomKey.trim(), r, startAlong, endAlong, set.corridorKm, set.searchMinKw) }
            res.onSuccess { hits ->
                val withAlong = hits.filter { it.alongM >= startAlong - 500 }
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, hits = withAlong)) } ?: st }
                loadHitAvailability(withAlong)
            }.onFailure { e ->
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, error = e.message)) } ?: st }
            }
        }
    }

    fun closeChargerSearch() { _state.update { it.copy(chargerSearch = null) } }

    /** Gewählte Ladestation als festen Ladestopp in die Route nehmen */
    fun pickCharger(h: ChargerHit) {
        val s = _state.value
        val replace = s.chargerSearch?.replaceUuid
        if (replace != null) avoidedParks += replace
        val v = Via(Place(h.name, h.pos), chargeParkId = h.availId, isCharger = true, powerKw = h.powerKw)
        _state.update { it.copy(chargerSearch = null) }
        if (s.navigating) {
            insertViaDuringNav(v)
        } else {
            val dest = s.dest ?: return
            plan(dest, insertSorted(s.route, s.vias, v), keepAvoided = true)
        }
    }

    private fun loadHitAvailability(hits: List<ChargerHit>) {
        val key = Settings.state.value.tomtomKey.trim()
        val ids = hits.mapNotNull { it.availId }.filter { it !in _state.value.hitAvailability }.take(8)
        if (key.isBlank() || ids.isEmpty()) return
        scope.launch {
            val found = ids.map { id -> async { id to safe { TomTom.availability(key, id) }.getOrNull() } }
                .mapNotNull { d -> d.await().let { (id, a) -> if (a != null) id to a else null } }
            if (found.isNotEmpty()) _state.update { it.copy(hitAvailability = it.hitAvailability + found) }
        }
    }

    fun select(i: Int) {
        _state.update { if (i in it.routes.indices) it.copy(selected = i) else it }
        _state.value.route?.let { loadAvailability(it) }
    }

    fun clear() {
        stopLive()
        planJob?.cancel()
        checkJob?.cancel()
        _state.value = State()
    }

    fun start(ctx: Context) {
        val s = _state.value
        val r = s.route ?: return
        lastSeg = 0; needFull = true; offCount = 0; viasPassed = 0
        announcedFull.clear()
        voice.reset()
        _state.value = s.copy(routes = listOf(r), selected = 0, navigating = true, arrived = false, offer = null, fullPark = null)
        runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, NavigationService::class.java)) }
        val first = r.steps.getOrNull(1)
        val stopsText = when (r.stops.size) {
            0 -> ""
            1 -> " Ein Ladestopp ist eingeplant."
            else -> " ${r.stops.size} Ladestopps sind eingeplant."
        }
        voice.say("Route gestartet.$stopsText " + if (first != null) "${first.phrase.cap()}${first.spokenTarget()}" else "")
        LocationHub.fix.value?.let { onFix(it) }
        startChecks()
        startLive()
    }

    fun stop(ctx: Context) {
        stopLive()
        voice.stop()
        checkJob?.cancel()
        ctx.stopService(Intent(ctx, NavigationService::class.java))
        planJob?.cancel()
        _state.value = State()
    }

    fun rerouteNow() { LocationHub.fix.value?.let { reroute(it, manual = true) } }

    fun acceptOffer() {
        val o = _state.value.offer ?: return
        lastSeg = 0; needFull = true; offCount = 0
        voice.reset()
        lastFixNs = 0L
        _state.update { it.copy(routes = listOf(o.route), selected = 0, offer = null, vias = it.vias.drop(viasPassed)) }
        viasPassed = 0
        loadAvailability(o.route)
        voice.say("Neue Route übernommen")
    }

    fun dismissOffer() { _state.update { it.copy(offer = null) } }

    /** Belegten Ladepark meiden und neu planen */
    fun avoidFullPark() {
        val p = _state.value.fullPark ?: return
        p.uuid?.let { avoidedParks += it }
        _state.update { it.copy(fullPark = null) }
        rerouteNow()
    }

    fun dismissFullPark() { _state.update { it.copy(fullPark = null) } }

    private fun currentSoc(): Double {
        Obd.freshSoc()?.let { return it }
        val s = _state.value
        val r = s.route
        val p = s.progress
        return if (r != null && p != null) r.socAt(p.alongM) ?: Settings.state.value.socStart else Settings.state.value.socStart
    }

    private fun onFix(f: Fix) {
        val s = _state.value
        if (!s.navigating || s.arrived) return
        val r = s.route ?: return
        val p = NavEngine.update(r, f.pos, lastSeg, needFull)
        lastSeg = p.segIdx
        val off = p.offRouteM > max(50.0, f.accuracy * 1.5)
        needFull = off
        offCount = if (off && f.accuracy < 60) offCount + 1 else 0
        _state.update { it.copy(progress = p) }
        if (viaAlongsFor !== r) {
            viaAlongs = s.vias.map { alongOf(r, it.place.pos) }
            viaAlongsFor = r
        }
        viasPassed = viaAlongs.count { it < p.alongM - 30 }

        // Alter der GPS-Messung (meist einige Zehntelsekunden) ausgleichen
        val age = if (f.elapsedNs > 0) ((SystemClock.elapsedRealtimeNanos() - f.elapsedNs) / 1e9).coerceIn(0.0, 2.0) else 0.0
        if (!off) {
            lastAlong = p.alongM
            lastSpeed = f.speed
            lastFixNs = if (f.elapsedNs > 0) f.elapsedNs else SystemClock.elapsedRealtimeNanos()
        }
        val pv = p.copy(distToStepM = max(0.0, p.distToStepM - f.speed * age))
        if (primeVoice && !off) { voice.prime(pv, f.speed); primeVoice = false }
        if (!off) updateWarning(r, p.alongM + f.speed * age, f.speed)
        if (offCount >= 3 && !s.rerouting && System.currentTimeMillis() - lastReroute > 8000) {
            reroute(f, manual = false)
        } else if (!off) {
            voice.onProgress(r, pv, f.speed)
        }
        if (!off && p.remainingM < 25) {
            checkJob?.cancel()
            stopLive()
            _state.update { it.copy(arrived = true) }
            app.stopService(Intent(app, NavigationService::class.java))
        }
    }

    /** Stauende, Baustelle oder Sperrung auf den nächsten Kilometern? */
    private fun updateWarning(r: Route, along: Double, speedMs: Double) {
        val kmh = speedMs * 3.6
        var best: Warning? = null
        var bestKey = ""
        for (j in r.jams) {
            if (j.magnitude <= 0 && j.category != "ROAD_CLOSURE" && j.category != "ROAD_WORK") continue
            if (j.startIdx !in r.cumM.indices) continue
            val a = r.cumM[j.startIdx]
            val b = if (j.endIdx in r.cumM.indices) r.cumM[j.endIdx] else a
            if (b < along) continue
            val dist = a - along
            if (dist > 3000) continue
            val inside = dist <= 0
            val title = when {
                j.category == "ROAD_CLOSURE" -> "Sperrung"
                j.category == "ROAD_WORK" -> "Baustelle"
                inside -> "Stau"
                else -> "Stauende"
            }
            if (best == null || dist < best.distM) {
                best = Warning(j.category, title, max(0.0, dist), j.delayS, inside, b - max(a, along))
                val pt = r.points.getOrElse(j.startIdx) { r.points.first() }
                bestKey = String.format(Locale.US, "%.3f,%.3f", pt.lat, pt.lon)
            }
        }
        _state.update { it.copy(warning = best) }
        val w = best ?: return
        if (w.inside) return
        val first = if (kmh > 80) 1500.0 else 700.0
        if (w.distM <= first && announcedJams.add("$bestKey/1")) {
            val km = (w.distM / 500).roundToInt() / 2.0
            val d = when {
                w.distM < 950 -> "${(w.distM / 50).roundToInt() * 50} Metern"
                abs(km - 1.0) < 0.01 -> "einem Kilometer"
                km % 1.0 == 0.0 -> "${km.toInt()} Kilometern"
                else -> "${km.toString().replace('.', ',')} Kilometern"
            }
            val extra = if (w.delayS > 120) ", etwa ${(w.delayS / 60).roundToInt()} Minuten Verzögerung" else ""
            voice.say("Achtung, ${w.title} in $d$extra")
        } else if (w.distM <= 400 && kmh > 60 && announcedJams.add("$bestKey/2")) {
            voice.say("Achtung, ${w.title} voraus")
        }
    }

    private fun reroute(f: Fix, manual: Boolean) {
        val s = _state.value
        val dest = s.dest ?: return
        val vias = s.vias.drop(viasPassed)
        val noToll = s.route?.tag == "Mautfrei"
        val soc = currentSoc()
        lastReroute = System.currentTimeMillis()
        _state.update { it.copy(rerouting = true, offer = null) }
        voice.say("Route wird neu berechnet")
        scope.launch {
            val res = safe {
                computeOptions(f.pos, if (f.speed > 3) f.bearing else null, dest.pos, soc,
                    alternatives = 0, withTollFree = false, noToll = noToll, vias = vias).first()
            }
            res.onSuccess { r ->
                lastSeg = 0; needFull = true; offCount = 0; viasPassed = 0
                lastFixNs = 0L
                voice.reset()
                _state.update { it.copy(routes = listOf(r.copy(tag = "Neu berechnet")), selected = 0, rerouting = false, vias = vias) }
                loadAvailability(r)
            }.onFailure {
                _state.update { it.copy(rerouting = false) }
                if (manual) voice.say("Neuberechnung fehlgeschlagen")
            }
        }
    }

    /** Alle 5 Minuten: schnellere Route? Nächster Ladepark belegt? */
    private fun startChecks() {
        checkJob?.cancel()
        checkJob = scope.launch {
            while (isActive) {
                delay(5 * 60_000L)
                checkAvailabilityAhead()
                checkBetterRoute()
            }
        }
    }

    private suspend fun checkBetterRoute() {
        val s = _state.value
        val set = Settings.state.value
        if (!set.hasTomTom || !s.navigating || s.rerouting || s.offer != null || s.arrived) return
        val f = LocationHub.fix.value ?: return
        val p = s.progress ?: return
        val dest = s.dest ?: return
        if (p.offRouteM > 50 || p.remainingM < 5_000) return
        val cand = safe {
            computeOptions(f.pos, if (f.speed > 3) f.bearing else null, dest.pos, currentSoc(),
                alternatives = 0, withTollFree = false, noToll = s.route?.tag == "Mautfrei", vias = s.vias.drop(viasPassed)).first()
        }.getOrNull() ?: return
        if (cand.source != "TomTom" || !cand.feasible) return
        val saved = p.remainingS - cand.durationS
        if (saved > max(300.0, 0.05 * p.remainingS)) {
            _state.update { it.copy(offer = Offer(cand.copy(tag = "Schneller"), saved)) }
            voice.say("Schnellere Route gefunden, etwa ${(saved / 60).roundToInt()} Minuten schneller.")
        } else if (abs(cand.distanceM - p.remainingM) / max(1.0, p.remainingM) < 0.02) {
            // Gleiche Strecke, aber frische Verkehrs-, Stau- und Spurdaten: still übernehmen
            lastSeg = 0; needFull = true; lastFixNs = 0L; primeVoice = true
            _state.update { it.copy(routes = listOf(cand.copy(tag = s.route?.tag ?: cand.tag)), selected = 0, vias = it.vias.drop(viasPassed)) }
            viasPassed = 0
        }
    }

    private suspend fun checkAvailabilityAhead() {
        val s = _state.value
        val key = Settings.state.value.tomtomKey
        if (key.isBlank()) return
        val r = s.route ?: return
        val p = s.progress ?: return
        val next = r.stops.firstOrNull { it.alongM > p.alongM } ?: return
        val uuid = next.uuid ?: return
        if (next.alongM - p.alongM > 60_000) return
        val a = safe { TomTom.availability(key, uuid) }.getOrNull() ?: return
        _state.update { it.copy(availability = it.availability + (uuid to a)) }
        if (a.known && a.total > 0 && a.available == 0 && announcedFull.add(uuid)) {
            _state.update { it.copy(fullPark = next) }
            voice.say("Der nächste Ladepark ist gerade voll belegt.")
        }
    }

    /** Belegung der ersten Ladestopps einer Route laden */
    private fun loadAvailability(r: Route) {
        val key = Settings.state.value.tomtomKey
        if (key.isBlank()) return
        val ids = r.stops.mapNotNull { it.uuid }.filter { it !in _state.value.availability }.take(5)
        if (ids.isEmpty()) return
        scope.launch {
            val found = ids.map { id -> async { id to safe { TomTom.availability(key, id) }.getOrNull() } }
                .mapNotNull { d -> d.await().let { (id, a) -> if (a != null) id to a else null } }
            if (found.isNotEmpty()) _state.update { it.copy(availability = it.availability + found) }
        }
    }

    /** Routenoptionen: TomTom (Verkehr + Ladestopps), sonst OSRM mit einfacher Akku-Schätzung */
    private suspend fun computeOptions(
        from: LatLon,
        heading: Float?,
        to: LatLon,
        socPct: Double,
        alternatives: Int,
        withTollFree: Boolean,
        noToll: Boolean,
        vias: List<Via> = emptyList(),
    ): List<Route> = coroutineScope {
        val set = Settings.state.value
        val weather = safe { Weather.along(from, to) }.getOrNull()
        if (set.hasTomTom) {
            val avoid = TomTom.avoids(set, noToll)
            val main: Deferred<Result<List<Route>>> = async {
                safe { TomTom.ldev(set, from, heading, to, socPct, weather, avoid, alternatives, avoidedParks.toList(), vias) }
            }
            val tollFree: Deferred<Result<List<Route>>>? = if (withTollFree && "tollRoads" !in avoid) {
                async { safe { TomTom.ldev(set, from, heading, to, socPct, weather, avoid + "tollRoads", 0, avoidedParks.toList(), vias) } }
            } else {
                null
            }
            val mainRes = main.await()
            val mainList = mainRes.getOrNull()
            if (mainList != null) {
                val out = mutableListOf<Route>()
                mainList.forEachIndexed { i, r -> out += r.copy(tag = if (noToll) "Mautfrei" else if (i == 0) "Empfohlen" else "Alternative") }
                tollFree?.await()?.getOrNull()?.firstOrNull()?.let { t ->
                    if (out.none { similar(it, t) }) out += t.copy(tag = "Mautfrei")
                }
                return@coroutineScope out.take(3)
            }
            _state.update {
                it.copy(note = "TomTom nicht verfügbar (${mainRes.exceptionOrNull()?.message}). Route ohne Verkehr und ohne Ladeplanung.")
            }
        } else {
            _state.update { it.copy(note = "Für Verkehr und automatische Ladestopps den TomTom-Key in den Einstellungen eintragen.") }
        }
        osrmOptions(from, heading, to, alternatives, vias.map { it.place.pos }).map { EvModel.estimateSimple(it, set, socPct, weather) }
    }

    private suspend fun osrmOptions(from: LatLon, bearing: Float?, to: LatLon, alts: Int, vias: List<LatLon>): List<Route> {
        val ex = Settings.osrmExcludes()
        val list = try {
            Routing.routes(from, bearing, to, ex, alts, vias)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (ex.isEmpty()) throw e
            Routing.routes(from, bearing, to, emptyList(), alts, vias)
        }
        return list.mapIndexed { i, r -> r.copy(tag = if (i == 0) "Empfohlen" else "Alternative") }.take(3)
    }

    private fun similar(a: Route, b: Route) =
        abs(a.distanceM - b.distanceM) / max(1.0, a.distanceM) < 0.01 &&
            abs(a.durationS - b.durationS) / max(1.0, a.durationS) < 0.01
}

// ---------------- Vordergrund-Dienst (Navigation im Hintergrund) ----------------

class NavigationService : Service() {
    private val scope = MainScope()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Navigation", NotificationManager.IMPORTANCE_LOW))
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, ID, build("Navigation läuft", ""), type)
        LocationHub.acquire(this, "nav")
        Obd.acquire("nav")
        scope.launch {
            NavSession.state
                .map { s ->
                    val r = s.route
                    val p = s.progress
                    if (r == null || p == null) {
                        "Navigation läuft" to ""
                    } else {
                        val step = r.steps[p.stepIdx]
                        "${fmtDistShort(p.distToStepM)} · ${step.bannerText()}" to
                            "Ankunft ${fmtEta(p.remainingS)} · ${fmtKm(p.remainingM)}"
                    }
                }
                .distinctUntilChanged()
                .collect { (title, text) -> nm.notify(ID, build(title, text)) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        scope.cancel()
        LocationHub.release("nav")
        Obd.release("nav")
        super.onDestroy()
    }

    private fun build(title: String, text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(R.drawable.ic_nav)
        .setContentTitle(title)
        .setContentText(text)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        )
        .build()

    companion object {
        private const val CHANNEL = "nav"
        private const val ID = 42
    }
}
