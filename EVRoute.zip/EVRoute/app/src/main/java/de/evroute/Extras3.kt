package de.evroute

import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ======================= Tempo-Coach =======================

/** Ein Tipp des Tempo-Coachs */
data class CoachTip(
    val capKmh: Int,
    val title: String,   // „115 statt 130 km/h“
    val detail: String,  // „Ladestopp entfällt · nur +6 min“
    val warning: Boolean,
    val spoken: String,
)

/**
 * Rechnet während der Fahrt durch, ob eine niedrigere Höchstgeschwindigkeit
 * einen Ladestopp spart oder einen zu knappen Akku verhindert.
 * Rein lokal (gelernter Verbrauch + verbleibende Strecke), ohne TomTom-Anfrage.
 */
object TempoCoach {
    private val CAPS = listOf(130, 120, 110, 100, 90)

    private data class Seg(val km: Double, val kmh: Double)

    /** Abschnitte der Route zwischen zwei Positionen, mit geplantem Tempo je Abbiegeschritt */
    private fun segments(r: Route, from: Double, to: Double): List<Seg> {
        val out = mutableListOf<Seg>()
        for (i in r.steps.indices) {
            val a = r.stepAlongM[i]
            val b = if (i + 1 < r.steps.size) r.stepAlongM[i + 1] else r.cumM.last()
            val lo = max(a, from)
            val hi = min(b, to)
            if (hi <= lo) continue
            val st = r.steps[i]
            val kmh = if (st.durationS > 1 && st.distanceM > 1) st.distanceM / st.durationS * 3.6 else 80.0
            out += Seg((hi - lo) / 1000, kmh.coerceIn(10.0, 180.0))
        }
        return out
    }

    /** Energie (kWh) und Zeit (h) für Abschnitte bei Tempo-Obergrenze cap */
    private fun cost(segs: List<Seg>, cap: Int?, s: AppSettings, w: WeatherInfo?): Pair<Double, Double> {
        var kwh = 0.0
        var h = 0.0
        val aux = EvModel.auxKw(w)
        segs.forEach { sg ->
            val v = if (cap != null) min(sg.kmh, cap.toDouble()) else sg.kmh
            val t = sg.km / v
            kwh += sg.km * EvModel.kwhPer100(v, s, w) / 100 + aux * t
            h += t
        }
        return kwh to h
    }

    fun evaluate(r: Route, along: Double, socNow: Double, s: AppSettings): CoachTip? {
        val w = r.weather
        val usable = s.usableKwh
        val nextStop = r.stops.firstOrNull { it.alongM > along + 2000 }
        val targetAlong = nextStop?.alongM ?: r.cumM.last()
        val segsA = segments(r, along, targetAlong)
        if (segsA.sumOf { it.km } < 15) return null
        val base = cost(segsA, null, s, w)
        // Plan-Akku am Ziel bzw. nächsten Stopp, korrigiert um die aktuelle Abweichung vom Plan
        val planNow = r.socAt(along) ?: socNow
        val planArrive = nextStop?.arriveSoc ?: r.arrivalSoc ?: return null
        val arriveBase = planArrive + (socNow - planNow)
        val maxPlanned = segsA.maxOf { it.kmh }

        // 1) Ladestopp einsparen?
        if (nextStop != null) {
            val after = r.stops.firstOrNull { it.alongM > nextStop.alongM + 2000 }
            val t2 = after?.alongM ?: r.cumM.last()
            val need = if (after == null) s.minSocDest else s.minSocStop
            val segsB = segments(r, targetAlong, t2)
            for (cap in CAPS) {
                if (cap >= maxPlanned - 3) continue
                val a = cost(segsA, cap, s, w)
                val b = cost(segsB, cap, s, w)
                val bBase = cost(segsB, null, s, w)
                val arriveA = arriveBase - (a.first - base.first) / usable * 100
                val arriveB = arriveA - b.first / usable * 100
                if (arriveA >= s.minSocStop && arriveB >= need) {
                    val extraMin = ((a.second - base.second) + (b.second - bBase.second)) * 60
                    val savedMin = nextStop.chargeS / 60 + 5 - extraMin // +5 min für Abfahrt, Anstecken, Umweg
                    if (savedMin >= 3) {
                        val cur = maxPlanned.roundToInt().coerceAtMost(200)
                        return CoachTip(
                            cap, "$cap statt $cur km/h",
                            "Ladestopp entfällt · ${if (extraMin >= 1) "nur +${extraMin.roundToInt()} min Fahrzeit" else "kaum langsamer"} · ca. ${savedMin.roundToInt()} min gespart",
                            false,
                            "Tipp: Mit $cap Kilometern pro Stunde sparst du dir den nächsten Ladestopp und bist etwa ${savedMin.roundToInt()} Minuten früher da.",
                        )
                    }
                    break
                }
            }
        }

        // 2) Akku wird knapp?
        val minOk = if (nextStop != null) s.minSocStop else s.minSocDest
        if (arriveBase < minOk - 2) {
            for (cap in CAPS) {
                if (cap >= maxPlanned - 3) continue
                val a = cost(segsA, cap, s, w)
                val arriveA = arriveBase - (a.first - base.first) / usable * 100
                if (arriveA >= minOk) {
                    val extraMin = ((a.second - base.second) * 60).roundToInt()
                    val where = if (nextStop != null) "am Ladestopp" else "am Ziel"
                    return CoachTip(
                        cap, "Akku wird knapp: max. $cap km/h",
                        "Sonst ${fmtPct(arriveBase)} $where, so ${fmtPct(arriveA)} · +$extraMin min",
                        true,
                        "Achtung, der Akku wird knapp. Fahr höchstens $cap Kilometer pro Stunde, dann kommst du mit ${arriveA.roundToInt()} Prozent an.",
                    )
                }
            }
        }
        return null
    }
}

// ======================= Reichweiten-Blase =======================

object Reach {
    data class State(
        val active: Boolean = false,
        val loading: Boolean = false,
        val outer: List<LatLon> = emptyList(),
        val round: List<LatLon> = emptyList(),
        val soc: Double? = null,
        val error: String? = null,
        val version: Int = 0,
        val center: LatLon? = null,
    )

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    fun toggle() {
        if (_state.value.active) _state.value = State() else compute()
    }

    /** Neu berechnen, wenn offen und Akku um 5 % gesunken oder 10 km gefahren */
    fun maybeRefresh() {
        val s = _state.value
        if (!s.active || s.loading) return
        val soc = Obd.freshSoc()
        val pos = LocationHub.fix.value?.pos ?: return
        val movedFar = s.center?.let { haversine(it, pos) > 10_000 } ?: false
        val socDrop = soc != null && s.soc != null && s.soc - soc >= 5
        if (movedFar || socDrop) compute(fit = false)
    }

    fun compute(fit: Boolean = true) {
        val set = Settings.state.value
        val pos = LocationHub.fix.value?.pos
        if (pos == null) { _state.update { it.copy(active = true, error = "Standort noch nicht verfügbar") }; return }
        val soc = Obd.freshSoc() ?: set.socStart
        _state.update { it.copy(active = true, loading = true, error = null, soc = soc) }
        scope.launch {
            val budget = (soc - set.minSocStop) / 100 * set.usableKwh
            if (budget <= 0.5) {
                _state.update { it.copy(loading = false, error = "Akku unter der Reserve – keine Reichweite") }
                return@launch
            }
            val w = runCatching { Weather.along(pos, pos) }.getOrNull()
            val (outer, round) = if (set.hasTomTom) {
                val o = runCatching { TomTom.reachable(set, pos, budget, w) }
                val rnd = if (set.reachRoundTrip) runCatching { TomTom.reachable(set, pos, budget / 2, w) }.getOrNull() else null
                if (o.isFailure) {
                    _state.update { it.copy(loading = false, error = "Reichweite nicht verfügbar: ${o.exceptionOrNull()?.message}") }
                    return@launch
                }
                o.getOrThrow() to (rnd ?: emptyList())
            } else {
                // Ohne TomTom: einfache Schätzung als Kreis (Landstraße/Autobahn gemischt, ~90 km/h)
                val km = budget / (EvModel.kwhPer100(90.0, set, w) / 100 + EvModel.auxKw(w) / 90.0) * 0.8
                circle(pos, km) to if (set.reachRoundTrip) circle(pos, km / 2) else emptyList()
            }
            _state.update { it.copy(loading = false, outer = outer, round = round, version = it.version + (if (fit) 1 else 0), center = pos) }
        }
    }

    private fun circle(c: LatLon, km: Double): List<LatLon> = (0 until 72).map { i ->
        val a = Math.toRadians(i * 5.0)
        LatLon(c.lat + cos(a) * km / 110.54, c.lon + sin(a) * km / (111.32 * cos(Math.toRadians(c.lat))))
    }
}
