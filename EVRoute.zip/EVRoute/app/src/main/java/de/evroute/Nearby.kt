package de.evroute

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import okhttp3.FormBody
import okhttp3.Request
import java.io.IOException
import kotlin.math.roundToInt

/** Was liegt an einer Ladestation? (aus OpenStreetMap über Overpass) */
data class NearbyInfo(
    val location: String?,            // z. B. "Raststätte Lippetal"
    val toilets: String?,             // z. B. "Toiletten · 60 m" oder "an der Raststätte"
    val food: List<String>,           // "McDonald’s · 80 m"
    val shops: List<String>,          // "Edeka · 120 m"
)

object Nearby {
    private const val URL = "https://overpass-api.de/api/interpreter"

    private fun JsonObject.tag(k: String): String = ((this["tags"] as? JsonObject)?.get(k) as? JsonPrimitive)?.contentOrNull ?: ""

    suspend fun around(p: LatLon): NearbyInfo = withContext(Dispatchers.IO) {
        val lat = p.lat.f6()
        val lon = p.lon.f6()
        val q = """
            [out:json][timeout:25];
            (
              nwr(around:350,$lat,$lon)[amenity~"^(toilets|restaurant|cafe|fast_food|fuel)$"];
              nwr(around:350,$lat,$lon)[shop~"^(supermarket|convenience|bakery|kiosk|mall)$"];
              nwr(around:600,$lat,$lon)[highway~"^(services|rest_area)$"];
            );
            out center 60;
        """.trimIndent()
        val req = Request.Builder().url(URL).header("User-Agent", "EVRoute/0.15 (privat)")
            .post(FormBody.Builder().add("data", q).build()).build()
        val r = Http.call(req)
        if (r.code != 200) throw IOException("Overpass ${r.code}")
        val els = json.parseToJsonElement(r.body).jsonObject["elements"]?.jsonArray?.mapNotNull { it as? JsonObject } ?: emptyList()

        data class E(val kind: String, val name: String, val dist: Int, val o: JsonObject)
        val list = els.mapNotNull { o ->
            val elat = (o["lat"] as? JsonPrimitive)?.doubleOrNull ?: ((o["center"] as? JsonObject)?.get("lat") as? JsonPrimitive)?.doubleOrNull ?: return@mapNotNull null
            val elon = (o["lon"] as? JsonPrimitive)?.doubleOrNull ?: ((o["center"] as? JsonObject)?.get("lon") as? JsonPrimitive)?.doubleOrNull ?: return@mapNotNull null
            val kind = o.tag("amenity").ifBlank { o.tag("shop") }.ifBlank { o.tag("highway") }
            val name = o.tag("name").ifBlank { o.tag("brand") }
            E(kind, name, haversine(p, LatLon(elat, elon)).roundToInt(), o)
        }.sortedBy { it.dist }

        fun label(e: E, fallback: String) = (e.name.ifBlank { fallback }) + " · ${(e.dist / 10) * 10} m"

        val services = list.firstOrNull { it.kind == "services" }
        val rest = list.firstOrNull { it.kind == "rest_area" }
        val market = list.firstOrNull { it.kind == "supermarket" && it.dist < 120 }
        val mall = list.firstOrNull { it.kind == "mall" && it.dist < 250 }
        val fuel = list.firstOrNull { it.kind == "fuel" && it.dist < 120 }
        val location = when {
            services != null -> "Raststätte" + if (services.name.isNotBlank()) " ${services.name}" else ""
            rest != null -> "Rastplatz" + if (rest.name.isNotBlank()) " ${rest.name}" else ""
            mall != null -> "Einkaufszentrum" + if (mall.name.isNotBlank()) " ${mall.name}" else ""
            market != null -> "Supermarkt-Parkplatz" + if (market.name.isNotBlank()) " (${market.name})" else ""
            fuel != null -> "Tankstelle" + if (fuel.name.isNotBlank()) " ${fuel.name}" else ""
            else -> null
        }
        val wc = list.firstOrNull { it.kind == "toilets" }
        val toilets = when {
            wc != null -> "Toiletten · ${(wc.dist / 10) * 10} m"
            services != null -> "an der Raststätte"
            list.any { it.o.tag("toilets") == "yes" && it.dist < 200 } ->
                "bei " + list.first { it.o.tag("toilets") == "yes" && it.dist < 200 }.let { label(it, "einem Geschäft") }
            else -> null
        }
        val food = list.filter { it.kind in setOf("restaurant", "cafe", "fast_food") }.take(5).map {
            label(it, when (it.kind) { "cafe" -> "Café"; "fast_food" -> "Imbiss"; else -> "Restaurant" })
        }
        val shops = list.filter { it.kind in setOf("supermarket", "convenience", "bakery", "kiosk") }.take(4).map {
            label(it, when (it.kind) { "supermarket" -> "Supermarkt"; "bakery" -> "Bäckerei"; else -> "Kiosk" })
        }
        NearbyInfo(location, toilets, food, shops)
    }
}

/** Typische Farbe eines Ladeanbieters (kein Logo, nur Farbe) */
fun operatorColor(op: String): Long {
    val o = op.lowercase()
    return when {
        "tesla" in o -> 0xFFE31937
        "enbw" in o -> 0xFF1E3C96
        "ionity" in o -> 0xFF6E2C91
        "fastned" in o -> 0xFFE8B100
        "allego" in o -> 0xFFF04E23
        "aral" in o -> 0xFF0057A8
        "shell" in o -> 0xFFE8B800
        "ewe" in o -> 0xFF0091D2
        "e.on" in o || "eon" in o -> 0xFFE2001A
        "electra" in o -> 0xFF00A3A1
        "mer" == o || o.startsWith("mer ") -> 0xFF00843D
        else -> 0xFF30D158
    }
}

/** Klingt die Sucheingabe nach Ladestation? */
fun isChargingQuery(q: String): Boolean {
    val s = q.lowercase()
    val words = listOf(
        "tesla", "supercharger", "enbw", "ionity", "fastned", "allego", "aral pulse", "aral", "shell recharge",
        "ewe go", "e.on", "electra", "atlante", "ladestation", "ladesäule", "ladepark", "laden ", "lader", "schnelllader",
        "charger", "charging", "hpc", "e-tankstelle",
    )
    if (words.any { it in s }) return true
    val ops = KnownOperators.items.value + Settings.state.value.preferOperators
    return ops.any { it.length >= 4 && it.lowercase() in s }
}
