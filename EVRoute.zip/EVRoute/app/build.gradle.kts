plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Release-Schlüssel kommt (falls hinterlegt) aus den GitHub-Secrets, siehe build.yml
val releaseKs: String? = System.getenv("EVR_KEYSTORE")

android {
    namespace = "de.evroute"
    compileSdk = 34
    defaultConfig {
        applicationId = "de.evroute"
        minSdk = 26
        targetSdk = 34
        versionCode = 37
        versionName = "0.30"
        // Nur ARM (alle echten Handys); Intel-Varianten für Emulatoren weggelassen -> kleinere APK
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    signingConfigs {
        // Fester Schlüssel, damit neue Builds sich über die alte App installieren lassen
        getByName("debug") {
            storeFile = file("evroute-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    if (releaseKs != null) {
        signingConfigs.create("release") {
            storeFile = file(releaseKs!!)
            storePassword = System.getenv("EVR_KEYSTORE_PASSWORD")
            keyAlias = "evroute"
            keyPassword = System.getenv("EVR_KEYSTORE_PASSWORD")
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = if (releaseKs != null) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.maplibre.gl:android-sdk:11.5.2")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    // Android Auto
    implementation("androidx.car.app:app:1.4.0")
    implementation("androidx.car.app:app-projected:1.4.0")
}
