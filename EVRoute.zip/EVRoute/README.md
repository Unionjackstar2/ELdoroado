# EVRoute – Runde 4: Lernen aus Fahrten

Private Android-App (Kotlin, Jetpack Compose, MapLibre). Später: Ladeplanung (Runde 2), OBD2 ë-C4 (Runde 3), Lernen und Einstellungen (Runde 4).

## APK bauen lassen (GitHub, geht auch am Handy)
1. Auf github.com ein neues **privates** Repository „EVRoute“ anlegen, „Add a README file“ anhaken.
2. „Add file → Create new file“, Dateiname `.github/workflows/build.yml`, Inhalt der Datei `build.yml` einfügen, „Commit changes“.
   (Der erste automatische Lauf schlägt fehl, weil das Projekt noch fehlt – das ist normal.)
3. „Add file → Upload files“, `EVRoute.zip` hochladen, „Commit changes“.
4. Unter „Actions“ läuft der Build (ca. 5–10 Minuten). Danach unter „Releases → EVRoute – neuester Build“ die `EVRoute.apk` laden und installieren.
5. Neue Version: einfach die neue `EVRoute.zip` erneut hochladen (ersetzen).

Hinweis: Ist eine ältere App mit gleichem Namen (z. B. aus Google AI Studio) installiert, vorher deinstallieren. Danach lassen sich alle neuen Builds drüber installieren.

## Funktionen Runde 1
- Karte im Apple-Maps-Stil, Tag-/Nachtmodus (OpenFreeMap / OpenStreetMap)
- Suche mit „Zuletzt“-Liste (Photon)
- Bis zu 3 Routenoptionen (Empfohlen, Alternative, Mautfrei), Auswahl per Tippen
- Blaue Fahrtlinie mit Kontur, gefahrener Teil wird grau
- Fahrsymbol: Pfeil, Auto (Farbe wählbar) oder Punkt, weich animiert, rastet auf der Route ein
- Auto-Zoom nach Tempo, geneigte 3D-Ansicht, Zentrieren-Knopf
- Abbiege-Banner mit Pfeilen, „Dann“-Hinweis, Tempo und Tempolimit
- Sprachansagen (Deutsch), Neuberechnung bei Abweichung und per Knopf
- Navigation läuft im Hintergrund weiter (Benachrichtigung)

## Neu in Runde 2
- TomTom-Key in den Einstellungen eintragen (wird nur auf dem Handy gespeichert)
- Langstrecken-Routing mit automatischen Ladestopps (Ladekurve ë-C4), Live-Verkehr, bis zu 3 Optionen + Mautfrei
- Wetter entlang der Strecke (Temperatur, Gegenwind, Regen) fließt in den Verbrauch ein
- Akku-Verlauf, Ladestopps mit Leistung, Ladezeit und Live-Belegung
- Verkehrslage auf der Karte, Staus auf der Route farbig
- Während der Fahrt: alle 5 Minuten Suche nach schnellerer Route, Warnung bei belegtem Ladepark
- Ohne Key: Route über OSRM mit einfacher Akku-Schätzung

## Neu in Runde 2b
- Favoriten: Zuhause, Arbeit, weitere (Leiste in der Suche, ⭐ im Routenfenster, langes Drücken auf Karte)
- Zwischenstopps mit Pause, sortierbar; langes Drücken auf die Karte: Route / Als Stopp / Favorit
- Ladestation selbst wählen (Suche entlang der Route) oder automatischen Stopp ersetzen
- Während der Fahrt: ⚡ Ladestationen auf den nächsten 250 km, „Hier laden“; + Stopp hinzufügen
- Routenfenster ziehbar in 3 Stufen
- Einstellungen: bevorzugte/gemiedene Betreiber, eigene Ladekarten

## Neu in Runde 3
- Einstellungen → OBD2-Adapter: suchen, auswählen (z. B. Vgate iCar Pro 2S), automatisch verbinden
- Live & Rohdaten: SoC, SoC kalibriert, Energie, SOH, Zellspannungen, Temperaturen, Tempo, Spannung/Strom (kalibrierbar), Konsole, Protokoll
- Akkustand fließt automatisch in die Planung, Plan gegen Ist mit automatischer Neuplanung
- Optional: fester Release-Schlüssel über GitHub-Secrets (KEYSTORE_BASE64, KEYSTORE_PASSWORD)

## Neu in Runde 4
- Fahrten werden automatisch aufgezeichnet, wenn OBD verbunden ist (Energie, Strecke, Tempo, Höhe, Temperatur)
- Verbrauch wird je Tempo- und Temperaturbereich gelernt und ersetzt nach und nach die Fahrweise-Einstellung
- Ladekurve wird beim Schnellladen gelernt (App offen oder Navigation läuft)
- Einstellungen: Referenzverbrauch, Höchstgeschwindigkeit (an TomTom), Zusatzgewicht, Akkustand abrunden
- Einstellungen → Fahrten & Lernen: Tabelle, Ladekurve, Fahrtenliste, Teilen als Tabelle, Zurücksetzen

## Bekannte Grenzen
- Der freie OSRM-Server liefert nicht immer Alternativen; Spurinfos fehlen noch.
- Tempolimits nur, wo sie in OpenStreetMap eingetragen sind.
