package de.evroute

import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Dehaze
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbCloudy
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

// ---------------- Wetter am Standort (dezent in der Begrüßung) ----------------

object NowWeather {
    data class W(val tempC: Double, val code: Int, val day: Boolean)

    private val _state = MutableStateFlow<W?>(null)
    val state: StateFlow<W?> = _state.asStateFlow()
    private var lastAt = 0L
    private var lastPos: LatLon? = null

    /** Höchstens alle 20 Minuten bzw. nach 5 km neu abrufen (Open-Meteo, ohne Schlüssel) */
    suspend fun refresh(p: LatLon) {
        val fresh = System.currentTimeMillis() - lastAt < 20 * 60_000
        val near = lastPos?.let { haversine(it, p) < 5000 } == true
        if (_state.value != null && fresh && near) return
        runCatching {
            val url = String.format(
                Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f&current=temperature_2m,weather_code,is_day&timezone=auto",
                p.lat, p.lon,
            )
            val cur = json.parseToJsonElement(Http.get(url)).jsonObject["current"]!!.jsonObject
            val t = cur["temperature_2m"]!!.jsonPrimitive.doubleOrNull!!
            val c = cur["weather_code"]?.jsonPrimitive?.intOrNull ?: 0
            val d = (cur["is_day"]?.jsonPrimitive?.intOrNull ?: 1) == 1
            _state.value = W(t, c, d)
            lastAt = System.currentTimeMillis()
            lastPos = p
        }
    }

    /** WMO-Wettercode als kurzes deutsches Wort */
    fun label(code: Int, day: Boolean): String = when (code) {
        0 -> if (day) "sonnig" else "klar"
        1 -> if (day) "heiter" else "fast klar"
        2 -> "leicht bewölkt"
        3 -> "bewölkt"
        45, 48 -> "Nebel"
        51, 53, 55, 56, 57 -> "Nieselregen"
        61, 63, 65, 66, 67 -> "Regen"
        71, 73, 75, 77 -> "Schnee"
        80, 81, 82 -> "Schauer"
        85, 86 -> "Schneeschauer"
        95, 96, 99 -> "Gewitter"
        else -> ""
    }

    fun icon(code: Int, day: Boolean): ImageVector = when (code) {
        0, 1 -> if (day) Icons.Filled.WbSunny else Icons.Filled.NightsStay
        2 -> Icons.Filled.WbCloudy
        3 -> Icons.Filled.Cloud
        45, 48 -> Icons.Filled.Dehaze
        71, 73, 75, 77, 85, 86 -> Icons.Filled.AcUnit
        95, 96, 99 -> Icons.Filled.Bolt
        in 51..82 -> Icons.Filled.WaterDrop
        else -> Icons.Filled.Cloud
    }
}

// ---------------- Vorschläge anhand der Favoriten, Ort und Uhrzeit ----------------

object HomeSuggest {
    fun greeting(hour: Int): String = when (hour) {
        in 5..10 -> "Guten Morgen"
        in 11..17 -> "Guten Tag"
        in 18..22 -> "Guten Abend"
        else -> "Gute Nacht"
    }

    /**
     * Welcher Favorit passt gerade? [homeM]/[workM]: Entfernung dorthin (null = nicht festgelegt).
     * Am Ziel selbst wird es nicht vorgeschlagen; ohne passendes Muster gibt es keinen Vorschlag.
     */
    fun pick(homeM: Double?, workM: Double?, hour: Int, weekday: Boolean): FavKind? {
        val near = 400.0
        val morning = weekday && hour in 5..10
        return when {
            homeM != null && homeM < near -> if (morning && workM != null && workM > 1000) FavKind.WORK else null
            workM != null && workM < near -> if (hour >= 12 && homeM != null) FavKind.HOME else null
            morning && workM != null -> FavKind.WORK
            homeM != null && (hour >= 12 || hour < 4) -> FavKind.HOME
            else -> null
        }
    }

    /** grobe Schätzung ohne Routenabruf: Umweg-Faktor 1,3 und typische Durchschnittstempi */
    fun estimate(straightM: Double): Pair<Double, Int> {
        val km = straightM / 1000 * 1.3
        val kmh = when {
            km < 8 -> 32.0
            km < 30 -> 50.0
            else -> 75.0
        }
        return km to (km / kmh * 60).roundToInt().coerceAtLeast(1)
    }
}

/** Startbereich unter den Favoriten: Begrüßung, Vorschlag, Akku und Eco-Score */
@Composable
fun HomeOverview(vm: MainViewModel) {
    val pal = LocalPal.current
    val set by Settings.state.collectAsState()
    val fix by LocationHub.fix.collectAsState()
    val weather by NowWeather.state.collectAsState()
    val favs by Favorites.items.collectAsState()
    val values by Obd.values.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(60_000); tick++ } }
    val pos = fix?.pos
    LaunchedEffect(pos?.let { (it.lat * 50).roundToInt() to (it.lon * 50).roundToInt() }) { pos?.let { NowWeather.refresh(it) } }
    val cal = remember(tick) { Calendar.getInstance() }
    val hour = cal.get(Calendar.HOUR_OF_DAY)
    val weekday = cal.get(Calendar.DAY_OF_WEEK) !in listOf(Calendar.SATURDAY, Calendar.SUNDAY)
    val soc = remember(values, tick, set.socStart) { Obd.freshSoc() ?: set.socStart }

    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Begrüßung mit Wetter
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(HomeSuggest.greeting(hour), color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            weather?.let { w ->
                Icon(NowWeather.icon(w.code, w.day), null, tint = pal.sub, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                val word = NowWeather.label(w.code, w.day)
                Text("${w.tempC.roundToInt()} °C" + if (word.isNotBlank()) " · $word" else "", color = pal.sub, fontSize = 13.sp)
            }
        }

        // Vorschlag (nur wenn er passt)
        val home = favs.firstOrNull { it.kind == FavKind.HOME }
        val work = favs.firstOrNull { it.kind == FavKind.WORK }
        val kind = if (pos == null) null else HomeSuggest.pick(home?.let { haversine(pos, it.place.pos) }, work?.let { haversine(pos, it.place.pos) }, hour, weekday)
        val target = when (kind) {
            FavKind.HOME -> home
            FavKind.WORK -> work
            else -> null
        }
        if (target != null && pos != null) {
            val (km, min) = HomeSuggest.estimate(haversine(pos, target.place.pos))
            val per100 = EvModel.kwhPer100(if (km < 30) 50.0 else 90.0, set, null)
            val arrive = soc - km * per100 / 100 / set.usableKwh * 100
            val needsCharge = arrive < set.minSocStop
            Surface(shape = RoundedCornerShape(20.dp), color = pal.field.copy(alpha = 0.55f), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 14.dp, end = 10.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(pal.gold.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                        Icon(if (kind == FavKind.HOME) Icons.Filled.Home else Icons.Filled.Work, null, tint = pal.gold, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (kind == FavKind.HOME) "Nach Hause?" else "Zur Arbeit?", color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "ca. $min min · " + if (needsCharge) "Ladestopp nötig" else "Ankunft mit ca. ${arrive.coerceAtLeast(0.0).roundToInt()} %",
                            color = if (needsCharge) pal.gold else pal.sub, fontSize = 13.sp,
                        )
                    }
                    Box(
                        Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(pal.goldFill).clickable { vm.pickDirect(target.place) }.padding(horizontal = 20.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("Los", color = Color(0xFF0B1530), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
                }
            }
        }

        BatteryCard(vm)
    }
}

/** Akku-Karte: Reichweite groß, Akku als goldenes Band – live per OBD oder per Wischen einstellbar */
@Composable
fun BatteryCard(vm: MainViewModel) {
    val pal = LocalPal.current
    val set by Settings.state.collectAsState()
    val conn by Obd.conn.collectAsState()
    val values by Obd.values.collectAsState()
    val last by LastSoc.state.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(30_000); tick++ } }
    val live = remember(values, tick) { Obd.freshSoc() }
    var editing by remember { mutableStateOf<Double?>(null) }
    val soc = live ?: editing ?: set.socStart
    // Bewusst keine Reichweite in km: sie kann von der Anzeige im Auto abweichen und dann in die Irre führen
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
        LiquidBattery(
            value = soc, editable = live == null,
            onChange = { editing = it },
            onCommit = { v -> Settings.update { it.copy(socStart = v) }; editing = null },
            modifier = Modifier.width(100.dp).height(170.dp),
        )
        Spacer(Modifier.width(12.dp))
        Box(Modifier.width(1.dp).fillMaxHeight().padding(vertical = 18.dp).background(pal.divider))
        Spacer(Modifier.width(12.dp))
        // Plastische Karte rechts: Fahrzeug, Herkunft des Akkuwerts, Eco-Blatt
        PlasticCard(Modifier.weight(1f)) {
            Column(Modifier.padding(14.dp)) {
                Row(
                    Modifier.clip(RoundedCornerShape(14.dp)).clickable { vm.openSettings("VEHICLE") },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PlasticIcon(Icons.Filled.DirectionsCar, pal.text, 40.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(Vehicles.byId(set.vehicleId).name, color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, lineHeight = 20.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        when {
                            live != null -> Row(
                                Modifier.clip(RoundedCornerShape(10.dp)).clickable { vm.openObd() }.padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                ObdPlugIcon(pal.green, Modifier.size(22.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("OBD live", color = pal.green, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            }
                            conn == Obd.Conn.CONNECTING || conn == Obd.Conn.INIT -> StatusLine(Color(0xFFFF9500), "Verbinde mit OBD …")
                            last != null -> StatusLine(pal.sub, "Zuletzt ${agoText(last!!.second)}: ${last!!.first.roundToInt()} %")
                            else -> StatusLine(pal.green, "Von Hand eingestellt")
                        }
                        if (live == null) {
                            Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.SwapVert, null, tint = pal.sub, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Füllstand ziehen", color = pal.sub, fontSize = 12.sp)
                            }
                        }
                    }
                    EcoLeaf(vm)
                }
            }
        }
    }
}

@Composable
private fun StatusLine(dot: Color, text: String) {
    val pal = LocalPal.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(8.dp))
        Text(text, color = pal.sub, fontSize = 14.sp, maxLines = 2)
    }
}

/** Plastische Fläche: heller Verlauf, weicher Schatten, feiner Lichtrand oben */
@Composable
fun PlasticCard(modifier: Modifier = Modifier, corner: androidx.compose.ui.unit.Dp = 22.dp, content: @Composable () -> Unit) {
    val pal = LocalPal.current
    val top = if (pal.dark) Color(0xFF2B3038) else Color.White
    val bottom = if (pal.dark) Color(0xFF1F232A) else Color(0xFFF0F3F7)
    Box(
        modifier
            .shadow(6.dp, RoundedCornerShape(corner), ambientColor = Color.Black.copy(alpha = 0.15f), spotColor = Color.Black.copy(alpha = 0.18f))
            .clip(RoundedCornerShape(corner))
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = if (pal.dark) 0.10f else 0.9f), Color.Transparent)), RoundedCornerShape(corner)),
    ) { content() }
}

/** Symbol in einer plastischen, runden Mulde */
@Composable
fun PlasticIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, size: androidx.compose.ui.unit.Dp, glow: Color? = null) {
    val pal = LocalPal.current
    val g = glow ?: tint
    Box(
        Modifier.size(size).shadow(3.dp, CircleShape).clip(CircleShape)
            .background(Brush.radialGradient(listOf(g.copy(alpha = if (pal.dark) 0.28f else 0.16f), if (pal.dark) Color(0xFF2B3038) else Color.White))),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.55f)) }
}

/** Kleiner OBD2-Stecker (Trapez mit zwei Pin-Reihen) – zeigt die aktive OBD-Verbindung */
@Composable
fun ObdPlugIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val body = Path().apply {
            moveTo(w * 0.04f, h * 0.22f); lineTo(w * 0.96f, h * 0.22f)
            lineTo(w * 0.82f, h * 0.82f); lineTo(w * 0.18f, h * 0.82f); close()
        }
        drawPath(body, color)
        val pin = w * 0.055f
        for (i in 0 until 4) {
            drawCircle(Color.White, pin, Offset(w * (0.25f + i * 0.167f), h * 0.40f))
            drawCircle(Color.White, pin, Offset(w * (0.30f + i * 0.133f), h * 0.62f))
        }
    }
}

/** Eco-Score als Blatt mit der Zahl darauf; Antippen öffnet die Auswertung */
@Composable
fun EcoLeaf(vm: MainViewModel) {
    val trips by EcoStore.items.collectAsState()
    if (trips.isEmpty()) return
    val total = EcoStats.weighted(trips) { it.score.toDouble() }?.roundToInt() ?: return
    val (light, deep) = when {
        total >= 80 -> Color(0xFF4ADE80) to Color(0xFF15803D)
        total >= 60 -> Color(0xFFFBBF24) to Color(0xFFB45309)
        else -> Color(0xFFF87171) to Color(0xFFB91C1C)
    }
    Box(
        Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)).clickable { vm.openSettings("ECO") },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize().padding(2.dp)) {
            val w = size.width
            val h = size.height
            // Blattform: Spitze oben rechts, Stiel unten links
            val leaf = Path().apply {
                moveTo(w * 0.16f, h * 0.86f)
                cubicTo(w * 0.02f, h * 0.40f, w * 0.40f, h * 0.06f, w * 0.94f, h * 0.06f)
                cubicTo(w * 0.96f, h * 0.60f, w * 0.62f, h * 0.96f, w * 0.16f, h * 0.86f)
                close()
            }
            drawPath(Path().apply { addPath(leaf, Offset(0f, 2.dp.toPx())) }, Color.Black.copy(alpha = 0.12f))
            drawPath(leaf, Brush.linearGradient(listOf(light, deep), start = Offset(w, 0f), end = Offset(0f, h)))
            // Mittelrippe und Stiel
            drawLine(Color.White.copy(alpha = 0.35f), Offset(w * 0.18f, h * 0.84f), Offset(w * 0.86f, h * 0.14f), 1.5.dp.toPx())
            drawLine(deep, Offset(w * 0.16f, h * 0.86f), Offset(w * 0.06f, h * 0.97f), 2.5.dp.toPx())
        }
        Text("$total", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 2.dp))
    }
}

/**
 * Akku als große Batterie mit grüner Flüssigkeit und aufsteigenden Bläschen; der Füllstand lässt sich
 * ohne OBD nach oben/unten ziehen. Die Prozentzahl klebt als „Aufkleber“ auf der Batterie.
 * Die Bläschen laufen nur einige Sekunden nach dem Anzeigen bzw. Ziehen (dauernde Animation kostet Akku).
 */
@Composable
fun LiquidBattery(value: Double, editable: Boolean, onChange: (Double) -> Unit, onCommit: (Double) -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    var v by remember { mutableFloatStateOf(value.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(value) { if (!dragging) v = value.toFloat() }
    // Animation: Zeit in Sekunden, läuft bis „until“
    var t by remember { mutableFloatStateOf(0f) }
    var until by remember { mutableLongStateOf(System.currentTimeMillis() + 15_000) }
    LaunchedEffect(until) {
        while (System.currentTimeMillis() < until) {
            kotlinx.coroutines.delay(40)
            t += 0.04f
        }
    }
    fun wake() { until = System.currentTimeMillis() + 15_000 }
    // Füllstand aus der Fingerposition (innerer Bereich ohne Pol und Rand)
    fun pctAt(y: Float, h: Int): Float {
        val top = h * 0.10f
        val bottom = h * 0.97f
        return ((bottom - y) / (bottom - top) * 100f).coerceIn(0f, 100f).let { kotlin.math.round(it) }
    }
    val liquidTop = when {
        v < 10 -> Color(0xFFF87171)
        v < 20 -> Color(0xFFFBBF24)
        else -> Color(0xFF4ADE80)
    }
    val liquidBottom = when {
        v < 10 -> Color(0xFFDC2626)
        v < 20 -> Color(0xFFD97706)
        else -> Color(0xFF15803D)
    }
    val outline = pal.text.copy(alpha = 0.55f)
    Box(
        modifier.then(
            if (editable) {
                Modifier
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragStart = { p -> dragging = true; wake(); v = pctAt(p.y, size.height); onChange(v.toDouble()) },
                            onDragEnd = { dragging = false; onCommit(v.toDouble()) },
                            onDragCancel = { dragging = false; onCommit(v.toDouble()) },
                        ) { change, _ ->
                            change.consume()
                            v = pctAt(change.position.y, size.height)
                            onChange(v.toDouble())
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures { p -> wake(); v = pctAt(p.y, size.height); onChange(v.toDouble()); onCommit(v.toDouble()) }
                    }
            } else {
                Modifier.clickable { wake() }
            },
        ),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 3.dp.toPx()
            val capH = size.height * 0.06f
            val capW = size.width * 0.38f
            val bodyTop = capH + stroke
            val body = Size(size.width - stroke, size.height - bodyTop - stroke / 2)
            val bodyTl = Offset(stroke / 2, bodyTop)
            val r = 18.dp.toPx()
            // Pol oben
            drawRoundRect(outline, Offset((size.width - capW) / 2, stroke / 2), Size(capW, capH + stroke), CornerRadius(5.dp.toPx()))
            // Innenraum
            val pad = 6.dp.toPx()
            val inTl = Offset(bodyTl.x + pad, bodyTl.y + pad)
            val inSz = Size(body.width - 2 * pad, body.height - 2 * pad)
            val inner = Path().apply { addRoundRect(androidx.compose.ui.geometry.RoundRect(inTl.x, inTl.y, inTl.x + inSz.width, inTl.y + inSz.height, CornerRadius(r - pad))) }
            drawPath(inner, outline.copy(alpha = 0.10f))
            clipPath(inner) {
                val level = inTl.y + inSz.height * (1f - v / 100f)
                // Flüssigkeit mit leichter Welle an der Oberfläche
                val amp = if (v in 1f..99f) 3.dp.toPx() else 0f
                val wave = Path().apply {
                    moveTo(inTl.x, inTl.y + inSz.height)
                    lineTo(inTl.x, level)
                    var x = 0f
                    while (x <= inSz.width) {
                        val y = level + amp * kotlin.math.sin((x / inSz.width * 2f * Math.PI.toFloat() * 1.3f) + t * 2.2f)
                        lineTo(inTl.x + x, y)
                        x += 4f
                    }
                    lineTo(inTl.x + inSz.width, inTl.y + inSz.height)
                    close()
                }
                drawPath(wave, Brush.verticalGradient(listOf(liquidTop, liquidBottom), startY = level, endY = inTl.y + inSz.height))
                // Bläschen steigen vom Boden zur Oberfläche
                val liquidH = inTl.y + inSz.height - level
                if (liquidH > 12.dp.toPx()) {
                    for (i in 0 until 9) {
                        val seed = i * 0.6180339f
                        val fx = (seed * 7.31f) % 1f
                        val speed = 0.08f + (seed * 3.7f % 1f) * 0.10f
                        val prog = (t * speed + seed) % 1f
                        val y = inTl.y + inSz.height - prog * liquidH
                        val x = inTl.x + 6.dp.toPx() + fx * (inSz.width - 12.dp.toPx()) + 2.dp.toPx() * kotlin.math.sin(t * 3f + i)
                        val rad = (1.6f + (seed * 5.1f % 1f) * 2.6f).dp.toPx()
                        drawCircle(Color.White.copy(alpha = 0.35f * (1f - prog * 0.6f)), rad, Offset(x, y))
                    }
                }
                // Glanzlicht
                drawRect(
                    Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.18f), Color.Transparent)),
                    topLeft = Offset(inTl.x, inTl.y), size = Size(inSz.width * 0.28f, inSz.height),
                )
            }
            // Gehäuse
            drawRoundRect(outline, bodyTl, body, CornerRadius(r), style = Stroke(stroke))
        }
        // Aufkleber mit der Prozentzahl
        Box(
            Modifier.graphicsLayer { rotationZ = -5f }
                .shadow(3.dp, RoundedCornerShape(6.dp))
                .background(Color(0xFFFAFAF7), RoundedCornerShape(6.dp))
                .padding(horizontal = 9.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${v.roundToInt()} %", color = Color(0xFF1F2937), fontSize = 22.sp, fontWeight = FontWeight.Bold, lineHeight = 24.sp)
                Text("AKKU", color = Color(0xFF6B7280), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, lineHeight = 10.sp)
            }
        }
    }
}

/** Akku als waagerechtes Band; ohne OBD mit Anfasser zum Ziehen oder Antippen */
@Composable
fun BatteryBand(value: Double, editable: Boolean, onChange: (Double) -> Unit, onCommit: (Double) -> Unit) {
    val pal = LocalPal.current
    var v by remember { mutableFloatStateOf(value.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(value) { if (!dragging) v = value.toFloat() }
    fun pct(x: Float, w: Int): Float = (x / w.coerceAtLeast(1) * 100f).coerceIn(0f, 100f).let { kotlin.math.round(it) }
    val fill = if (v < 15) pal.red else pal.goldFill
    val track = pal.sub.copy(alpha = 0.22f)
    Box(
        Modifier.fillMaxWidth().height(30.dp).padding(end = 6.dp).then(
            if (editable) {
                Modifier
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragStart = { p -> dragging = true; v = pct(p.x, size.width); onChange(v.toDouble()) },
                            onDragEnd = { dragging = false; onCommit(v.toDouble()) },
                            onDragCancel = { dragging = false; onCommit(v.toDouble()) },
                        ) { change, _ ->
                            change.consume()
                            v = pct(change.position.x, size.width)
                            onChange(v.toDouble())
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures { p -> v = pct(p.x, size.width); onChange(v.toDouble()); onCommit(v.toDouble()) }
                    }
            } else {
                Modifier
            },
        ),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val h = 8.dp.toPx()
            val top = (size.height - h) / 2
            val r = CornerRadius(h / 2, h / 2)
            drawRoundRect(track, topLeft = Offset(0f, top), size = Size(size.width, h), cornerRadius = r)
            val w = size.width * v / 100f
            if (w > 0f) drawRoundRect(fill, topLeft = Offset(0f, top), size = Size(w.coerceAtLeast(h), h), cornerRadius = r)
            if (editable) {
                val c = Offset(w.coerceIn(h / 2, size.width - h / 2), size.height / 2)
                drawCircle(Color.Black.copy(alpha = 0.22f), radius = 9.5.dp.toPx(), center = c + Offset(0f, 1.5.dp.toPx()))
                drawCircle(Color.White, radius = 8.5.dp.toPx(), center = c)
                drawCircle(fill, radius = 3.5.dp.toPx(), center = c)
            }
        }
    }
}

/** Eco-Score über alle Fahrten als Ring neben dem Akku-Band; Antippen öffnet die Auswertung */
@Composable
fun EcoBadge(vm: MainViewModel) {
    val pal = LocalPal.current
    val trips by EcoStore.items.collectAsState()
    if (trips.isEmpty()) return
    val total = EcoStats.weighted(trips) { it.score.toDouble() }?.roundToInt() ?: return
    val ringColor = when {
        total >= 80 -> pal.green
        total >= 60 -> pal.goldFill
        else -> pal.red
    }
    Column(
        Modifier.padding(start = 12.dp).clip(RoundedCornerShape(14.dp)).clickable { vm.openSettings("ECO") }.padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
            val track = pal.sub.copy(alpha = 0.22f)
            Canvas(Modifier.fillMaxSize()) {
                val sw = 5.dp.toPx()
                val tl = Offset(sw / 2, sw / 2)
                val sz = Size(size.width - sw, size.height - sw)
                drawArc(track, -90f, 360f, false, tl, sz, style = Stroke(sw))
                drawArc(ringColor, -90f, 3.6f * total, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
            Text("$total", color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.Normal)
        }
        Spacer(Modifier.height(4.dp))
        Text("Eco-Score", color = pal.sub, fontSize = 12.sp)
    }
}
