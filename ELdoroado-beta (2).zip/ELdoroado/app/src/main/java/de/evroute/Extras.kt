@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package de.evroute

import androidx.compose.material.icons.filled.Bolt
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.animation.core.animate
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.zIndex
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt

// ---------------- Favoriten-Leiste in der Suche ----------------

@Composable
fun FavoritesRow(vm: MainViewModel) {
    val pal = LocalPal.current
    val favs by Favorites.items.collectAsState()
    val home = favs.firstOrNull { it.kind == FavKind.HOME }
    val work = favs.firstOrNull { it.kind == FavKind.WORK }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        FavChip(Icons.Filled.Home, pal.blue, "Zuhause", if (home == null) "Festlegen" else null,
            onClick = { if (home != null) vm.pickDirect(home.place) else vm.startSearch(SearchMode.HOME) },
            onLong = { home?.let { vm.editFavorite(it) } })
        FavChip(Icons.Filled.Work, Color(0xFF8E5A2B), "Arbeit", if (work == null) "Festlegen" else null,
            onClick = { if (work != null) vm.pickDirect(work.place) else vm.startSearch(SearchMode.WORK) },
            onLong = { work?.let { vm.editFavorite(it) } })
        favs.filter { it.kind == FavKind.OTHER }.forEach { f ->
            FavChip(Icons.Filled.Star, Color(0xFFFF9F0A), f.label, null, onClick = { vm.pick(f.place) }, onLong = { vm.editFavorite(f) })
        }
        FavChip(Icons.Filled.Add, pal.sub, "Neu", null, onClick = { vm.startSearch(SearchMode.FAV) }, onLong = {})
    }
}

@Composable
private fun FavChip(icon: ImageVector, color: Color, label: String, sub: String?, onClick: () -> Unit, onLong: () -> Unit) {
    val pal = LocalPal.current
    Column(
        Modifier.width(62.dp).clip(RoundedCornerShape(12.dp)).combinedClickable(onClick = onClick, onLongClick = onLong).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // nur das Symbol (der Name bleibt für Bedienungshilfen erhalten)
        Box(Modifier.size(50.dp).clip(CircleShape).background(color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = color, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
fun FavEditDialog(f: Favorite, onClose: () -> Unit) {
    var name by remember(f.id) { mutableStateOf(f.label) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Favorit bearbeiten") },
        text = {
            Column {
                Text(f.place.name, fontSize = 13.sp, maxLines = 2)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = { Favorites.rename(f.id, name.ifBlank { f.label }); onClose() }) { Text("Speichern") }
        },
        dismissButton = {
            TextButton(onClick = { Favorites.remove(f.id); onClose() }) { Text("Löschen", color = Color(0xFFFF3B30)) }
        },
    )
}

// ---------------- Langes Drücken auf die Karte ----------------

@Composable
fun LongPressCard(lp: MainViewModel.LongPress, canAddStop: Boolean, vm: MainViewModel) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 24.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Place, null, tint = pal.red)
                Spacer(Modifier.width(8.dp))
                Text(
                    lp.name ?: "Adresse wird gesucht …", color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                )
                CloseDot(vm::closeLongPress)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = vm::longPressRoute, shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                ) { Text("Route", fontWeight = FontWeight.Bold) }
                if (canAddStop) {
                    Button(
                        onClick = vm::longPressVia, shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = pal.field, contentColor = pal.text),
                    ) { Text("Als Stopp") }
                }
                Button(
                    onClick = vm::longPressFavorite, shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.field, contentColor = pal.text),
                ) { Text("Favorit") }
            }
        }
    }
}

@Composable
fun CloseDot(onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(32.dp).clip(CircleShape).background(pal.field).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(Icons.Filled.Close, "Schließen", tint = pal.sub, modifier = Modifier.size(18.dp)) }
}

// ---------------- Ziehbares Routenfenster (3 Stufen wie bei Apple Maps) ----------------

@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
fun RouteSheet(nav: NavSession.State, settings: AppSettings, screenH: Dp, vm: MainViewModel, onGo: () -> Unit) {
    val pal = LocalPal.current
    val density = LocalDensity.current
    // zu: genau bis unter Ziel, Dauer und „Los“ (Kopf wird eigenständig gemessen)
    var headerPx by remember { mutableFloatStateOf(0f) }
    val peek = if (headerPx > 0f) headerPx + with(density) { 4.dp.toPx() } else with(density) { 150.dp.toPx() }
    val half = with(density) { (screenH * 0.50f).toPx() }
    val full = with(density) { (screenH * 0.86f).toPx() }
    var h by remember { mutableFloatStateOf(half) }
    LaunchedEffect(Unit) { vm.setSheetPx(half.toInt()) }
    val dragState = rememberDraggableState { delta -> h = (h - delta).coerceIn(peek, full) }
    val favs by Favorites.items.collectAsState()
    val dest = nav.dest
    val isFav = dest != null && favs.any { haversine(it.place.pos, dest.pos) < 30 }
    val r = nav.route

    GlassCard(Modifier.fillMaxWidth().height(with(density) { h.toDp() }), corner = 26.dp) {
        // Griff + Kopf: hier wird gezogen
        Column(
            Modifier.fillMaxWidth()
                .onSizeChanged { headerPx = it.height.toFloat() }
                .draggable(
                    state = dragState,
                    orientation = Orientation.Vertical,
                    onDragStopped = { v ->
                        val stops = listOf(peek, half, full)
                        val target = when {
                            v < -1200f -> stops.firstOrNull { it > h + 1 } ?: full
                            v > 1200f -> stops.lastOrNull { it < h - 1 } ?: peek
                            else -> stops.minByOrNull { abs(it - h) } ?: half
                        }
                        animate(h, target, initialVelocity = -v) { value, _ -> h = value }
                        vm.setSheetPx(target.toInt())
                    },
                )
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 6.dp),
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(pal.sub.copy(alpha = 0.5f)))
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    dest?.title ?: "", color = pal.text, fontSize = 21.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                )
                Box(
                    Modifier.size(32.dp).clip(CircleShape).background(pal.field).clickable {
                        if (dest == null) return@clickable
                        if (isFav) favs.filter { haversine(it.place.pos, dest.pos) < 30 }.forEach { Favorites.remove(it.id) }
                        else Favorites.set(FavKind.OTHER, dest)
                    },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder, "Favorit",
                        tint = if (isFav) Color(0xFFFF9F0A) else pal.sub, modifier = Modifier.size(18.dp),
                    )
                }
                Spacer(Modifier.width(8.dp))
                CloseDot { vm.backFromRoute() }
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    if (nav.loading) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            val step by PlanProgress.step.collectAsState()
                            Text(step ?: "Berechne …", color = pal.sub, fontSize = 15.sp, maxLines = 2)
                        }
                    } else if (r != null) {
                        Text(fmtDuration(r.durationS), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        val extra = buildList {
                            add("Ankunft ${fmtEta(r.durationS)}")
                            if (r.stops.isNotEmpty()) add("${r.stops.size} × laden")
                            r.arrivalSoc?.let { add("Ziel ${fmtPct(it)}") }
                        }.joinToString(" · ")
                        Text(extra, color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } else {
                        Text(nav.error ?: "", color = pal.red, fontSize = 14.sp, maxLines = 2)
                    }
                }
                Button(
                    onClick = onGo,
                    enabled = r != null && !nav.loading,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.green, contentColor = Color.White),
                    modifier = Modifier.height(46.dp),
                ) { Text("Los", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            }
        }
        // Inhalt: scrollt – zugeklappt unsichtbar, blendet beim Aufziehen weich ein
        val fadePx = with(density) { 60.dp.toPx() }
        Column(
            Modifier.weight(1f).graphicsLayer { alpha = ((h - peek) / fadePx).coerceIn(0f, 1f) }
                .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp),
        ) {
            Spacer(Modifier.height(6.dp))
            SocStartRow(settings)
            Spacer(Modifier.height(10.dp))
            StopsList(nav, vm)
            Spacer(Modifier.height(10.dp))
            nav.error?.let { Text(it, color = pal.red, modifier = Modifier.padding(vertical = 6.dp)) }
            nav.note?.let { Text(it, color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp)) }
            r?.note?.let { Text(it, color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp)) }
            val fastest = nav.routes.minOfOrNull { it.durationS } ?: 0.0
            // Routen nebeneinander: wischen wählt die Route, Punkte zeigen die Position
            if (nav.routes.isNotEmpty()) {
                val pager = rememberPagerState(initialPage = nav.selected.coerceIn(0, nav.routes.lastIndex)) { nav.routes.size }
                LaunchedEffect(pager.settledPage) {
                    if (pager.settledPage != nav.selected && pager.settledPage in nav.routes.indices) NavSession.select(pager.settledPage)
                }
                LaunchedEffect(nav.selected, nav.routes.size) {
                    if (nav.selected in nav.routes.indices && pager.currentPage != nav.selected) pager.animateScrollToPage(nav.selected)
                }
                HorizontalPager(
                    state = pager,
                    pageSpacing = 10.dp,
                    verticalAlignment = Alignment.Top,
                    modifier = Modifier.fillMaxWidth(),
                ) { i ->
                    val rt = nav.routes.getOrNull(i) ?: return@HorizontalPager
                    Box {
                        RouteRow(rt, selected = true, deltaS = rt.durationS - fastest) { NavSession.select(i) }
                        if (nav.routes.size > 1) {
                            Row(
                                Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                nav.routes.indices.forEach { j ->
                                    Box(
                                        Modifier.size(if (j == i) 8.dp else 6.dp).clip(CircleShape)
                                            .background(if (j == i) pal.blue else pal.sub.copy(alpha = 0.4f)),
                                    )
                                }
                            }
                        }
                    }
                }
            }
            if (nav.routes.size == 1 && !nav.loading && nav.vias.isEmpty()) {
                Text("Keine weiteren Alternativen gefunden", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
            r?.let { RouteDetails(it, nav.availability) }
            if (r != null && settings.hasTomTom) {
                Spacer(Modifier.height(8.dp))
                Text("Am Ziel", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                r.arrivalSoc?.let { Text("Ankunft mit ca. ${fmtPct(it)} Akku", color = pal.sub, fontSize = 13.sp) }
                DestInfoList(
                    nav, null,
                    onPlace = { p -> vm.openCard(p) },
                    onCharger = { h -> MapChargers.show(h) },
                    me = null,
                )
            }
            val off by OfflineMaps.state.collectAsState()
            if (r != null) {
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when {
                            off.running -> "Offline-Karte: ${off.percent} %"
                            off.done -> "Offline-Karte gespeichert"
                            else -> "Offline-Karte: nicht gespeichert"
                        },
                        color = pal.sub, fontSize = 13.sp, modifier = Modifier.weight(1f),
                    )
                    if (!off.running && !off.done) TextButton(onClick = { NavSession.saveOffline() }) { Text("Jetzt speichern") }
                }
            }
            // Wünsche (Pausen, Anbieter) entfernt – die Ladeplanung wählt selbst
            if (r != null) {
                Spacer(Modifier.height(8.dp))
                nav.planNote?.let { Text(it, color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                TextButton(onClick = { vm.openSaveDialog() }) {
                    Icon(Icons.Filled.BookmarkAdd, null, tint = pal.blue)
                    Spacer(Modifier.width(6.dp))
                    Text("Route speichern", color = pal.blue, fontWeight = FontWeight.SemiBold)
                }
                TextButton(onClick = { NavSession.recheck() }) {
                    Icon(Icons.Filled.Refresh, null, tint = pal.blue)
                    Spacer(Modifier.width(6.dp))
                    Text("Planung prüfen", color = pal.blue, fontWeight = FontWeight.SemiBold)
                }
            }
            if (r != null && settings.hasTomTom) {
                TextButton(onClick = { NavSession.openChargerSearch() }) {
                    Icon(Icons.Filled.EvStation, null, tint = pal.green)
                    Spacer(Modifier.width(6.dp))
                    Text("Ladestation selbst wählen", color = pal.green, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** Ein Eintrag der Stopp-Liste */
private data class StopEntry(val kind: Int, val place: Place, val via: Via?) // 0 Start, 1 Zwischenstopp, 2 Ziel

/** Start, Zwischenstopps und Ziel – alle per langem Drücken auf ≡ verschiebbar */
@Composable
private fun StopsList(nav: NavSession.State, vm: MainViewModel) {
    val pal = LocalPal.current
    val dest = nav.dest ?: return
    Text("Stopps", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)

    // „Mein Standort“ steht immer oben fest; ein eigener Start ist verschiebbar
    if (nav.start == null) {
        Row(
            Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(12.dp)).clickable { vm.startSearch(SearchMode.START) },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) { Text("●", color = pal.blue, fontSize = 14.sp) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Mein Standort", color = pal.text, fontSize = 15.sp)
                Text("Start ändern", color = pal.blue, fontSize = 12.sp)
            }
        }
    }
    val entries = buildList {
        nav.start?.let { add(StopEntry(0, it, null)) }
        nav.vias.forEach { add(StopEntry(1, it.place, it)) }
        add(StopEntry(2, dest, null))
    }
    var dragFrom by remember { mutableIntStateOf(-1) }
    var dragDy by remember { mutableFloatStateOf(0f) }
    val rowH = with(androidx.compose.ui.platform.LocalDensity.current) { 58.dp.toPx() }
    val count = entries.size
    fun targetIdx(): Int = if (dragFrom < 0) -1 else (dragFrom + (dragDy / rowH).roundToInt()).coerceIn(0, count - 1)
    fun drop(from: Int, to: Int) {
        val list = entries.toMutableList()
        val e = list.removeAt(from)
        list.add(to, e)
        val hasStart = nav.start != null
        val newStart = if (hasStart) list.first().place else null
        val newDest = list.last().place
        val middle = list.subList(if (hasStart) 1 else 0, list.size - 1).map { it.via ?: Via(it.place) }
        NavSession.reorder(newStart, middle, newDest)
    }
    var viaNo = 0
    entries.forEachIndexed { i, e ->
        val target = targetIdx()
        val shift = when {
            dragFrom < 0 || i == dragFrom -> 0f
            dragFrom < target && i in (dragFrom + 1)..target -> -rowH
            dragFrom > target && i in target until dragFrom -> rowH
            else -> 0f
        }
        val animShift by androidx.compose.animation.core.animateFloatAsState(shift, label = "stopShift")
        val dragging = i == dragFrom
        // Rolle nach der (vorläufigen) neuen Position: oben Start, unten Ziel
        val isFirst = nav.start != null && i == 0
        val isLast = i == count - 1
        if (e.kind == 1) viaNo++
        Row(
            Modifier.fillMaxWidth().height(58.dp)
                .zIndex(if (dragging) 1f else 0f)
                .graphicsLayer {
                    translationY = if (dragging) dragDy else animShift
                    if (dragging) { shadowElevation = 16f; scaleX = 1.02f; scaleY = 1.02f; shape = RoundedCornerShape(14.dp); clip = true }
                }
                .background(if (dragging) pal.card else Color.Transparent, RoundedCornerShape(14.dp))
                .padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val v = e.via
            when {
                isFirst -> Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) { Text("●", color = pal.blue, fontSize = 14.sp) }
                isLast -> Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) { Text("◆", color = pal.red, fontSize = 14.sp) }
                else -> Box(
                    Modifier.size(24.dp).clip(CircleShape).background(if (v?.isCharger == true) pal.green else pal.blue),
                    contentAlignment = Alignment.Center,
                ) {
            if (v?.isCharger == true) Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(14.dp))
            else Text("$viaNo", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(e.place.title, color = pal.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                when {
                    isFirst -> Text("Eigener Start", color = pal.sub, fontSize = 12.sp)
                    isLast -> Text("Ziel", color = pal.sub, fontSize = 12.sp)
                    v?.isCharger == true -> Text("Fester Ladestopp · ${(v?.powerKw ?: 0.0).roundToInt()} kW", color = pal.green, fontSize = 13.sp)
                    v != null -> {
                        val idx = nav.vias.indexOf(v)
                        Text(
                            if (v.pauseMin > 0) "Pause ${v.pauseMin} min" else "Pause hinzufügen",
                            color = pal.blue, fontSize = 13.sp,
                            modifier = Modifier.clickable { if (idx >= 0) NavSession.cyclePause(idx) },
                        )
                    }
                    else -> Text("Zwischenstopp", color = pal.sub, fontSize = 12.sp)
                }
            }
            when (e.kind) {
                0 -> SmallIcon(Icons.Filled.Close) { NavSession.setStart(null) }
                1 -> SmallIcon(Icons.Filled.Close) { val idx = nav.vias.indexOf(e.via); if (idx >= 0) NavSession.removeVia(idx) }
            }
            if (count > 1) {
                Box(
                    Modifier.size(44.dp).pointerInput(i, count, e) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { dragFrom = i; dragDy = 0f },
                            onDrag = { change, d -> change.consume(); dragDy += d.y },
                            onDragEnd = {
                                val to = targetIdx()
                                val from = dragFrom
                                dragFrom = -1; dragDy = 0f
                                if (from >= 0 && to >= 0 && to != from) drop(from, to)
                            },
                            onDragCancel = { dragFrom = -1; dragDy = 0f },
                        )
                    },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.DragHandle, "Zum Verschieben lange drücken und ziehen", tint = pal.sub) }
            }
        }
    }
    if (count > 1) {
        Text(
            "≡ lange drücken und ziehen: Reihenfolge ändern. Ganz unten ist das Ziel" + if (nav.start != null) ", ganz oben der Start." else ".",
            color = pal.sub, fontSize = 12.sp,
        )
    }
    TextButton(onClick = { vm.startSearch(SearchMode.VIA) }) {
        Icon(Icons.Filled.Add, null, tint = pal.blue)
        Spacer(Modifier.width(4.dp))
        Text("Stopp hinzufügen", color = pal.blue, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SmallIcon(icon: ImageVector, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = pal.sub, modifier = Modifier.size(20.dp))
    }
}

// ---------------- Ladestationen entlang der Route ----------------

@Composable
fun ChargerSheet(nav: NavSession.State, settings: AppSettings, screenH: Dp) {
    val pal = LocalPal.current
    val cs = nav.chargerSearch ?: return
    val r = nav.route
    val here = if (nav.navigating) nav.progress?.alongM ?: 0.0 else 0.0
    var q by remember(cs.replaceUuid) { mutableStateOf(cs.query) }
    val focus = androidx.compose.ui.platform.LocalFocusManager.current
    GlassCard(Modifier.fillMaxWidth().height(screenH * 0.52f), corner = 26.dp) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (cs.replaceUuid != null) "Alternativen" + if (cs.focusName.isNotBlank()) " zu ${cs.focusName}" else "" else "Ladestationen entlang der Route",
                        color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        when {
                            cs.query.isNotBlank() -> "Suche „${cs.query}“ · ${cs.hits.size} gefunden"
                            cs.replaceUuid != null -> "Nächste zuerst · ${cs.hits.size} gefunden"
                            else -> (if (nav.navigating) "Nächste 250 km" else "Ganze Route") + " · ${cs.hits.size} gefunden"
                        },
                        color = pal.sub, fontSize = 13.sp,
                    )
                }
                CloseDot { NavSession.closeChargerSearch() }
            }
            Spacer(Modifier.height(8.dp))
            // eigene Suche
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f)) {
                    if (q.isEmpty()) Text("Ladestation suchen, z. B. IONITY Lüneburg", color = pal.sub, fontSize = 15.sp)
                    androidx.compose.foundation.text.BasicTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = pal.text, fontSize = 15.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(pal.blue),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                        keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { focus.clearFocus(); NavSession.searchChargerText(q) }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (q.isNotEmpty()) {
                    Text(
                        "Suchen", color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { focus.clearFocus(); NavSession.searchChargerText(q) }.padding(start = 8.dp),
                    )
                }
            }
            if (cs.query.isBlank()) {
                Spacer(Modifier.height(8.dp))
                Segmented(listOf("ab 50 kW", "ab 100 kW", "ab 150 kW"), listOf(50, 100, 150).indexOf(settings.searchMinKw).coerceAtLeast(0)) { i ->
                    Settings.update { it.copy(searchMinKw = listOf(50, 100, 150)[i]) }
                    NavSession.openChargerSearch(cs.replaceUuid)
                }
                Spacer(Modifier.height(6.dp))
                Segmented(listOf("bis 5 km abseits", "bis 10 km", "bis 15 km"), listOf(5, 10, 15).indexOf(settings.corridorKm).coerceAtLeast(1)) { i ->
                    Settings.update { it.copy(corridorKm = listOf(5, 10, 15)[i]) }
                    NavSession.openChargerSearch(cs.replaceUuid)
                }
            }
            Spacer(Modifier.height(6.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
            if (cs.loading) {
                Row(Modifier.padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), color = pal.blue, strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Suche Ladestationen …", color = pal.sub)
                }
            }
            cs.error?.let { Text(it, color = pal.red, modifier = Modifier.padding(vertical = 8.dp)) }
            if (!cs.loading && cs.error == null && cs.hits.isEmpty()) {
                Text("Keine passenden Ladestationen gefunden.", color = pal.sub, modifier = Modifier.padding(vertical = 8.dp))
            }
            cs.hits.forEach { h ->
                val soc = r?.takeIf { h.offsetM < 15_000 }?.socAt(h.alongM)
                val a = h.availId?.let { nav.hitAvailability[it] }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(14.dp))
                        .background(pal.field.copy(alpha = 0.6f))
                        .clickable { MapChargers.show(h) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(30.dp).clip(CircleShape).background(Color(operatorColor(h.operator.ifBlank { h.name }))),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(chargerTitle(h), color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val op = if (h.operator.isNotBlank()) "${h.operator} · " else ""
                        val where = when {
                            h.stopAlongRef != null -> {
                                val d = h.alongM - h.stopAlongRef
                                if (kotlin.math.abs(d) < 1000) "beim bisherigen Stopp" else "${fmtKm(kotlin.math.abs(d))} ${if (d < 0) "vorher" else "später"}"
                            }
                            h.offsetM > 15_000 -> "abseits der Route"
                            else -> "in ${fmtKm(h.alongM - here)}"
                        }
                        Text("$op${h.powerKw.roundToInt()} kW · $where", color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Row {
                            if (h.offsetM in 400.0..15_000.0) Text("${fmtKm(h.offsetM)} abseits", color = pal.sub, fontSize = 12.sp)
                            if (soc != null) {
                                Text(
                                    (if (h.offsetM in 400.0..15_000.0) "  ·  " else "") + if (soc < 0) "nicht erreichbar" else "Ankunft ca. ${fmtPct(soc)}",
                                    color = if (soc < settings.minSocStop) pal.red else pal.text, fontSize = 12.sp,
                                )
                            }
                            if (a != null && a.known) {
                                Text("  ·  ${a.available}/${a.total} frei", color = if (a.available > 0) pal.green else pal.red, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    Text("›", color = pal.sub, fontSize = 22.sp)
                }
            }
        }
    }
}

// ---------------- Einstellungen: Ladeanbieter ----------------

@Composable
fun OperatorSettings(s: AppSettings) {
    val pal = LocalPal.current
    val seen by KnownOperators.items.collectAsState()
    var custom by remember { mutableStateOf("") }
    val all = (KnownOperators.PRESET + seen.sorted() + s.preferOperators + s.avoidOperators).distinctBy { it.lowercase() }

    Label("Betreiber der Ladesäulen")
    Text("Antippen wechselt: neutral → bevorzugt → meiden", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
    all.forEach { name ->
        val state = when (name) {
            in s.preferOperators -> 1
            in s.avoidOperators -> 2
            else -> 0
        }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                Settings.update {
                    when (state) {
                        0 -> it.copy(preferOperators = it.preferOperators + name)
                        1 -> it.copy(preferOperators = it.preferOperators - name, avoidOperators = it.avoidOperators + name)
                        else -> it.copy(avoidOperators = it.avoidOperators - name)
                    }
                }
            }.padding(vertical = 8.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(name, color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            val (label, color) = when (state) {
                1 -> "bevorzugt" to pal.green
                2 -> "meiden" to pal.red
                else -> "–" to pal.sub
            }
            Text(
                label, color = if (state == 0) pal.sub else Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (state == 0) Color.Transparent else color)
                    .border(1.dp, color, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
        OutlinedTextField(
            value = custom, onValueChange = { custom = it }, singleLine = true,
            label = { Text("Weiterer Betreiber") }, modifier = Modifier.weight(1f),
        )
        TextButton(onClick = {
            val n = custom.trim()
            if (n.isNotEmpty()) Settings.update { it.copy(preferOperators = it.preferOperators + n) }
            custom = ""
        }) { Text("Bevorzugen") }
    }

    Spacer(Modifier.height(16.dp))
    Label("Meine Ladekarten und Apps")
    Text("Säulen, an denen diese Karten funktionieren, werden bevorzugt.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
    (KnownOperators.MSPS + s.preferredMsps).distinct().forEach { m ->
        ToggleRow(m, m in s.preferredMsps) { on ->
            Settings.update { if (on) it.copy(preferredMsps = it.preferredMsps + m) else it.copy(preferredMsps = it.preferredMsps - m) }
        }
    }
    Text(
        "Hinweis: TomTom erkennt Namen nur, wenn sie wie in seinen Daten geschrieben sind. Betreiber aus deinen Routen erscheinen automatisch in der Liste.",
        color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
    )
}

// ---------------- Wünsche für die Planung ----------------

private val COMMON_OPERATORS = listOf("Tesla", "EnBW", "IONITY", "Fastned", "Aral pulse", "Shell Recharge", "EWE Go", "Allego", "Electra", "E.ON", "Atlante", "Pfalzwerke")
private val BREAK_SUGGESTIONS = listOf("Burger King", "McDonald's", "IKEA", "Raststätte", "Autohof", "Restaurant", "Bäckerei", "Starbucks")

@Composable
fun WishesSection(nav: NavSession.State) {
    val pal = LocalPal.current
    val w = nav.wishes
    var opDialog by remember { mutableStateOf(false) }
    var breakDialog by remember { mutableStateOf(false) }
    Spacer(Modifier.height(10.dp))
    Text("Wünsche", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
        WishChip(
            "⚡ " + when {
                w.onlyOperators.isNotEmpty() -> "Nur " + w.onlyOperators.joinToString(", ")
                w.avoidOperators.isNotEmpty() -> "Ohne " + w.avoidOperators.joinToString(", ")
                else -> "Alle Anbieter"
            },
            w.onlyOperators.isNotEmpty() || w.avoidOperators.isNotEmpty(),
        ) { opDialog = true }
        WishChip(
            "☕ " + if (w.breakAtMin != null && w.breakQuery.isNotBlank()) "%02d:%02d · %s".format(w.breakAtMin / 60, w.breakAtMin % 60, w.breakQuery) else "Keine Pause",
            w.breakAtMin != null,
        ) { breakDialog = true }
    }
    if (opDialog) OperatorWishDialog(w, onDone = { opDialog = false })
    if (breakDialog) BreakWishDialog(w, onDone = { breakDialog = false })
}

@Composable
private fun WishChip(text: String, active: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    Text(
        text, color = if (active) Color.White else pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
        modifier = Modifier.widthIn(max = 220.dp).clip(RoundedCornerShape(16.dp)).background(if (active) pal.blue else pal.field)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

@Composable
private fun OperatorWishDialog(w: TripWishes, onDone: () -> Unit) {
    val pal = LocalPal.current
    val known by KnownOperators.items.collectAsState()
    val all = (COMMON_OPERATORS + known.filter { k -> COMMON_OPERATORS.none { it.equals(k, true) } }).distinct().take(30)
    var only by remember { mutableStateOf(w.onlyOperators) }
    var avoid by remember { mutableStateOf(w.avoidOperators) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDone,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Ladeanbieter", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                Text("Antippen wechselt: – → nur → meiden", color = pal.sub, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                all.forEach { op ->
                    val state = when { op in only -> 1; op in avoid -> 2; else -> 0 }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                            when (state) {
                                0 -> { only = only + op; avoid = avoid - op }
                                1 -> { only = only - op; avoid = avoid + op }
                                else -> { avoid = avoid - op }
                            }
                        }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(24.dp).clip(CircleShape).background(Color(operatorColor(op))), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(12.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(op, color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        Text(
                            when (state) { 1 -> "nur"; 2 -> "meiden"; else -> "–" },
                            color = when (state) { 1 -> pal.green; 2 -> pal.red; else -> pal.sub }, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { NavSession.setWishes(w.copy(onlyOperators = only, avoidOperators = avoid)); onDone() }) { Text("Übernehmen", fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDone) { Text("Abbrechen") } },
    )
}

@Composable
private fun BreakWishDialog(w: TripWishes, onDone: () -> Unit) {
    val pal = LocalPal.current
    var at by remember { mutableIntStateOf(w.breakAtMin ?: 12 * 60) }
    var q by remember { mutableStateOf(w.breakQuery.ifBlank { "Burger King" }) }
    var dur by remember { mutableIntStateOf(w.breakMin) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDone,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Pause einplanen", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Uhrzeit", color = pal.sub, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StepBtn("−") { at = (at - 15).coerceAtLeast(5 * 60) }
                    Text("%02d:%02d".format(at / 60, at % 60), color = pal.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 14.dp))
                    StepBtn("+") { at = (at + 15).coerceAtMost(23 * 60) }
                }
                Spacer(Modifier.height(10.dp))
                Text("Wo?", color = pal.sub, fontSize = 13.sp)
                androidx.compose.material3.OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, shape = RoundedCornerShape(16.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BREAK_SUGGESTIONS.forEach { sug ->
                        Text(
                            sug, color = pal.text, fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(pal.field).clickable { q = sug }.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Dauer", color = pal.sub, fontSize = 13.sp)
                Segmented(listOf("15", "30", "45", "60 min"), listOf(15, 30, 45, 60).indexOf(dur).coerceAtLeast(1)) { i -> dur = listOf(15, 30, 45, 60)[i] }
            }
        },
        confirmButton = { TextButton(onClick = { NavSession.setWishes(w.copy(breakAtMin = at, breakQuery = q.trim(), breakMin = dur)); onDone() }) { Text("Übernehmen", fontWeight = FontWeight.Bold) } },
        dismissButton = {
            TextButton(onClick = { NavSession.setWishes(w.copy(breakAtMin = null, breakQuery = "")); onDone() }) { Text(if (w.breakAtMin != null) "Pause entfernen" else "Abbrechen") }
        },
    )
}

@Composable
private fun StepBtn(t: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(Modifier.size(40.dp).clip(CircleShape).background(pal.field).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(t, color = pal.blue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}
