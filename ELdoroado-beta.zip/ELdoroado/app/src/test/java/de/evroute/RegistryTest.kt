package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RegistryTest {
    @Test
    fun betreiberKurz() {
        assertEquals("EnBW", ChargerRegistry.shortOperator("EnBW mobility+ AG und Co.KG "))
        assertEquals("DEW21", ChargerRegistry.shortOperator("Dortmunder Energie- und Wasserversorgung GmbH"))
        assertEquals("Muster Energie", ChargerRegistry.shortOperator("Muster Energie GmbH & Co. KG"))
    }

    @Test
    fun deutschlandGrenzen() {
        assertTrue(Chargers.inGermany(LatLon(51.40, 7.43))) // Herdecke
        assertFalse(Chargers.inGermany(LatLon(52.37, 4.90))) // Amsterdam
    }
}
