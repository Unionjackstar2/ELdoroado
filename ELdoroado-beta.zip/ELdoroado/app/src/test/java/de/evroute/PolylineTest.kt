package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Test

class PolylineTest {
    @Test
    fun polylineDekodieren() {
        val p = Routing.decodePolyline("_p~iF~ps|U_ulLnnqC_mqNvxq`@", 5)
        assertEquals(3, p.size)
        assertEquals(38.5, p[0].lat, 1e-6)
        assertEquals(-120.2, p[0].lon, 1e-6)
        assertEquals(43.252, p[2].lat, 1e-6)
        assertEquals(-126.453, p[2].lon, 1e-6)
    }

    @Test
    fun valhallaVersionVertraeglich() {
        assertEquals(true, ValhallaTiles.compatible(ValhallaTiles.Remote("2026_Q4", "", "3.6.3", "x.tar", null)))
        assertEquals(true, ValhallaTiles.compatible(ValhallaTiles.Remote("2026_Q4", "", "3.5.1", "x.tar", null)))
        assertEquals(false, ValhallaTiles.compatible(ValhallaTiles.Remote("2026_Q4", "", "3.9.1", "x.tar", null)))
    }
}
