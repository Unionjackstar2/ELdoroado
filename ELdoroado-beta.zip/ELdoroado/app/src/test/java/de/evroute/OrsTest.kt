package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OrsTest {
    private val feature = """
    {"type":"Feature","geometry":{"type":"LineString","coordinates":[
      [7.400,51.400,100.0],[7.400,51.402,102.0],[7.400,51.404,104.0],[7.402,51.404,104.0],[7.404,51.404,103.0]]},
     "properties":{"segments":[{"distance":500.0,"duration":60.0,"steps":[
       {"distance":440.0,"duration":40.0,"type":11,"instruction":"Losfahren","name":"Hauptstraße","way_points":[0,2]},
       {"distance":280.0,"duration":20.0,"type":1,"instruction":"Rechts abbiegen","name":"Wittener Straße, B 226","way_points":[2,4],
        "maneuver":{"bearing_before":0,"bearing_after":90,"location":[7.4,51.404]}},
       {"distance":0.0,"duration":0.0,"type":10,"instruction":"Ziel","name":"-","way_points":[4,4]}]}],
      "summary":{"distance":720.0,"duration":60.0},"ascent":4.0,"descent":1.0}}
    """.trimIndent()

    @Test
    fun featureWirdUebersetzt() {
        val r = Ors.parseForTest(feature)
        assertNotNull(r)
        r!!
        assertEquals("ORS", r.source)
        assertEquals(3, r.steps.size)
        assertEquals("depart", r.steps[0].type)
        assertEquals("turn", r.steps[1].type)
        assertEquals("right", r.steps[1].mod)
        assertEquals("arrive", r.steps[2].type)
        assertTrue(r.steps[1].road.startsWith("B 226"))
        assertTrue(r.stepAlongM[1] > 400 && r.stepAlongM[1] < 460)
        assertEquals(5, r.elevations?.size)
    }
}
