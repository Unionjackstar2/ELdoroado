package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HomeTest {
    @Test
    fun morgensZuhauseZurArbeit() {
        assertEquals(FavKind.WORK, HomeSuggest.pick(homeM = 50.0, workM = 20_000.0, hour = 7, weekday = true))
    }

    @Test
    fun amWochenendeZuhauseKeinVorschlag() {
        assertNull(HomeSuggest.pick(homeM = 50.0, workM = 20_000.0, hour = 7, weekday = false))
    }

    @Test
    fun nachmittagsAufDerArbeitNachHause() {
        assertEquals(FavKind.HOME, HomeSuggest.pick(homeM = 20_000.0, workM = 100.0, hour = 16, weekday = true))
    }

    @Test
    fun abendsUnterwegsNachHause() {
        assertEquals(FavKind.HOME, HomeSuggest.pick(homeM = 8_000.0, workM = 30_000.0, hour = 19, weekday = false))
    }

    @Test
    fun ohneFavoritenKeinVorschlag() {
        assertNull(HomeSuggest.pick(homeM = null, workM = null, hour = 19, weekday = true))
    }

    @Test
    fun begruessung() {
        assertEquals("Guten Morgen", HomeSuggest.greeting(7))
        assertEquals("Guten Abend", HomeSuggest.greeting(21))
        assertEquals("Gute Nacht", HomeSuggest.greeting(2))
    }
}
