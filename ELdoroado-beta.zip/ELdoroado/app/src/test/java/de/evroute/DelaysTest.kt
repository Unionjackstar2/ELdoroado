package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Test

class DelaysTest {
    @Test
    fun stauVerschiebtNurSpaetereManoever() {
        val pts = (0..10).map { LatLon(51.0 + it * 0.01, 7.0) }
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
        val steps = List(3) { Step("turn", "right", null, "", "", 1000.0, 60.0, "") }
        val r = Route(pts, cum, doubleArrayOf(0.0, cum[3], cum[8]), doubleArrayOf(0.0, 100.0, 400.0), cum.last(), 500.0, 500.0, steps, "")
        val jam = Jam(5, 6, 300.0, 2, "JAM")
        val t = Delays.shift(r, listOf(jam), 1.0)
        assertEquals(100.0, t[1], 0.01) // vor dem Stau unverändert
        assertEquals(700.0, t[2], 0.01) // danach +5 Minuten
        val back = Delays.shift(r.copy(stepTimeS = t), listOf(jam), -1.0)
        assertEquals(400.0, back[2], 0.01)
    }
}
