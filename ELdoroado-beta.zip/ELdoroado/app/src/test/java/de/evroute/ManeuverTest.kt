package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ManeuverTest {
    @Test
    fun autobahnkreuzWirdZumWechsel() {
        val r = ManeuverRefiner.refine("fork", "slight right", "KEEP_RIGHT", "BIFURCATION", 12.0, listOf("A1"), listOf("A45"), "")
        assertEquals("fork", r.type)
        assertTrue(r.phrase!!.contains("auf die A45 wechseln"))
        assertTrue(r.phraseHasRoad)
    }

    @Test
    fun rampeOhneNummerNimmtAutobahnAusWegweiser() {
        val r = ManeuverRefiner.refine("off ramp", "slight right", "MOTORWAY_EXIT_RIGHT", "REGULAR", 20.0, listOf("A1"), emptyList(), "A 45 Frankfurt")
        assertTrue(r.phrase!!.contains("A 45"))
    }

    @Test
    fun abfahrtVonDerAutobahn() {
        val r = ManeuverRefiner.refine("fork", "slight right", "KEEP_RIGHT", "BIFURCATION", 15.0, listOf("A1"), listOf("B54"), "Münster")
        assertEquals("off ramp", r.type)
    }

    @Test
    fun deutlicherWinkelIstAbbiegen() {
        val r = ManeuverRefiner.refine("fork", "slight right", "KEEP_RIGHT", "REGULAR", 80.0, listOf("L675"), listOf("K12"), "")
        assertEquals("turn", r.type)
        assertEquals("right", r.mod)
    }

    @Test
    fun kreisverkehrBleibtUnveraendert() {
        val r = ManeuverRefiner.refine("roundabout", "right", "ROUNDABOUT_RIGHT", "ROUNDABOUT", 90.0, emptyList(), emptyList(), "")
        assertEquals("roundabout", r.type)
    }
}
