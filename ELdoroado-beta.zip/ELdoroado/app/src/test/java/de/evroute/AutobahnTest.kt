package de.evroute

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class AutobahnTest {
    private fun route(): Route {
        val pts = (0..40).map { LatLon(51.0 + it * 0.001, 7.0) } // gerade nach Norden, ~4,4 km
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
        return Route(pts, cum, DoubleArray(0), DoubleArray(0), cum.last(), 300.0, 300.0, emptyList(), "")
    }

    @Test
    fun meldungInFahrtrichtungWirdErkannt() {
        val line = (10..20).map { LatLon(51.0 + it * 0.001, 7.0001) }
        assertNotNull(AutobahnApi.matchForTest(route(), line))
    }

    @Test
    fun gegenrichtungWirdIgnoriert() {
        val line = (20 downTo 10).map { LatLon(51.0 + it * 0.001, 7.0001) }
        assertNull(AutobahnApi.matchForTest(route(), line))
    }

    @Test
    fun ferneMeldungWirdIgnoriert() {
        val line = (10..20).map { LatLon(51.0 + it * 0.001, 7.02) }
        assertNull(AutobahnApi.matchForTest(route(), line))
    }
}
