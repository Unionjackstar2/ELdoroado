package de.evroute

import org.junit.Assert.assertTrue
import org.junit.Test

class LocalChargingTest {
    @Test
    fun energieProfilSteigtMitDerStrecke() {
        val pts = (0..100).map { LatLon(51.0 + it * 0.01, 7.0) } // ~111 km nach Norden
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
        val step = Step("depart", null, null, "A 1", "", cum.last(), 3600.0, "Losfahren")
        val r = Route(pts, cum, doubleArrayOf(0.0), doubleArrayOf(0.0), cum.last(), 3600.0, 3600.0, listOf(step), "")
        val p = LocalCharging.profile(r, AppSettings(useLearned = false), null)
        assertTrue(p.e.last() > 5.0 && p.e.last() < 40.0) // plausibler Verbrauch für ~111 km bei ~110 km/h
        for (i in 1 until p.e.size) assertTrue(p.e[i] >= p.e[i - 1])
        assertTrue(kotlin.math.abs(p.t.last() - 3600.0) < 1.0)
    }
}
