package de.evroute

import org.junit.Assert.assertEquals
import org.junit.Test

class OcmTest {
    // Beispiel aus der Google-Polyline-Dokumentation
    @Test
    fun polylineKodierung() {
        val m = OpenChargeMap::class.java.getDeclaredMethod("encode", List::class.java)
        m.isAccessible = true
        val enc = m.invoke(OpenChargeMap, listOf(LatLon(38.5, -120.2), LatLon(40.7, -120.95), LatLon(43.252, -126.453))) as String
        assertEquals("_p~iF~ps|U_ulLnnqC_mqNvxq`@", enc)
    }
}
