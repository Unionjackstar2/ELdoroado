package de.evroute

import android.content.Context
import android.view.Gravity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.isActive
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.Layer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import kotlin.math.roundToInt
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.cos
import org.maplibre.geojson.Polygon
import org.maplibre.android.style.layers.PropertyFactory.lineTranslate
import org.maplibre.android.style.layers.PropertyFactory.lineBlur
import org.maplibre.android.style.layers.PropertyFactory.lineOpacity
import org.maplibre.android.style.layers.PropertyFactory.fillAntialias
import org.maplibre.android.style.layers.PropertyFactory.fillColor
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap
import org.maplibre.android.style.layers.PropertyFactory.iconAnchor
import org.maplibre.android.style.layers.PropertyFactory.iconSize
import org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement
import org.maplibre.android.style.layers.PropertyFactory.iconImage
import org.maplibre.android.style.layers.PropertyFactory.iconPitchAlignment
import org.maplibre.android.style.layers.PropertyFactory.iconRotate
import org.maplibre.android.style.layers.PropertyFactory.iconRotationAlignment
import org.maplibre.android.style.layers.PropertyFactory.lineCap
import org.maplibre.android.style.layers.PropertyFactory.lineColor
import org.maplibre.android.style.layers.PropertyFactory.lineGradient
import org.maplibre.android.style.layers.PropertyFactory.lineJoin
import org.maplibre.android.style.layers.PropertyFactory.lineWidth
import org.maplibre.android.style.layers.PropertyFactory.rasterOpacity
import org.maplibre.android.style.layers.RasterLayer
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonOptions
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.android.style.sources.TileSet
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point

internal const val DAY_STYLE = "https://tiles.openfreemap.org/styles/bright"
internal const val POSITRON_STYLE = "https://tiles.openfreemap.org/styles/positron"
internal const val NIGHT_STYLE = "https://tiles.openfreemap.org/styles/dark"
internal const val FIORD_STYLE = "https://tiles.openfreemap.org/styles/fiord"

/** Kartenstil je nach Einstellung und Tag/Nacht */
internal fun styleUrl(dark: Boolean): String {
    val s = Settings.state.value
    return when {
        dark && s.nightStyle == 0 -> FIORD_STYLE
        dark -> NIGHT_STYLE
        s.mapStyle == 1 -> POSITRON_STYLE
        else -> DAY_STYLE
    }
}

/** Kartenstil für die Offline-Kopie entlang der Route */
internal fun offlineStyleUrl(dark: Boolean): String {
    val s = Settings.state.value
    return when {
        dark && s.nightStyle == 0 -> FIORD_STYLE
        dark -> NIGHT_STYLE
        s.mapStyle == 1 -> POSITRON_STYLE
        else -> DAY_STYLE
    }
}

/**
 * Breite der Routenlinie: schmal in der Übersicht, sanft wachsend beim Heranzoomen.
 * extra = zusätzliche Breite (für Ränder), factor = schmaler/breiter (z. B. Alternativen)
 */
internal fun routeWidth(extra: Float = 0f, factor: Float = 1f): Expression = Expression.interpolate(
    Expression.exponential(1.3f), Expression.zoom(),
    Expression.stop(5, 3.0f * factor + extra),
    Expression.stop(10, 4.6f * factor + extra),
    Expression.stop(13, 6.2f * factor + extra),
    Expression.stop(15, 7.8f * factor + extra),
    Expression.stop(17, 10f * factor + extra),
    Expression.stop(19, 14f * factor + extra),
)

/** Farben der Fahrtlinie (Tag/Nacht) */
internal class LineColors(dark: Boolean) {
    val route = if (dark) 0xFF2E8BFF.toInt() else 0xFF0A84FF.toInt()
    val casing = if (dark) 0xFF0A3A80.toInt() else 0xFF1667C8.toInt()
    val done = if (dark) 0xFF5A5F69.toInt() else 0xFFA3AAB5.toInt()
    val alt = if (dark) 0xFF3C5F8F.toInt() else 0xFFA9CBF5.toInt()
    val altCasing = if (dark) 0xFF27405F.toInt() else 0xFF7DA6DB.toInt()
}

/**
 * Fahrzeugposition vorausberechnen: aus der letzten GPS-Messung, dem Tempo und der seither vergangenen Zeit
 * (inkl. Alter der Messung) wird geschätzt, wo das Auto *jetzt* ist – in der Navigation entlang der Route.
 * Die Anzeige folgt dieser Schätzung mit einer sehr kurzen Glättung (~0,12 s), damit nichts springt.
 */
internal class Predictor {
    var route: Route? = null
    var onRoute = false
    var fixPos = LatLon(0.0, 0.0)
    var fixBearing = 0.0
    var speed = 0.0
    var fixNs = 0L
    var fixAlong = 0.0
    var ready = false
        private set
    private var shown: LatLon? = null
    private var shownBearing = 0.0
    private var lastFrameNs = 0L

    fun set(pos: LatLon, bearingDeg: Double, speedMs: Double, ns: Long, r: Route?, along: Double?, routeMode: Boolean) {
        fixPos = pos
        fixBearing = bearingDeg
        speed = speedMs
        fixNs = if (ns > 0) ns else android.os.SystemClock.elapsedRealtimeNanos()
        route = r
        onRoute = routeMode && r != null && along != null
        fixAlong = along ?: 0.0
        ready = true
    }

    private fun target(now: Long): Pair<LatLon, Double> {
        val r = route
        // auf der Route bis 45 s weiterrechnen (Tunnel), sonst höchstens 1,5 s
        val dt = ((now - fixNs) / 1e9).coerceIn(0.0, if (onRoute) 45.0 else 1.5)
        val moving = speed > 1.0
        if (onRoute && r != null) {
            val end = r.cumM.lastOrNull() ?: 0.0
            val a = (fixAlong + (if (moving) speed * dt else 0.0)).coerceIn(0.0, end)
            val pos = pointAt(r, a)
            val brg = if (moving) bearing(pointAt(r, a - 8.0), pointAt(r, a + 12.0)) else fixBearing
            return pos to brg
        }
        if (!moving) return fixPos to fixBearing
        val d = speed * dt
        val rad = Math.toRadians(fixBearing)
        val lat = fixPos.lat + kotlin.math.cos(rad) * d / 110540.0
        val lon = fixPos.lon + kotlin.math.sin(rad) * d / (111320.0 * kotlin.math.cos(Math.toRadians(fixPos.lat)))
        return LatLon(lat, lon) to fixBearing
    }

    /** Position und Richtung für dieses Bild; false = keine sichtbare Änderung */
    fun frame(now: Long): Triple<LatLon, Double, Boolean> {
        val (t, tb) = target(now)
        val cur = shown
        val dtF = if (lastFrameNs == 0L) 1.0 else ((now - lastFrameNs) / 1e9).coerceIn(0.0, 1.0)
        lastFrameNs = now
        if (cur == null || haversine(cur, t) > 150.0) {
            shown = t; shownBearing = tb
            return Triple(t, tb, true)
        }
        val a = 1.0 - kotlin.math.exp(-dtF / 0.12)
        val ab = 1.0 - kotlin.math.exp(-dtF / 0.25)
        val next = lerp(cur, t, a)
        val diff = ((tb - shownBearing + 540.0) % 360.0) - 180.0
        val nb = (shownBearing + diff * ab + 360.0) % 360.0
        val changed = haversine(cur, next) > 0.05 || kotlin.math.abs(diff) > 0.3
        shown = next
        shownBearing = nb
        return Triple(next, nb, changed)
    }

    val bearingNow: Double get() = shownBearing
}

/** Punkt auf der Route bei Strecke m (Meter ab Start) */
internal fun pointAt(r: Route, m: Double): LatLon {
    val pts = r.points
    val cum = r.cumM
    if (pts.isEmpty()) return LatLon(0.0, 0.0)
    var i = cum.binarySearch(m)
    if (i >= 0) return pts[i]
    i = -i - 1
    if (i <= 0) return pts.first()
    if (i >= pts.size) return pts.last()
    val span = cum[i] - cum[i - 1]
    return if (span <= 0) pts[i] else lerp(pts[i - 1], pts[i], (m - cum[i - 1]) / span)
}

internal fun progressGradient(frac: Double, c: LineColors): Expression = Expression.step(
    Expression.lineProgress(),
    Expression.color(c.done),
    Expression.stop(frac.coerceIn(0.0, 1.0), Expression.color(c.route)),
)

internal fun lineFeature(r: Route): Feature =
    Feature.fromGeometry(LineString.fromLngLats(r.points.map { Point.fromLngLat(it.lon, it.lat) }))

internal fun emptyFc(): FeatureCollection = FeatureCollection.fromFeatures(emptyList<Feature>())

internal fun iconId(v: VehicleIcon) = when (v) {
    VehicleIcon.ARROW -> "veh-arrow"
    VehicleIcon.CAR -> "veh-car"
    VehicleIcon.DOT -> "veh-dot"
    else -> "veh3d-0"
}

/** Ortsnamen auf Deutsch, wo vorhanden (sonst lateinische Schrift bzw. Originalname) */
internal fun germanLabels(s: Style) {
    s.layers.filterIsInstance<SymbolLayer>().forEach { l ->
        val tf = runCatching { l.textField }.getOrNull() ?: return@forEach
        val desc = (tf.expression?.toString() ?: tf.value?.toString() ?: "")
        if (desc.contains("name")) {
            runCatching {
                l.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.textField(
                        Expression.toString(
                            Expression.coalesce(
                                Expression.get("name:de"), Expression.get("name_de"),
                                Expression.get("name:latin"), Expression.get("name"),
                            ),
                        ),
                    ),
                )
            }
        }
    }
}

internal fun setupStyle(ctx: Context, s: Style, dark: Boolean, carColor: Long) {
    runCatching { germanLabels(s) }
    val c = LineColors(dark)
    s.addImage("veh-arrow", VehicleIcons.arrow(ctx))
    s.addImage("veh-dot", VehicleIcons.dot(ctx))
    s.addImage("veh-cone", VehicleIcons.cone(ctx))
    s.addImage("veh-car", VehicleIcons.car(ctx, carColor.toInt()))
    s.addImage("stop-icon", VehicleIcons.charger(ctx))
    s.addImage("turn-head", VehicleIcons.arrowHead(ctx))
    s.addSource(GeoJsonSource("turn-line", emptyFc()))
    s.addSource(GeoJsonSource("turn-head", emptyFc()))
    s.addSource(GeoJsonSource("alts", emptyFc()))
    s.addSource(GeoJsonSource("jams", emptyFc()))
    s.addSource(GeoJsonSource("stops", emptyFc()))
    s.addSource(GeoJsonSource("map-chargers", emptyFc()))
    s.addSource(GeoJsonSource("pin", emptyFc()))
    Pois.addIcons(ctx, s)
    s.addImage("pin-icon", VehicleIcons.pin(ctx))
    MapChargers.addIcons(ctx, s)
    s.addSource(GeoJsonSource("route", emptyFc(), GeoJsonOptions().withLineMetrics(true)))
    s.addSource(GeoJsonSource("me", emptyFc()))

    // Linien unter die Beschriftungen legen, damit Straßennamen lesbar bleiben
    // Unsere Linien direkt über die oberste Straßen-/Gebäudeebene legen (aber unter die Beschriftungen danach).
    // So liegen sie in jedem Kartenstil über den Straßen – auch wenn ein Stil früh schon Beschriftungen hat.
    var anchor: String? = s.layers.lastOrNull { it !is SymbolLayer }?.id
    fun add(l: Layer) {
        val a = anchor
        if (a != null) s.addLayerAbove(l, a) else s.addLayer(l)
        anchor = l.id
    }

    s.addSource(GeoJsonSource("reach", emptyFc()))
    s.addSource(GeoJsonSource("reach-round", emptyFc()))
    add(
        org.maplibre.android.style.layers.FillLayer("reach-fill", "reach").withProperties(
            org.maplibre.android.style.layers.PropertyFactory.fillColor(if (dark) "#2E8BFF" else "#0A84FF"),
            org.maplibre.android.style.layers.PropertyFactory.fillOpacity(0.14f),
        ),
    )
    add(LineLayer("reach-line", "reach").withProperties(lineColor(if (dark) "#5AA9FF" else "#0A84FF"), lineWidth(2.5f), lineJoin(Property.LINE_JOIN_ROUND)))
    add(
        LineLayer("reach-round-line", "reach-round").withProperties(
            lineColor(if (dark) "#9CCBFF" else "#0057B8"), lineWidth(2.5f), lineJoin(Property.LINE_JOIN_ROUND),
            org.maplibre.android.style.layers.PropertyFactory.lineDasharray(arrayOf(2f, 2f)),
        ),
    )
    add(LineLayer("alt-casing", "alts").withProperties(lineColor(c.altCasing), lineWidth(routeWidth(2.5f, 0.8f)), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
    add(LineLayer("alt-line", "alts").withProperties(lineColor(c.alt), lineWidth(routeWidth(0f, 0.8f)), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
    add(LineLayer("route-casing", "route").withProperties(lineColor(c.casing), lineWidth(routeWidth(2.5f)), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
    add(
        LineLayer("route-line", "route").withProperties(
            lineGradient(progressGradient(0.0, c)), lineWidth(routeWidth()),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND),
        ),
    )
    add(
        LineLayer("jams", "jams").withProperties(
            lineColor(Expression.toColor(Expression.get("c"))), lineWidth(routeWidth()),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND),
        ),
    )
    // Abbiegepfeil auf der Route: eine Fläche (Körper + Spitze), weiß mit blauem Rand und weichem Schatten
    add(
        LineLayer("turn-shadow", "turn-line").withProperties(
            lineColor("#000000"), lineOpacity(0.22f), lineWidth(6f), lineBlur(5f), lineTranslate(arrayOf(0f, 2f)),
            lineJoin(Property.LINE_JOIN_ROUND),
        ),
    )
    add(FillLayer("turn-fill", "turn-line").withProperties(fillColor("#FFFFFF"), fillAntialias(true)))
    add(
        LineLayer("turn-casing", "turn-line").withProperties(
            lineColor("#1A5BD8"), lineWidth(2.2f), lineJoin(Property.LINE_JOIN_ROUND),
        ),
    )
    s.addLayer(
        SymbolLayer("turn-head", "turn-head").withProperties(
            iconImage("turn-head"),
            iconRotate(Expression.get("bearing")),
            iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
            iconAnchor(Property.ICON_ANCHOR_BOTTOM),
            iconAllowOverlap(true),
            iconIgnorePlacement(true),
            iconSize(
                Expression.interpolate(
                    Expression.linear(), Expression.zoom(),
                    Expression.stop(12, 0.5f), Expression.stop(16, 0.9f), Expression.stop(19, 1.4f),
                ),
            ),
        ),
    )
    s.addLayer(
        SymbolLayer("map-chargers", "map-chargers").withProperties(
            iconImage(Expression.get("icon")),
            iconAllowOverlap(true),
            iconIgnorePlacement(true),
            iconSize(
                Expression.interpolate(
                    Expression.linear(), Expression.zoom(),
                    Expression.stop(9, 0.6f), Expression.stop(13, 0.85f), Expression.stop(17, 1.1f),
                ),
            ),
        ),
    )
    s.addLayer(
        SymbolLayer("pin", "pin").withProperties(
            iconImage("pin-icon"),
            iconAnchor(Property.ICON_ANCHOR_BOTTOM),
            iconAllowOverlap(true),
            iconIgnorePlacement(true),
        ),
    )
    s.addLayer(
        SymbolLayer("stops", "stops").withProperties(
            iconImage(Expression.get("img")),
            org.maplibre.android.style.layers.PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
            iconAllowOverlap(true),
            iconIgnorePlacement(true),
        ),
    )
    // Lichtkegel vor dem Fahrzeug (nur nachts in der Navigation sichtbar)
    s.addLayer(
        SymbolLayer("me-cone", "me").withProperties(
            iconImage("veh-cone"),
            iconRotate(Expression.get("bearing")),
            iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
            org.maplibre.android.style.layers.PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
            org.maplibre.android.style.layers.PropertyFactory.iconOpacity(0f),
            iconAllowOverlap(true),
            iconIgnorePlacement(true),
        ),
    )
    s.addLayer(
        SymbolLayer("me", "me").withProperties(
            iconImage("veh-arrow"),
            iconRotate(Expression.get("bearing")),
            iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
            iconAllowOverlap(true),
            iconIgnorePlacement(true),
        ),
    )
}

/** Punkte der Route zwischen Strecke a und b (in Metern ab Start) */
internal fun slice(r: Route, a: Double, b: Double): List<LatLon> {
    val pts = r.points
    val cum = r.cumM
    if (pts.size < 2) return emptyList()
    fun at(m: Double): LatLon = pointAt(r, m)
    val from = a.coerceIn(0.0, cum.last())
    val to = b.coerceIn(0.0, cum.last())
    val out = mutableListOf(at(from))
    for (i in pts.indices) if (cum[i] > from && cum[i] < to) out += pts[i]
    out += at(to)
    return out
}

internal fun autoZoom(kmh: Double, distToStep: Double): Double {
    // stufenlos: langsam = nah, schnell = weiter weg
    val pts = listOf(0.0 to 17.4, 30.0 to 17.0, 50.0 to 16.6, 80.0 to 16.0, 110.0 to 15.4, 140.0 to 14.9)
    val v = kmh.coerceIn(0.0, 140.0)
    val i = pts.indexOfFirst { it.first >= v }.coerceAtLeast(1)
    val (a, za) = pts[i - 1]
    val (b, zb) = pts[i]
    var z = za + (zb - za) * ((v - a) / (b - a))
    // vor einer Abbiegung allmählich näher heran (ab ~480 m, voll bei 80 m)
    if (kmh < 90) z += 0.6 * ((480 - distToStep) / 400).coerceIn(0.0, 1.0)
    return z
}

@Composable
fun EvMap(
    routes: List<Route>,
    selected: Int,
    navigating: Boolean,
    progress: NavProgress?,
    fix: Fix?,
    vehicle: VehicleIcon,
    carColor: Long,
    dark: Boolean,
    follow: Boolean,
    recenterTick: Int,
    pip: Boolean = false, // kleines Bild-im-Bild-Fenster: Draufsicht, etwas weiter herausgezoomt
    topPadPx: Double,
    bottomPadPx: Double,
    sheetPadPx: Int,
    leftPadPx: Double = 0.0, // Querformat: Breite der Seitenleiste links (Karte rechts davon zentrieren)
    onGesture: () -> Unit,
    onTap: (LatLon, Double) -> Unit,
    trafficUrl: String?,
    mapStyleChoice: Int = 0,
    nightStyleChoice: Int = 0,
    onLongPress: (LatLon) -> Unit = {},
    mapChargers: List<ChargerHit> = emptyList(),
    pin: LatLon? = null,
    fitPoints: List<LatLon>? = null,
    reach: Reach.State = Reach.State(),
    overviewPts: List<LatLon>? = null,
    overviewKey: Int = 0,
    poiEnabled: Boolean = false,
    poiCats: Set<String> = emptySet(),
    onPoiTap: (Poi) -> Unit = {},
    onChargerTap: (String) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val mapView = remember { MapView(ctx) }
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    var style by remember { mutableStateOf<Style?>(null) }
    val pred = remember { Predictor() }
    val followNow = rememberUpdatedState(navigating && follow)
    val zoomTarget = remember { doubleArrayOf(16.0) }
    val speedEma = remember { doubleArrayOf(-1.0) }
    val padTop = rememberUpdatedState(topPadPx)
    val padBottom = rememberUpdatedState(bottomPadPx)
    val padLeft = rememberUpdatedState(leftPadPx)
    val pipNow = rememberUpdatedState(pip)
    var centered by remember { mutableStateOf(false) }
    val gestureCb = rememberUpdatedState(onGesture)
    val tapCb = rememberUpdatedState(onTap)
    val longCb = rememberUpdatedState(onLongPress)
    val chargerCb = rememberUpdatedState(onChargerTap)
    val poiCb = rememberUpdatedState(onPoiTap)
    val poiOn = rememberUpdatedState(poiEnabled && poiCats.isNotEmpty())
    val navNow = rememberUpdatedState(navigating)
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_CREATE -> mapView.onCreate(null)
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(Unit) {
        mapView.getMapAsync { m ->
            m.uiSettings.isLogoEnabled = false
            m.uiSettings.isCompassEnabled = true
            m.uiSettings.compassGravity = Gravity.TOP or Gravity.START
            m.uiSettings.setCompassMargins(36, (ctx.resources.displayMetrics.density * 150).toInt(), 0, 0)
            m.uiSettings.attributionGravity = Gravity.TOP or Gravity.START
            m.uiSettings.setAttributionMargins(36, (ctx.resources.displayMetrics.density * 200).toInt(), 0, 0)
            m.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) gestureCb.value()
            }
            m.addOnMapClickListener { ll ->
                // Ladestation auf der Karte angetippt?
                val hit = runCatching {
                    m.queryRenderedFeatures(m.projection.toScreenLocation(ll), "map-chargers").firstOrNull()?.getStringProperty("id")
                }.getOrNull()
                val poiHit = if (hit == null) runCatching {
                    val pt = m.projection.toScreenLocation(ll)
                    val area = android.graphics.RectF(pt.x - 24f, pt.y - 24f, pt.x + 24f, pt.y + 24f)
                    m.queryRenderedFeatures(area, TilePois.LAYER).firstOrNull()?.let { f ->
                        val g = f.geometry() as? Point
                        val sub = f.getStringProperty("subclass") ?: ""
                        val name = listOf("name:de", "name_de", "name").firstNotNullOfOrNull { k ->
                            runCatching { f.getStringProperty(k) }.getOrNull()?.takeIf { it.isNotBlank() }
                        } ?: Nominatim.categoryLabel(TilePois.kindOf(sub))
                        val pos = if (g != null) LatLon(g.latitude(), g.longitude()) else LatLon(ll.latitude, ll.longitude)
                        Poi("", name, TilePois.kindOf(sub), TilePois.catOf(sub) ?: "", pos)
                    }
                }.getOrNull() else null
                if (hit != null) {
                    chargerCb.value(hit)
                    true
                } else if (poiHit != null && poiOn.value) {
                    poiCb.value(poiHit)
                    true
                } else {
                    tapCb.value(LatLon(ll.latitude, ll.longitude), m.projection.getMetersPerPixelAtLatitude(ll.latitude))
                    false
                }
            }
            m.addOnCameraIdleListener {
                val t = m.cameraPosition.target ?: return@addOnCameraIdleListener
                val c = LatLon(t.latitude, t.longitude)
                val corner = m.projection.visibleRegion.farLeft
                val r = if (corner != null) haversine(c, LatLon(corner.latitude, corner.longitude)) else 5000.0
                MapChargers.onCameraIdle(c, r.toInt())
            }
            m.addOnMapLongClickListener { ll ->
                longCb.value(LatLon(ll.latitude, ll.longitude))
                true
            }
            map = m
        }
    }

    // Kartenstil laden (Tag/Nacht), bei Fehler auf den Tagstil zurückfallen
    LaunchedEffect(map, dark, mapStyleChoice, nightStyleChoice) {
        val m = map ?: return@LaunchedEffect
        var fellBack = false
        fun load(url: String) {
            style = null
            m.setStyle(Style.Builder().fromUri(url)) { s ->
                setupStyle(ctx, s, dark, carColor)
                style = s
            }
        }
        val fail = MapView.OnDidFailLoadingMapListener {
            if (!fellBack) { fellBack = true; load(if (dark) NIGHT_STYLE else DAY_STYLE) }
        }
        mapView.addOnDidFailLoadingMapListener(fail)
        load(styleUrl(dark))
        try { awaitCancellation() } finally { mapView.removeOnDidFailLoadingMapListener(fail) }
    }

    // In der Navigation mit Kamera-Folgen liegt das Fahrzeug als festes Bild über der Karte (kein Flackern)
    LaunchedEffect(style, navigating, follow, dark) {
        val s = style ?: return@LaunchedEffect
        s.getLayerAs<SymbolLayer>("me-cone")?.setProperties(
            org.maplibre.android.style.layers.PropertyFactory.iconOpacity(if (navigating && dark && !follow) 1f else 0f),
        )
    }
    LaunchedEffect(style, navigating, follow, routes.isNotEmpty()) {
        val s = style ?: return@LaunchedEffect
        val planningFromHere = !navigating && routes.isNotEmpty() && NavSession.state.value.start == null
        s.getLayerAs<SymbolLayer>("me")?.setProperties(
            org.maplibre.android.style.layers.PropertyFactory.iconOpacity(if ((navigating && follow) || planningFromHere) 0f else 1f),
        )
    }

    // Fahrzeugsymbol und Autofarbe (3D-Fahrzeuge: 72 Ansichten, je nach Richtung)
    val origColor = Settings.state.collectAsState().value.modelOrigColor
    // Ohne Navigation zeigt die Karte immer den Punkt, in der Navigation das gewählte Fahrsymbol
    LaunchedEffect(style, vehicle, carColor, origColor, navigating) {
        val s = style ?: return@LaunchedEffect
        val vehicle = if (navigating) vehicle else VehicleIcon.DOT
        s.addImage("veh-car", VehicleIcons.car(ctx, carColor.toInt()))
        val layer = s.getLayerAs<SymbolLayer>("me") ?: return@LaunchedEffect
        val frames = if (VehicleSprites.isSprite(vehicle)) {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                VehicleSprites.frames(ctx, vehicle, if (origColor) null else carColor.toInt())
            }
        } else {
            null
        }
        if (frames != null) {
            frames.forEachIndexed { i, bmp -> s.addImage("veh3d-$i", bmp) }
            layer.setProperties(
                iconImage(Expression.concat(Expression.literal("veh3d-"), Expression.toString(Expression.get("frame")))),
                org.maplibre.android.style.layers.PropertyFactory.iconRotate(0f),
                org.maplibre.android.style.layers.PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_VIEWPORT),
                org.maplibre.android.style.layers.PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
            )
        } else {
            layer.setProperties(
                iconImage(iconId(vehicle)),
                org.maplibre.android.style.layers.PropertyFactory.iconRotate(Expression.get("bearing")),
                org.maplibre.android.style.layers.PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                org.maplibre.android.style.layers.PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
            )
        }
    }

    // Routen zeichnen
    LaunchedEffect(style, routes, selected, navigating) {
        val s = style ?: return@LaunchedEffect
        applyRoutes(s, routes, selected, navigating, dark)
    }

    // Verkehrslage (TomTom-Kacheln) unter den Routenlinien
    LaunchedEffect(style, trafficUrl) {
        val s = style ?: return@LaunchedEffect
        applyTraffic(s, trafficUrl)
    }

    // Abbiegepfeil am nächsten Manöver (nur in der Navigation)
    // Neu zeichnen bei neuem Manöver und alle ~15 m (sonst erscheint der Pfeil nie, wenn das Manöver anfangs weit weg war)
    val arrowTick = progress?.alongM?.let { (it / 15).toInt() }
    LaunchedEffect(style, routes, selected, navigating, progress?.stepIdx, arrowTick) {
        val s = style ?: return@LaunchedEffect
        applyTurnArrow(s, routes.getOrNull(selected), progress, navigating, map?.cameraPosition?.zoom ?: 16.5)
    }

    // Gewählter Ort (Ortsfenster): Pin setzen und hinfliegen
    LaunchedEffect(style, pin) {
        val s = style ?: return@LaunchedEffect
        s.getSourceAs<GeoJsonSource>("pin")?.setGeoJson(
            pin?.let { FeatureCollection.fromFeature(Feature.fromGeometry(Point.fromLngLat(it.lon, it.lat))) } ?: emptyFc(),
        )
        val m = map ?: return@LaunchedEffect
        val p = pin ?: return@LaunchedEffect
        val cam = CameraPosition.Builder().target(LatLng(p.lat, p.lon)).zoom(15.5).tilt(0.0).bearing(0.0)
            .padding(leftPadPx, 0.0, 0.0, sheetPadPx.toDouble()).build()
        m.easeCamera(CameraUpdateFactory.newCameraPosition(cam), 800)
    }

    // Ersatz-Suche: Karte auf die Alternativen um den Stopp einpassen
    LaunchedEffect(map, fitPoints) {
        val m = map ?: return@LaunchedEffect
        val pts = fitPoints ?: return@LaunchedEffect
        if (pts.size < 2) return@LaunchedEffect
        val b = LatLngBounds.Builder()
        pts.forEach { b.include(LatLng(it.lat, it.lon)) }
        val d = ctx.resources.displayMetrics.density
        m.easeCamera(CameraUpdateFactory.newLatLngBounds(b.build(), (40 * d).toInt() + leftPadPx.toInt(), (90 * d).toInt(), (70 * d).toInt(), sheetPadPx), 800)
    }

    // Orte (POI) aus den Kartenkacheln; die eingebauten, nicht antippbaren POI-Symbole des Stils ausblenden
    LaunchedEffect(style, poiEnabled, poiCats) {
        val s = style ?: return@LaunchedEffect
        runCatching { TilePois.apply(s, poiEnabled, poiCats) }.onFailure { CrashLog.note("POI-Ebene: ${it.message}") }
        s.layers.filterIsInstance<SymbolLayer>()
            .filter { it.id != TilePois.LAYER && runCatching { it.sourceLayer }.getOrNull() == "poi" }
            .forEach {
                it.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(if (poiEnabled) Property.NONE else Property.VISIBLE))
            }
    }

    // Übersicht während der Navigation: Abschnitt flach und nach Norden einpassen
    LaunchedEffect(map, overviewKey) {
        val m = map ?: return@LaunchedEffect
        val pts = overviewPts ?: return@LaunchedEffect
        if (pts.size < 2) return@LaunchedEffect
        val b = LatLngBounds.Builder()
        pts.forEach { b.include(LatLng(it.lat, it.lon)) }
        val d = ctx.resources.displayMetrics.density
        runCatching {
            m.easeCamera(CameraUpdateFactory.newLatLngBounds(b.build(), (90 * d).toInt(), (200 * d).toInt(), (90 * d).toInt(), (200 * d).toInt()), 1200)
        }
    }

    // Reichweiten-Blase zeichnen und beim ersten Anzeigen einpassen
    LaunchedEffect(style, reach.outer, reach.round, reach.active) {
        val s = style ?: return@LaunchedEffect
        fun poly(pts: List<LatLon>) = if (pts.size < 3) emptyFc() else FeatureCollection.fromFeature(
            Feature.fromGeometry(org.maplibre.geojson.Polygon.fromLngLats(listOf((pts + pts.first()).map { Point.fromLngLat(it.lon, it.lat) }))),
        )
        fun line(pts: List<LatLon>) = if (pts.size < 3) emptyFc() else FeatureCollection.fromFeature(
            Feature.fromGeometry(LineString.fromLngLats((pts + pts.first()).map { Point.fromLngLat(it.lon, it.lat) })),
        )
        s.getSourceAs<GeoJsonSource>("reach")?.setGeoJson(if (reach.active) poly(reach.outer) else emptyFc())
        s.getSourceAs<GeoJsonSource>("reach-round")?.setGeoJson(if (reach.active) line(reach.round) else emptyFc())
    }
    LaunchedEffect(map, reach.version) {
        val m = map ?: return@LaunchedEffect
        if (!reach.active || reach.outer.size < 3) return@LaunchedEffect
        val b = LatLngBounds.Builder()
        reach.outer.forEach { b.include(LatLng(it.lat, it.lon)) }
        val d = ctx.resources.displayMetrics.density
        m.easeCamera(CameraUpdateFactory.newLatLngBounds(b.build(), (40 * d).toInt(), (150 * d).toInt(), (70 * d).toInt(), (140 * d).toInt()), 900)
    }

    // Bildrate der Karte: in der Navigation 30 Bilder/s genügen (das Handy könnte 120)
    LaunchedEffect(navigating) { runCatching { mapView.setMaximumFps(if (navigating) 30 else 60) } }

    // Kompass und Quellenhinweis je nach Ansicht
    LaunchedEffect(map, navigating) {
        val m = map ?: return@LaunchedEffect
        val d = ctx.resources.displayMetrics.density
        m.uiSettings.isCompassEnabled = !navigating
        m.uiSettings.compassGravity = Gravity.TOP or Gravity.END
        m.uiSettings.setCompassMargins(0, (d * 330).toInt(), (d * 22).toInt(), 0)
        if (navigating) {
            m.uiSettings.attributionGravity = Gravity.BOTTOM or Gravity.START
            m.uiSettings.setAttributionMargins((d * 30).toInt(), 0, 0, (d * 330).toInt())
        } else {
            m.uiSettings.attributionGravity = Gravity.TOP or Gravity.START
            m.uiSettings.setAttributionMargins(36, (d * 200).toInt(), 0, 0)
        }
    }

    // Ladestationen im Kartenausschnitt
    LaunchedEffect(style, mapChargers) {
        val s = style ?: return@LaunchedEffect
        val feats = mapChargers.map { h ->
            Feature.fromGeometry(Point.fromLngLat(h.pos.lon, h.pos.lat)).also {
                it.addStringProperty("id", h.id)
                it.addStringProperty("icon", MapChargers.iconFor(h.powerKw))
            }
        }
        s.getSourceAs<GeoJsonSource>("map-chargers")?.setGeoJson(FeatureCollection.fromFeatures(feats))
    }

    // Fahnen (Start, Zwischenstopps, Ladestopps, Ziel) und Staus der gewählten Route
    LaunchedEffect(style, routes, selected, dark, navigating) {
        val s = style ?: return@LaunchedEffect
        applyStopsAndJams(s, routes.getOrNull(selected), 0, ctx, dark, navigating)
    }

    // Übersicht über alle Routen – nur bei neuen Routen (kurz danach darf sich der Abstand fürs Fenster noch anpassen),
    // nicht wenn man in der Gegend sucht und ein Fenster schließt
    val fitFor = remember { arrayOfNulls<Any>(1) }
    val fitAt = remember { longArrayOf(0L) }
    LaunchedEffect(map, routes, sheetPadPx, leftPadPx) {
        val m = map ?: return@LaunchedEffect
        if (navigating || routes.isEmpty()) return@LaunchedEffect
        if (fitFor[0] === routes && System.currentTimeMillis() - fitAt[0] > 1500) return@LaunchedEffect
        if (fitFor[0] !== routes) { fitFor[0] = routes; fitAt[0] = System.currentTimeMillis() }
        val b = LatLngBounds.Builder()
        var count = 0
        routes.forEach { r ->
            val stepN = (r.points.size / 300).coerceAtLeast(1)
            r.points.forEachIndexed { i, p -> if (i % stepN == 0 || i == r.points.lastIndex) { b.include(LatLng(p.lat, p.lon)); count++ } }
        }
        if (count >= 2) {
            val d = ctx.resources.displayMetrics.density
            m.easeCamera(CameraUpdateFactory.newLatLngBounds(b.build(), (40 * d).toInt() + leftPadPx.toInt(), (120 * d).toInt(), (40 * d).toInt(), sheetPadPx), 900)
        }
    }

    // Gefahrener Teil der Route grau
    LaunchedEffect(style, progress?.alongM, navigating) {
        val s = style ?: return@LaunchedEffect
        applyProgress(s, routes.getOrNull(selected), progress, navigating, dark)
    }
    LaunchedEffect(style, (progress?.segIdx ?: 0) / 20, navigating) {
        val s = style ?: return@LaunchedEffect
        if (navigating) applyStopsAndJams(s, routes.getOrNull(selected), progress?.segIdx ?: 0, ctx, dark, true)
    }

    // Neue GPS-Messung oder neue Position auf der Route: Vorausberechnung aktualisieren
    LaunchedEffect(fix, progress, navigating) {
        val f = fix ?: return@LaunchedEffect
        val r = routes.getOrNull(selected)
        val onRoute = navigating && progress != null && progress.offRouteM < 30 && r != null
        val b = when {
            onRoute && f.speed > 1.5 -> progress!!.routeBearing
            f.bearing != null && f.speed > 1.5 -> f.bearing.toDouble()
            else -> pred.bearingNow
        }
        pred.set(
            pos = if (onRoute) progress!!.snapped else f.pos,
            bearingDeg = b,
            speedMs = f.speed,
            ns = f.elapsedNs,
            r = if (onRoute) r else null,
            along = if (onRoute) progress!!.alongM else null,
            routeMode = onRoute,
        )
        // Tempo geglättet (einige Sekunden), damit der Zoom nicht bei jeder kleinen Änderung pumpt
        val kmhNow = f.speed * 3.6
        speedEma[0] = if (speedEma[0] < 0) kmhNow else speedEma[0] * 0.8 + kmhNow * 0.2
        val zt = autoZoom(speedEma[0], progress?.distToStepM ?: 1e9)
        if (kotlin.math.abs(zt - zoomTarget[0]) > 0.08) zoomTarget[0] = zt
        val m = map ?: return@LaunchedEffect
        if (!navigating && !centered && routes.isEmpty()) {
            centered = true
            m.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(f.pos.lat, f.pos.lon), 14.0))
        }
    }

    // „Zentrieren“-Knopf außerhalb der Navigation
    LaunchedEffect(recenterTick) {
        if (recenterTick == 0 || navigating) return@LaunchedEffect
        val f = fix ?: return@LaunchedEffect
        val cam = CameraPosition.Builder().target(LatLng(f.pos.lat, f.pos.lon)).zoom(15.5).tilt(0.0).bearing(0.0)
            .padding(0.0, 0.0, 0.0, 0.0).build()
        map?.easeCamera(CameraUpdateFactory.newCameraPosition(cam), 700)
    }

    // Bildschleife (~30 fps): Fahrzeugsymbol und – in der Navigation – Kamera auf die vorausberechnete Position
    LaunchedEffect(style) {
        val s = style ?: return@LaunchedEffect
        val src = s.getSourceAs<GeoJsonSource>("me") ?: return@LaunchedEffect
        var last = 0L
        var lastSym = 0L
        var wasFollow = false
        var zoom = 16.0
        var camFollow = false
        var transitionEnd = 0L
        while (isActive) {
            // Nur in der Fahransicht im Bildtakt; sonst reicht 10x pro Sekunde (spart Akku und Wärme)
            if (followNow.value) {
                // bis zum nächsten 30-fps-Takt schlafen, dann auf das nächste Bild warten (statt jedes 120-Hz-Bild aufzuwachen)
                val waitMs = (33_000_000L - (System.nanoTime() - last)) / 1_000_000L
                if (waitMs > 2) kotlinx.coroutines.delay(waitMs)
                withFrameNanos { }
            } else {
                kotlinx.coroutines.delay(if (AppVisibility.visible) 100 else 1000)
            }
            val wall = System.nanoTime()
            if (!pred.ready || wall - last < 33_000_000L) continue
            last = wall
            val (p, b, changed) = pred.frame(android.os.SystemClock.elapsedRealtimeNanos())
            val follow = followNow.value
            // Kartensymbol nur aktualisieren, wenn es sichtbar ist (sonst liegt das feste Bild darüber), max. ~10×/s
            if (!follow && (wasFollow || (changed && wall - lastSym > 95_000_000L))) {
                lastSym = wall
                val feat = Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat))
                feat.addNumberProperty("bearing", b)
                // 3D-Fahrzeug: passende Ansicht zur Richtung relativ zur Karte
                feat.addNumberProperty("frame", VehicleSprites.frameFor(b - (map?.cameraPosition?.bearing ?: 0.0)))
                src.setGeoJson(feat)
            }
            wasFollow = follow
            if (follow) {
                // Zeitkonstante ~1,6 s: gleitet weich zum Ziel-Zoom
                val zTarget = zoomTarget[0] - if (pipNow.value) 0.8 else 0.0
                val tilt = if (pipNow.value) 0.0 else 58.0
                zoom += (zTarget - zoom) * 0.0204
                val cam = CameraPosition.Builder()
                    .target(LatLng(p.lat, p.lon))
                    .zoom(zoom)
                    .tilt(tilt)
                    .bearing(b)
                    .padding(padLeft.value, padTop.value, 0.0, padBottom.value)
                    .build()
                if (!camFollow) {
                    // eben erst (wieder) in die Fahransicht: weiche Kamerafahrt statt Sprung
                    zoom = zTarget
                    val target = CameraPosition.Builder().target(LatLng(p.lat, p.lon)).zoom(zoom).tilt(tilt).bearing(b)
                        .padding(padLeft.value, padTop.value, 0.0, padBottom.value).build()
                    map?.easeCamera(CameraUpdateFactory.newCameraPosition(target), 1100)
                    transitionEnd = wall + 1_150_000_000L
                    camFollow = true
                } else if (wall > transitionEnd) {
                    map?.moveCamera(CameraUpdateFactory.newCameraPosition(cam))
                }
            } else {
                camFollow = false
                zoom = map?.cameraPosition?.zoom ?: zoom
            }
        }
    }

    AndroidView(factory = { mapView }, modifier = modifier)
}

// ---------------- Gemeinsame Kartenfunktionen (Handy und Android Auto) ----------------

internal fun applyRoutes(s: Style, routes: List<Route>, selected: Int, navigating: Boolean, dark: Boolean) {
    val sel = routes.getOrNull(selected)
    val alts = if (navigating) emptyList() else routes.filterIndexed { i, _ -> i != selected }.map { lineFeature(it) }
    s.getSourceAs<GeoJsonSource>("alts")?.setGeoJson(FeatureCollection.fromFeatures(alts))
    s.getSourceAs<GeoJsonSource>("route")?.setGeoJson(sel?.let { FeatureCollection.fromFeature(lineFeature(it)) } ?: emptyFc())
    if (!navigating) s.getLayerAs<LineLayer>("route-line")?.setProperties(lineGradient(progressGradient(0.0, LineColors(dark))))
}

internal fun applyTraffic(s: Style, url: String?) {
    s.getLayer("traffic-layer")?.let { s.removeLayer(it) }
    s.getSource("traffic")?.let { s.removeSource(it) }
    if (url != null) {
        s.addSource(RasterSource("traffic", TileSet("2.2.0", url), 256))
        val layer = RasterLayer("traffic-layer", "traffic").withProperties(rasterOpacity(0.9f))
        if (s.getLayer("alt-casing") != null) s.addLayerBelow(layer, "alt-casing") else s.addLayer(layer)
    }
}

internal fun applyTurnArrow(s: Style, r: Route?, p: NavProgress?, navigating: Boolean, zoom: Double = 16.5) {
    val src = s.getSourceAs<GeoJsonSource>("turn-line") ?: return
    s.getSourceAs<GeoJsonSource>("turn-head")?.setGeoJson(emptyFc())
    // im Kreisverkehr: Pfeil des Kreisverkehrs bis zur Ausfahrt weiter zeigen
    var idx = p?.stepIdx ?: -1
    if (r != null && p != null) {
        val prev = r.steps.getOrNull(idx - 1)
        if (prev != null && prev.isRoundabout) {
            val ex = roundaboutExitAlong(r, idx - 1)
            if (ex != null && p.alongM < ex) idx -= 1
        }
    }
    val step = if (r != null) r.steps.getOrNull(idx) else null
    val show = navigating && r != null && p != null && step != null &&
        step.type !in listOf("arrive", "depart", "charge", "via") &&
        !(step.type == "continue" && (step.mod == null || step.mod == "straight"))
    val at = if (show) r!!.stepAlongM.getOrNull(idx) else null
    if (!show || at == null || r == null || p == null || step == null || at - p.alongM > 450) { src.setGeoJson(emptyFc()); return }
    // Größe in Metern passend zur Kartenzoomstufe (bleibt bei jeder Neigung auf der Fahrbahn)
    val lat = r.points.first().lat
    val mPerDp = 78271.517 * cos(Math.toRadians(lat)) / 2.0.pow(zoom)
    val before = (60 * mPerDp).coerceIn(25.0, 140.0)
    val after = if (step.isRoundabout) (roundaboutExitAlong(r, idx)?.let { it - at + 14 * mPerDp } ?: (40 * mPerDp)) else (38 * mPerDp).coerceIn(18.0, 90.0)
    val pts = slice(r, max(p.alongM, at - before), at + after)
    if (pts.size < 2) { src.setGeoJson(emptyFc()); return }
    val poly = arrowPolygon(pts, bodyHalf = 5.0 * mPerDp, headHalf = 12.0 * mPerDp, headLen = 14.0 * mPerDp)
    if (poly == null) { src.setGeoJson(emptyFc()); return }
    src.setGeoJson(Feature.fromGeometry(Polygon.fromLngLats(listOf(poly.map { Point.fromLngLat(it.lon, it.lat) }))))
}

/** Pfeil als geschlossene Fläche: Körper entlang der Linie, am Ende eine Spitze (Maße in Metern) */
private fun arrowPolygon(line: List<LatLon>, bodyHalf: Double, headHalf: Double, headLen: Double): List<LatLon>? {
    val lat0 = line.first().lat; val lon0 = line.first().lon
    val kx = 111320.0 * cos(Math.toRadians(lat0)); val ky = 110540.0
    var xy = line.map { (it.lon - lon0) * kx to (it.lat - lat0) * ky }
    // doppelte Punkte entfernen
    xy = xy.filterIndexed { i, q -> i == 0 || hypot(q.first - xy[i - 1].first, q.second - xy[i - 1].second) > 0.5 }
    if (xy.size < 2) return null
    // Linie um die Länge der Spitze kürzen
    val total = xy.zipWithNext().sumOf { (a, b) -> hypot(b.first - a.first, b.second - a.second) }
    if (total < headLen * 1.4) return null
    val tip = xy.last()
    val body = mutableListOf(xy.first())
    var acc = 0.0
    for (i in 1 until xy.size) {
        val a = xy[i - 1]; val b = xy[i]
        val seg = hypot(b.first - a.first, b.second - a.second)
        if (acc + seg >= total - headLen) {
            val t = ((total - headLen) - acc) / seg
            body += (a.first + (b.first - a.first) * t) to (a.second + (b.second - a.second) * t)
            break
        }
        body += b
        acc += seg
    }
    fun normal(i: Int): Pair<Double, Double> {
        val a = body[maxOf(0, i - 1)]; val b = body[minOf(body.lastIndex, i + 1)]
        val dx = b.first - a.first; val dy = b.second - a.second
        val l = hypot(dx, dy).coerceAtLeast(1e-6)
        return (-dy / l) to (dx / l)
    }
    val left = body.indices.map { i -> val n = normal(i); (body[i].first + n.first * bodyHalf) to (body[i].second + n.second * bodyHalf) }
    val right = body.indices.map { i -> val n = normal(i); (body[i].first - n.first * bodyHalf) to (body[i].second - n.second * bodyHalf) }
    val base = body.last(); val nb = normal(body.lastIndex)
    val ring = mutableListOf<Pair<Double, Double>>()
    ring += left
    ring += (base.first + nb.first * headHalf) to (base.second + nb.second * headHalf)
    ring += tip
    ring += (base.first - nb.first * headHalf) to (base.second - nb.second * headHalf)
    ring += right.reversed()
    ring += ring.first()
    return ring.map { (x, y) -> LatLon(lat0 + y / ky, lon0 + x / kx) }
}

internal fun applyStopsAndJams(s: Style, r: Route?, fromIdx: Int = 0, ctx: android.content.Context? = null, dark: Boolean = false, navigating: Boolean = false) {
    val flags = mutableListOf<Feature>()
    fun flag(pos: LatLon, kind: RouteFlags.Kind, text: String?) {
        val id = "flag-${kind.name}-${text ?: ""}-$dark"
        if (s.getImage(id) == null && ctx != null) s.addImage(id, RouteFlags.bitmap(ctx, kind, text, dark))
        flags += Feature.fromGeometry(Point.fromLngLat(pos.lon, pos.lat)).also { it.addStringProperty("img", id) }
    }
    if (r != null && r.points.size >= 2) {
        val passed = r.cumM.getOrElse(fromIdx) { 0.0 }
        // Start (nur bei der Planung – in der Navigation sitzt dort das Fahrzeug)
        if (!navigating) flag(r.points.first(), RouteFlags.Kind.START, r.socProfile.firstOrNull()?.second?.let { "${it.roundToInt()} %" })
        // Zwischenstopps (ohne Ladestopps, die bekommen eigene Fahnen)
        NavSession.state.value.vias.filter { !it.isCharger }.forEach { v -> flag(v.place.pos, RouteFlags.Kind.VIA, null) }
        r.stops.filter { !navigating || it.alongM > passed - 50 }.forEach { st ->
            flag(st.pos, RouteFlags.Kind.CHARGE, "${st.arriveSoc.roundToInt()} → ${st.targetSoc.roundToInt()} %")
        }
        flag(r.points.last(), RouteFlags.Kind.DEST, r.arrivalSoc?.let { "${it.roundToInt()} %" })
    }
    s.getSourceAs<GeoJsonSource>("stops")?.setGeoJson(FeatureCollection.fromFeatures(flags))
    val jams = if (r == null) emptyList() else r.jams.mapNotNull { j ->
        if (j.magnitude <= 0 && j.category != "ROAD_CLOSURE") return@mapNotNull null
        // bereits gefahrene Teile nicht mehr einfärben
        val a = maxOf(j.startIdx, fromIdx).coerceIn(0, r.points.lastIndex)
        val b = j.endIdx.coerceIn(0, r.points.lastIndex)
        if (b - a < 1) return@mapNotNull null
        val f = Feature.fromGeometry(LineString.fromLngLats(r.points.subList(a, b + 1).map { Point.fromLngLat(it.lon, it.lat) }))
        f.addStringProperty(
            "c",
            when {
                j.category == "ROAD_CLOSURE" || j.magnitude >= 4 -> "#7A1010"
                j.magnitude == 3 -> "#E5332A"
                j.magnitude == 2 -> "#FF8A00"
                else -> "#FFB800"
            },
        )
        f
    }
    s.getSourceAs<GeoJsonSource>("jams")?.setGeoJson(FeatureCollection.fromFeatures(jams))
}

internal fun applyProgress(s: Style, r: Route?, p: NavProgress?, navigating: Boolean, dark: Boolean) {
    if (r == null || !navigating || p == null) return
    val frac = p.alongM / r.cumM.last().coerceAtLeast(1.0)
    s.getLayerAs<LineLayer>("route-line")?.setProperties(lineGradient(progressGradient(frac, LineColors(dark))))
}
