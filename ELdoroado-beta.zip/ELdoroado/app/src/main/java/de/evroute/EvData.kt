package de.evroute

import android.content.Context
import android.net.ConnectivityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import java.io.File

/**
 * Fahrzeugdaten aus Open EV Data (github.com/KilowattApp/open-ev-data, MIT-Lizenz mit Namensnennung).
 * Ein Grundstock liegt in der App (offline), monatlich wird im WLAN die aktuelle Fassung geladen.
 */
object EvDatabase {
    private const val URL = "https://raw.githubusercontent.com/KilowattApp/open-ev-data/master/data/ev-data.json"
    private const val FILE = "ev-data.json"
    private const val MAX_AGE_MS = 30L * 24 * 3600 * 1000

    data class Spec(
        val id: String,
        val brand: String,
        val model: String,
        val variant: String,
        val year: Int?,
        val usableKwh: Double,
        val avgConsumption: Double?, // kWh/100 km
        val acKw: Double?,
        val acPhases: Int?,
        val dcKw: Double?,
        val dcPorts: List<String>,
        val curve: List<Pair<Double, Double>>, // (Prozent, kW)
        val defaultCurve: Boolean,
        val voltage: Int?,
    ) {
        val title get() = listOf(model, variant.takeIf { it.isNotBlank() && !model.contains(it, true) }).filterNotNull().joinToString(" ")
        val details get() = listOfNotNull(
            year?.toString(),
            "${fmt(usableKwh)} kWh netto",
            dcKw?.let { "DC ${it.toInt()} kW" },
            acKw?.let { "AC ${fmt(it)} kW" },
            voltage?.let { "${it} V" },
        ).joinToString(" · ")
    }

    private fun fmt(d: Double) = if (d % 1.0 == 0.0) d.toInt().toString() else String.format(java.util.Locale.GERMANY, "%.1f", d)

    private val _all = MutableStateFlow<List<Spec>>(emptyList())
    val all: StateFlow<List<Spec>> = _all.asStateFlow()
    private val _updated = MutableStateFlow("")
    val updated: StateFlow<String> = _updated.asStateFlow()
    @Volatile private var byId: Map<String, Spec> = emptyMap()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var app: Context

    fun init(ctx: Context) {
        app = ctx.applicationContext
        // sofort laden, damit das gewählte Fahrzeug beim Start bekannt ist
        runCatching { load() }
        scope.launch { runCatching { updateIfOld() } }
    }

    fun spec(id: String): Spec? = byId[id.removePrefix("ev:")]

    private fun load() {
        val f = File(app.filesDir, FILE)
        val text = if (f.exists() && f.length() > 100_000) f.readText() else app.assets.open(FILE).bufferedReader().use { it.readText() }
        apply(text)
    }

    private fun apply(text: String) {
        val root = json.parseToJsonElement(text).jsonObject
        val list = (root["data"] as? JsonArray)?.mapNotNull { (it as? JsonObject)?.let(::parse) } ?: emptyList()
        if (list.size < 300) return
        _all.value = list.sortedWith(compareBy({ it.brand.lowercase() }, { it.model.lowercase() }, { -(it.year ?: 0) }))
        byId = list.associateBy { it.id }
        _updated.value = ((root["meta"] as? JsonObject)?.get("updated_at") as? JsonPrimitive)?.content?.take(10) ?: ""
    }

    private fun JsonObject.o(k: String) = this[k] as? JsonObject
    private fun JsonObject.d(k: String) = (this[k] as? JsonPrimitive)?.doubleOrNull
    private fun JsonObject.s(k: String) = (this[k] as? JsonPrimitive)?.takeIf { it.isString }?.content ?: ""

    private fun parse(o: JsonObject): Spec? {
        val type = o.s("vehicle_type")
        if (type.isNotBlank() && type != "car") return null
        val usable = o.d("usable_battery_size") ?: return null
        if (usable < 5) return null
        val dc = o.o("dc_charger")
        val ac = o.o("ac_charger")
        val curve = (dc?.get("charging_curve") as? JsonArray)?.mapNotNull { p ->
            val po = p as? JsonObject ?: return@mapNotNull null
            val pct = po.d("percentage") ?: return@mapNotNull null
            val kw = po.d("power") ?: return@mapNotNull null
            pct to kw
        }?.sortedBy { it.first } ?: emptyList()
        return Spec(
            id = o.s("id").ifBlank { return null },
            brand = o.s("brand").trim(),
            model = o.s("model").trim(),
            variant = o.s("variant").trim(),
            year = (o["release_year"] as? JsonPrimitive)?.intOrNull,
            usableKwh = usable,
            avgConsumption = o.o("energy_consumption")?.d("average_consumption"),
            acKw = ac?.d("max_power"),
            acPhases = (ac?.get("usable_phases") as? JsonPrimitive)?.intOrNull,
            dcKw = dc?.d("max_power"),
            dcPorts = (dc?.get("ports") as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.content } ?: emptyList(),
            curve = curve,
            defaultCurve = (dc?.get("is_default_charging_curve") as? JsonPrimitive)?.booleanOrNull ?: true,
            voltage = (o["charging_voltage"] as? JsonPrimitive)?.intOrNull,
        )
    }

    /** Monatlich im WLAN die aktuelle Fassung von GitHub laden */
    private suspend fun updateIfOld(force: Boolean = false) {
        val f = File(app.filesDir, FILE)
        val age = System.currentTimeMillis() - (if (f.exists()) f.lastModified() else 0L)
        if (!force && age < MAX_AGE_MS) return
        val metered = runCatching { (app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered }.getOrDefault(true)
        if (!force && metered) return
        val text = Http.get(URL)
        apply(text) // prüft selbst, ob genug Fahrzeuge drin sind
        if (_all.value.size >= 300) f.writeText(text)
    }

    fun updateNow() { if (::app.isInitialized) scope.launch { runCatching { updateIfOld(force = true) } } }

    // ---------- Umwandlung in ein Fahrzeugprofil der App ----------

    private val STELLANTIS = listOf("citro", "peugeot", "opel", "ds", "jeep", "fiat", "alfa", "lancia")

    fun profile(id: String): VehicleProfile? {
        val sp = spec(id) ?: return null
        // Verbrauchsfaktor relativ zum ë-C4 (Open EV Data: 16 kWh/100 km ↔ Faktor 1,0 in unserem Modell)
        val eff = ((sp.avgConsumption ?: 16.0) / 16.0).coerceIn(0.6, 1.9)
        val stellantis = STELLANTIS.any { sp.brand.lowercase().startsWith(it) } && sp.usableKwh in 44.0..52.0
        return VehicleProfile(
            id = "ev:${sp.id}",
            brand = sp.brand,
            model = sp.title,
            years = sp.year?.toString() ?: "",
            grossKwh = 0.0,
            usableKwh = sp.usableKwh,
            maxDcKw = sp.dcKw ?: sp.curve.maxOfOrNull { it.second } ?: 50.0,
            eff = eff,
            curve = "evdata",
            obd = if (stellantis) ObdSupport.LIKELY else ObdSupport.NONE,
            note = if (sp.defaultCurve) "Ladekurve geschätzt (Standardkurve aus Open EV Data); sie wird mit jedem Ladevorgang gelernt." else "",
        )
    }

    /** Ladekurve als (Anteil 0…1, kW) */
    fun curve(id: String): List<Pair<Double, Double>>? {
        val sp = spec(id) ?: return null
        if (sp.curve.size < 2) return null
        val c = sp.curve.map { (pct, kw) -> (pct / 100.0).coerceIn(0.0, 1.0) to kw }.toMutableList()
        if (c.first().first > 0.0) c.add(0, 0.0 to c.first().second)
        if (c.last().first < 1.0) c += 1.0 to (c.last().second * 0.3)
        return c
    }
}
