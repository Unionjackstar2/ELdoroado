package de.evroute

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import kotlin.math.roundToInt
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.float
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import java.io.File
import java.security.MessageDigest
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ---------------- Spurassistent ----------------

private fun laneAngle(d: String): Double = when (d) {
    "SLIGHT_RIGHT" -> 40.0
    "RIGHT" -> 90.0
    "SHARP_RIGHT" -> 135.0
    "SLIGHT_LEFT" -> -40.0
    "LEFT" -> -90.0
    "SHARP_LEFT" -> -135.0
    "U_TURN" -> 180.0
    else -> 0.0
}

private fun DrawScope.laneArrow(dir: String, color: Color, strokeW: Float) {
    val w = size.width
    val h = size.height
    val st = Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val deg = laneAngle(dir)
    val baseX = w * 0.5f
    val baseY = h * 0.94f
    if (deg == 180.0) {
        val p = Path().apply {
            moveTo(w * 0.62f, baseY); lineTo(w * 0.62f, h * 0.42f)
            cubicTo(w * 0.62f, h * 0.12f, w * 0.30f, h * 0.12f, w * 0.30f, h * 0.42f); lineTo(w * 0.30f, h * 0.52f)
        }
        drawPath(p, color, style = st)
        laneHead(Offset(w * 0.30f, h * 0.52f), 180.0, h * 0.16f, color)
        return
    }
    val a = deg * PI / 180
    val dv = Offset(sin(a).toFloat(), -cos(a).toFloat())
    // weich gebogener Pfeil: erst nach oben, dann in die Richtung
    val end = Offset(baseX, h * 0.50f) + dv * (h * 0.30f)
    val p = Path().apply {
        moveTo(baseX, baseY)
        if (deg == 0.0) {
            lineTo(baseX, h * 0.26f)
        } else {
            lineTo(baseX, h * 0.62f)
            quadraticTo(baseX, h * 0.42f, end.x, end.y)
        }
    }
    drawPath(p, color, style = st)
    laneHead(if (deg == 0.0) Offset(baseX, h * 0.26f) else end, deg, h * 0.16f, color)
}

private fun DrawScope.laneHead(e: Offset, deg: Double, hh: Float, color: Color) {
    val a = deg * PI / 180
    val dv = Offset(sin(a).toFloat(), -cos(a).toFloat())
    val n = Offset(-dv.y, dv.x)
    val head = Path().apply {
        moveTo((e + dv * hh).x, (e + dv * hh).y)
        lineTo((e + n * (hh * 0.8f)).x, (e + n * (hh * 0.8f)).y)
        lineTo((e - n * (hh * 0.8f)).x, (e - n * (hh * 0.8f)).y)
        close()
    }
    drawPath(head, color)
}

/** Eine Spur: empfohlene hell hinterlegt mit kräftigem weißem Pfeil, andere gedimmt */
@Composable
fun LaneCell(lane: Lane, dp: Dp, on: Color = Color.White, off: Color = Color.White.copy(alpha = 0.30f), hi: Color = Color.White.copy(alpha = 0.22f)) {
    val active = lane.follow != null
    Box(
        Modifier.size(dp * 0.82f, dp).clip(RoundedCornerShape(10.dp))
            .background(if (active) hi else Color.Transparent),
    ) {
        Canvas(Modifier.size(dp * 0.82f, dp)) {
            val sw = size.width * 0.13f
            lane.directions.filter { it != lane.follow }.forEach { laneArrow(it, off, sw) }
            if (lane.directions.isEmpty() && lane.follow == null) laneArrow("STRAIGHT", off, sw)
            lane.follow?.let { laneArrow(it, on, sw * 1.2f) }
        }
    }
}

/** Gestrichelte Fahrbahnmarkierung zwischen zwei Spuren */
@Composable
fun LaneDivider(height: Dp, color: Color = Color.White.copy(alpha = 0.45f)) {
    Canvas(Modifier.width(3.dp).height(height)) {
        val dash = size.height / 7
        var y = dash * 0.5f
        while (y < size.height) {
            drawLine(color, Offset(size.width / 2, y), Offset(size.width / 2, (y + dash * 0.6f).coerceAtMost(size.height)), size.width, StrokeCap.Round)
            y += dash
        }
    }
}

/** Spurempfehlung als Ansagetext, z. B. „die beiden rechten Spuren“; null = keine Ansage nötig */
fun lanePhrase(ls: LaneSection): String? {
    val n = ls.lanes.size
    val rec = ls.lanes.indices.filter { ls.lanes[it].follow != null }
    if (rec.isEmpty() || rec.size == n || n < 2) return null
    val contiguous = rec.last() - rec.first() + 1 == rec.size
    val zahl = listOf("", "", "beiden", "drei", "vier", "fünf")
    fun count(k: Int) = zahl.getOrElse(k) { "$k" }
    return when {
        contiguous && rec.last() == n - 1 -> if (rec.size == 1) "die rechte Spur" else "eine der ${count(rec.size)} rechten Spuren"
        contiguous && rec.first() == 0 -> if (rec.size == 1) "die linke Spur" else "eine der ${count(rec.size)} linken Spuren"
        rec.size == 1 && n == 3 -> "die mittlere Spur"
        rec.size == 1 -> {
            val fromLeft = rec[0] + 1
            val fromRight = n - rec[0]
            if (fromLeft <= fromRight) "die ${ordinalDe(fromLeft)} Spur von links" else "die ${ordinalDe(fromRight)} Spur von rechts"
        }
        else -> "eine der mittleren Spuren"
    }
}

/** Spurabschnitt, der jetzt angezeigt werden soll (Handy und Android Auto) */
fun findLaneSection(r: Route, p: NavProgress, along: Double, speedMs: Double): LaneSection? {
    val range = if (speedMs * 3.6 > 75) 1500.0 else 500.0
    val stepAlong = r.stepAlongM.getOrNull(p.stepIdx) ?: return null
    fun at(i: Int) = r.cumM.getOrElse(i) { 0.0 }
    return r.laneSections.firstOrNull { ls ->
        val a = at(ls.startIdx)
        val b = at(ls.endIdx)
        b >= along - 5 && a - along <= range && a <= stepAlong + 50 && ls.lanes.any { it.follow != null } &&
            ls.lanes.any { it.follow == null } // nur zeigen, wenn es wirklich falsche Spuren gibt
    }
}

// ---------------- Stauende, Baustelle, Sperrung ----------------

@Composable
fun WarningCard(w: NavSession.Warning) {
    val color = when (w.kind) {
        "ROAD_CLOSURE" -> Color(0xFF8E1B1B)
        "ROAD_WORK" -> Color(0xFFE07800)
        else -> Color(0xFFE5332A)
    }
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = color, shadowElevation = 10.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(26.dp)) {
                    val s = size.width
                    val tri = Path().apply { moveTo(s * 0.5f, s * 0.06f); lineTo(s * 0.96f, s * 0.9f); lineTo(s * 0.04f, s * 0.9f); close() }
                    drawPath(tri, Color.White)
                    drawLine(color, Offset(s * 0.5f, s * 0.36f), Offset(s * 0.5f, s * 0.64f), s * 0.1f, StrokeCap.Round)
                    drawCircle(color, s * 0.055f, Offset(s * 0.5f, s * 0.77f))
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (w.inside) "noch ${fmtKm(w.lengthM)}" else fmtDistShort(w.distM),
                    color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                )
                Text(
                    w.title + if (!w.inside && w.lengthM > 300) " · ${fmtKm(w.lengthM)}" else "",
                    color = Color.White.copy(alpha = 0.95f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                )
            }
            if (w.delayS > 60) Text("+${(w.delayS / 60).roundToInt()} min", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

// ---------------- Signatur der App anzeigen ----------------

@Suppress("DEPRECATION")
fun signingSha256(ctx: Context): String? = runCatching {
    val pm = ctx.packageManager
    val sigs = if (Build.VERSION.SDK_INT >= 28) {
        val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        info.signingInfo?.apkContentsSigners
    } else {
        pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures
    }
    val sig = sigs?.firstOrNull() ?: return null
    MessageDigest.getInstance("SHA-256").digest(sig.toByteArray()).joinToString(":") { String.format("%02X", it) }
}.getOrNull()

@Composable
fun SigningInfo() {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val fp = remember { signingSha256(ctx) }
    Spacer(Modifier.height(10.dp))
    Text("Signatur der App (SHA-256)", color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    Text(fp ?: "unbekannt", color = pal.sub, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    val release = fp?.startsWith("8E:70:07:FC") == true
    Text(
        if (release) "✓ Release-Schlüssel (bei Google registriert)" else "Debug-Schlüssel",
        color = if (release) pal.green else pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
    )
    if (fp != null) TextButton(onClick = { clip.setText(AnnotatedString(fp)) }) { Text("Kopieren") }
}

// ---------------- Sichern und Wiederherstellen ----------------

object Backup {
    private val FILES = listOf("settings", "favorites", "recents", "learn", "operators", "routes")

    /** Diese Einträge landen nie in einer Sicherung und werden beim Einlesen ignoriert */
    private val SECRET_KEYS = setOf("tomtomKey", "ocmKey", "orsKey", "apiKey", "key")

    fun export(ctx: Context): String = buildJsonObject {
        put("app", "ELdoroado")
        put("format", 1)
        putJsonObject("prefs") {
            FILES.forEach { name ->
                val p = ctx.getSharedPreferences(name, Context.MODE_PRIVATE)
                putJsonObject(name) {
                    p.all.filterKeys { it !in SECRET_KEYS }.forEach { (k, v) ->
                        putJsonObject(k) {
                            when (v) {
                                is Boolean -> { put("t", "b"); put("v", v) }
                                is Int -> { put("t", "i"); put("v", v) }
                                is Long -> { put("t", "l"); put("v", v) }
                                is Float -> { put("t", "f"); put("v", v) }
                                is String -> { put("t", "s"); put("v", v) }
                                is Set<*> -> { put("t", "set"); putJsonArray("v") { v.forEach { add(it.toString()) } } }
                                else -> { put("t", "s"); put("v", v.toString()) }
                            }
                        }
                    }
                }
            }
        }
        put("trips", File(ctx.filesDir, "trips.csv").takeIf { it.exists() }?.readText() ?: "")
    }.toString()

    /** Sicherung einspielen; true bei Erfolg */
    fun import(ctx: Context, text: String): Boolean = runCatching {
        val root = json.parseToJsonElement(text).jsonObject
        if (root["app"]?.jsonPrimitive?.contentOrNull !in setOf("ELdoroado", "EVRoute")) return false
        val prefs = root["prefs"]?.jsonObject ?: return false
        FILES.forEach { name ->
            val data = prefs[name] as? JsonObject ?: return@forEach
            val e = ctx.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
            data.forEach { (k, el) ->
                if (k in SECRET_KEYS) return@forEach // alte Sicherungen mit Key: Key verwerfen
                val o = el.jsonObject
                val v = o["v"] ?: return@forEach
                when (o["t"]?.jsonPrimitive?.contentOrNull) {
                    "b" -> e.putBoolean(k, v.jsonPrimitive.boolean)
                    "i" -> e.putInt(k, v.jsonPrimitive.int)
                    "l" -> e.putLong(k, v.jsonPrimitive.long)
                    "f" -> e.putFloat(k, v.jsonPrimitive.float)
                    "set" -> e.putStringSet(k, v.jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull }.toSet())
                    else -> e.putString(k, v.jsonPrimitive.contentOrNull ?: "")
                }
            }
            e.commit()
        }
        root["trips"]?.jsonPrimitive?.contentOrNull?.let { File(ctx.filesDir, "trips.csv").writeText(it) }
        Settings.init(ctx)
        Favorites.init(ctx)
        Recents.init(ctx)
        Learner.init(ctx)
        KnownOperators.init(ctx)
        TripRecorder.reload()
        true
    }.getOrDefault(false)
}

@Composable
fun BackupSection() {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf<String?>(null) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            msg = runCatching {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(Backup.export(ctx).toByteArray()) }
                "Gesichert."
            }.getOrElse { "Sichern fehlgeschlagen: ${it.message}" }
        }
    }
    val load = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching { ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } }.getOrNull()
            msg = if (text != null && Backup.import(ctx, text)) "Wiederhergestellt." else "Diese Datei ist keine ELdoroado-Sicherung."
        }
    }
    Text(
        "Sichert Einstellungen, TomTom-Key, Favoriten, OBD-Adapter, gelernte Werte und Fahrten in eine Datei (z. B. in Google Drive).",
        color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp),
    )
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = { save.launch("ELdoroado-Sicherung.json") }, shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
        ) { Text("Sichern") }
        Button(
            onClick = { load.launch(arrayOf("application/json", "text/plain", "*/*")) }, shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = pal.field, contentColor = pal.text),
        ) { Text("Wiederherstellen") }
    }
    msg?.let { Text(it, color = pal.text, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
    Text("Die Datei enthält deinen TomTom-Key – nicht weitergeben.", color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
}
