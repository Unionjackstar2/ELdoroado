package de.evroute

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import okhttp3.Request
import kotlin.math.abs
import kotlin.math.max

/**
 * Verkehrsmeldungen der Autobahn GmbH des Bundes (verkehr.autobahn.de), frei und ohne Schlüssel:
 * Staus mit Verzögerung, Sperrungen und Baustellen. Meldungen auf der eigenen Route und in Fahrtrichtung
 * werden als Jam-Abschnitte an die Route gehängt – Warnung, Ansage und Anzeige laufen dann wie bei TomTom.
 */
object AutobahnApi {
    private const val BASE = "https://verkehr.autobahn.de/o/autobahn"
    /** Markierung im Feld Jam.cause: stammt von der Autobahn-API (wird beim Auffrischen ersetzt) */
    const val MARK = -77

    data class Item(
        val kind: String, // warning, closure, roadworks
        val title: String,
        val line: List<LatLon>,
        val delayS: Double,
        val blocked: Boolean,
        val speedKmh: Double?,
    )

    private val cache = TtlCache<List<Item>>(5 * 60_000L, 40)

    private fun roadsOf(r: Route): List<String> {
        val re = Regex("\\bA\\s?(\\d{1,3})\\b")
        return r.steps.flatMap { st -> re.findAll(st.road + " " + st.towards).map { "A" + it.groupValues[1] }.toList() }
            .distinct().take(10)
    }

    private fun JsonObject.str(k: String): String = (this[k] as? JsonPrimitive)?.content ?: ""
    private fun JsonObject.num(k: String): Double? = (this[k] as? JsonPrimitive)?.let { it.doubleOrNull ?: it.content.replace(',', '.').toDoubleOrNull() }
    private fun JsonObject.bool(k: String): Boolean = (this[k] as? JsonPrimitive)?.let { it.booleanOrNull ?: (it.content == "true") } ?: false

    private fun parse(kind: String, o: JsonObject): Item? {
        if (o.bool("future")) return null
        val geo = o["geometry"] as? JsonObject
        val coords = (geo?.get("coordinates") as? JsonArray)?.mapNotNull { p ->
            val a = p as? JsonArray ?: return@mapNotNull null
            val lon = (a.getOrNull(0) as? JsonPrimitive)?.doubleOrNull ?: return@mapNotNull null
            val lat = (a.getOrNull(1) as? JsonPrimitive)?.doubleOrNull ?: return@mapNotNull null
            LatLon(lat, lon)
        } ?: emptyList()
        val line = coords.ifEmpty {
            val c = o["coordinate"] as? JsonObject ?: return null
            val lat = c.num("lat") ?: return null
            val lon = c.num("long") ?: c.num("lon") ?: return null
            listOf(LatLon(lat, lon))
        }
        val delayMin = o.num("delayTimeValue") ?: 0.0
        return Item(
            kind = kind,
            title = o.str("title"),
            line = line,
            delayS = delayMin * 60,
            blocked = kind == "closure" || o.bool("isBlocked"),
            speedKmh = o.num("averageSpeed")?.takeIf { it > 0 },
        )
    }

    private suspend fun fetch(road: String): List<Item> = withContext(Dispatchers.IO) {
        cache.get(road)?.let { return@withContext it }
        val out = mutableListOf<Item>()
        for ((path, key) in listOf("warning" to "warning", "closure" to "closure", "roadworks" to "roadworks")) {
            val req = Request.Builder().url("$BASE/$road/services/$path").header("User-Agent", "ELdoroado/${BuildConfigLite.version}").build()
            val r = runCatching { Http.call(req) }.getOrNull() ?: continue
            if (r.code != 200) continue
            val root = runCatching { json.parseToJsonElement(r.body).jsonObject }.getOrNull() ?: continue
            (root[key] as? JsonArray)?.forEach { e -> (e as? JsonObject)?.let { parse(path, it) }?.let { out += it } }
        }
        cache.put(road, out)
        out
    }

    /** nächster Routenpunkt im Umkreis (Index) oder -1 */
    private fun nearestIdx(r: Route, p: LatLon, maxM: Double, from: Int = 0): Int {
        var best = -1
        var bd = maxM
        val dLat = maxM / 111_000.0 * 3
        for (i in from until r.points.size) {
            val q = r.points[i]
            if (abs(q.lat - p.lat) > dLat || abs(q.lon - p.lon) > dLat * 2) continue
            val d = haversine(p, q)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    /** Meldung auf die Route legen: Punkte der Meldung müssen in Fahrtrichtung nacheinander auf der Route liegen */
    private fun match(r: Route, item: Item): Pair<Int, Int>? {
        val ln = item.line
        val pts = if (ln.size > 12) ln.filterIndexed { i, _ -> i % (ln.size / 12 + 1) == 0 } + ln.last() else ln
        if (pts.size == 1) {
            // nur ein Punkt: Richtung unbekannt – nur Sperrungen sehr nah an der Route übernehmen
            if (!item.blocked) return null
            val i = nearestIdx(r, pts[0], 25.0)
            return if (i < 0) null else i to i
        }
        val idx = pts.map { p -> nearestIdx(r, p, 45.0) }
        val hit = idx.filter { i -> i >= 0 }
        if (hit.size < max(2, (pts.size * 0.6).toInt())) return null
        // Fahrtrichtung: Indizes müssen überwiegend steigen
        var up = 0
        var down = 0
        for (k in 1 until hit.size) { if (hit[k] > hit[k - 1]) up++ else if (hit[k] < hit[k - 1]) down++ }
        if (up <= down) return null
        return hit.min() to hit.max()
    }

    /** Route um Autobahn-Meldungen ergänzen (ersetzt frühere Meldungen derselben Quelle) */
    suspend fun enrich(r: Route, set: AppSettings): Route {
        if (!set.autobahnApi || r.points.size < 2) return r
        val roads = roadsOf(r)
        val base = r.jams.filter { it.cause != MARK }
        val baseDur = r.durationS - r.autobahnDelayS
        if (roads.isEmpty()) return if (r.autobahnDelayS > 0 || base.size != r.jams.size) r.copy(jams = base, durationS = baseDur, autobahnDelayS = 0.0) else r
        val items = withTimeoutOrNull(8_000) { roads.flatMap { fetch(it) } } ?: return r
        val added = mutableListOf<Jam>()
        withContext(Dispatchers.Default) {
            for (it in items) {
                val (a, b) = match(r, it) ?: continue
                // TomTom kennt den Stau schon? Dann nicht doppelt
                if (base.any { j -> j.startIdx <= b + 15 && j.endIdx >= a - 15 && (j.magnitude > 0 || j.category == "ROAD_CLOSURE") && it.kind == "warning" }) continue
                if (added.any { j -> j.startIdx <= b && j.endIdx >= a && j.category == categoryOf(it) }) continue
                added += Jam(
                    startIdx = a,
                    endIdx = max(a, b),
                    delayS = it.delayS,
                    magnitude = if (it.kind == "warning") (if (it.delayS >= 600) 3 else 2) else 0,
                    category = categoryOf(it),
                    cause = MARK,
                    speedKmh = it.speedKmh,
                )
            }
        }
        // Verzögerungen nur dort aufschlagen, wo die Route selbst keinen Verkehr kennt
        val extra = if (r.source == "TomTom") 0.0 else added.filter { it.category == "JAM" }.sumOf { it.delayS }
        return r.copy(
            jams = (base + added).sortedBy { it.startIdx },
            durationS = baseDur + extra,
            trafficDelayS = (r.trafficDelayS - r.autobahnDelayS).coerceAtLeast(0.0) + extra,
            autobahnDelayS = extra,
        )
    }

    private fun categoryOf(it: Item) = when {
        it.blocked -> "ROAD_CLOSURE"
        it.kind == "roadworks" -> "ROAD_WORK"
        else -> "JAM"
    }

    /** für Tests: wie viele Punkte einer Linie auf der Route liegen */
    internal fun matchForTest(r: Route, line: List<LatLon>, blocked: Boolean = false): Pair<Int, Int>? =
        match(r, Item("warning", "", line, 0.0, blocked, null))
}
