package de.evroute

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint

/** Ein antippbarer Ort auf der Karte */
data class Poi(val osm: String, val name: String, val kind: String, val cat: String, val pos: LatLon)

/** Kategorie für die Einstellungen und die Karte */
data class PoiCat(val id: String, val label: String, val emoji: String, val color: Int, val filter: String)

/** Kategorien und Symbole der Orte auf der Karte (Daten kommen aus den Kartenkacheln, siehe TilePois) */
object Pois {
    val CATS = listOf(
        PoiCat("food", "Essen und Trinken", "🍴", 0xFFFF9500.toInt(), "[\"amenity\"~\"^(restaurant|cafe|fast_food|bar|pub|ice_cream|biergarten)$\"]"),
        PoiCat("shop", "Einkaufen", "🛒", 0xFF0A84FF.toInt(), "[\"shop\"~\"^(supermarket|convenience|bakery|mall|department_store|doityourself|hardware|chemist|butcher|beverages)$\"]"),
        PoiCat("wc", "Toiletten", "🚻", 0xFF5E5CE6.toInt(), "[\"amenity\"=\"toilets\"]"),
        PoiCat("fuel", "Tankstellen", "⛽", 0xFF8E8E93.toInt(), "[\"amenity\"=\"fuel\"]"),
        PoiCat("parking", "Parkplätze", "🅿", 0xFF1E5AA8.toInt(), "[\"amenity\"=\"parking\"][\"access\"!~\"private|customers\"]"),
        PoiCat("hotel", "Hotels", "🛏", 0xFFAF52DE.toInt(), "[\"tourism\"~\"^(hotel|motel|guest_house|hostel)$\"]"),
        PoiCat("sight", "Sehenswürdigkeiten", "📷", 0xFF30B0C7.toInt(), "[\"tourism\"~\"^(attraction|museum|viewpoint|zoo|theme_park)$\"]"),
        PoiCat("health", "Apotheken und Ärzte", "➕", 0xFFFF3B30.toInt(), "[\"amenity\"~\"^(pharmacy|hospital|doctors|dentist)$\"]"),
        PoiCat("money", "Geldautomaten und Banken", "€", 0xFF34C759.toInt(), "[\"amenity\"~\"^(atm|bank)$\"]"),
    )

    fun iconId(cat: String) = "poi-$cat"

    fun addIcons(ctx: Context, s: org.maplibre.android.maps.Style) {
        CATS.forEach { s.addImage(iconId(it.id), icon(ctx, it)) }
    }

    private fun icon(ctx: Context, c: PoiCat): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val size = (26 * d).toInt()
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val cx = size / 2f
        cv.drawCircle(cx, cx, size * 0.48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE })
        cv.drawCircle(cx, cx, size * 0.41f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c.color })
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = size * 0.46f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        cv.drawText(c.emoji, cx, cx - (tp.descent() + tp.ascent()) / 2, tp)
        return b
    }
}
