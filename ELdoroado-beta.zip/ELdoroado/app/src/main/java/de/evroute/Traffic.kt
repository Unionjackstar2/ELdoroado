package de.evroute

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import okhttp3.Request
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * TomTom nur noch für Verkehr: Störungsmeldungen (Traffic Incidents API v5) entlang der Route –
 * Staus mit Verzögerung, Sperrungen, Baustellen, Unfälle, auch in der Stadt und im Ausland.
 * Abgefragt wird in Kästen von höchstens ~80 km Strecke (TomTom erlaubt bis 10.000 km² je Anfrage).
 */
object TrafficIncidents {
    const val MARK = -78
    private val cache = TtlCache<List<Pair<List<LatLon>, JsonObject>>>(4 * 60_000L, 30)
    private val FIELDS = "{incidents{type,geometry{type,coordinates},properties{iconCategory,magnitudeOfDelay,delay,events{description}}}}"

    /** Kästen entlang der Route ab [fromM] (je bis 80 km Strecke) */
    private fun boxes(r: Route, fromM: Double): List<DoubleArray> {
        val out = mutableListOf<DoubleArray>()
        var minLa = 90.0; var maxLa = -90.0; var minLo = 180.0; var maxLo = -180.0
        var start = -1.0
        for (i in r.points.indices) {
            if (r.cumM[i] < fromM) continue
            if (start < 0) start = r.cumM[i]
            val p = r.points[i]
            minLa = min(minLa, p.lat); maxLa = max(maxLa, p.lat); minLo = min(minLo, p.lon); maxLo = max(maxLo, p.lon)
            if (r.cumM[i] - start >= 80_000 || i == r.points.lastIndex) {
                out += doubleArrayOf(minLo - 0.01, minLa - 0.01, maxLo + 0.01, maxLa + 0.01)
                minLa = 90.0; maxLa = -90.0; minLo = 180.0; maxLo = -180.0
                start = r.cumM[i]
                if (i < r.points.lastIndex) { minLa = p.lat; maxLa = p.lat; minLo = p.lon; maxLo = p.lon }
            }
        }
        return out.take(12)
    }

    private suspend fun fetch(key: String, b: DoubleArray): List<Pair<List<LatLon>, JsonObject>> = withContext(Dispatchers.IO) {
        val bbox = String.format(Locale.US, "%.4f,%.4f,%.4f,%.4f", b[0], b[1], b[2], b[3])
        cache.get(bbox)?.let { return@withContext it }
        val url = "https://api.tomtom.com/traffic/services/5/incidentDetails?bbox=$bbox&language=de-DE&timeValidityFilter=present" +
            "&fields=" + URLEncoder.encode(FIELDS, "UTF-8") + "&key=" + URLEncoder.encode(key, "UTF-8")
        val r = runCatching { Http.call(Request.Builder().url(url).build()) }.getOrNull() ?: return@withContext emptyList()
        if (r.code != 200) return@withContext emptyList()
        val root = runCatching { json.parseToJsonElement(r.body).jsonObject }.getOrNull() ?: return@withContext emptyList()
        val list = (root["incidents"] as? JsonArray)?.mapNotNull { e ->
            val o = e as? JsonObject ?: return@mapNotNull null
            val g = o["geometry"] as? JsonObject ?: return@mapNotNull null
            val coords = g["coordinates"] as? JsonArray ?: return@mapNotNull null
            val pts = if ((g["type"] as? JsonPrimitive)?.content == "Point") {
                listOfNotNull(pt(coords))
            } else {
                coords.mapNotNull { pt(it as? JsonArray) }
            }
            if (pts.isEmpty()) null else pts to ((o["properties"] as? JsonObject) ?: JsonObject(emptyMap()))
        } ?: emptyList()
        cache.put(bbox, list)
        list
    }

    private fun pt(a: JsonArray?): LatLon? {
        val lon = (a?.getOrNull(0) as? JsonPrimitive)?.doubleOrNull ?: return null
        val lat = (a.getOrNull(1) as? JsonPrimitive)?.doubleOrNull ?: return null
        return LatLon(lat, lon)
    }

    /** Route um TomTom-Störungen ergänzen (nur mit TomTom-Key, ersetzt frühere Meldungen derselben Quelle) */
    suspend fun enrich(r: Route, set: AppSettings, fromM: Double = 0.0): Route {
        if (!set.hasTomTom || r.points.size < 2) return r
        val base = r.jams.filter { it.cause != MARK }
        val baseDur = r.durationS - r.ttDelayS
        val items = withTimeoutOrNull(10_000) { boxes(r, fromM).flatMap { fetch(set.tomtomKey.trim(), it) } } ?: return r
        val added = mutableListOf<Jam>()
        withContext(Dispatchers.Default) {
            for ((line, p) in items) {
                val icon = (p["iconCategory"] as? JsonPrimitive)?.intOrNull ?: 0
                val delay = (p["delay"] as? JsonPrimitive)?.doubleOrNull ?: 0.0
                val mag = (p["magnitudeOfDelay"] as? JsonPrimitive)?.intOrNull ?: 0
                val closed = icon == 8
                val category = when (icon) {
                    8 -> "ROAD_CLOSURE"
                    9 -> "ROAD_WORK"
                    6, 1, 7, 14 -> "JAM"
                    else -> continue // Wetter, Glätte usw. nicht als Stau werten
                }
                val (a, b) = AutobahnApi.matchLine(r, line, closed) ?: continue
                // schon von der Autobahn-API bekannt? dann nicht doppelt
                if (base.any { j -> j.startIdx <= b + 15 && j.endIdx >= a - 15 && j.category == category }) continue
                added += Jam(a, max(a, b), delay, if (category == "JAM") mag.coerceIn(1, 4) else 0, category, MARK, null)
            }
        }
        val extra = added.filter { it.category == "JAM" }.sumOf { it.delayS }
        return r.copy(
            jams = (base + added).sortedBy { it.startIdx },
            durationS = baseDur + extra,
            trafficDelayS = (r.trafficDelayS - r.ttDelayS).coerceAtLeast(0.0) + extra,
            ttDelayS = extra,
        )
    }

    /** Kleine Sperrflächen um einen gesperrten Abschnitt (für Valhalla „exclude_polygons“) */
    fun closureAreas(r: Route, j: Jam): List<List<LatLon>> {
        val idx = (j.startIdx..j.endIdx.coerceAtMost(r.points.lastIndex)).filter { it >= 0 }
        if (idx.isEmpty()) return emptyList()
        val pick = idx.filterIndexed { k, _ -> k % max(1, idx.size / 6) == 0 }.take(8)
        return pick.map { i ->
            val c = r.points[i]
            val d = 0.00025 // ~25 m
            listOf(LatLon(c.lat - d, c.lon - d * 1.6), LatLon(c.lat - d, c.lon + d * 1.6), LatLon(c.lat + d, c.lon + d * 1.6), LatLon(c.lat + d, c.lon - d * 1.6))
        }
    }
}
