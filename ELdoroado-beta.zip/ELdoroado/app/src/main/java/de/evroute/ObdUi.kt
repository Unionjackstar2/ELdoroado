@file:OptIn(ExperimentalMaterial3Api::class)

package de.evroute

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
private fun connColor(c: Obd.Conn): Color {
    val pal = LocalPal.current
    return when (c) {
        Obd.Conn.READY -> pal.green
        Obd.Conn.CONNECTING, Obd.Conn.INIT -> Color(0xFFFF9F0A)
        Obd.Conn.ERROR -> pal.red
        Obd.Conn.OFF -> pal.sub
    }
}

/** Bereich in den Einstellungen: Adapter suchen, auswählen, Optionen */
@Composable
fun ObdSettingsSection(s: AppSettings, onOpenScreen: () -> Unit) {
    val veh = Vehicles.byId(s.vehicleId)
    if (veh.obd == ObdSupport.NONE) {
        Section("OBD2") {
            Text(
                "Für ${veh.name} sind keine OBD-Abfragen hinterlegt (eigenes System). Den Akkustand stellst du in der Suche über den Regler der Fahrzeugkarte ein.",
                color = LocalPal.current.sub, fontSize = 14.sp,
            )
        }
        return
    }
    Section("Außentemperatur") {
        Text(AmbientTemp.status(), color = LocalPal.current.text, fontSize = 14.sp)
        Text("Weicht der OBD-Wert stark vom Wetter ab, nutzt die App die Wettertemperatur.", color = LocalPal.current.sub, fontSize = 12.sp)
    }
    if (veh.obd == ObdSupport.LIKELY) {
        Section("Hinweis") {
            Text(
                "Für ${veh.name} sind die Abfragen ungetestet. Sie stammen vom ë-C4 und passen auf derselben Plattform sehr wahrscheinlich. Werte bitte einmal mit dem Kombiinstrument vergleichen.",
                color = Color(0xFFFF9500), fontSize = 13.sp,
            )
        }
    }
    val pal = LocalPal.current
    val conn by Obd.conn.collectAsState()
    val status by Obd.status.collectAsState()
    val devices by Obd.devices.collectAsState()
    val scanning by Obd.scanning.collectAsState()
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { Obd.startScan() }

    Row(verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.layout.Box(Modifier.size(10.dp).clip(CircleShape).background(connColor(conn)))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(if (s.obdName.isBlank()) "Kein Adapter gewählt" else s.obdName, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(status, color = pal.sub, fontSize = 13.sp)
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
            onClick = {
                if (Obd.hasPermission()) {
                    Obd.startScan()
                } else {
                    val list = if (Build.VERSION.SDK_INT >= 31) {
                        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                    } else {
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                    }
                    perms.launch(list)
                }
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
        ) { Text(if (scanning) "Suche läuft …" else "Adapter suchen") }
        if (s.obdAddress.isNotBlank()) {
            Button(
                onClick = onOpenScreen, shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = pal.field, contentColor = pal.text),
            ) { Text("Live & Rohdaten") }
        }
    }
    if (devices.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Text("Gefundene Geräte (antippen zum Auswählen)", color = pal.sub, fontSize = 13.sp)
        devices.take(12).forEach { d ->
            val likely = listOf("OBD", "VGATE", "ICAR", "VLINK", "IOS-VLINK", "ELM", "V-LINK", "ANDROID-VLINK").any { d.name.uppercase(Locale.ROOT).contains(it) }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { Obd.select(d) }
                    .background(if (d.address == s.obdAddress) pal.blue.copy(alpha = 0.12f) else Color.Transparent)
                    .padding(vertical = 10.dp, horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(d.name + if (likely) "  ✓" else "", color = pal.text, fontSize = 15.sp, fontWeight = if (likely) FontWeight.SemiBold else FontWeight.Normal)
                    Text(d.address, color = pal.sub, fontSize = 12.sp)
                }
                Text("${d.rssi} dBm", color = pal.sub, fontSize = 12.sp)
            }
        }
    }
    Spacer(Modifier.height(8.dp))
    ToggleRow("Beim Öffnen der App verbinden", s.obdAuto) { v -> Settings.update { it.copy(obdAuto = v) } }
    ToggleRow("Neu planen, wenn Akku vom Plan abweicht", s.obdReplan) { v -> Settings.update { it.copy(obdReplan = v) } }
    Spacer(Modifier.height(6.dp))
    Label("Akkustand-Quelle")
    Segmented(listOf("SoC (D810)", "Kalibriert (D410)"), s.obdSocSource) { i -> Settings.update { it.copy(obdSocSource = i) } }
    Text(
        "Wähle den Wert, der zur Anzeige im Auto passt (in „Live & Rohdaten“ siehst du beide).",
        color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
    )
    if (s.obdAddress.isNotBlank()) {
        TextButton(onClick = { Obd.forget() }) { Text("Adapter vergessen", color = pal.red) }
    }
}

/** Vollbild: Live-Werte, Kalibrierung, Konsole und Protokoll */
@Composable
fun ObdScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by Settings.state.collectAsState()
    val conn by Obd.conn.collectAsState()
    val status by Obd.status.collectAsState()
    val values by Obd.values.collectAsState()
    val log by Obd.log.collectAsState()
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var cmd by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Surface(Modifier.fillMaxSize(), color = pal.screen) {
        Column(
            Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("OBD2 live", color = pal.text, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = vm::closeObd) { Text("Fertig", color = pal.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.foundation.layout.Box(Modifier.size(10.dp).clip(CircleShape).background(connColor(conn)))
                Spacer(Modifier.width(8.dp))
                Text(status, color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { Obd.reconnectNow() }) { Text("Neu verbinden") }
            }

            Section("Werte") {
                if (values.isEmpty()) {
                    Text(
                        if (conn == Obd.Conn.READY) "Warte auf Antworten … Zündung an?" else "Noch keine Daten. Adapter steckt, Auto an?",
                        color = pal.sub, fontSize = 14.sp,
                    )
                }
                val order = Obd.PIDS.map { it.key } + listOf("power", "capacity")
                values.entries.sortedBy { order.indexOf(it.key).let { i -> if (i < 0) 99 else i } }.forEach { (key, v) ->
                    val age = (System.currentTimeMillis() - v.time) / 1000
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(v.label, color = pal.text, fontSize = 15.sp)
                            if (v.raw.isNotBlank()) {
                                Text("roh: ${v.raw}" + if (age > 10) " · vor $age s" else "", color = pal.sub, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                        Text(
                            v.value?.let { String.format(Locale.GERMANY, if (v.unit == "%" || v.unit == "V") "%.2f" else "%.1f", it) + " " + v.unit } ?: "–",
                            color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                        )
                    }
                    if (key == "capacity") {
                        v.value?.let { cap ->
                            TextButton(onClick = { Settings.update { it.copy(usableKwh = (cap * 2).toInt() / 2.0) } }) {
                                Text("Als nutzbare Kapazität übernehmen (jetzt ${String.format(Locale.GERMANY, "%.1f", s.usableKwh)} kWh)", fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            Section("Kalibrierung Spannung und Strom") {
                Text(
                    "Bei diesen beiden Werten sind sich die Quellen nicht einig. Vergleiche die Rohwerte mit Car Scanner und passe die Faktoren an.",
                    color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp),
                )
                NumberField("Faktor Spannung (V pro Rohwert)", s.obdVoltFactor) { v -> Settings.update { it.copy(obdVoltFactor = v) } }
                NumberField("Faktor Strom (A pro Rohwert)", s.obdCurrFactor) { v -> Settings.update { it.copy(obdCurrFactor = v) } }
                NumberField("Versatz Strom (A)", s.obdCurrOffset) { v -> Settings.update { it.copy(obdCurrOffset = v) } }
                ToggleRow("Strom mit Vorzeichen (laden = negativ)", s.obdCurrSigned) { v -> Settings.update { it.copy(obdCurrSigned = v) } }
                ToggleRow("Leistung aus Strom × Spannung anzeigen", s.obdPowerEnabled) { v -> Settings.update { it.copy(obdPowerEnabled = v) } }
            }

            Section("Konsole") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ATI", "ATRV", "ATSH6B4", "ATCRA694", "22D810", "22D860", "ATSH6A2", "ATCRA682").forEach { q ->
                        Text(
                            q, color = pal.blue, fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(pal.field).clickable { cmd = q }.padding(horizontal = 8.dp, vertical = 6.dp),
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = cmd, onValueChange = { cmd = it }, singleLine = true,
                        label = { Text("Befehl, z. B. 22D810") }, modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val c = cmd.trim()
                            if (c.isNotEmpty() && !busy) {
                                busy = true
                                scope.launch { Obd.console(c); busy = false }
                            }
                        },
                        enabled = conn == Obd.Conn.READY && !busy,
                        shape = RoundedCornerShape(12.dp),
                    ) { if (busy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Text("Senden") }
                }
                ToggleRow("Auch die laufenden Abfragen protokollieren", s.obdLogPolling) { v -> Settings.update { it.copy(obdLogPolling = v) } }
            }

            Section("Protokoll") {
                Row {
                    TextButton(onClick = { clip.setText(AnnotatedString(log.joinToString("\n"))) }) { Text("Kopieren") }
                    TextButton(onClick = { Obd.clearLog() }) { Text("Leeren") }
                }
                if (log.isEmpty()) Text("Noch keine Einträge.", color = pal.sub, fontSize = 13.sp)
                log.takeLast(120).reversed().forEach { line ->
                    Text(line, color = pal.text, fontSize = 12.sp, fontFamily = FontFamily.Monospace, maxLines = 4, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: Double, onChange: (Double) -> Unit) {
    var text by remember { mutableStateOf(trimNum(value)) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            text = t
            t.replace(',', '.').toDoubleOrNull()?.let(onChange)
        },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    )
}

private fun trimNum(v: Double): String = String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')

/** Akkustand vom OBD für die Anzeige (oder null) */
@Composable
fun obdSocState(): Double? {
    val vals by Obd.values.collectAsState()
    val src by Settings.state.collectAsState()
    val key = if (src.obdSocSource == 1) "socCal" else "soc"
    val v = vals[key]
    return if (v != null && System.currentTimeMillis() - v.time < 120_000) v.value else null
}
