package de.evroute

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * 3D-Fahrzeuge als vorgerenderte Ansichten (72 Richtungen, alle 5°).
 * Modelle: Kenney „Car Kit“ (CC0) und Quaternius „Spaceship Pack“.
 * Die Lackflächen liegen als Maske bei und werden zur Laufzeit eingefärbt.
 */
object VehicleSprites {
    const val FRAMES = 72

    fun assetId(v: VehicleIcon): String? = when (v) {
        VehicleIcon.COMPACT3D -> "car_compact"
        VehicleIcon.SUV3D -> "car_suv"
        VehicleIcon.SPORT3D -> "car_sport"
        VehicleIcon.FUTURE3D -> "car_future"
        VehicleIcon.SHIP3 -> "ship_3"
        VehicleIcon.SHIP4 -> "ship_4"
        else -> null
    }

    fun isSprite(v: VehicleIcon) = assetId(v) != null

    private var cacheKey = ""
    private var cache: Array<Bitmap>? = null

    /** Bildnummer zur Fahrtrichtung relativ zur Karte (0 = nach oben, im Uhrzeigersinn) */
    fun frameFor(relBearing: Double): Int = ((((relBearing % 360) + 360) % 360) / 5.0).roundToInt() % FRAMES

    /** Alle 72 Ansichten, eingefärbt (color = null: Originalfarbe des Modells) */
    @Synchronized
    fun frames(ctx: Context, v: VehicleIcon, color: Int?): Array<Bitmap>? {
        val id = assetId(v) ?: return null
        val key = "$id/$color"
        if (key == cacheKey) cache?.let { return it }
        return runCatching {
            val meta = JSONObject(ctx.assets.open("vehicles/vehicles.json").bufferedReader().readText()).getJSONObject(id)
            val cell = meta.getInt("cell")
            val cols = meta.getInt("cols")
            val paint = android.graphics.Color.parseColor(meta.getString("paint"))
            val tint = color ?: paint
            val opts = BitmapFactory.Options().apply { inScaled = false; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val base = ctx.assets.open("vehicles/$id.webp").use { BitmapFactory.decodeStream(it, null, opts) }!!
            val mask = ctx.assets.open("vehicles/${id}_mask.webp").use { BitmapFactory.decodeStream(it, null, opts) }!!
            val tr = android.graphics.Color.red(tint) / 255f
            val tg = android.graphics.Color.green(tint) / 255f
            val tb = android.graphics.Color.blue(tint) / 255f
            val px = IntArray(cell * cell)
            val mk = IntArray(cell * cell)
            val out = Array(FRAMES) { k ->
                val x = (k % cols) * cell
                val y = (k / cols) * cell
                base.getPixels(px, 0, cell, x, y, cell, cell)
                mask.getPixels(mk, 0, cell, x, y, cell, cell)
                for (i in px.indices) {
                    val m = (mk[i] shr 16 and 0xFF) / 255f
                    if (m <= 0f) continue
                    val c = px[i]
                    val a = c ushr 24
                    val r = (c shr 16 and 0xFF); val g = (c shr 8 and 0xFF); val b = (c and 0xFF)
                    // Lack: weiß gerenderte Helligkeit × Wunschfarbe
                    val nr = (r * (1 - m) + r * tr * m).toInt().coerceIn(0, 255)
                    val ng = (g * (1 - m) + g * tg * m).toInt().coerceIn(0, 255)
                    val nb = (b * (1 - m) + b * tb * m).toInt().coerceIn(0, 255)
                    px[i] = (a shl 24) or (nr shl 16) or (ng shl 8) or nb
                }
                Bitmap.createBitmap(px, cell, cell, Bitmap.Config.ARGB_8888).also {
                    // Anzeigegröße auf der Karte: etwa 60 dp
                    it.density = (cell / 60f * 160f).toInt()
                }
            }
            base.recycle(); mask.recycle()
            cacheKey = key
            cache = out
            out
        }.onFailure { CrashLog.note("3D-Fahrzeug: ${it.message}") }.getOrNull()
    }
}
