package de.evroute

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.cos
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

// ---------------- HTTP ----------------

object Http {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    data class Resp(val code: Int, val body: String)

    suspend fun call(req: Request): Resp = withContext(Dispatchers.IO) {
        ApiCounter.classify(req.url.host, req.url.encodedPath)?.let { ApiCounter.count(it) }
        client.newCall(req).execute().use { r -> Resp(r.code, r.body?.string() ?: "") }
    }

    /** Liefert den Text auch bei 4xx (Fehlermeldung des Servers), wirft bei 5xx */
    suspend fun get(url: String): String {
        val r = call(Request.Builder().url(url).header("User-Agent", "ELdoroado (privat)").build())
        if (r.code >= 500) throw IOException("Server-Fehler ${r.code}")
        return r.body
    }
}

val json = Json { ignoreUnknownKeys = true }

// kleine Helfer für JSON
private fun JsonObject.obj(k: String): JsonObject? = (this[k] as? JsonObject)
private fun JsonObject.arr(k: String): JsonArray = (this[k] as? JsonArray) ?: JsonArray(emptyList())
private fun JsonObject.num(k: String): Double? = (this[k] as? JsonPrimitive)?.doubleOrNull
private fun JsonObject.int(k: String): Int? = (this[k] as? JsonPrimitive)?.let { it.intOrNull ?: it.contentOrNull?.toIntOrNull() }
private fun JsonObject.str(k: String): String = (this[k] as? JsonPrimitive)?.contentOrNull ?: ""
private val JsonElement.d: Double get() = jsonPrimitive.doubleOrNull ?: 0.0

private fun cumulative(pts: List<LatLon>): DoubleArray {
    val cum = DoubleArray(pts.size)
    for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
    return cum
}

// ---------------- Routing ohne Schlüssel (OSRM, Rückfall) ----------------

object Routing {
    private const val BASE = "https://router.project-osrm.org/route/v1/driving/"

    suspend fun routes(
        from: LatLon,
        bearing: Float?,
        to: LatLon,
        exclude: List<String>,
        alternatives: Int,
        vias: List<LatLon> = emptyList(),
    ): List<Route> {
        val coords = listOf(from) + vias + listOf(to)
        val url = buildString {
            append(BASE)
            append(coords.joinToString(";") { "${it.lon.f6()},${it.lat.f6()}" })
            append("?overview=full&geometries=geojson&steps=true")
            append("&alternatives=").append(if (alternatives > 0 && vias.isEmpty()) alternatives.toString() else "false")
            if (bearing != null) append("&bearings=${bearing.roundToInt().mod(360)},45" + ";0,180".repeat(coords.size - 1))
            if (exclude.isNotEmpty()) append("&exclude=").append(exclude.joinToString(","))
        }
        return parseResponse(Http.get(url), 5, "OSRM")
    }

    /** OSRM-Antwort (auch von Valhalla im OSRM-Format) in Routen übersetzen */
    fun parseResponse(body: String, precision: Int, source: String): List<Route> {
        val root = json.parseToJsonElement(body).jsonObject
        val code = root.str("code")
        if (code.isNotBlank() && !code.equals("Ok", true)) throw IOException(root.str("message").ifBlank { "Routing-Fehler ($code)" })
        return root.arr("routes").map { parse(it.jsonObject, precision, source) }
    }

    /** Google-Polyline mit wählbarer Genauigkeit (5 = OSRM, 6 = Valhalla) */
    fun decodePolyline(s: String, precision: Int): List<LatLon> {
        val f = Math.pow(10.0, precision.toDouble())
        val out = ArrayList<LatLon>(s.length / 4)
        var i = 0; var lat = 0L; var lon = 0L
        fun next(): Long {
            var shift = 0; var res = 0L; var b: Int
            do { b = s[i++].code - 63; res = res or ((b and 0x1f).toLong() shl shift); shift += 5 } while (b >= 0x20 && i < s.length)
            return if (res and 1L != 0L) (res shr 1).inv() else res shr 1
        }
        while (i < s.length) {
            lat += next(); if (i >= s.length) break
            lon += next()
            out += LatLon(lat / f, lon / f)
        }
        return out
    }

    private fun parse(r: JsonObject, precision: Int = 5, source: String = "OSRM"): Route {
        val g = r["geometry"]
        val pts = if (g is JsonPrimitive && g.isString) decodePolyline(g.content, precision)
        else r.obj("geometry")?.arr("coordinates")?.map { c ->
            val a = c.jsonArray
            LatLon(a[1].d, a[0].d)
        } ?: emptyList()
        val steps = mutableListOf<Step>()
        var summary = ""
        val legsArr = r.arr("legs")
        val angles = ArrayList<Double?>()
        legsArr.forEachIndexed { li, lg ->
            val leg = lg.jsonObject
            if (summary.isEmpty()) summary = leg.str("summary")
            leg.arr("steps").forEach { st ->
                val mm = st.jsonObject.obj("maneuver")
                val b0 = mm?.num("bearing_before"); val b1 = mm?.num("bearing_after")
                angles += if (b0 == null || b1 == null) null else ((b1 - b0 + 540) % 360) - 180
                var step = parseStep(st.jsonObject)
                // Zwischenstopps: „Ankunft“ mitten in der Route ist ein Zwischenziel, „Abfahrt“ danach ein Weiterfahren
                if (li < legsArr.size - 1 && step.type == "arrive") step = step.copy(type = "via", mod = null, phrase = Phrases.build("via", null, null))
                if (li > 0 && step.type == "depart") step = step.copy(type = "continue", mod = "straight", phrase = Phrases.build("continue", "straight", null))
                steps += step
            }
        }
        val cum = cumulative(pts)
        val osrmDist = r.num("distance") ?: 0.0
        val dur = r.num("duration") ?: 0.0
        val scale = if (osrmDist > 0 && cum.isNotEmpty()) cum.last() / osrmDist else 1.0
        val stepAlong = DoubleArray(steps.size)
        val stepTime = DoubleArray(steps.size)
        var acc = 0.0
        var t = 0.0
        steps.forEachIndexed { i, s ->
            stepAlong[i] = acc * scale
            stepTime[i] = t
            acc += s.distanceM
            t += s.durationS
        }
        // Manöver anhand von Winkel und Straßenart genauer einordnen (wie bei TomTom und ORS)
        val refined = steps.mapIndexed { i, st ->
            val nums = { x: Step -> Regex("\\b([ABLK])\\s?(\\d{1,4})\\b").findAll(x.road).map { it.groupValues[1] + it.groupValues[2] }.toList() }
            val ref = ManeuverRefiner.refine(
                st.type, st.mod,
                when {
                    st.mod?.contains("left") == true -> if (st.type == "fork") "KEEP_LEFT" else "TURN_LEFT"
                    st.mod?.contains("right") == true -> if (st.type == "fork") "KEEP_RIGHT" else "TURN_RIGHT"
                    else -> "STRAIGHT"
                },
                if (st.type == "fork") "BIFURCATION" else if (st.type.startsWith("roundabout") || st.type == "rotary") "ROUNDABOUT" else "REGULAR",
                angles.getOrNull(i), steps.getOrNull(i - 1)?.let(nums) ?: emptyList(), nums(st), st.towards,
            )
            if (ref.type == st.type && ref.mod == st.mod && ref.phrase == null) st
            else st.copy(type = ref.type, mod = ref.mod, phrase = ref.phrase ?: Phrases.build(ref.type, ref.mod, st.exit), phraseHasRoad = ref.phraseHasRoad)
        }
        return Route(pts, cum, stepAlong, stepTime, osrmDist, dur, dur, refined, summary, source = source)
    }

    private fun parseStep(s: JsonObject): Step {
        val m = s.obj("maneuver") ?: JsonObject(emptyMap())
        val type = m.str("type")
        val mod = (m["modifier"] as? JsonPrimitive)?.contentOrNull
        val exit = m.int("exit")
        val ref = s.str("ref").split(';').firstOrNull()?.trim() ?: ""
        val road = listOf(ref, s.str("name")).filter { it.isNotBlank() }.distinct().joinToString(" · ")
        val dest = s.str("destinations")
        val exits = s.str("exits")
        val towards0 = if (dest.contains(": ")) dest.substringAfter(": ") else dest
        // Ausfahrtnummer bei Abfahrten mit ansagen („Ausfahrt 89, Schwerte“)
        val towards = if (type == "off ramp" && exits.isNotBlank()) listOf("Ausfahrt ${exits.split(';').first().trim()}", towards0).filter { it.isNotBlank() }.joinToString(" · ") else towards0
        return Step(type, mod, exit, road, towards, s.num("distance") ?: 0.0, s.num("duration") ?: 0.0, Phrases.build(type, mod, exit))
    }
}

/** Ordnungszahl als Wort, damit die Ansage „zweite“ statt „zwei“ sagt */
fun ordinalDe(n: Int): String = when (n) {
    1 -> "erste"; 2 -> "zweite"; 3 -> "dritte"; 4 -> "vierte"; 5 -> "fünfte"
    6 -> "sechste"; 7 -> "siebte"; 8 -> "achte"; 9 -> "neunte"; 10 -> "zehnte"
    else -> "$n."
}

/** Deutsche Manöver-Texte */
object Phrases {
    private fun dir(mod: String?) = when (mod) {
        "left" -> "links"
        "right" -> "rechts"
        "slight left" -> "leicht links"
        "slight right" -> "leicht rechts"
        "sharp left" -> "scharf links"
        "sharp right" -> "scharf rechts"
        else -> "geradeaus"
    }

    fun build(type: String, mod: String?, exit: Int?): String = when (type) {
        "depart" -> "losfahren"
        "arrive" -> "Ziel erreichen"
        "charge" -> "Ladestopp erreichen"
        "via" -> "Zwischenziel erreichen"
        "ferry" -> "die Fähre nehmen"
        "roundabout", "rotary", "roundabout turn" ->
            if (exit != null) "im Kreisverkehr die ${ordinalDe(exit)} Ausfahrt nehmen" else "in den Kreisverkehr fahren"
        "merge" -> if (mod == null || mod == "straight") "einfädeln" else "${dir(mod)} einfädeln"
        "on ramp" -> "die Auffahrt nehmen"
        "off ramp" -> if (mod == null || mod == "straight") "die Ausfahrt nehmen" else "${dir(mod)} die Ausfahrt nehmen"
        "fork" -> "an der Gabelung ${dir(mod)} halten"
        "end of road" -> "am Ende der Straße ${dir(mod)} abbiegen"
        "continue", "new name" -> when (mod) {
            null, "straight" -> "geradeaus weiterfahren"
            "uturn" -> "wenden"
            else -> "${dir(mod)} halten"
        }
        else -> when (mod) {
            null, "straight" -> "geradeaus weiterfahren"
            "uturn" -> "wenden"
            else -> "${dir(mod)} abbiegen"
        }
    }
}

// ---------------- Suche (Photon / OpenStreetMap) ----------------

object Geocode {
    private val cache = TtlCache<List<Place>>(15 * 60_000L)

    suspend fun search(q: String, near: LatLon?): List<Place> {
        // Standort auf ~1 km gerundet: dieselbe Suche in der Nähe nutzt das gespeicherte Ergebnis
        val ck = q.trim().lowercase() + "|" + (near?.let { "%.2f,%.2f".format(java.util.Locale.US, it.lat, it.lon) } ?: "")
        cache.get(ck)?.let { return it }
        return searchRaw(q, near).also { if (it.isNotEmpty()) cache.put(ck, it) }
    }

    private suspend fun searchRaw(q: String, near: LatLon?): List<Place> {
        val bias = if (near != null) "&lat=${near.lat.f6()}&lon=${near.lon.f6()}" else ""
        val url = "https://photon.komoot.io/api/?limit=7&lang=de$bias&q=" + URLEncoder.encode(q, "UTF-8")
        return json.parseToJsonElement(Http.get(url)).jsonObject.arr("features").mapNotNull { f ->
            val p = f.jsonObject.obj("properties") ?: return@mapNotNull null
            val c = f.jsonObject.obj("geometry")?.arr("coordinates") ?: return@mapNotNull null
            val street = listOf(p.str("street"), p.str("housenumber")).filter { it.isNotBlank() }.joinToString(" ")
            val first = p.str("name").ifBlank { street }
            val parts = listOf(first, if (first == street) "" else street, p.str("city"), p.str("country"))
                .filter { it.isNotBlank() }.distinct()
            val type = p.str("osm_type")
            val id = (p["osm_id"] as? JsonPrimitive)?.contentOrNull ?: ""
            Place(
                parts.joinToString(", "), LatLon(c[1].d, c[0].d),
                osm = if (type.isNotBlank() && id.isNotBlank()) "$type$id" else null,
                kind = listOf(p.str("osm_key"), p.str("osm_value")).filter { it.isNotBlank() }.joinToString("="),
            )
        }
    }
}

/** Adresse zu einem Kartenpunkt (für langes Drücken) */
object Reverse {
    suspend fun name(p: LatLon): String {
        val url = "https://photon.komoot.io/reverse?lang=de&lat=${p.lat.f6()}&lon=${p.lon.f6()}"
        val f = runCatching { json.parseToJsonElement(Http.get(url)).jsonObject.arr("features").firstOrNull()?.jsonObject }.getOrNull()
        val pr = f?.obj("properties") ?: return "Markierter Ort"
        val street = listOf(pr.str("street"), pr.str("housenumber")).filter { it.isNotBlank() }.joinToString(" ")
        val first = pr.str("name").ifBlank { street }.ifBlank { "Markierter Ort" }
        return listOf(first, if (first == street) "" else street, pr.str("city")).filter { it.isNotBlank() }.distinct().joinToString(", ")
    }
}

// ---------------- Wetter entlang der Strecke (Open-Meteo) ----------------

object Weather {
    /** Temperatur, Gegenwind und Regen an 5 Punkten zur voraussichtlichen Durchfahrtszeit */
    suspend fun along(from: LatLon, to: LatLon): WeatherInfo {
        val n = 5
        val pts = (0 until n).map { lerp(from, to, it / (n - 1.0)) }
        val km = haversine(from, to) / 1000 * 1.25
        val lat = pts.joinToString(",") { String.format(Locale.US, "%.4f", it.lat) }
        val lon = pts.joinToString(",") { String.format(Locale.US, "%.4f", it.lon) }
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&hourly=temperature_2m,precipitation,wind_speed_10m,wind_direction_10m&forecast_days=3&timezone=GMT"
        val root = json.parseToJsonElement(Http.get(url))
        val list = (root as? JsonArray)?.map { it.jsonObject } ?: listOf(root.jsonObject)
        val now = ZonedDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:00"))
        val travel = bearing(from, to)
        var tSum = 0.0
        var hSum = 0.0
        var rainy = 0
        var count = 0
        list.forEachIndexed { i, o ->
            val h = o.obj("hourly") ?: return@forEachIndexed
            val times = h.arr("time").map { it.jsonPrimitive.content }
            if (times.isEmpty()) return@forEachIndexed
            val base = times.indexOf(now).coerceAtLeast(0)
            val eta = (km * i / (n - 1) / 85.0).roundToInt()
            val k = (base + eta).coerceAtMost(times.lastIndex)
            val temp = h.arr("temperature_2m").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: return@forEachIndexed
            val ws = h.arr("wind_speed_10m").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: 0.0
            val wd = h.arr("wind_direction_10m").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: 0.0
            val pr = h.arr("precipitation").getOrNull(k)?.jsonPrimitive?.doubleOrNull ?: 0.0
            tSum += temp
            hSum += ws * cos(Math.toRadians(wd - travel)) // Wind „aus“ Fahrtrichtung = Gegenwind
            if (pr > 0.3) rainy++
            count++
        }
        if (count == 0) throw IOException("Keine Wetterdaten")
        return WeatherInfo(tSum / count, hSum / count, rainy * 2 >= count)
    }
}

// ---------------- Verbrauchsmodell (Grundlage ë-C4 2022, je Fahrzeug skaliert) ----------------

object EvModel {
    private val SPEEDS = intArrayOf(20, 40, 60, 80, 100, 120, 140)

    private fun styleFactor(s: AppSettings) = when (s.style) {
        0 -> 0.94
        2 -> 1.08
        else -> 1.0
    }

    /** Grundmodell ohne Wind, Regen, Fahrweise und Gelerntes (für das Lernen) */
    fun basePer100(v: Double, tempC: Double): Double {
        val base = (8.5 + 0.00082 * v * v) * Vehicles.current().eff
        val cold = 1.0 + 0.007 * max(0.0, 15.0 - tempC)
        return base * cold
    }

    /** kWh/100 km bei konstantem Tempo, inkl. Wind, Kälte, Regen, Fahrweise bzw. gelerntem Verhalten (ohne Heizung/Klima) */
    fun kwhPer100(v: Double, s: AppSettings, w: WeatherInfo?): Double {
        val air = (v + (w?.headwindKmh ?: 0.0)).coerceAtLeast(0.0)
        val temp = w?.tempC ?: 15.0
        val base = (8.5 + 0.00082 * air * air) * Vehicles.byId(s.vehicleId).eff
        val cold = 1.0 + 0.007 * max(0.0, 15.0 - temp)
        val rain = if (w?.rain == true) 1.06 else 1.0
        // Gelerntes ersetzt die Fahrweise, je nachdem wie viele Kilometer schon gelernt sind
        val (learned, conf) = if (s.useLearned) Learner.factor(v, temp) else (1.0 to 0.0)
        val behaviour = styleFactor(s) * (1 - conf) + learned * conf
        val ref = s.refConsumptionPct / 100.0
        val weight = 1.0 + 0.0002 * s.extraWeightKg
        return base * cold * rain * behaviour * ref * weight
    }

    /** Heizung bzw. Klimaanlage in kW */
    fun auxKw(w: WeatherInfo?): Double {
        val t = w?.tempC ?: 15.0
        return when {
            t < 0 -> 2.5
            t < 8 -> 1.8
            t < 15 -> 1.0
            t < 24 -> 0.4
            t < 30 -> 0.9
            else -> 1.4
        }
    }

    fun curveParam(s: AppSettings, w: WeatherInfo?): String =
        SPEEDS.joinToString(":") { v -> String.format(Locale.US, "%d,%.2f", v, kwhPer100(v.toDouble(), s, w)) }

    /** Ladekurve des gewählten Fahrzeugs (Startwerte) als (Akku kWh, max. kW); Gelerntes hat Vorrang */
    fun batteryCurve(usable: Double): List<Pair<Double, Double>> {
        val set = Settings.state.value
        val useLearned = set.useLearned
        val v = Vehicles.byId(set.vehicleId)
        val shape = when (v.curve) {
            "ecmp1" -> listOf(0.0 to 80.0, 0.10 to 100.0, 0.30 to 85.0, 0.50 to 65.0, 0.70 to 48.0, 0.80 to 36.0, 0.90 to 22.0, 1.0 to 7.0)
            "ecmp2" -> listOf(0.0 to 85.0, 0.10 to 100.0, 0.30 to 95.0, 0.50 to 75.0, 0.70 to 55.0, 0.80 to 40.0, 0.90 to 22.0, 1.0 to 7.0)
            else -> {
                val p = Vehicles.maxDc(set)
                listOf(0.0 to 0.8, 0.10 to 1.0, 0.30 to 0.95, 0.50 to 0.8, 0.70 to 0.6, 0.80 to 0.45, 0.90 to 0.25, 1.0 to 0.08).map { it.first to it.second * p }
            }
        }
        return shape.map { (f, kw) ->
            val learned = if (useLearned) Learner.chargeAt(f * 100 - if (f >= 1.0) 1.0 else 0.0) else null
            f * usable to (learned ?: kw)
        }
    }

    /** Schätzung ohne Ladeplanung (Rückfall ohne TomTom) */
    fun estimateSimple(r: Route, s: AppSettings, startSoc: Double, w: WeatherInfo?): Route {
        val hours = max(r.driveS, 1.0) / 3600
        val avgKmh = (r.distanceM / 1000) / hours
        // Höhenmeter (nur wenn die Route sie liefert, z. B. OpenRouteService)
        val kwh = r.distanceM / 1000 * kwhPer100(avgKmh * 1.1, s, w) / 100 + auxKw(w) * hours + Ors.climbKwh(r)
        val arrival = startSoc - kwh / s.usableKwh * 100
        val ok = arrival >= s.minSocDest
        return r.copy(
            socProfile = listOf(0.0 to startSoc, r.cumM.lastOrNull().orZero() to arrival),
            arrivalSoc = arrival,
            feasible = ok,
            reason = if (ok) null else "Akku reicht nicht bis zum Ziel. Für automatische Ladestopps TomTom-Key in den Einstellungen eintragen.",
            weather = w,
        )
    }

    private fun Double?.orZero() = this ?: 0.0
}

// ---------------- TomTom ----------------

object TomTom {
    private const val BASE = "https://api.tomtom.com"
    private val JSON_TYPE = "application/json".toMediaType()

    fun trafficTileUrl(key: String, dark: Boolean): String =
        "$BASE/traffic/map/4/tile/flow/${if (dark) "relative0-dark" else "relative0"}/{z}/{x}/{y}.png?key=$key&tileSize=256&thickness=8"

    fun avoids(s: AppSettings, noToll: Boolean): List<String> = buildList {
        if (s.avoidToll || noToll) add("tollRoads")
        if (s.avoidMotorway) add("motorways")
        if (s.avoidFerry) add("ferries")
    }

    private fun errorText(r: Http.Resp): String {
        val o = runCatching { json.parseToJsonElement(r.body).jsonObject }.getOrNull()
        val msg = o?.obj("detailedError")?.str("message")?.ifBlank { null }
            ?: o?.obj("error")?.str("description")?.ifBlank { null }
        return when {
            r.code == 403 -> "TomTom-Key ungültig oder Tageslimit erreicht (403)"
            msg != null -> "TomTom: $msg"
            else -> "TomTom-Fehler ${r.code}"
        }
    }

    /** Langstrecken-Routing mit automatischen Ladestopps, Verkehr und Abbiegehinweisen */
    suspend fun ldev(
        s: AppSettings,
        from: LatLon,
        heading: Float?,
        to: LatLon,
        socPct: Double,
        w: WeatherInfo?,
        avoid: List<String>,
        alternatives: Int,
        avoidParks: List<String>,
        vias: List<Via> = emptyList(),
        chargeIndexMode: Int = 0, // 0 = Index unter den Zwischenstopps, 1 = Index in allen Orten, 2 = Ladestationen als normale Stopps
        withLanes: Boolean = true,
    ): List<Route> {
        val usable = s.usableKwh
        val locs = listOf(from) + vias.map { it.place.pos } + listOf(to)
        val cur = (socPct.coerceIn(1.0, 100.0) / 100 * usable).coerceAtMost(usable)
        val url = buildString {
            append("$BASE/routing/1/calculateLongDistanceEVRoute/")
            append(locs.joinToString(":") { "${it.lat.f6()},${it.lon.f6()}" }).append("/json")
            append("?key=").append(s.tomtomKey.trim())
            append("&vehicleEngineType=electric")
            append("&constantSpeedConsumptionInkWhPerHundredkm=").append(EvModel.curveParam(s, w))
            append("&currentChargeInkWh=").append(String.format(Locale.US, "%.2f", cur))
            append("&maxChargeInkWh=").append(String.format(Locale.US, "%.2f", usable))
            append("&minChargeAtDestinationInkWh=").append(String.format(Locale.US, "%.2f", s.minSocDest / 100 * usable))
            append("&minChargeAtChargingStopsInkWh=").append(String.format(Locale.US, "%.2f", s.minSocStop / 100 * usable))
            append("&auxiliaryPowerInkW=").append(String.format(Locale.US, "%.2f", EvModel.auxKw(w)))
            append("&consumptionInkWhPerkmAltitudeGain=5.0&recuperationInkWhPerkmAltitudeLoss=3.0")
            append("&traffic=true&routeType=fastest&travelMode=car")
            append("&instructionsType=text&language=de-DE&sectionType=traffic&sectionType=speedLimit")
            if (withLanes) append("&sectionType=lanes")
            append("&chargingStopsStrategy=automaticFastestWithFallbackToManual")
            append("&maxAlternatives=").append(if (vias.isEmpty()) alternatives else 0)
            if (heading != null) append("&vehicleHeading=").append(heading.roundToInt().mod(360))
            if (s.maxSpeedKmh > 0) append("&vehicleMaxSpeed=").append(s.maxSpeedKmh.coerceIn(30, 250))
            avoid.forEach { append("&avoid=").append(it) }
        }
        val body = buildJsonObject {
            putJsonObject("chargingParameters") {
                put("batteryCurveInterpolation", "piecewiseLinear")
                putJsonArray("batteryCurve") {
                    EvModel.batteryCurve(usable).forEach { (kwh, kw) ->
                        addJsonObject {
                            put("stateOfChargeInkWh", kwh)
                            put("maxPowerInkW", kw)
                        }
                    }
                }
                putJsonArray("chargingConnectors") {
                    addJsonObject {
                        put("currentType", "DC")
                        putJsonArray("plugTypes") { add("Combo_to_IEC_62196_Type_2_Base") }
                        put("efficiency", 0.92)
                        put("maxPowerInkW", Vehicles.maxDc(s))
                    }
                }
                put("chargingTimeOffsetInSec", 120)
            }
            if (avoidParks.isNotEmpty()) putJsonArray("avoidChargingParks") { avoidParks.take(40).forEach { add(it) } }
            if (s.preferOperators.isNotEmpty()) putJsonArray("preferChargingParkOperators") { s.preferOperators.take(20).forEach { add(it) } }
            if (s.avoidOperators.isNotEmpty()) putJsonArray("avoidChargingParkOperators") { s.avoidOperators.take(40).forEach { add(it) } }
            if (s.preferredMsps.isNotEmpty()) putJsonArray("preferredMSPs") { s.preferredMsps.take(20).forEach { add(it) } }
            if (vias.isNotEmpty()) {
                val chargers = vias.withIndex().filter { it.value.isCharger && it.value.chargeParkId != null }
                if (chargeIndexMode < 2 && chargers.isNotEmpty()) {
                    putJsonArray("chargingWaypoints") {
                        chargers.forEach { (i, v) ->
                            addJsonObject {
                                put("waypointIndex", if (chargeIndexMode == 0) i else i + 1)
                                put("chargingParkId", v.chargeParkId)
                            }
                        }
                    }
                }
                putJsonArray("legs") {
                    vias.forEach { v ->
                        addJsonObject {
                            val pause = if (v.isCharger && chargeIndexMode < 2) 0 else v.pauseMin * 60 + if (v.isCharger) 1500 else 0
                            if (pause > 0) putJsonObject("routeStop") { put("pauseTimeInSeconds", pause) }
                        }
                    }
                    addJsonObject { }
                }
            }
        }
        ApiCounter.hit()
        val req = Request.Builder().url(url).post(body.toString().toRequestBody(JSON_TYPE)).build()
        val r = Http.call(req)
        if (r.code != 200) {
            // Spurdaten werden vom Key/Endpunkt nicht unterstützt: ohne Spuren erneut versuchen
            if (withLanes && (r.code == 403 || (r.code == 400 && (r.body.contains("lane", true) || r.body.contains("sectionType", true))))) {
                return ldev(s, from, heading, to, socPct, w, avoid, alternatives, avoidParks, vias, chargeIndexMode, withLanes = false)
            }
            // Feste Ladestopps: falls die Zählweise oder die Ladepark-ID nicht passt, schrittweise zurückfallen
            if (r.code == 400 && chargeIndexMode < 2 && vias.any { it.isCharger }) {
                return ldev(s, from, heading, to, socPct, w, avoid, alternatives, avoidParks, vias, chargeIndexMode + 1, withLanes)
            }
            throw IOException(errorText(r))
        }
        val root = json.parseToJsonElement(r.body).jsonObject
        val routes = root.arr("routes")
        if (routes.isEmpty()) throw IOException("TomTom hat keine Route gefunden")
        val out = routes.map { parseRoute(it.jsonObject, s, socPct, w, vias) }
        KnownOperators.note(out.flatMap { rt -> rt.stops.map { it.operator } })
        return if (chargeIndexMode == 2) out.map { it.copy(note = "Gewählte Ladestation als normaler Stopp eingeplant (TomTom kannte die Ladepark-ID nicht).") } else out
    }

    private fun maneuver(m: String): Pair<String, String?> = when (m) {
        "DEPART" -> "depart" to null
        "ARRIVE", "ARRIVE_LEFT", "ARRIVE_RIGHT" -> "arrive" to null
        "WAYPOINT_REACHED", "WAYPOINT_LEFT", "WAYPOINT_RIGHT" -> "charge" to null
        "KEEP_RIGHT" -> "fork" to "slight right"
        "KEEP_LEFT" -> "fork" to "slight left"
        "BEAR_RIGHT" -> "turn" to "slight right"
        "BEAR_LEFT" -> "turn" to "slight left"
        "TURN_RIGHT" -> "turn" to "right"
        "TURN_LEFT" -> "turn" to "left"
        "SHARP_RIGHT" -> "turn" to "sharp right"
        "SHARP_LEFT" -> "turn" to "sharp left"
        "MAKE_UTURN", "TRY_MAKE_UTURN" -> "turn" to "uturn"
        "ENTER_MOTORWAY", "ENTER_FREEWAY", "ENTER_HIGHWAY", "ENTRANCE_RAMP" -> "on ramp" to "slight right"
        "TAKE_EXIT", "MOTORWAY_EXIT_RIGHT" -> "off ramp" to "slight right"
        "MOTORWAY_EXIT_LEFT" -> "off ramp" to "slight left"
        "TAKE_FERRY" -> "ferry" to null
        "ROUNDABOUT_CROSS" -> "roundabout" to "straight"
        "ROUNDABOUT_RIGHT" -> "roundabout" to "right"
        "ROUNDABOUT_LEFT" -> "roundabout" to "left"
        "ROUNDABOUT_BACK" -> "roundabout" to "uturn"
        else -> "continue" to "straight"
    }

    private fun parseRoute(r: JsonObject, s: AppSettings, startSoc: Double, w: WeatherInfo?, vias: List<Via>): Route {
        val usable = s.usableKwh
        val sum = r.obj("summary") ?: JsonObject(emptyMap())
        val legs = r.arr("legs").map { it.jsonObject }

        // Punkte aller Abschnitte hintereinander (Indizes passen so zu den TomTom-Sections)
        val pts = mutableListOf<LatLon>()
        val legEndIdx = mutableListOf<Int>()
        legs.forEach { leg ->
            leg.arr("points").forEach { p ->
                val o = p.jsonObject
                pts += LatLon(o.num("latitude") ?: 0.0, o.num("longitude") ?: 0.0)
            }
            legEndIdx += pts.lastIndex
        }
        val cum = cumulative(pts)
        val length = sum.num("lengthInMeters") ?: cum.lastOrNull() ?: 0.0
        val scale = if (length > 0 && cum.isNotEmpty()) cum.last() / length else 1.0

        // Ladestopps
        val stops = mutableListOf<ChargeStop>()
        val legEnds = mutableListOf<Pair<String, ChargeStop?>>() // (Name, Ladestopp) für jedes Abschnittsende außer dem Ziel
        var viaNo = 0
        var pauses = 0.0
        var legTravel = 0.0
        var chargeTotal = 0.0
        val profile = mutableListOf(0.0 to startSoc)
        var ok = true
        legs.forEachIndexed { i, leg ->
            val ls = leg.obj("summary") ?: JsonObject(emptyMap())
            legTravel += ls.num("travelTimeInSeconds") ?: 0.0
            val arrive = (ls.num("remainingChargeAtArrivalInkWh") ?: 0.0) / usable * 100
            if (arrive < 0) ok = false
            val idx = legEndIdx.getOrElse(i) { pts.lastIndex }.coerceAtLeast(0)
            val along = cum.getOrElse(idx) { 0.0 }
            profile += along to arrive
            val ci = ls.obj("chargingInformationAtEndOfLeg")
            val userStop = ci == null || ci.str("chargingStopType").equals("User_Defined", ignoreCase = true)
            if (i < legs.lastIndex && userStop) {
                val v = vias.getOrNull(viaNo)
                viaNo++
                if (v != null && (ci == null || !v.isCharger)) pauses += v.pauseMin * 60.0
                if (ci == null) legEnds += (v?.place?.title ?: "Zwischenziel") to null
            }
            if (ci != null) {
                val target = (ci.num("targetChargeInkWh") ?: 0.0) / usable * 100
                val cs = ci.num("chargingTimeInSeconds") ?: 0.0
                chargeTotal += cs
                val conn = ci.obj("chargingConnectionInfo")
                stops += ChargeStop(
                    name = ci.str("chargingParkName").ifBlank { "Ladepark" },
                    operator = ci.str("chargingParkOperatorName"),
                    pos = pts.getOrElse(idx) { LatLon(0.0, 0.0) },
                    alongM = along,
                    powerKw = conn?.num("chargingPowerInkW") ?: ci.num("chargingParkPowerInkW") ?: 0.0,
                    arriveSoc = arrive,
                    targetSoc = target,
                    chargeS = cs,
                    uuid = ci.str("chargingParkUuid").ifBlank { null },
                )
                legEnds += stops.last().name to stops.last()
                profile += along to target
            }
        }
        val arrival = (sum.num("remainingChargeAtArrivalInkWh") ?: 0.0) / usable * 100
        if (arrival < 0) ok = false

        // Abbiegehinweise
        val instr = r.obj("guidance")?.arr("instructions")?.map { it.jsonObject } ?: emptyList()
        val steps = mutableListOf<Step>()
        val stepAlong = DoubleArray(instr.size)
        val stepTime = DoubleArray(instr.size)
        var endIdx = 0
        instr.forEachIndexed { i, o ->
            val off = o.num("routeOffsetInMeters") ?: 0.0
            val t = o.num("travelTimeInSeconds") ?: 0.0
            val nextOff = instr.getOrNull(i + 1)?.num("routeOffsetInMeters") ?: off
            val nextT = instr.getOrNull(i + 1)?.num("travelTimeInSeconds") ?: t
            var (type, mod) = maneuver(o.str("maneuver"))
            val numbers = o.arr("roadNumbers").mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
            var road = (numbers.take(1) + listOf(o.str("street"))).filter { it.isNotBlank() }.distinct().joinToString(" · ")
            var note = ""
            if (type == "charge") {
                val end = legEnds.getOrNull(endIdx)
                endIdx++
                val st = end?.second
                if (st != null) {
                    road = st.name
                    note = "Laden auf ${st.targetSoc.roundToInt()} Prozent, etwa ${(st.chargeS / 60).roundToInt()} Minuten."
                } else {
                    type = "via"
                    mod = null
                    road = end?.first ?: "Zwischenziel"
                }
            }
            val exit = o.int("roundaboutExitNumber")
            val exitNo = o.str("exitNumber")
            var towards = listOf(if (exitNo.isNotBlank()) "Ausfahrt $exitNo" else "", o.str("signpostText"))
                .filter { it.isNotBlank() }.joinToString(" · ")
            // Position des Manövers: Punktindex ist genauer als die Meterangabe
            val pi = o.int("pointIndex")
            val byOff = off * scale
            val along = if (pi != null && pi in cum.indices && abs(cum[pi] - byOff) < 250) cum[pi] else byOff
            // Manöver anhand von Winkel, Kreuzungsart und Straßenart genauer einordnen
            val prevNums = instr.getOrNull(i - 1)?.arr("roadNumbers")?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull } ?: emptyList()
            val ref = ManeuverRefiner.refine(
                type, mod, o.str("maneuver"), o.str("junctionType"),
                o.num("turnAngleInDecimalDegrees") ?: ManeuverRefiner.geoAngle(pts, cum, along),
                prevNums, numbers, o.str("signpostText"),
            )
            type = ref.type
            mod = ref.mod
            if (ref.phraseHasRoad) towards = o.str("signpostText")
            steps += Step(
                type, mod, exit, road, towards,
                max(0.0, nextOff - off), max(0.0, nextT - t),
                ref.phrase ?: Phrases.build(type, mod, exit), note, ref.phraseHasRoad,
            )
            stepAlong[i] = if (i > 0) max(along, stepAlong[i - 1]) else along
            stepTime[i] = t
        }

        // Tempolimits je Abschnitt
        val limits = IntArray(max(0, pts.size - 1))
        r.arr("sections").forEach { e ->
            val o = e.jsonObject
            if (o.str("sectionType") != "SPEED_LIMIT") return@forEach
            val v = o.num("maxSpeedLimitInKmh")?.roundToInt() ?: return@forEach
            val a = (o.int("startPointIndex") ?: 0).coerceIn(0, limits.size)
            val b = (o.int("endPointIndex") ?: 0).coerceIn(0, limits.size)
            for (k in a until b) limits[k] = v
        }

        // Spurinformationen
        val laneSections = r.arr("sections").mapNotNull { e ->
            val o = e.jsonObject
            if (o.str("sectionType") != "LANES") return@mapNotNull null
            val lanes = o.arr("lanes").mapNotNull { l ->
                val lo = l as? JsonObject ?: return@mapNotNull null
                Lane(
                    directions = lo.arr("directions").mapNotNull { (it as? JsonPrimitive)?.contentOrNull },
                    follow = lo.str("follow").ifBlank { null },
                )
            }
            if (lanes.size < 2) return@mapNotNull null
            LaneSection(o.int("startPointIndex") ?: 0, o.int("endPointIndex") ?: 0, lanes)
        }

        // Staus
        val jams = r.arr("sections").mapNotNull { e ->
            val o = e.jsonObject
            if (o.str("sectionType") != "TRAFFIC") return@mapNotNull null
            Jam(
                startIdx = o.int("startPointIndex") ?: 0,
                endIdx = o.int("endPointIndex") ?: 0,
                delayS = o.num("delayInSeconds") ?: 0.0,
                magnitude = o.int("magnitudeOfDelay") ?: 1,
                category = o.str("simpleCategory"),
                cause = o.obj("tec")?.arr("causes")?.firstOrNull()?.let { (it as? JsonObject)?.int("mainCauseCode") },
                speedKmh = o.num("effectiveSpeedInKmh"),
            )
        }

        // Fahrstrecken-Zusammenfassung „über A 1, A 61“
        val via = steps.filter { it.distanceM > 20_000 }.mapNotNull { st ->
            st.road.split(" · ").firstOrNull()?.takeIf { it.isNotBlank() && it.any(Char::isDigit) }
        }.distinct().take(3).joinToString(", ")

        val lastT = stepTime.lastOrNull() ?: legTravel
        val includes = chargeTotal > 0 && lastT > legTravel + chargeTotal * 0.5
        val reason = when {
            ok -> null
            stops.isEmpty() -> "Mit dem aktuellen Akkustand nicht erreichbar und keine passende Schnellladesäule gefunden."
            else -> "Ein Abschnitt ist mit dem Akku nicht erreichbar – zu wenige Schnellladesäulen auf der Strecke."
        }
        return Route(
            points = pts,
            cumM = cum,
            stepAlongM = stepAlong,
            stepTimeS = stepTime,
            distanceM = length,
            durationS = legTravel + chargeTotal + pauses,
            driveS = legTravel,
            steps = steps,
            summary = via,
            source = "TomTom",
            stops = stops,
            socProfile = profile,
            arrivalSoc = arrival,
            chargeS = chargeTotal,
            trafficDelayS = sum.num("trafficDelayInSeconds") ?: 0.0,
            jams = jams,
            timesIncludeCharging = includes,
            feasible = ok,
            reason = reason,
            weather = w,
            speedLimits = if (limits.any { it > 0 }) limits else null,
            laneSections = laneSections,
        )
    }

    /** Einen Treffer der TomTom-Suche in eine Ladestation umwandeln */
    private fun parseHit(o: JsonObject): ChargerHit? {
        val poi = o.obj("poi") ?: return null
        val pos = o.obj("position") ?: return null
        val brand = poi.arr("brands").firstOrNull()?.let { (it as? JsonObject)?.str("name") } ?: ""
        val conns = o.obj("chargingPark")?.arr("connectors")?.mapNotNull { it as? JsonObject } ?: emptyList()
        val kw = conns.mapNotNull { it.num("ratedPowerKW") }.maxOrNull() ?: 0.0
        val types = conns.map { it.str("connectorType") }
        val ccs = types.count { it.contains("CCS", true) }
        val type2 = types.count { it.startsWith("IEC62196Type2") && !it.contains("CCS", true) }
        val tesla = types.count { it.contains("Tesla", true) }
        val desc = listOfNotNull(
            if (ccs > 0) "$ccs× CCS" else null,
            if (type2 > 0) "$type2× Typ 2" else null,
            if (tesla > 0) "$tesla× Tesla" else null,
        ).joinToString(" · ")
        val name = poi.str("name").ifBlank { "Ladestation" }
        fun typeLabel(t: String) = when {
            t.contains("CCS", true) -> "CCS"
            t.contains("Tesla", true) -> "Tesla"
            t.contains("CHAdeMO", true) -> "CHAdeMO"
            t.startsWith("IEC62196Type2") -> "Typ 2"
            t.contains("Schuko", true) || t.contains("StandardHouseholdCountrySpecific", true) -> "Schuko"
            else -> t
        }
        val groups = conns.groupBy { typeLabel(it.str("connectorType")) to (it.num("ratedPowerKW") ?: 0.0) }
            .entries.sortedByDescending { it.key.second }
            .map { (k, v) -> "${v.size}× ${k.first}" + if (k.second > 0) " · ${k.second.roundToInt()} kW" else "" }
        val opening = poi.obj("openingHours")?.arr("timeRanges")?.mapNotNull { tr ->
            val o2 = tr as? JsonObject ?: return@mapNotNull null
            val st = o2.obj("startTime") ?: return@mapNotNull null
            val en = o2.obj("endTime") ?: return@mapNotNull null
            val date = st.str("date")
            val dow = runCatching { java.time.LocalDate.parse(date).dayOfWeek.value - 1 }.getOrNull() ?: return@mapNotNull null
            val label = listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")[dow]
            val sh = st.int("hour") ?: 0; val sm = st.int("minute") ?: 0
            val eh = en.int("hour") ?: 0; val em = en.int("minute") ?: 0
            val allDay = sh == 0 && sm == 0 && (eh == 0 && em == 0 || eh == 23 && em == 59) && en.str("date") != date
            label to if (allDay) "24 Stunden" else String.format("%02d:%02d–%02d:%02d", sh, sm, eh, em)
        }?.distinctBy { it.first }?.map { "${it.first}  ${it.second}" } ?: emptyList()
        val openingLines = if (opening.isNotEmpty() && opening.all { it.endsWith("24 Stunden") }) listOf("Rund um die Uhr geöffnet") else opening
        return ChargerHit(
            name = name,
            operator = brand.ifBlank { if (name.contains("Tesla", true)) "Tesla" else "" },
            pos = LatLon(pos.num("lat") ?: 0.0, pos.num("lon") ?: 0.0),
            powerKw = kw,
            detourS = 0.0,
            alongM = 0.0,
            availId = o.obj("dataSources")?.obj("chargingAvailability")?.str("id")?.ifBlank { null },
            id = o.str("id").ifBlank { "${pos.num("lat")},${pos.num("lon")}" },
            connectors = desc,
            teslaOnly = tesla > 0 && ccs == 0,
            address = o.obj("address")?.str("freeformAddress") ?: "",
            connectorGroups = groups,
            openingLines = openingLines,
        )
    }

    /** Freitextsuche nur nach Ladestationen, z. B. „Tesla Kamen“ oder „EnBW Aachen“ */
    suspend fun searchChargers(key: String, q: String, near: LatLon?, radiusM: Int? = null, limit: Int = 10): List<ChargerHit> {
        val url = buildString {
            append("$BASE/search/2/search/").append(URLEncoder.encode(q.trim(), "UTF-8").replace("+", "%20")).append(".json?key=").append(key)
            append("&categorySet=7309&limit=").append(limit).append("&language=de-DE&openingHours=nextSevenDays")
            if (radiusM == null) append("&typeahead=true")
            if (near != null) append("&lat=").append(near.lat.f6()).append("&lon=").append(near.lon.f6())
            if (radiusM != null) append("&radius=").append(radiusM)
        }
        ApiCounter.hit()
        val r = Http.call(Request.Builder().url(url).build())
        if (r.code != 200) throw IOException(errorText(r))
        val hits = json.parseToJsonElement(r.body).jsonObject.arr("results").mapNotNull { parseHit(it.jsonObject) }
        KnownOperators.note(hits.map { it.operator })
        return hits
    }

    /** Erreichbare Fläche mit einem Energiebudget (TomTom Reachable Range, über echte Straßen) */
    suspend fun reachable(s: AppSettings, from: LatLon, budgetKwh: Double, w: WeatherInfo?): List<LatLon> {
        val url = buildString {
            append("$BASE/routing/1/calculateReachableRange/${from.lat.f6()},${from.lon.f6()}/json")
            append("?key=").append(s.tomtomKey.trim())
            append("&vehicleEngineType=electric")
            append("&constantSpeedConsumptionInkWhPerHundredkm=").append(EvModel.curveParam(s, w))
            append("&energyBudgetInkWh=").append(String.format(Locale.US, "%.2f", budgetKwh.coerceAtLeast(0.5)))
            append("&auxiliaryPowerInkW=").append(String.format(Locale.US, "%.2f", EvModel.auxKw(w)))
            append("&consumptionInkWhPerkmAltitudeGain=5.0&recuperationInkWhPerkmAltitudeLoss=3.0")
            append("&routeType=fastest&traffic=false")
            if (s.maxSpeedKmh > 0) append("&vehicleMaxSpeed=").append(s.maxSpeedKmh.coerceIn(30, 250))
        }
        ApiCounter.hit()
        val r = Http.call(Request.Builder().url(url).build())
        if (r.code != 200) throw IOException(errorText(r))
        val rr = json.parseToJsonElement(r.body).jsonObject.obj("reachableRange") ?: throw IOException("Keine Reichweite erhalten")
        return rr.arr("boundary").mapNotNull { e ->
            val o = e as? JsonObject ?: return@mapNotNull null
            LatLon(o.num("latitude") ?: return@mapNotNull null, o.num("longitude") ?: return@mapNotNull null)
        }
    }

    /** Freie Ortssuche nahe einem Punkt, z. B. „Burger King“ oder „IKEA“ */
    private val poiCache = TtlCache<List<Place>>(30 * 60_000L)

    suspend fun poiSearch(key: String, q: String, near: LatLon, radiusM: Int): List<Place> {
        val ck = "p|" + q.trim().lowercase() + "|%.2f,%.2f|$radiusM".format(Locale.US, near.lat, near.lon)
        poiCache.get(ck)?.let { return it }
        return poiSearchRaw(key, q, near, radiusM).also { poiCache.put(ck, it) }
    }

    private suspend fun poiSearchRaw(key: String, q: String, near: LatLon, radiusM: Int): List<Place> {
        val url = "$BASE/search/2/search/" + URLEncoder.encode(q.trim(), "UTF-8").replace("+", "%20") +
            ".json?key=$key&lat=${near.lat.f6()}&lon=${near.lon.f6()}&radius=$radiusM&limit=15&idxSet=POI&language=de-DE"
        ApiCounter.hit()
        val r = Http.call(Request.Builder().url(url).build())
        if (r.code != 200) throw IOException(errorText(r))
        return json.parseToJsonElement(r.body).jsonObject.arr("results").mapNotNull { e ->
            val o = e.jsonObject
            val poi = o.obj("poi") ?: return@mapNotNull null
            val pos = o.obj("position") ?: return@mapNotNull null
            val addr = o.obj("address")?.str("municipality") ?: ""
            Place(listOf(poi.str("name"), addr).filter { it.isNotBlank() }.joinToString(", "), LatLon(pos.num("lat") ?: 0.0, pos.num("lon") ?: 0.0))
        }
    }

    /** Parkplätze und Parkhäuser im Umkreis (TomTom-Kategorien 7369 und 7313) */
    suspend fun nearbyParking(key: String, c: LatLon, radiusM: Int): List<Place> {
        val ck = "k|%.3f,%.3f|$radiusM".format(Locale.US, c.lat, c.lon)
        poiCache.get(ck)?.let { return it }
        return nearbyParkingRaw(key, c, radiusM).also { poiCache.put(ck, it) }
    }

    private suspend fun nearbyParkingRaw(key: String, c: LatLon, radiusM: Int): List<Place> {
        val url = "$BASE/search/2/nearbySearch/.json?key=$key&lat=${c.lat.f6()}&lon=${c.lon.f6()}" +
            "&radius=$radiusM&limit=8&categorySet=7369,7313&language=de-DE"
        ApiCounter.hit()
        val r = Http.call(Request.Builder().url(url).build())
        if (r.code != 200) throw IOException(errorText(r))
        return json.parseToJsonElement(r.body).jsonObject.arr("results").mapNotNull { e ->
            val o = e.jsonObject
            val poi = o.obj("poi") ?: return@mapNotNull null
            val pos = o.obj("position") ?: return@mapNotNull null
            val garage = poi.arr("categorySet").any { (it as? JsonObject)?.num("id")?.toInt() == 7313 }
            val name = poi.str("name").ifBlank { if (garage) "Parkhaus" else "Parkplatz" }
            val addr = o.obj("address")?.str("freeformAddress") ?: ""
            Place(listOf(name, addr).filter { it.isNotBlank() }.joinToString(", "), LatLon(pos.num("lat") ?: 0.0, pos.num("lon") ?: 0.0), kind = "amenity=parking")
        }
    }

    /** Ladestationen im Umkreis (Kategorie Ladestation, ohne Suchbegriff) */
    suspend fun nearby(key: String, c: LatLon, radiusM: Int, minKw: Int, fastOnly: Boolean): List<ChargerHit> {
        val url = buildString {
            append("$BASE/search/2/nearbySearch/.json?key=").append(key)
            append("&lat=").append(c.lat.f6()).append("&lon=").append(c.lon.f6())
            append("&radius=").append(radiusM.coerceIn(500, 50_000))
            append("&limit=100&categorySet=7309&language=de-DE&openingHours=nextSevenDays")
            if (fastOnly) append("&connectorSet=IEC62196Type2CCS,Tesla")
            if (minKw > 0) append("&minPowerKW=").append(minKw)
        }
        ApiCounter.hit()
        val r = Http.call(Request.Builder().url(url).build())
        if (r.code != 200) throw IOException(errorText(r))
        val hits = json.parseToJsonElement(r.body).jsonObject.arr("results").mapNotNull { parseHit(it.jsonObject) }
        KnownOperators.note(hits.map { it.operator })
        return hits
    }

    /**
     * Ladestationen in einem Korridor entlang der Route: alle ~15 km ein Suchkreis,
     * Treffer zusammenführen, Position und Abstand zur Route berechnen.
     */
    suspend fun corridor(key: String, r: Route, fromM: Double, toM: Double, widthKm: Int, minKw: Int): List<ChargerHit> = coroutineScope {
        val end = minOf(toM, r.cumM.lastOrNull() ?: 0.0)
        // ~15 km Abstand; bei sehr langen Strecken weiter auseinander (höchstens ~60 Anfragen)
        val spacing = max(15_000.0, (end - max(0.0, fromM)) / 60)
        val centers = mutableListOf<LatLon>()
        var m = max(0.0, fromM)
        while (m <= end) { centers += pointOnRoute(r, m); m += spacing }
        if (centers.isEmpty() || end - (m - spacing) > 2_000) centers += pointOnRoute(r, end)
        val radius = kotlin.math.hypot(spacing / 2, widthKm * 1000.0).toInt() + 500
        val results = mutableListOf<ChargerHit>()
        // in kleinen Gruppen parallel, um TomTom nicht zu überlasten
        for (group in centers.chunked(4)) {
            val part = group.map { c -> async { runCatching { nearby(key, c, radius, minKw, true) }.getOrDefault(emptyList()) } }
            part.forEach { results += it.await() }
        }
        val unique = results.distinctBy { it.id }
        unique.mapNotNull { h ->
            val (along, off) = locateOnRoute(r, h.pos)
            if (off > widthKm * 1000.0 || along < fromM - 1000 || along > end + 1000) null
            else h.copy(alongM = along, offsetM = off)
        }.sortedBy { it.alongM }
    }

    private val BRANDS = listOf(
        "tesla supercharger", "supercharger", "tesla", "enbw", "ionity", "fastned", "aral pulse", "aral", "shell recharge", "shell",
        "ewe go", "allego", "electra", "e.on", "atlante", "pfalzwerke", "totalenergies", "total", "maingau", "lidl", "kaufland", "aldi",
        "mer", "zunder", "eviny", "be charge", "plugsurfing", "stadtwerke",
    )

    /**
     * Ladesäulen-Suche mit Ort: „Tesla Kamen“ → Ort „Kamen“ suchen, dort Lader des Anbieters im Umkreis von 15 km.
     * (TomTom vergleicht den Text sonst mit den Namen der Stationen – und die heißen oft nur „Tesla“.)
     */
    suspend fun searchChargersSmart(key: String, q: String, near: LatLon?): List<ChargerHit> {
        val lower = q.trim().lowercase()
        val all = (BRANDS + KnownOperators.items.value.map { it.lowercase() }).distinct().sortedByDescending { it.length }
        val brand = all.firstOrNull { b -> Regex("(^|\\s)" + Regex.escape(b) + "($|\\s)").containsMatchIn(lower) }
        if (brand != null) {
            val rest = lower.replace(Regex("(^|\\s)" + Regex.escape(brand) + "($|\\s)"), " ")
                .replace(Regex("\\b(ladestation|ladesäule|ladepark|lader|laden|in|bei|am|an|im|der|die|das|nähe)\\b"), " ")
                .replace(Regex("\\s+"), " ").trim(' ', ',')
            if (rest.length >= 3) {
                val place = runCatching { Geocode.search(rest, near).firstOrNull() }.getOrNull()
                if (place != null) {
                    val q2 = if (brand.contains("supercharger")) "tesla" else brand
                    val hits = runCatching { searchChargers(key, q2, place.pos, 15_000, 20) }.getOrDefault(emptyList())
                        .filter { it.operator.contains(q2, true) || it.name.contains(q2, true) }
                        .sortedBy { haversine(it.pos, place.pos) }
                    if (hits.isNotEmpty()) return hits
                }
            }
        }
        return searchChargers(key, q, near)
    }

    /** Lader bestimmter Anbieter entlang der Route (gezielte Suche nach dem Namen, damit sie nicht unter vielen anderen untergehen) */
    suspend fun corridorBrands(key: String, r: Route, brands: Set<String>, widthKm: Int, minKw: Int): List<ChargerHit> = coroutineScope {
        val end = r.cumM.lastOrNull() ?: 0.0
        val spacing = max(35_000.0, end / 45)
        val centers = mutableListOf<LatLon>()
        var m = 0.0
        while (m <= end) { centers += pointOnRoute(r, m); m += spacing }
        centers += pointOnRoute(r, end)
        val radius = kotlin.math.hypot(spacing / 2, widthKm * 1000.0).toInt() + 2000
        val out = mutableListOf<ChargerHit>()
        for (group in centers.chunked(4)) {
            val jobs = group.flatMap { c -> brands.map { b -> async { runCatching { searchChargers(key, b, c, radius.coerceAtMost(50_000), 20) }.getOrDefault(emptyList()) } } }
            jobs.forEach { out += it.await() }
        }
        out.distinctBy { it.id }.filter { it.powerKw <= 0 || it.powerKw >= minKw }.mapNotNull { h ->
            val (along, off) = locateOnRoute(r, h.pos)
            if (off > widthKm * 1000.0) null else h.copy(alongM = along, offsetM = off)
        }.sortedBy { it.alongM }
    }

    /** Punkt auf der Route bei m Metern */
    private fun pointOnRoute(r: Route, m: Double): LatLon {
        val cum = r.cumM
        var i = cum.binarySearch(m)
        if (i >= 0) return r.points[i]
        i = -i - 1
        if (i <= 0) return r.points.first()
        if (i >= r.points.size) return r.points.last()
        val span = cum[i] - cum[i - 1]
        return if (span <= 0) r.points[i] else lerp(r.points[i - 1], r.points[i], (m - cum[i - 1]) / span)
    }

    /** Position entlang der Route und Abstand zu ihr */
    fun locateOnRoute(r: Route, p: LatLon): Pair<Double, Double> {
        val pts = r.points
        if (pts.size < 2) return 0.0 to Double.MAX_VALUE
        // grob über jeden 10. Punkt, dann fein in der Umgebung
        var coarse = 0
        var cd = Double.MAX_VALUE
        for (i in pts.indices step 10) { val d = haversine(pts[i], p); if (d < cd) { cd = d; coarse = i } }
        val from = (coarse - 12).coerceAtLeast(0)
        val to = (coarse + 12).coerceAtMost(pts.size - 2)
        var best = from
        var bd = Double.MAX_VALUE
        for (i in from..to) { val d = distToSeg(p, pts[i], pts[i + 1]); if (d < bd) { bd = d; best = i } }
        val t = projectT(p, pts[best], pts[best + 1])
        val along = r.cumM[best] + t * (r.cumM[best + 1] - r.cumM[best])
        return along to bd
    }

    /** Live-Belegung eines Ladeparks (nicht jeder Betreiber liefert Daten) */
    suspend fun availability(key: String, uuid: String): Availability {
        ApiCounter.hit()
        val url = "$BASE/search/2/chargingAvailability.json?key=$key&chargingAvailability=$uuid"
        val r = Http.call(Request.Builder().url(url).build())
        if (r.code != 200) return Availability(0, 0, false)
        val o = runCatching { json.parseToJsonElement(r.body).jsonObject }.getOrNull() ?: return Availability(0, 0, false)
        var avail = 0
        var total = 0
        var known = false
        val lines = mutableListOf<String>()
        o.arr("connectors").forEach { c ->
            val co = c.jsonObject
            val t = co.str("type")
            val label = when {
                t.contains("CCS", true) -> "CCS"
                t.contains("Tesla", true) -> "Tesla"
                t.contains("CHAdeMO", true) -> "CHAdeMO"
                t.startsWith("IEC62196Type2") -> "Typ 2"
                else -> t
            }
            val cur = co.obj("availability")?.obj("current") ?: return@forEach
            val a = cur.int("available") ?: 0
            val unknown = cur.int("unknown") ?: 0
            val sumAll = a + (cur.int("occupied") ?: 0) + (cur.int("reserved") ?: 0) + (cur.int("outOfService") ?: 0) + unknown
            avail += a
            total += sumAll
            if (sumAll > unknown) known = true
            val levels = co.obj("availability")?.arr("perPowerLevel")?.mapNotNull { it as? JsonObject } ?: emptyList()
            if (levels.isNotEmpty()) {
                levels.forEach { lv ->
                    val la = lv.int("available") ?: 0
                    val lt = la + (lv.int("occupied") ?: 0) + (lv.int("reserved") ?: 0) + (lv.int("outOfService") ?: 0) + (lv.int("unknown") ?: 0)
                    val kw = lv.num("powerKW")?.roundToInt()
                    if (lt > 0) lines += "$label${if (kw != null) " $kw kW" else ""}: $la von $lt frei"
                }
            } else if (sumAll > 0) {
                lines += "$label: $a von $sumAll frei"
            }
        }
        return Availability(avail, total, known, lines)
    }
}
