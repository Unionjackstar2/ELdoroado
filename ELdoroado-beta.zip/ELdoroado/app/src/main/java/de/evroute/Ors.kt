package de.evroute

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Routing über OpenRouteService (HeiGIT, Heidelberg) mit eigenem kostenlosen Schlüssel.
 * Die Antwort wird in unser eigenes Routenformat übersetzt, damit Ansagen, Banner, Kreisverkehr-Logik,
 * Abbiegepfeil und Autobahn-Meldungen genauso funktionieren wie bei TomTom oder OSRM.
 * Freikontingent laut HeiGIT: 2.000 Routen pro Tag, 40 pro Minute; Alternativrouten nur bis 100 km.
 */
object Ors {
    private const val URL = "https://api.openrouteservice.org/v2/directions/driving-car/geojson"
    private val JSON_TYPE = "application/json".toMediaType()
    private val REF = Regex("\\b([ABLKE])\\s?(\\d{1,4})\\b")

    /** Fahrzeugmasse für die Höhenrechnung (ë-C4 mit Fahrer, grob) */
    private const val MASS_KG = 1650.0

    suspend fun routes(
        key: String,
        from: LatLon,
        bearing: Float?,
        to: LatLon,
        alternatives: Int,
        vias: List<LatLon>,
        s: AppSettings,
    ): List<Route> {
        val coords = listOf(from) + vias + listOf(to)
        // Alternativen nur bei kurzen Strecken (ORS-Grenze 100 km) und ohne Zwischenziele
        val wantAlts = alternatives > 0 && vias.isEmpty() && haversine(from, to) < 75_000
        suspend fun call(withBearing: Boolean, withAlts: Boolean): List<Route> {
            val body = buildJsonObject {
                putJsonArray("coordinates") { coords.forEach { c -> add(buildJsonArray { add(JsonPrimitive(c.lon)); add(JsonPrimitive(c.lat)) }) } }
                put("instructions", true)
                put("language", "de")
                put("elevation", true)
                put("units", "m")
                put("maneuvers", true)
                put("geometry_simplify", false)
                if (withBearing && bearing != null) {
                    putJsonArray("bearings") { add(buildJsonArray { add(JsonPrimitive(bearing.roundToInt().mod(360))); add(JsonPrimitive(45)) }) }
                }
                if (withAlts) {
                    putJsonObject("alternative_routes") {
                        put("target_count", (alternatives + 1).coerceAtMost(3))
                        put("weight_factor", 1.4)
                        put("share_factor", 0.6)
                    }
                }
                val avoid = buildList {
                    if (s.avoidToll) add("tollways")
                    if (s.avoidMotorway) add("highways")
                    if (s.avoidFerry) add("ferries")
                }
                if (avoid.isNotEmpty()) putJsonObject("options") { putJsonArray("avoid_features") { avoid.forEach { add(JsonPrimitive(it)) } } }
            }.toString()
            val req = Request.Builder().url(URL)
                .header("Authorization", key)
                .header("Accept", "application/json, application/geo+json")
                .header("User-Agent", "ELdoroado/${BuildConfigLite.version}")
                .post(body.toRequestBody(JSON_TYPE))
                .build()
            val r = Http.call(req)
            if (r.code == 401 || r.code == 403) throw IOException("OpenRouteService: Schlüssel ungültig (Einstellungen → Routing).")
            if (r.code == 429) throw IOException("OpenRouteService: Tageskontingent erreicht.")
            if (r.code != 200) {
                val msg = runCatching { json.parseToJsonElement(r.body).jsonObject["error"]?.let { e -> (e as? JsonObject)?.get("message") ?: e } }.getOrNull()
                throw OrsError(r.code, (msg as? JsonPrimitive)?.content ?: "Fehler ${r.code}")
            }
            val root = json.parseToJsonElement(r.body).jsonObject
            val feats = root["features"] as? JsonArray ?: throw IOException("OpenRouteService: leere Antwort")
            return feats.mapNotNull { (it as? JsonObject)?.let { f -> parse(f, vias.size) } }
        }
        // Rückfälle: erst ohne Fahrtrichtung, dann ohne Alternativen
        val attempts = listOf(true to wantAlts, false to wantAlts, false to false).distinct()
        var last: Exception? = null
        for ((b, a) in attempts) {
            try {
                return call(b, a).mapIndexed { i, rt -> rt.copy(tag = if (i == 0) "Empfohlen" else "Alternative") }
            } catch (e: OrsError) {
                last = e
                if (e.code >= 500) break
            }
        }
        throw last ?: IOException("OpenRouteService nicht erreichbar")
    }

    class OrsError(val code: Int, msg: String) : IOException("OpenRouteService: $msg")

    private fun JsonObject.d(k: String) = (this[k] as? JsonPrimitive)?.doubleOrNull
    private fun JsonObject.i(k: String) = (this[k] as? JsonPrimitive)?.intOrNull
    private fun JsonObject.s(k: String) = (this[k] as? JsonPrimitive)?.takeIf { it.isString }?.content ?: ""

    /** Straßennummern aus dem Namen, z. B. „Wittener Straße, B 226“ → [B226] */
    private fun refs(name: String): List<String> = REF.findAll(name).map { it.groupValues[1] + it.groupValues[2] }.toList()

    private fun typeMod(t: Int): Pair<String, String?> = when (t) {
        0 -> "turn" to "left"
        1 -> "turn" to "right"
        2 -> "turn" to "sharp left"
        3 -> "turn" to "sharp right"
        4 -> "turn" to "slight left"
        5 -> "turn" to "slight right"
        6 -> "continue" to "straight"
        7 -> "roundabout" to "right"
        8 -> "exit roundabout" to null
        9 -> "continue" to "uturn"
        10 -> "arrive" to null
        11 -> "depart" to null
        12 -> "fork" to "slight left"
        13 -> "fork" to "slight right"
        else -> "continue" to "straight"
    }

    private fun maneuverName(t: Int) = when (t) {
        0, 2, 4 -> "TURN_LEFT"
        1, 3, 5 -> "TURN_RIGHT"
        12 -> "KEEP_LEFT"
        13 -> "KEEP_RIGHT"
        else -> "STRAIGHT"
    }

    private fun parse(f: JsonObject, viaCount: Int): Route? {
        val coords = ((f["geometry"] as? JsonObject)?.get("coordinates") as? JsonArray) ?: return null
        val pts = ArrayList<LatLon>(coords.size)
        val ele = ArrayList<Double>(coords.size)
        for (c in coords) {
            val a = c as? JsonArray ?: continue
            val lon = (a.getOrNull(0) as? JsonPrimitive)?.doubleOrNull ?: continue
            val lat = (a.getOrNull(1) as? JsonPrimitive)?.doubleOrNull ?: continue
            pts += LatLon(lat, lon)
            ele += (a.getOrNull(2) as? JsonPrimitive)?.doubleOrNull ?: Double.NaN
        }
        if (pts.size < 2) return null
        val props = f["properties"] as? JsonObject ?: return null
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])

        data class Raw(val type: Int, val name: String, val dist: Double, val dur: Double, val wp: Int, val exit: Int?, val angle: Double?)
        val raws = mutableListOf<Raw>()
        val segs = props["segments"] as? JsonArray ?: JsonArray(emptyList())
        segs.forEachIndexed { si, sg ->
            val seg = sg as? JsonObject ?: return@forEachIndexed
            (seg["steps"] as? JsonArray)?.forEach { st ->
                val o = st as? JsonObject ?: return@forEach
                var t = o.i("type") ?: 6
                // Zwischenziel: „Ziel“ mitten in der Route ist ein Zwischenstopp, „Abfahrt“ danach ein Weiterfahren
                if (t == 10 && si < segs.size - 1) t = 100
                if (t == 11 && si > 0) t = 6
                val wp = ((o["way_points"] as? JsonArray)?.getOrNull(0) as? JsonPrimitive)?.intOrNull ?: 0
                val m = o["maneuver"] as? JsonObject
                val angle = m?.let { mm ->
                    val b0 = mm.d("bearing_before"); val b1 = mm.d("bearing_after")
                    if (b0 == null || b1 == null) null else {
                        var d = b1 - b0
                        while (d > 180) d -= 360
                        while (d < -180) d += 360
                        d
                    }
                }
                raws += Raw(t, o.s("name").let { if (it == "-") "" else it }, o.d("distance") ?: 0.0, o.d("duration") ?: 0.0, wp, o.i("exit_number"), angle)
            }
        }
        // „Kreisverkehr verlassen“ ist bei uns kein eigenes Manöver (die Ausfahrt wird aus der Linie erkannt)
        val kept = raws.filter { it.type != 8 }
        val steps = mutableListOf<Step>()
        val stepAlong = DoubleArray(kept.size)
        val stepTime = DoubleArray(kept.size)
        var t = 0.0
        var lastAlong = 0.0
        kept.forEachIndexed { i, rw ->
            val along = cum.getOrElse(rw.wp.coerceIn(0, cum.lastIndex)) { 0.0 }.coerceAtLeast(lastAlong)
            val nextAlong = kept.getOrNull(i + 1)?.let { n -> cum.getOrElse(n.wp.coerceIn(0, cum.lastIndex)) { along } } ?: cum.last()
            val dist = max(0.0, nextAlong - along)
            // Fahrzeit des Abschnitts: Summe der ORS-Zeiten bis zum nächsten behaltenen Manöver
            val idx = raws.indexOf(rw)
            val nextIdx = kept.getOrNull(i + 1)?.let { raws.indexOf(it) } ?: raws.size
            val dur = (idx until nextIdx).sumOf { raws[it].dur }
            val (type0, mod0) = if (rw.type == 100) "via" to null else typeMod(rw.type)
            val toNums = refs(rw.name)
            val fromNums = kept.getOrNull(i - 1)?.let { refs(it.name) } ?: emptyList()
            val junction = when (rw.type) { 7 -> "ROUNDABOUT"; 12, 13 -> "BIFURCATION"; else -> "REGULAR" }
            val ref = ManeuverRefiner.refine(type0, mod0, maneuverName(rw.type), junction, rw.angle, fromNums, toNums, "")
            val road = rw.name.split(',').map { it.trim() }.filter { it.isNotBlank() }.let { parts ->
                // Nummer vorn, Name dahinter – wie bei den anderen Quellen
                val num = parts.firstOrNull { REF.matches(it) }
                listOfNotNull(num, parts.firstOrNull { !REF.matches(it) }).joinToString(" · ")
            }
            val exit = if (rw.type == 7) rw.exit else null
            steps += Step(
                ref.type, ref.mod, exit, road, "", dist, dur,
                ref.phrase ?: Phrases.build(ref.type, ref.mod, exit), "", ref.phraseHasRoad,
            )
            stepAlong[i] = along
            stepTime[i] = t
            t += dur
            lastAlong = along
        }
        val sum = props["summary"] as? JsonObject
        val dist = sum?.d("distance") ?: cum.last()
        val dur = sum?.d("duration") ?: t
        val ascent = props.d("ascent") ?: 0.0
        val descent = props.d("descent") ?: 0.0
        val summary = kept.map { refs(it.name) }.flatten().filter { it.startsWith("A") || it.startsWith("B") }
            .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(2).joinToString(", ") { it.key.replace(Regex("(\\D)(\\d)"), "$1 $2") }
        return Route(
            pts, cum, stepAlong, stepTime, dist, dur, dur, steps, summary,
            source = "ORS",
            note = if (ascent > 50) "Höhenmeter: ↑ ${ascent.roundToInt()} m · ↓ ${descent.roundToInt()} m" else null,
            elevations = if (ele.count { !it.isNaN() } > pts.size / 2) ele.map { if (it.isNaN()) 0f else it.toFloat() }.toFloatArray() else null,
            ascentM = ascent,
            descentM = descent,
        )
    }

    /** für Tests: ein GeoJSON-Feature übersetzen */
    internal fun parseForTest(feature: String): Route? = parse(json.parseToJsonElement(feature).jsonObject, 0)

    /** Energie für Höhenmeter (kWh): bergauf mit Antriebsverlusten, bergab mit Rekuperation */
    fun climbKwh(r: Route): Double {
        if (r.ascentM <= 0 && r.descentM <= 0) return 0.0
        val g = 9.81
        val up = MASS_KG * g * r.ascentM / 3.6e6 / 0.88
        val down = MASS_KG * g * r.descentM / 3.6e6 * 0.62
        return up - down
    }
}
