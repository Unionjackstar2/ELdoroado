package de.evroute

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import android.graphics.Color as AColor

/**
 * Kleine Fahnen auf der Route (Glas-Schilder mit Spitze nach unten):
 * Start mit Start-Akku, Ziel mit Ziel-Akku, Ladestopp „⚡ 18 → 62 %“, Zwischenstopp als kleine gelbe Fahne.
 */
object RouteFlags {
    enum class Kind { START, DEST, CHARGE, VIA }

    fun bitmap(ctx: Context, kind: Kind, text: String?, dark: Boolean): Bitmap {
        val d = ctx.resources.displayMetrics.density
        if (kind == Kind.VIA) return viaFlag(d)
        val font = runCatching { ResourcesCompat.getFont(ctx, R.font.noto_sans_700) }.getOrNull() ?: Typeface.DEFAULT_BOLD
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = font
            textSize = 12.5f * d
            color = if (dark) AColor.WHITE else AColor.rgb(27, 31, 36)
        }
        val label = text ?: ""
        val iconW = 14f * d
        val padH = 8f * d
        val gap = if (label.isNotEmpty()) 5f * d else 0f
        val textW = tp.measureText(label)
        val h = 26f * d
        val tip = 6f * d
        val shadow = 4f * d
        val w = padH * 2 + iconW + gap + textW
        val bmp = Bitmap.createBitmap((w + shadow * 2).toInt() + 1, (h + tip + shadow * 2).toInt() + 1, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val x0 = shadow
        val y0 = shadow * 0.6f
        val body = Path().apply {
            addRoundRect(RectF(x0, y0, x0 + w, y0 + h), h / 2, h / 2, Path.Direction.CW)
            val cx = x0 + w / 2
            moveTo(cx - tip, y0 + h - 1)
            lineTo(cx, y0 + h + tip)
            lineTo(cx + tip, y0 + h - 1)
            close()
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (dark) AColor.argb(238, 30, 34, 42) else AColor.argb(245, 250, 251, 253)
            setShadowLayer(shadow, 0f, 1.5f * d, AColor.argb(90, 0, 0, 0))
        }
        c.drawPath(body, fill)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1f * d
            color = if (dark) AColor.argb(70, 255, 255, 255) else AColor.argb(40, 0, 0, 0)
        }
        c.drawPath(body, edge)
        // Symbol links
        val ix = x0 + padH
        val iy = y0 + (h - iconW) / 2
        when (kind) {
            Kind.START -> drawFlag(c, ix, iy, iconW, AColor.rgb(47, 111, 224), dark)
            Kind.DEST -> drawChecker(c, ix, iy, iconW, dark)
            Kind.CHARGE -> drawBolt(c, ix, iy, iconW, AColor.rgb(31, 157, 85))
            else -> {}
        }
        if (label.isNotEmpty()) {
            val fm = tp.fontMetrics
            c.drawText(label, ix + iconW + gap, y0 + h / 2 - (fm.ascent + fm.descent) / 2, tp)
        }
        return bmp
    }

    private fun drawFlag(c: Canvas, x: Float, y: Float, s: Float, color: Int, dark: Boolean) {
        val pole = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = if (dark) AColor.WHITE else AColor.rgb(27, 31, 36)
            strokeWidth = s * 0.12f
            strokeCap = Paint.Cap.ROUND
        }
        c.drawLine(x + s * 0.2f, y + s * 0.05f, x + s * 0.2f, y + s, pole)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        c.drawPath(Path().apply { moveTo(x + s * 0.26f, y + s * 0.08f); lineTo(x + s * 0.98f, y + s * 0.3f); lineTo(x + s * 0.26f, y + s * 0.55f); close() }, p)
    }

    private fun drawChecker(c: Canvas, x: Float, y: Float, s: Float, dark: Boolean) {
        val pole = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (dark) AColor.WHITE else AColor.rgb(27, 31, 36)
            strokeWidth = s * 0.12f
            strokeCap = Paint.Cap.ROUND
        }
        c.drawLine(x + s * 0.15f, y + s * 0.05f, x + s * 0.15f, y + s, pole)
        val left = x + s * 0.22f
        val top = y + s * 0.08f
        val cw = (s * 0.76f) / 4
        val ch = (s * 0.5f) / 3
        val black = Paint().apply { color = if (dark) AColor.WHITE else AColor.rgb(27, 31, 36) }
        val white = Paint().apply { color = if (dark) AColor.rgb(30, 34, 42) else AColor.WHITE }
        for (r in 0 until 3) for (k in 0 until 4) {
            c.drawRect(left + k * cw, top + r * ch, left + (k + 1) * cw, top + (r + 1) * ch, if ((r + k) % 2 == 0) black else white)
        }
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = s * 0.05f; color = black.color }
        c.drawRect(left, top, left + 4 * cw, top + 3 * ch, frame)
    }

    private fun drawBolt(c: Canvas, x: Float, y: Float, s: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val pts = listOf(0.62f to 0f, 0.12f to 0.58f, 0.46f to 0.58f, 0.32f to 1f, 0.88f to 0.38f, 0.54f to 0.38f)
        c.drawPath(Path().apply { pts.forEachIndexed { i, (px, py) -> if (i == 0) moveTo(x + px * s, y + py * s) else lineTo(x + px * s, y + py * s) }; close() }, p)
    }

    /** Zwischenstopp: kleine gelbe Fahne am Mast, Fuß auf dem Punkt */
    private fun viaFlag(d: Float): Bitmap {
        val w = (22 * d).toInt(); val h = (28 * d).toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val px = 6 * d
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.argb(70, 0, 0, 0) }
        c.drawOval(RectF(px - 4 * d, h - 4 * d, px + 4 * d, h - 0.5f * d), shadow)
        val pole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.rgb(40, 44, 52); strokeWidth = 2.2f * d; strokeCap = Paint.Cap.ROUND }
        c.drawLine(px, 2 * d, px, h - 2 * d, pole)
        val flag = Path().apply { moveTo(px + 1 * d, 2.5f * d); lineTo(w - 1.5f * d, 8 * d); lineTo(px + 1 * d, 14 * d); close() }
        c.drawPath(flag, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.rgb(255, 196, 0) })
        c.drawPath(flag, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d; color = AColor.rgb(150, 105, 0) })
        return bmp
    }
}
