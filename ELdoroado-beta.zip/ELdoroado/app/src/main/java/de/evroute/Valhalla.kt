package de.evroute

/**
 * Offline-Routing mit Valhalla (valhalla-mobile, MIT). Kacheln kommen vom eigenen Server,
 * der Zugang (Token) wird erst beim Bauen aus dem GitHub-Secret eingesetzt.
 * Diese Runde: Bibliothek eingebunden, Routing folgt in der nächsten.
 */
object ValhallaEngine {
    /** Ist die Bibliothek in der App enthalten? (prüft nur die Klasse, lädt noch keine native Bibliothek) */
    fun libraryPresent(): Boolean = runCatching { Class.forName("com.valhalla.valhalla.Valhalla"); true }.getOrDefault(false)

    /** Ist der Kachel-Server samt Zugang beim Bauen hinterlegt worden? */
    fun serverConfigured(): Boolean = BuildConfig.TILES_TOKEN.isNotBlank() && BuildConfig.TILES_BASE.startsWith("https://")

    val metadataUrl get() = BuildConfig.TILES_BASE.trimEnd('/') + "/metadata.json"
    val tilesUrl get() = BuildConfig.TILES_BASE.trimEnd('/') + "/valhalla_germany.tar"

    /** Header für Anfragen an den Kachel-Server */
    fun authHeader(): Pair<String, String> = "Authorization" to "Bearer ${BuildConfig.TILES_TOKEN}"
}
