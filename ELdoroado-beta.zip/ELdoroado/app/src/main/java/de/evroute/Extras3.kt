package de.evroute

import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ======================= Tempo-Coach =======================

/** Ein Tipp des Tempo-Coachs */
data class CoachTip(
    val capKmh: Int,
    val title: String,   // „115 statt 130 km/h“
    val detail: String,  // „Ladestopp entfällt · nur +6 min“
    val warning: Boolean,
    val spoken: String,
)

/**
 * Rechnet während der Fahrt durch, ob eine niedrigere Höchstgeschwindigkeit
 * einen Ladestopp spart oder einen zu knappen Akku verhindert.
 * Rein lokal (gelernter Verbrauch + verbleibende Strecke), ohne TomTom-Anfrage.
 */
object TempoCoach {
    private val CAPS = listOf(130, 120, 110, 100, 90)

    internal data class Seg(val km: Double, val kmh: Double)

    /** Abschnitte der Route zwischen zwei Positionen, mit geplantem Tempo je Abbiegeschritt */
    internal fun segments(r: Route, from: Double, to: Double): List<Seg> {
        val out = mutableListOf<Seg>()
        for (i in r.steps.indices) {
            val a = r.stepAlongM[i]
            val b = if (i + 1 < r.steps.size) r.stepAlongM[i + 1] else r.cumM.last()
            val lo = max(a, from)
            val hi = min(b, to)
            if (hi <= lo) continue
            val st = r.steps[i]
            val kmh = if (st.durationS > 1 && st.distanceM > 1) st.distanceM / st.durationS * 3.6 else 80.0
            out += Seg((hi - lo) / 1000, kmh.coerceIn(10.0, 180.0))
        }
        return out
    }

    /** Energie (kWh) und Zeit (h) für Abschnitte bei Tempo-Obergrenze cap */
    internal fun cost(segs: List<Seg>, cap: Int?, s: AppSettings, w: WeatherInfo?): Pair<Double, Double> {
        var kwh = 0.0
        var h = 0.0
        val aux = EvModel.auxKw(w)
        segs.forEach { sg ->
            val v = if (cap != null) min(sg.kmh, cap.toDouble()) else sg.kmh
            val t = sg.km / v
            kwh += sg.km * EvModel.kwhPer100(v, s, w) / 100 + aux * t
            h += t
        }
        return kwh to h
    }

    fun evaluate(r: Route, along: Double, socNow: Double, s: AppSettings): CoachTip? {
        val w = r.weather
        val usable = s.usableKwh
        val nextStop = r.stops.firstOrNull { it.alongM > along + 2000 }
        val targetAlong = nextStop?.alongM ?: r.cumM.last()
        val segsA = segments(r, along, targetAlong)
        if (segsA.sumOf { it.km } < 15) return null
        val base = cost(segsA, null, s, w)
        // Plan-Akku am Ziel bzw. nächsten Stopp, korrigiert um die aktuelle Abweichung vom Plan
        val planNow = r.socAt(along) ?: socNow
        val planArrive = nextStop?.arriveSoc ?: r.arrivalSoc ?: return null
        val arriveBase = planArrive + (socNow - planNow)
        val maxPlanned = segsA.maxOf { it.kmh }

        // 1) Ladestopp einsparen?
        if (nextStop != null) {
            val after = r.stops.firstOrNull { it.alongM > nextStop.alongM + 2000 }
            val t2 = after?.alongM ?: r.cumM.last()
            val need = if (after == null) s.minSocDest else s.minSocStop
            val segsB = segments(r, targetAlong, t2)
            for (cap in CAPS) {
                if (cap >= maxPlanned - 3) continue
                val a = cost(segsA, cap, s, w)
                val b = cost(segsB, cap, s, w)
                val bBase = cost(segsB, null, s, w)
                val arriveA = arriveBase - (a.first - base.first) / usable * 100
                val arriveB = arriveA - b.first / usable * 100
                if (arriveA >= s.minSocStop && arriveB >= need) {
                    val extraMin = ((a.second - base.second) + (b.second - bBase.second)) * 60
                    val savedMin = nextStop.chargeS / 60 + 5 - extraMin // +5 min für Abfahrt, Anstecken, Umweg
                    if (savedMin >= 3) {
                        val cur = maxPlanned.roundToInt().coerceAtMost(200)
                        return CoachTip(
                            cap, "$cap statt $cur km/h",
                            "Ladestopp entfällt · ${if (extraMin >= 1) "nur +${extraMin.roundToInt()} min Fahrzeit" else "kaum langsamer"} · ca. ${savedMin.roundToInt()} min gespart",
                            false,
                            "Tipp: Mit $cap Kilometern pro Stunde sparst du dir den nächsten Ladestopp und bist etwa ${savedMin.roundToInt()} Minuten früher da.",
                        )
                    }
                    break
                }
            }
        }

        // 2) Akku wird knapp?
        val minOk = if (nextStop != null) s.minSocStop else s.minSocDest
        if (arriveBase < minOk - 2) {
            for (cap in CAPS) {
                if (cap >= maxPlanned - 3) continue
                val a = cost(segsA, cap, s, w)
                val arriveA = arriveBase - (a.first - base.first) / usable * 100
                if (arriveA >= minOk) {
                    val extraMin = ((a.second - base.second) * 60).roundToInt()
                    val where = if (nextStop != null) "am Ladestopp" else "am Ziel"
                    return CoachTip(
                        cap, "Akku wird knapp: max. $cap km/h",
                        "Sonst ${fmtPct(arriveBase)} $where, so ${fmtPct(arriveA)} · +$extraMin min",
                        true,
                        "Achtung, der Akku wird knapp. Fahr höchstens $cap Kilometer pro Stunde, dann kommst du mit ${arriveA.roundToInt()} Prozent an.",
                    )
                }
            }
        }
        return null
    }
}

// ======================= Reichweiten-Blase =======================

object Reach {
    data class State(
        val active: Boolean = false,
        val loading: Boolean = false,
        val outer: List<LatLon> = emptyList(),
        val round: List<LatLon> = emptyList(),
        val soc: Double? = null,
        val error: String? = null,
        val version: Int = 0,
        val center: LatLon? = null,
    )

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    fun toggle() {
        if (_state.value.active) _state.value = State() else compute()
    }

    /** Neu berechnen, wenn offen und Akku um 5 % gesunken oder 10 km gefahren */
    fun maybeRefresh() {
        val s = _state.value
        if (!s.active || s.loading) return
        val soc = Obd.freshSoc()
        val pos = LocationHub.fix.value?.pos ?: return
        val movedFar = s.center?.let { haversine(it, pos) > 10_000 } ?: false
        val socDrop = soc != null && s.soc != null && s.soc - soc >= 5
        if (movedFar || socDrop) compute(fit = false)
    }

    fun compute(fit: Boolean = true) {
        val set = Settings.state.value
        val pos = LocationHub.fix.value?.pos
        if (pos == null) { _state.update { it.copy(active = true, error = "Standort noch nicht verfügbar") }; return }
        val soc = Obd.freshSoc() ?: set.socStart
        _state.update { it.copy(active = true, loading = true, error = null, soc = soc) }
        scope.launch {
            val budget = (soc - set.minSocStop) / 100 * set.usableKwh
            if (budget <= 0.5) {
                _state.update { it.copy(loading = false, error = "Akku unter der Reserve – keine Reichweite") }
                return@launch
            }
            val w = runCatching { Weather.along(pos, pos) }.getOrNull()
            val (outer, round) = if (set.hasTomTom && !TomTomPolicy.TRAFFIC_ONLY) {
                val o = runCatching { TomTom.reachable(set, pos, budget, w) }
                val rnd = if (set.reachRoundTrip) runCatching { TomTom.reachable(set, pos, budget / 2, w) }.getOrNull() else null
                if (o.isFailure) {
                    _state.update { it.copy(loading = false, error = "Reichweite nicht verfügbar: ${o.exceptionOrNull()?.message}") }
                    return@launch
                }
                o.getOrThrow() to (rnd ?: emptyList())
            } else {
                // Ohne TomTom: einfache Schätzung als Kreis (Landstraße/Autobahn gemischt, ~90 km/h)
                val km = budget / (EvModel.kwhPer100(90.0, set, w) / 100 + EvModel.auxKw(w) / 90.0) * 0.8
                circle(pos, km) to if (set.reachRoundTrip) circle(pos, km / 2) else emptyList()
            }
            _state.update { it.copy(loading = false, outer = outer, round = round, version = it.version + (if (fit) 1 else 0), center = pos) }
        }
    }

    private fun circle(c: LatLon, km: Double): List<LatLon> = (0 until 72).map { i ->
        val a = Math.toRadians(i * 5.0)
        LatLon(c.lat + cos(a) * km / 110.54, c.lon + sin(a) * km / (111.32 * cos(Math.toRadians(c.lat))))
    }
}


// ======================= Letzter Akkustand vom OBD =======================

/** Merkt sich den letzten OBD-Akkustand mit Uhrzeit („zuletzt gesehen vor 22 min“) */
object LastSoc {
    private lateinit var prefs: android.content.SharedPreferences
    private val _state = MutableStateFlow<Pair<Double, Long>?>(null)
    val state: StateFlow<Pair<Double, Long>?> = _state.asStateFlow()
    private var lastSaved = 0L

    fun init(ctx: android.content.Context) {
        prefs = ctx.getSharedPreferences("lastsoc", android.content.Context.MODE_PRIVATE)
        val at = prefs.getLong("at", 0L)
        if (at > 0) _state.value = prefs.getFloat("soc", 0f).toDouble() to at
    }

    /** Neuer OBD-Wert: anzeigen, höchstens einmal pro Minute speichern und als „Akku jetzt“ übernehmen */
    fun note(soc: Double) {
        val now = System.currentTimeMillis()
        _state.value = soc to now
        if (now - lastSaved < 60_000) return
        lastSaved = now
        if (::prefs.isInitialized) prefs.edit().putFloat("soc", soc.toFloat()).putLong("at", now).apply()
        if (kotlin.math.abs(Settings.state.value.socStart - soc) >= 1.0) Settings.update { it.copy(socStart = soc.roundToInt().toDouble()) }
    }
}


// ======================= Planung mit Wünschen =======================

object WishPlanner {
    /** Energie (kWh) zwischen zwei Stellen der Route, mit 12 % Sicherheitsaufschlag (Höhe ist hier nicht enthalten) */
    fun kwh(r: Route, a: Double, b: Double, s: AppSettings): Double {
        if (b <= a) return 0.0
        // TomTom rechnet Höhenmeter mit ein: Verbrauch je Abschnitt aus dessen Akkuverlauf ablesen und unser Tempo-Modell darauf eichen
        val prof = r.socProfile
        var total = 0.0
        var x = a
        while (x < b - 1) {
            val i = prof.indexOfLast { it.first <= x }
            val next = prof.getOrNull(i + 1)
            val segEnd = minOf(b, next?.first ?: b)
            val model = TempoCoach.cost(TempoCoach.segments(r, x, segEnd), null, s, r.weather).first
            var factor = 1.0
            val p0 = prof.getOrNull(i)
            if (p0 != null && next != null && next.second < p0.second && next.first - p0.first > 5_000) {
                val tt = (p0.second - next.second) / 100 * s.usableKwh
                val mm = TempoCoach.cost(TempoCoach.segments(r, p0.first, next.first), null, s, r.weather).first
                if (mm > 0.5) factor = (tt / mm).coerceIn(0.8, 1.8)
            }
            total += model * factor
            x = if (segEnd > x) segEnd else b
        }
        return total * 1.08
    }

    /** Fahrzeit (s) bis zu einer Stelle, Ladezeiten eingerechnet */
    fun timeAt(r: Route, along: Double): Double {
        var i = r.stepAlongM.indexOfLast { it <= along }.coerceAtLeast(0)
        if (i >= r.stepAlongM.lastIndex) i = (r.stepAlongM.size - 2).coerceAtLeast(0)
        val a = r.stepAlongM.getOrElse(i) { 0.0 }
        val b = r.stepAlongM.getOrElse(i + 1) { r.cumM.last() }
        val ta = r.stepTimeS.getOrElse(i) { 0.0 }
        val tb = r.stepTimeS.getOrElse(i + 1) { r.driveS }
        var t = ta + (tb - ta) * ((along - a) / (b - a).coerceAtLeast(1.0)).coerceIn(0.0, 1.0)
        if (!r.timesIncludeCharging) t += r.stops.filter { it.alongM <= along }.sumOf { it.chargeS }
        return t
    }

    /** Stelle der Route, an der man nach t Sekunden ist */
    fun alongAt(r: Route, t: Double): Double? {
        val end = r.cumM.last()
        if (t <= 0) return 0.0
        if (t > timeAt(r, end)) return null
        var lo = 0.0; var hi = end
        repeat(40) { val mid = (lo + hi) / 2; if (timeAt(r, mid) < t) lo = mid else hi = mid }
        return (lo + hi) / 2
    }

    /**
     * Ladestopps nur bei den gewünschten Anbietern: jeweils den am weitesten erreichbaren passenden Lader wählen.
     * Ergebnis: gewählte Lader und ggf. ein Hinweis, wo es keinen passenden gab.
     */
    fun pickChargers(r: Route, cands: List<ChargerHit>, socStart: Double, s: AppSettings): Pair<List<ChargerHit>, String?> {
        val usable = s.usableKwh
        val end = r.cumM.last()
        var pos = 0.0
        var soc = socStart
        val chosen = mutableListOf<ChargerHit>()
        var problem: String? = null
        var guard = 0
        while (guard++ < 30) {
            val toEnd = soc - kwh(r, pos, end, s) / usable * 100
            if (toEnd >= s.minSocDest) break
            val reachable = cands.filter { it.alongM > pos + 15_000 && soc - kwh(r, pos, it.alongM, s) / usable * 100 >= s.minSocStop }
            val pick = reachable.maxByOrNull { it.alongM }
            if (pick == null) {
                problem = "Nach km ${(pos / 1000).roundToInt()} ist kein passender Lader in Reichweite – dort plant TomTom einen anderen ein."
                break
            }
            chosen += pick
            val arrive = soc - kwh(r, pos, pick.alongM, s) / usable * 100
            val needToEnd = kwh(r, pick.alongM, end, s) / usable * 100 + s.minSocDest + 3
            soc = needToEnd.coerceIn(arrive + 10, 80.0)
            pos = pick.alongM
        }
        return chosen to problem
    }
}
