package de.evroute

/**
 * Live-Belegung von Ladepunkten (frei / belegt / außer Betrieb).
 * Nur punktuell: für den nächsten Ladestopp auf der Route und beim Antippen eines Ladeparks.
 * Vorbereitet für Moovility – sobald es eine Schnittstelle und einen Zugang gibt, wird hier der Anbieter eingehängt.
 */
interface LiveStatusProvider {
    val name: String
    fun configured(): Boolean
    suspend fun availability(id: String): Availability?
}

/** Platzhalter für Moovility (Zugang wird noch geklärt) */
object MoovilityProvider : LiveStatusProvider {
    override val name = "Moovility"
    // Später z. B. Basisadresse + Schlüssel aus einem GitHub-Secret (BuildConfig), wie bei den Valhalla-Kacheln
    override fun configured(): Boolean = false
    override suspend fun availability(id: String): Availability? = null
}

object LiveStatus {
    private val providers: List<LiveStatusProvider> = listOf(MoovilityProvider)

    fun available(): Boolean = providers.any { it.configured() }

    suspend fun availability(id: String): Availability? {
        for (p in providers) if (p.configured()) p.availability(id)?.let { return it }
        return null
    }
}
