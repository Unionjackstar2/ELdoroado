package de.evroute

import android.app.DownloadManager
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.StatFs
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.valhalla.api.models.CostingModel
import com.valhalla.api.models.RouteRequest
import com.valhalla.api.models.RoutingWaypoint
import com.valhalla.config.ValhallaConfigBuilder
import com.valhalla.valhalla.Valhalla
import com.valhalla.valhalla.ValhallaResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import kotlin.math.roundToInt
import com.osrm.api.models.RouteResponse as OsrmRouteResponse

/**
 * Valhalla-Kartendaten vom eigenen Server: Versionsprüfung über metadata.json,
 * Download über Androids Downloadmanager (nur WLAN, setzt nach Abbruch fort, läuft auch bei geschlossener App).
 */
object ValhallaTiles {
    /** Bibliothek valhalla-mobile 0.6.1 = Valhalla 3.6.3; ältere oder gleiche Kachel-Versionen sind lesbar */
    private const val LIB_MAJOR_MINOR = "3.6"

    data class Remote(val version: String, val buildDate: String, val valhallaVersion: String, val fileName: String, val sizeBytes: Long?)

    data class State(
        val installedVersion: String? = null,
        val installedDate: String? = null,
        val installedBytes: Long = 0,
        val remote: Remote? = null,
        val checking: Boolean = false,
        val downloading: Boolean = false,
        val bytes: Long = 0,
        val total: Long = 0,
        val waitingForWifi: Boolean = false,
        val error: String? = null,
    ) {
        val updateAvailable: Boolean get() = remote != null && remote.version != installedVersion
        val ready: Boolean get() = installedVersion != null
    }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    private lateinit var dir: File
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var watchJob: Job? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        prefs = ctx.getSharedPreferences("valhalla", Context.MODE_PRIVATE)
        dir = (ctx.getExternalFilesDir("valhalla") ?: File(ctx.filesDir, "valhalla")).also { it.mkdirs() }
        refreshInstalled()
        if (prefs.getLong("dlId", -1L) >= 0) watch()
        // höchstens zweimal am Tag nach neuen Kartendaten schauen
        if (System.currentTimeMillis() - prefs.getLong("checked", 0L) > 12 * 3600_000L) scope.launch { check() }
    }

    fun tarFile(): File? {
        if (!::prefs.isInitialized) return null
        val name = prefs.getString("file", null) ?: return null
        return File(dir, name).takeIf { it.exists() && it.length() > 1_000_000 }
    }

    private fun refreshInstalled() {
        val f = tarFile()
        _state.update {
            it.copy(
                installedVersion = if (f != null) prefs.getString("version", null) else null,
                installedDate = if (f != null) prefs.getString("date", null) else null,
                installedBytes = f?.length() ?: 0,
            )
        }
    }

    private fun auth(b: Request.Builder) = b.header(ValhallaEngine.authHeader().first, ValhallaEngine.authHeader().second)

    /** metadata.json abrufen */
    suspend fun check(): Remote? {
        if (!ValhallaEngine.serverConfigured()) return null
        _state.update { it.copy(checking = true, error = null) }
        return try {
            val r = Http.call(auth(Request.Builder().url(ValhallaEngine.metadataUrl)).build())
            if (r.code == 401 || r.code == 403) throw IOException("Kein Zugang zum Kartenserver (Token).")
            if (r.code != 200) throw IOException("Kartenserver antwortet nicht (Fehler ${r.code}).")
            val o = json.parseToJsonElement(r.body).jsonObject
            fun str(k: String) = (o[k] as? JsonPrimitive)?.content ?: ""
            val remote = Remote(
                version = str("version"),
                buildDate = str("build_date"),
                valhallaVersion = str("valhalla_version"),
                fileName = str("file_name").ifBlank { "valhalla_germany.tar" },
                sizeBytes = str("size_bytes").toLongOrNull(),
            )
            prefs.edit().putLong("checked", System.currentTimeMillis()).apply()
            _state.update { it.copy(remote = remote, checking = false) }
            remote
        } catch (e: Exception) {
            _state.update { it.copy(checking = false, error = e.message) }
            null
        }
    }

    fun compatible(r: Remote): Boolean {
        val v = r.valhallaVersion.trim()
        if (v.isBlank()) return true
        // gleiche Haupt-/Nebenversion oder älter ist lesbar
        val (a, b) = v.split('.').take(2).map { it.toIntOrNull() ?: 0 }.let { (it + listOf(0, 0)).take(2) }
        val (la, lb) = LIB_MAJOR_MINOR.split('.').map { it.toInt() }
        return a < la || (a == la && b <= lb)
    }

    private fun fileUrl(name: String) = BuildConfig.TILES_BASE.trimEnd('/') + "/" + name

    /** Download starten (Standard: nur WLAN) */
    suspend fun startDownload(wifiOnly: Boolean = true) = withContext(Dispatchers.IO) {
        val remote = _state.value.remote ?: check() ?: return@withContext
        if (!compatible(remote)) {
            _state.update { it.copy(error = "Kartendaten sind mit Valhalla ${remote.valhallaVersion} gebaut, die App kann höchstens $LIB_MAJOR_MINOR lesen.") }
            return@withContext
        }
        val size = remote.sizeBytes
        val free = runCatching { StatFs(dir.path).availableBytes }.getOrDefault(Long.MAX_VALUE)
        val need = (size ?: 4_500_000_000L) + 300_000_000L
        if (free < need) {
            _state.update { it.copy(error = "Zu wenig freier Speicher: nötig etwa ${gb(need)}, frei ${gb(free)}.") }
            return@withContext
        }
        val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        prefs.getLong("dlId", -1L).takeIf { it >= 0 }?.let { runCatching { dm.remove(it) } }
        File(dir, remote.fileName + ".part").delete()
        val req = DownloadManager.Request(Uri.parse(fileUrl(remote.fileName)))
            .addRequestHeader(ValhallaEngine.authHeader().first, ValhallaEngine.authHeader().second)
            .setTitle("ELdoroado Kartendaten")
            .setDescription("Routing offline · ${remote.version}")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(app, "valhalla", remote.fileName + ".part")
            .setAllowedOverMetered(!wifiOnly)
            .setAllowedOverRoaming(false)
        val id = dm.enqueue(req)
        prefs.edit().putLong("dlId", id).putString("dlVersion", remote.version).putString("dlDate", remote.buildDate)
            .putString("dlFile", remote.fileName).apply()
        _state.update { it.copy(downloading = true, bytes = 0, total = size ?: 0, error = null) }
        watch()
    }

    fun cancel() {
        val id = prefs.getLong("dlId", -1L)
        if (id >= 0) runCatching { (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id) }
        prefs.edit().remove("dlId").apply()
        watchJob?.cancel()
        _state.update { it.copy(downloading = false, bytes = 0, total = 0, waitingForWifi = false) }
    }

    fun delete() {
        cancel()
        ValhallaRouter.reset()
        tarFile()?.delete()
        prefs.edit().remove("file").remove("version").remove("date").apply()
        refreshInstalled()
    }

    private fun watch() {
        watchJob?.cancel()
        watchJob = scope.launch {
            val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            while (isActive) {
                val id = prefs.getLong("dlId", -1L)
                if (id < 0) break
                val c = dm.query(DownloadManager.Query().setFilterById(id))
                if (c == null || !c.moveToFirst()) {
                    c?.close()
                    prefs.edit().remove("dlId").apply()
                    _state.update { it.copy(downloading = false) }
                    break
                }
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                c.close()
                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> { finish(); break }
                    DownloadManager.STATUS_FAILED -> {
                        prefs.edit().remove("dlId").apply()
                        _state.update { it.copy(downloading = false, error = "Download fehlgeschlagen (Code $reason).") }
                        break
                    }
                    else -> _state.update {
                        it.copy(
                            downloading = true, bytes = done, total = if (total > 0) total else it.total,
                            waitingForWifi = status == DownloadManager.STATUS_PAUSED && reason == DownloadManager.PAUSED_QUEUED_FOR_WIFI,
                        )
                    }
                }
                delay(1000)
            }
        }
    }

    /** fertigen Download prüfen und an die Stelle der alten Kartendaten setzen */
    private fun finish() {
        val name = prefs.getString("dlFile", null) ?: return
        val part = File(dir, "$name.part")
        val ok = part.exists() && part.length() > 1_000_000 && runCatching {
            RandomAccessFile(part, "r").use { raf ->
                val b = ByteArray(5); raf.seek(257); raf.readFully(b); String(b) == "ustar"
            }
        }.getOrDefault(false)
        if (!ok) {
            part.delete()
            prefs.edit().remove("dlId").apply()
            _state.update { it.copy(downloading = false, error = "Die heruntergeladene Datei ist beschädigt. Bitte erneut laden.") }
            return
        }
        ValhallaRouter.reset()
        val target = File(dir, name)
        tarFile()?.takeIf { it.name != name }?.delete()
        target.delete()
        if (!part.renameTo(target)) {
            _state.update { it.copy(downloading = false, error = "Kartendaten konnten nicht übernommen werden.") }
            return
        }
        prefs.edit().putString("file", name).putString("version", prefs.getString("dlVersion", "")).putString("date", prefs.getString("dlDate", ""))
            .remove("dlId").apply()
        _state.update { it.copy(downloading = false, bytes = 0, total = 0, waitingForWifi = false, error = null) }
        refreshInstalled()
    }

    fun gb(b: Long) = String.format(java.util.Locale.GERMANY, "%.1f GB", b / 1e9)
}

/** Routenberechnung offline mit Valhalla, Antwort im OSRM-Format → bestehende Auswertung */
object ValhallaRouter {
    private val mutex = Mutex()
    private var engine: Valhalla? = null
    private var engineFor: String? = null
    private val moshi by lazy { Moshi.Builder().add(KotlinJsonAdapterFactory()).build() }
    private lateinit var app: Context

    fun init(ctx: Context) { app = ctx.applicationContext }

    fun ready(): Boolean = ::app.isInitialized && ValhallaTiles.tarFile() != null

    fun reset() {
        runCatching { engine?.close() }
        engine = null
        engineFor = null
    }

    suspend fun routes(from: LatLon, bearing: Float?, to: LatLon, alternatives: Int, vias: List<LatLon>, s: AppSettings): List<Route> =
        withContext(Dispatchers.Default) {
            mutex.withLock {
                val tar = ValhallaTiles.tarFile() ?: throw IOException("Keine Valhalla-Kartendaten auf dem Handy.")
                val eng = engine?.takeIf { engineFor == tar.absolutePath } ?: run {
                    reset()
                    Valhalla(app, ValhallaConfigBuilder().withTileExtract(tar.absolutePath).build()).also {
                        engine = it
                        engineFor = tar.absolutePath
                    }
                }
                val pts = listOf(from) + vias + listOf(to)
                val body = buildJsonObject {
                    put("locations", buildJsonArray {
                        pts.forEachIndexed { i, p ->
                            add(buildJsonObject {
                                put("lat", p.lat)
                                put("lon", p.lon)
                                put("type", "break")
                                if (i == 0 && bearing != null) {
                                    put("heading", bearing.roundToInt().mod(360))
                                    put("heading_tolerance", 45)
                                }
                            })
                        }
                    })
                    put("costing", "auto")
                    putJsonObject("costing_options") {
                        putJsonObject("auto") {
                            if (s.avoidToll) put("use_tolls", 0.0)
                            if (s.avoidMotorway) put("use_highways", 0.0)
                            if (s.avoidFerry) put("use_ferry", 0.0)
                        }
                    }
                    if (alternatives > 0 && vias.isEmpty()) put("alternates", alternatives.coerceAtMost(3))
                    put("format", "osrm")
                }.toString()
                val req = runCatching { moshi.adapter(RouteRequest::class.java).fromJson(body) }.getOrNull()
                    ?: RouteRequest(
                        locations = pts.map { RoutingWaypoint(lat = it.lat, lon = it.lon) },
                        costing = CostingModel.auto,
                        format = RouteRequest.Format.osrm,
                    )
                when (val resp = eng.route(req)) {
                    is ValhallaResponse.Osrm -> {
                        val raw = moshi.adapter(OsrmRouteResponse::class.java).toJson(resp.osrmResponse)
                        Routing.parseResponse(raw, 6, "Valhalla").mapIndexed { i, r -> r.copy(tag = if (i == 0) "Empfohlen" else "Alternative") }
                    }
                    else -> throw IOException("Valhalla: unerwartetes Antwortformat")
                }
            }
        }
}
