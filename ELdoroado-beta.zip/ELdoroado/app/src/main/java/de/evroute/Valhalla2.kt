package de.evroute

import android.app.DownloadManager
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.StatFs
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.valhalla.api.models.CostingModel
import com.valhalla.api.models.RouteRequest
import com.valhalla.api.models.RoutingWaypoint
import com.valhalla.config.ValhallaConfigBuilder
import com.valhalla.valhalla.Valhalla
import com.valhalla.valhalla.ValhallaResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import kotlin.math.roundToInt
import com.osrm.api.models.RouteResponse as OsrmRouteResponse

/**
 * Valhalla-Kartendaten vom eigenen Server: Versionsprüfung über metadata.json,
 * Download über Androids Downloadmanager (nur WLAN, setzt nach Abbruch fort, läuft auch bei geschlossener App).
 */
object ValhallaTiles {
    /** Bibliothek valhalla-mobile 0.6.1 = Valhalla 3.6.3; ältere oder gleiche Kachel-Versionen sind lesbar */
    private const val LIB_MAJOR_MINOR = "3.6"

    data class Remote(val version: String, val buildDate: String, val valhallaVersion: String, val fileName: String, val sizeBytes: Long?)

    data class State(
        val installedVersion: String? = null,
        val installedDate: String? = null,
        val installedBytes: Long = 0,
        val remote: Remote? = null,
        val checking: Boolean = false,
        val downloading: Boolean = false,
        val bytes: Long = 0,
        val total: Long = 0,
        val waitingForWifi: Boolean = false,
        val error: String? = null,
    ) {
        val updateAvailable: Boolean get() = remote != null && remote.version != installedVersion
        val ready: Boolean get() = installedVersion != null
    }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    private lateinit var dir: File
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var watchJob: Job? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        prefs = ctx.getSharedPreferences("valhalla", Context.MODE_PRIVATE)
        dir = (ctx.getExternalFilesDir("valhalla") ?: File(ctx.filesDir, "valhalla")).also { it.mkdirs() }
        refreshInstalled()
        if (prefs.getLong("dlId", -1L) >= 0) watch()
        // höchstens zweimal am Tag nach neuen Kartendaten schauen
        if (System.currentTimeMillis() - prefs.getLong("checked", 0L) > 12 * 3600_000L) scope.launch { check() }
    }

    fun tarFile(): File? {
        if (!::prefs.isInitialized) return null
        val name = prefs.getString("file", null) ?: return null
        return File(dir, name).takeIf { it.exists() && it.length() > 1_000_000 }
    }

    private fun refreshInstalled() {
        val f = tarFile()
        _state.update {
            it.copy(
                installedVersion = if (f != null) prefs.getString("version", null) else null,
                installedDate = if (f != null) prefs.getString("date", null) else null,
                installedBytes = f?.length() ?: 0,
            )
        }
    }

    private fun auth(b: Request.Builder) = b.header(ValhallaEngine.authHeader().first, ValhallaEngine.authHeader().second)

    /** metadata.json abrufen */
    suspend fun check(): Remote? {
        if (!ValhallaEngine.serverConfigured()) return null
        _state.update { it.copy(checking = true, error = null) }
        return try {
            val r = Http.call(auth(Request.Builder().url(ValhallaEngine.metadataUrl)).build())
            if (r.code == 401 || r.code == 403) throw IOException("Kein Zugang zum Kartenserver (Token).")
            if (r.code != 200) throw IOException("Kartenserver antwortet nicht (Fehler ${r.code}).")
            val o = json.parseToJsonElement(r.body).jsonObject
            fun str(k: String) = (o[k] as? JsonPrimitive)?.content ?: ""
            val remote = Remote(
                version = str("version"),
                buildDate = str("build_date"),
                valhallaVersion = str("valhalla_version"),
                fileName = str("file_name").ifBlank { "valhalla_germany.tar" },
                sizeBytes = str("size_bytes").toLongOrNull(),
            )
            prefs.edit().putLong("checked", System.currentTimeMillis()).apply()
            _state.update { it.copy(remote = remote, checking = false) }
            remote
        } catch (e: Exception) {
            _state.update { it.copy(checking = false, error = e.message) }
            null
        }
    }

    fun compatible(r: Remote): Boolean {
        val v = r.valhallaVersion.trim()
        if (v.isBlank()) return true
        // gleiche Haupt-/Nebenversion oder älter ist lesbar
        val (a, b) = v.split('.').take(2).map { it.toIntOrNull() ?: 0 }.let { (it + listOf(0, 0)).take(2) }
        val (la, lb) = LIB_MAJOR_MINOR.split('.').map { it.toInt() }
        return a < la || (a == la && b <= lb)
    }

    private fun fileUrl(name: String) = ValhallaEngine.url(name)

    /** Download starten (Standard: nur WLAN) */
    suspend fun startDownload(wifiOnly: Boolean = true) = withContext(Dispatchers.IO) {
        val remote = _state.value.remote ?: check() ?: return@withContext
        if (!compatible(remote)) {
            _state.update { it.copy(error = "Kartendaten sind mit Valhalla ${remote.valhallaVersion} gebaut, die App kann höchstens $LIB_MAJOR_MINOR lesen.") }
            return@withContext
        }
        val size = remote.sizeBytes
        val free = runCatching { StatFs(dir.path).availableBytes }.getOrDefault(Long.MAX_VALUE)
        val need = (size ?: 4_500_000_000L) + 300_000_000L
        if (free < need) {
            _state.update { it.copy(error = "Zu wenig freier Speicher: nötig etwa ${gb(need)}, frei ${gb(free)}.") }
            return@withContext
        }
        val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        prefs.getLong("dlId", -1L).takeIf { it >= 0 }?.let { runCatching { dm.remove(it) } }
        File(dir, remote.fileName + ".part").delete()
        val req = DownloadManager.Request(Uri.parse(fileUrl(remote.fileName)))
            .addRequestHeader(ValhallaEngine.authHeader().first, ValhallaEngine.authHeader().second)
            .setTitle("ELdoroado Kartendaten")
            .setDescription("Routing offline · ${remote.version}")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(app, "valhalla", remote.fileName + ".part")
            .setAllowedOverMetered(!wifiOnly)
            .setAllowedOverRoaming(false)
        val id = dm.enqueue(req)
        prefs.edit().putLong("dlId", id).putString("dlVersion", remote.version).putString("dlDate", remote.buildDate)
            .putString("dlFile", remote.fileName).apply()
        _state.update { it.copy(downloading = true, bytes = 0, total = size ?: 0, error = null) }
        watch()
    }

    fun cancel() {
        val id = prefs.getLong("dlId", -1L)
        if (id >= 0) runCatching { (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id) }
        prefs.edit().remove("dlId").apply()
        watchJob?.cancel()
        _state.update { it.copy(downloading = false, bytes = 0, total = 0, waitingForWifi = false) }
    }

    fun delete() {
        cancel()
        ValhallaRouter.reset()
        tarFile()?.delete()
        prefs.edit().remove("file").remove("version").remove("date").apply()
        refreshInstalled()
    }

    private fun watch() {
        watchJob?.cancel()
        watchJob = scope.launch {
            val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            while (isActive) {
                val id = prefs.getLong("dlId", -1L)
                if (id < 0) break
                val c = dm.query(DownloadManager.Query().setFilterById(id))
                if (c == null || !c.moveToFirst()) {
                    c?.close()
                    prefs.edit().remove("dlId").apply()
                    _state.update { it.copy(downloading = false) }
                    break
                }
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                c.close()
                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> { finish(); break }
                    DownloadManager.STATUS_FAILED -> {
                        prefs.edit().remove("dlId").apply()
                        _state.update { it.copy(downloading = false, error = "Download fehlgeschlagen (Code $reason).") }
                        break
                    }
                    else -> _state.update {
                        it.copy(
                            downloading = true, bytes = done, total = if (total > 0) total else it.total,
                            waitingForWifi = status == DownloadManager.STATUS_PAUSED && reason == DownloadManager.PAUSED_QUEUED_FOR_WIFI,
                        )
                    }
                }
                delay(1000)
            }
        }
    }

    /** fertigen Download prüfen und an die Stelle der alten Kartendaten setzen */
    private fun finish() {
        val name = prefs.getString("dlFile", null) ?: return
        val part = File(dir, "$name.part")
        val ok = part.exists() && part.length() > 1_000_000 && runCatching {
            RandomAccessFile(part, "r").use { raf ->
                val b = ByteArray(5); raf.seek(257); raf.readFully(b); String(b) == "ustar"
            }
        }.getOrDefault(false)
        if (!ok) {
            part.delete()
            prefs.edit().remove("dlId").apply()
            _state.update { it.copy(downloading = false, error = "Die heruntergeladene Datei ist beschädigt. Bitte erneut laden.") }
            return
        }
        ValhallaRouter.reset()
        val target = File(dir, name)
        tarFile()?.takeIf { it.name != name }?.delete()
        target.delete()
        if (!part.renameTo(target)) {
            _state.update { it.copy(downloading = false, error = "Kartendaten konnten nicht übernommen werden.") }
            return
        }
        prefs.edit().putString("file", name).putString("version", prefs.getString("dlVersion", "")).putString("date", prefs.getString("dlDate", ""))
            .remove("dlId").apply()
        _state.update { it.copy(downloading = false, bytes = 0, total = 0, waitingForWifi = false, error = null) }
        refreshInstalled()
    }

    fun gb(b: Long) = String.format(java.util.Locale.GERMANY, "%.1f GB", b / 1e9)
}

/** Routenberechnung offline mit Valhalla, Antwort im OSRM-Format → bestehende Auswertung */
object ValhallaRouter {
    private val mutex = Mutex()
    private var engine: Valhalla? = null
    private var engineFor: String? = null
    private val moshi by lazy { Moshi.Builder().add(KotlinJsonAdapterFactory()).build() }
    private lateinit var app: Context

    fun init(ctx: Context) { app = ctx.applicationContext }

    fun ready(): Boolean = ::app.isInitialized && ValhallaTiles.tarFile() != null

    /** Google-Polyline mit Genauigkeit 6 (Valhalla) */
    internal fun encode6(pts: List<LatLon>): String {
        val sb = StringBuilder()
        var pLat = 0L
        var pLon = 0L
        fun put(v: Long) {
            var x = if (v < 0) (v shl 1).inv() else v shl 1
            while (x >= 0x20) { sb.append(((0x20L or (x and 0x1f)) + 63).toInt().toChar()); x = x shr 5 }
            sb.append((x + 63).toInt().toChar())
        }
        for (p in pts) {
            val la = Math.round(p.lat * 1e6)
            val lo = Math.round(p.lon * 1e6)
            put(la - pLat); put(lo - pLon)
            pLat = la; pLon = lo
        }
        return sb.toString()
    }

    private class EdgeAttr(val lengthM: Double, val speedLimit: Int?, val elevation: Double?)

    /**
     * Straßeneigenschaften entlang der Route offline aus den Kacheln (Valhalla „trace_attributes“):
     * Tempolimit (OpenStreetMap) und mittlere Höhe je Straßenabschnitt. Die Route wird in Stücke bis 150 km geteilt,
     * weil Valhalla Spuren nur bis zu einer bestimmten Länge auswertet.
     * Gibt die Route mit Tempolimits und – falls die Kacheln Höhen enthalten – Höhenprofil zurück.
     */
    suspend fun attributes(r: Route): Route = withContext(Dispatchers.Default) {
        if (r.points.size < 2 || !ready()) return@withContext r
        val edges = ArrayList<EdgeAttr>()
        mutex.withLock {
            val tar = ValhallaTiles.tarFile() ?: return@withContext r
            val eng = engine?.takeIf { engineFor == tar.absolutePath } ?: run {
                reset()
                Valhalla(app, ValhallaConfigBuilder().withTileExtract(tar.absolutePath).build()).also { engine = it; engineFor = tar.absolutePath }
            }
            var start = 0
            while (start < r.points.lastIndex) {
                var end = start + 1
                while (end < r.points.lastIndex && end - start < 6000 && r.cumM[end] - r.cumM[start] < 150_000) end++
                val chunk = r.points.subList(start, end + 1)
                val body = buildJsonObject {
                    put("encoded_polyline", encode6(chunk))
                    put("costing", "auto")
                    put("shape_match", "edge_walk")
                    putJsonObject("filters") {
                        put("attributes", buildJsonArray {
                            listOf("edge.length", "edge.speed_limit", "edge.mean_elevation").forEach { add(JsonPrimitive(it)) }
                        })
                        put("action", "include")
                    }
                }.toString()
                val raw = runCatching { eng.traceAttributesRaw(body) }.getOrNull() ?: return@withContext r
                val root = runCatching { json.parseToJsonElement(raw).jsonObject }.getOrNull() ?: return@withContext r
                val arr = root["edges"] as? kotlinx.serialization.json.JsonArray ?: return@withContext r
                for (e in arr) {
                    val o = e as? kotlinx.serialization.json.JsonObject ?: continue
                    val len = (o["length"] as? JsonPrimitive)?.content?.toDoubleOrNull() ?: continue
                    val sl = (o["speed_limit"] as? JsonPrimitive)?.content?.toIntOrNull()
                    val el = (o["mean_elevation"] as? JsonPrimitive)?.content?.toDoubleOrNull()?.takeIf { it > -1000 && it < 9000 }
                    edges += EdgeAttr(len * 1000.0, sl?.takeIf { it in 5..200 }, el)
                }
                start = end
            }
        }
        if (edges.isEmpty()) return@withContext r
        // Kanten entlang der Route verteilen (Gesamtlänge auf unsere Routenlänge skaliert)
        val total = edges.sumOf { it.lengthM }
        val scale = if (total > 0) (r.cumM.last() / total) else 1.0
        val edgeEnd = DoubleArray(edges.size)
        var acc = 0.0
        for (i in edges.indices) { acc += edges[i].lengthM * scale; edgeEnd[i] = acc }
        val limits = IntArray(r.points.size - 1)
        var k = 0
        for (i in limits.indices) {
            val mid = (r.cumM[i] + r.cumM[i + 1]) / 2
            while (k < edges.lastIndex && edgeEnd[k] < mid) k++
            limits[i] = edges[k].speedLimit ?: 0
        }
        // Höhen: Mittelwert je Kante an der Kantenmitte, dazwischen linear
        val withEle = edges.indices.filter { edges[it].elevation != null }
        var out = r.copy(speedLimits = if (limits.any { it > 0 }) limits else r.speedLimits)
        if (withEle.size >= 2 && withEle.size >= edges.size / 2) {
            val mids = withEle.map { i -> (edgeEnd[i] - edges[i].lengthM * scale / 2) to edges[i].elevation!! }
            val ele = FloatArray(r.points.size)
            var j = 0
            for (i in r.points.indices) {
                val a = r.cumM[i]
                while (j < mids.lastIndex - 1 && mids[j + 1].first < a) j++
                val (m0, h0) = mids[j]
                val (m1, h1) = mids[(j + 1).coerceAtMost(mids.lastIndex)]
                val f = if (m1 > m0) ((a - m0) / (m1 - m0)).coerceIn(0.0, 1.0) else 0.0
                ele[i] = (h0 + (h1 - h0) * f).toFloat()
            }
            var up = 0.0; var down = 0.0; var ref = mids.first().second
            for ((_, h) in mids) {
                val d = h - ref
                if (kotlin.math.abs(d) >= 3) { if (d > 0) up += d else down -= d; ref = h }
            }
            out = out.copy(elevations = ele, ascentM = up, descentM = down)
        }
        out
    }

    fun reset() {
        runCatching { engine?.close() }
        engine = null
        engineFor = null
    }

    suspend fun routes(
        from: LatLon,
        bearing: Float?,
        to: LatLon,
        alternatives: Int,
        vias: List<LatLon>,
        s: AppSettings,
        exclude: List<List<LatLon>> = emptyList(),
    ): List<Route> =
        withContext(Dispatchers.Default) {
            mutex.withLock {
                val tar = ValhallaTiles.tarFile() ?: throw IOException("Keine Valhalla-Kartendaten auf dem Handy.")
                val eng = engine?.takeIf { engineFor == tar.absolutePath } ?: run {
                    reset()
                    Valhalla(app, ValhallaConfigBuilder().withTileExtract(tar.absolutePath).build()).also {
                        engine = it
                        engineFor = tar.absolutePath
                    }
                }
                val pts = listOf(from) + vias + listOf(to)
                val body = buildJsonObject {
                    put("locations", buildJsonArray {
                        pts.forEachIndexed { i, p ->
                            add(buildJsonObject {
                                put("lat", p.lat)
                                put("lon", p.lon)
                                put("type", "break")
                                if (i == 0 && bearing != null) {
                                    put("heading", bearing.roundToInt().mod(360))
                                    put("heading_tolerance", 45)
                                }
                            })
                        }
                    })
                    put("costing", "auto")
                    putJsonObject("costing_options") {
                        putJsonObject("auto") {
                            // eingestelltes Höchsttempo (viele E-Autos fahren bewusst 110–120): Fahrzeit und Streckenwahl passen besser
                            if (s.maxSpeedKmh in 60..250) put("top_speed", s.maxSpeedKmh)
                            if (s.avoidToll) put("use_tolls", 0.0)
                            if (s.avoidMotorway) put("use_highways", 0.0)
                            if (s.avoidFerry) put("use_ferry", 0.0)
                        }
                    }
                    if (alternatives > 0 && vias.isEmpty()) put("alternates", alternatives.coerceAtMost(3))
                    // gesperrte Abschnitte umfahren (geschlossene Ringe, lon/lat)
                    if (exclude.isNotEmpty()) {
                        put("exclude_polygons", buildJsonArray {
                            exclude.take(20).forEach { ring ->
                                add(buildJsonArray { (ring + ring.first()).forEach { p -> add(buildJsonArray { add(JsonPrimitive(p.lon)); add(JsonPrimitive(p.lat)) }) } })
                            }
                        })
                    }
                    put("format", "osrm")
                }.toString()
                val req = runCatching { moshi.adapter(RouteRequest::class.java).fromJson(body) }.getOrNull()
                    ?: RouteRequest(
                        locations = pts.map { RoutingWaypoint(lat = it.lat, lon = it.lon) },
                        costing = CostingModel.auto,
                        format = RouteRequest.Format.osrm,
                    )
                when (val resp = eng.route(req)) {
                    is ValhallaResponse.Osrm -> {
                        val raw = moshi.adapter(OsrmRouteResponse::class.java).toJson(resp.osrmResponse)
                        Routing.parseResponse(raw, 6, "Valhalla").mapIndexed { i, r -> r.copy(tag = if (i == 0) "Empfohlen" else "Alternative") }
                    }
                    else -> throw IOException("Valhalla: unerwartetes Antwortformat")
                }
            }
        }
}
