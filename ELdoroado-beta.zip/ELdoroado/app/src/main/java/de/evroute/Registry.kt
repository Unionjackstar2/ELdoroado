package de.evroute

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.util.JsonReader
import android.util.JsonToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.InputStreamReader
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Ladesäulen in Deutschland offline: Ladesäulenregister der Bundesnetzagentur (CC BY 4.0, Quelle: Bundesnetzagentur.de),
 * wöchentlich als JSON aufbereitet von github.com/ratopi/ladesaeule. Die App lädt die Datei (~10 MB) höchstens einmal pro Woche,
 * fasst Ladeeinrichtungen zu Standorten zusammen und sucht danach komplett lokal – ohne Schlüssel und ohne Kontingent.
 */
object ChargerRegistry {
    private val URLS = listOf(
        "https://ratopi.github.io/ladesaeule/ladesaeulen.json.gz",
        "https://raw.githubusercontent.com/ratopi/ladesaeule/gh-pages/ladesaeulen.json.gz",
    )
    private const val FILE = "ladesaeulen_v1.tsv"
    private const val MAX_AGE_MS = 7L * 24 * 3600 * 1000

    class Site(
        val lat: Double, val lon: Double, val kw: Double, val dc: Boolean, val ccs: Int,
        val op: String, val name: String, val addr: String, val groups: String, val conns: String,
        val hours: String, val pay: String,
    )

    @Volatile private var sites: Array<Site> = emptyArray()
    @Volatile private var grid: Map<Long, IntArray> = emptyMap()

    private val _count = MutableStateFlow(0)
    val count: StateFlow<Int> = _count.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    private val _stand = MutableStateFlow("")
    val stand: StateFlow<String> = _stand.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private lateinit var dir: File
    private lateinit var prefs: SharedPreferences
    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val client by lazy {
        OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()
    }

    fun ready() = sites.isNotEmpty()

    fun init(ctx: Context) {
        app = ctx.applicationContext
        dir = ctx.filesDir
        prefs = ctx.getSharedPreferences("registry", Context.MODE_PRIVATE)
        _stand.value = prefs.getString("stand", "") ?: ""
        scope.launch {
            runCatching { loadLocal() }
            update(force = false)
        }
    }

    fun updateNow() { if (::app.isInitialized) scope.launch { update(force = true) } }

    private fun metered(): Boolean = runCatching {
        (app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered
    }.getOrDefault(false)

    private suspend fun update(force: Boolean) {
        val f = File(dir, FILE)
        val age = System.currentTimeMillis() - prefs.getLong("checked", 0L)
        if (!force && f.exists() && age < MAX_AGE_MS) return
        if (!force && f.exists() && metered()) return // über Mobilfunk nur, wenn noch gar nichts da ist
        if (_loading.value) return
        _loading.value = true
        _error.value = null
        try {
            var done = false
            for (u in URLS) {
                val ok = runCatching { download(u, f) }.onFailure { _error.value = "Laden fehlgeschlagen: ${it.message}" }.getOrNull()
                if (ok != null) { done = true; break }
            }
            if (done) {
                _error.value = null
                prefs.edit().putLong("checked", System.currentTimeMillis()).apply()
                loadLocal()
            }
        } finally {
            _loading.value = false
        }
    }

    /** @return true = neu geladen, false = unverändert */
    private fun download(url: String, target: File): Boolean {
        val b = Request.Builder().url(url).header("User-Agent", "ELdoroado/${BuildConfigLite.version}")
        val etag = prefs.getString("etag_$url", null)
        if (etag != null && target.exists()) b.header("If-None-Match", etag)
        client.newCall(b.build()).execute().use { r ->
            if (r.code == 304) return false
            if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
            val body = r.body ?: throw java.io.IOException("leere Antwort")
            val tmp = File(dir, "$FILE.tmp")
            val n = convert(GZIPInputStream(body.byteStream()), tmp)
            if (n < 1000) { tmp.delete(); throw java.io.IOException("zu wenige Einträge ($n)") }
            if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
            r.header("ETag")?.let { prefs.edit().putString("etag_$url", it).apply() }
            return true
        }
    }

    // ---------- Umwandlung: JSON (gestreamt) → kompakte Standortliste ----------

    private class Acc(val lat: Double, val lon: Double) {
        var sumLat = 0.0; var sumLon = 0.0; var n = 0
        var kw = 0.0; var name = ""; var addr = ""; var hours = ""; var op = ""
        val pay = LinkedHashSet<String>()
        val byType = LinkedHashMap<String, Int>()
        val byTypeKw = LinkedHashMap<Pair<String, Int>, Int>()
    }

    private fun plug(t: String) = when {
        t.contains("CCS", true) -> "CCS"
        t.contains("CHAdeMO", true) -> "CHAdeMO"
        t.contains("Megawatt", true) || t.contains("MCS") -> "MCS"
        t.contains("Tesla", true) -> "Tesla"
        t.contains("Typ 2", true) -> "Typ 2"
        t.contains("Typ 1", true) -> "Typ 1"
        t.contains("Schuko", true) -> "Schuko"
        t.contains("CEE", true) -> "CEE"
        else -> t.take(20)
    }

    private fun payLabel(p: String) = when {
        p.startsWith("contactless") -> "kontaktlos"
        p == "rfid" -> "Ladekarte"
        p == "app" -> "App"
        p == "credit_cards" -> "Kreditkarte"
        p == "debit_cards" -> "EC-Karte"
        p == "cash" -> "bar"
        else -> null
    }

    private fun num(s: String): Double = s.replace(',', '.').trim().toDoubleOrNull() ?: 0.0

    private fun JsonReader.str(): String = when (peek()) {
        JsonToken.NULL -> { nextNull(); "" }
        JsonToken.STRING, JsonToken.NUMBER -> nextString()
        JsonToken.BOOLEAN -> nextBoolean().toString()
        else -> { skipValue(); "" }
    }

    private fun JsonReader.strings(): List<String> {
        if (peek() != JsonToken.BEGIN_ARRAY) { val v = str(); return if (v.isBlank()) emptyList() else listOf(v) }
        val out = ArrayList<String>(2)
        beginArray(); while (hasNext()) out += str(); endArray()
        return out
    }

    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim()

    private fun convert(input: java.io.InputStream, out: File): Int {
        val map = HashMap<String, Acc>(90_000)
        var stand = ""
        JsonReader(InputStreamReader(input, Charsets.UTF_8)).use { jr ->
            jr.beginObject()
            while (jr.hasNext()) {
                when (jr.nextName()) {
                    "data" -> {
                        jr.beginArray()
                        while (jr.hasNext()) readRecord(jr, map)
                        jr.endArray()
                    }
                    "meta" -> {
                        jr.beginObject()
                        while (jr.hasNext()) {
                            val k = jr.nextName()
                            if (k == "source") {
                                val src = jr.str()
                                Regex("(\\d{4})-(\\d{2})-(\\d{2})").find(src)?.let { m -> stand = "${m.groupValues[3]}.${m.groupValues[2]}.${m.groupValues[1]}" }
                            } else jr.skipValue()
                        }
                        jr.endObject()
                    }
                    else -> jr.skipValue()
                }
            }
            jr.endObject()
        }
        out.bufferedWriter().use { w ->
            for (a in map.values) {
                if (a.n == 0) continue
                val groups = a.byTypeKw.entries.sortedByDescending { it.key.second }
                    .joinToString("|") { (k, v) -> "$v× ${k.first}" + if (k.second > 0) " · ${k.second} kW" else "" }
                val conns = a.byType.entries.sortedByDescending { e -> a.byTypeKw.filterKeys { it.first == e.key }.keys.maxOfOrNull { it.second } ?: 0 }
                    .joinToString(" · ") { "${it.value}× ${it.key}" }
                val dc = a.byType.keys.any { it == "CCS" || it == "CHAdeMO" || it == "MCS" || it == "Tesla" }
                w.append(String.format(Locale.US, "%.6f\t%.6f\t%.1f\t", a.sumLat / a.n, a.sumLon / a.n, a.kw))
                    .append(if (dc) "1" else "0").append('\t').append((a.byType["CCS"] ?: 0).toString()).append('\t')
                    .append(clean(a.op)).append('\t').append(clean(a.name)).append('\t').append(clean(a.addr)).append('\t')
                    .append(clean(groups)).append('\t').append(clean(conns)).append('\t').append(clean(a.hours)).append('\t')
                    .append(clean(a.pay.joinToString(", "))).append('\n')
            }
        }
        if (stand.isNotBlank()) { _stand.value = stand; prefs.edit().putString("stand", stand).apply() }
        return map.size
    }

    private fun readRecord(jr: JsonReader, map: HashMap<String, Acc>) {
        var lat = Double.NaN; var lon = Double.NaN
        var status = ""; var op = ""; var display = ""; var location = ""
        var street = ""; var house = ""; var postcode = ""; var city = ""; var extra = ""
        var hours = ""; val pay = ArrayList<String>()
        var rated = 0.0
        val points = ArrayList<Pair<List<String>, List<Double>>>()
        jr.beginObject()
        while (jr.hasNext()) {
            when (jr.nextName()) {
                "status" -> status = jr.str()
                "operator" -> op = jr.str()
                "display_name" -> display = jr.str()
                "location_name" -> location = jr.str()
                "geo" -> { jr.beginObject(); while (jr.hasNext()) when (jr.nextName()) { "lat" -> lat = num(jr.str()); "lon" -> lon = num(jr.str()); else -> jr.skipValue() }; jr.endObject() }
                "addr" -> {
                    jr.beginObject()
                    while (jr.hasNext()) when (jr.nextName()) {
                        "street" -> street = jr.str(); "house_number" -> house = jr.str(); "postcode" -> postcode = jr.str()
                        "city" -> city = jr.str(); "address_extra" -> extra = jr.str(); else -> jr.skipValue()
                    }
                    jr.endObject()
                }
                "access" -> {
                    jr.beginObject()
                    while (jr.hasNext()) when (jr.nextName()) { "opening_hours" -> hours = jr.str(); "payment" -> pay += jr.strings(); else -> jr.skipValue() }
                    jr.endObject()
                }
                "charging" -> {
                    jr.beginObject()
                    while (jr.hasNext()) when (jr.nextName()) {
                        "rated_power_kw" -> rated = num(jr.str())
                        "points" -> {
                            jr.beginArray()
                            while (jr.hasNext()) {
                                var plugs = emptyList<String>(); var pw = emptyList<Double>()
                                jr.beginObject()
                                while (jr.hasNext()) when (jr.nextName()) { "plugs" -> plugs = jr.strings(); "power" -> pw = jr.strings().map { num(it) }; else -> jr.skipValue() }
                                jr.endObject()
                                points += plugs to pw
                            }
                            jr.endArray()
                        }
                        else -> jr.skipValue()
                    }
                    jr.endObject()
                }
                else -> jr.skipValue()
            }
        }
        jr.endObject()
        if (lat.isNaN() || lon.isNaN() || lat == 0.0) return
        if (status.isNotBlank() && !status.equals("operational", true)) return
        val opClean = op.trim()
        val key = String.format(Locale.US, "%.4f|%.4f|", lat, lon) + opClean.lowercase()
        val a = map.getOrPut(key) { Acc(lat, lon) }
        a.sumLat += lat; a.sumLon += lon; a.n++
        if (a.op.isBlank()) a.op = opClean.ifBlank { display.trim() }
        if (a.name.isBlank() && location.isNotBlank()) a.name = location.trim()
        if (a.addr.isBlank()) {
            val l1 = listOf(street.trim(), house.trim()).filter { it.isNotBlank() }.joinToString(" ")
            val l2 = listOf(postcode.trim(), city.trim()).filter { it.isNotBlank() }.joinToString(" ")
            a.addr = listOf(l1, l2).filter { it.isNotBlank() }.joinToString(", ") + if (extra.isNotBlank()) " (${extra.trim()})" else ""
        }
        if (a.hours.isBlank()) a.hours = hours.trim()
        pay.mapNotNull { payLabel(it) }.forEach { a.pay += it }
        a.kw = max(a.kw, rated)
        for ((plugs, pw) in points) {
            val pkw = (pw.maxOrNull() ?: rated).let { if (it <= 0) rated else it }
            a.kw = max(a.kw, pkw)
            plugs.map { plug(it) }.distinct().forEach { t ->
                a.byType[t] = (a.byType[t] ?: 0) + 1
                val k = t to pkw.roundToInt()
                a.byTypeKw[k] = (a.byTypeKw[k] ?: 0) + 1
            }
        }
    }

    // ---------- Laden und Suchen ----------

    private fun cell(lat: Double, lon: Double): Long = (floor(lat * 10).toLong() + 900) * 10_000 + (floor(lon * 10).toLong() + 1800)

    private suspend fun loadLocal() = withContext(Dispatchers.IO) {
        val f = File(dir, FILE)
        if (!f.exists()) return@withContext
        val list = ArrayList<Site>(75_000)
        val ops = HashMap<String, String>()
        f.bufferedReader().useLines { lines ->
            for (line in lines) {
                val c = line.split('\t')
                if (c.size < 12) continue
                val op = ops.getOrPut(c[5]) { c[5] }
                list += Site(c[0].toDouble(), c[1].toDouble(), c[2].toDouble(), c[3] == "1", c[4].toIntOrNull() ?: 0, op, c[6], c[7], c[8], c[9], c[10], c[11])
            }
        }
        val g = HashMap<Long, ArrayList<Int>>()
        list.forEachIndexed { i, s -> g.getOrPut(cell(s.lat, s.lon)) { ArrayList() }.add(i) }
        sites = list.toTypedArray()
        grid = g.mapValues { it.value.toIntArray() }
        _count.value = list.size
    }

    private fun candidates(c: LatLon, radiusM: Double): Sequence<Site> {
        val dLat = radiusM / 111_000.0
        val dLon = radiusM / (111_000.0 * max(0.2, cos(Math.toRadians(c.lat))))
        val g = grid
        val s = sites
        val lat0 = floor((c.lat - dLat) * 10).toInt(); val lat1 = floor((c.lat + dLat) * 10).toInt()
        val lon0 = floor((c.lon - dLon) * 10).toInt(); val lon1 = floor((c.lon + dLon) * 10).toInt()
        return sequence {
            for (la in lat0..lat1) for (lo in lon0..lon1) {
                val ids = g[(la.toLong() + 900) * 10_000 + (lo.toLong() + 1800)] ?: continue
                for (i in ids) yield(s[i])
            }
        }
    }

    /** Bekannte Netze kurz und einheitlich benennen, sonst Rechtsform-Zusätze entfernen */
    fun shortOperator(op: String): String {
        val l = op.lowercase()
        val brands = listOf(
            "enbw" to "EnBW", "ionity" to "IONITY", "tesla" to "Tesla", "aral" to "Aral pulse", "fastned" to "Fastned", "allego" to "Allego",
            "ewe go" to "EWE Go", "e.on" to "E.ON", "eon drive" to "E.ON", "shell" to "Shell Recharge", "mer germany" to "Mer", "pfalzwerke" to "Pfalzwerke",
            "totalenergies" to "TotalEnergies", "maingau" to "Maingau", "lidl" to "Lidl", "kaufland" to "Kaufland", "aldi" to "ALDI", "electra" to "Electra",
            "atlante" to "Atlante", "dortmunder energie" to "DEW21", "mark-e" to "Mark-E", "westenergie" to "Westenergie", "innogy" to "Westenergie",
            "eviny" to "Eviny", "be.energised" to "has·to·be", "vattenfall" to "Vattenfall", "zunder" to "Zunder", "avu" to "AVU",
        )
        brands.firstOrNull { l.contains(it.first) }?.let { return it.second }
        return op.replace(Regex("(?i)\\b(gmbh|mbh|ag|kg|co\\.?|& co\\.?|und co\\.?|aktiengesellschaft|se|ug|haftungsbeschränkt|e\\.\\s?k\\.)\\b"), " ")
            .replace(Regex("[()&,+]"), " ").replace(Regex("(?<=\\s|^)\\.+(?=\\s|$)"), " ").replace(Regex("\\s+"), " ").trim().take(40)
    }

    private fun toHit(s: Site): ChargerHit {
        val opShort = shortOperator(s.op)
        val lines = buildList {
            when {
                s.hours.equals("24/7", true) -> add("Rund um die Uhr geöffnet")
                s.hours.isNotBlank() -> add("Öffnungszeiten: ${s.hours}")
            }
            if (s.pay.isNotBlank()) add("Bezahlen: ${s.pay}")
        }
        return ChargerHit(
            name = s.name.ifBlank { opShort.ifBlank { "Ladestation" } },
            operator = opShort,
            pos = LatLon(s.lat, s.lon),
            powerKw = s.kw,
            detourS = 0.0,
            alongM = 0.0,
            availId = null,
            id = String.format(Locale.US, "bna:%.5f,%.5f", s.lat, s.lon),
            connectors = s.conns,
            teslaOnly = false,
            address = s.addr,
            connectorGroups = if (s.groups.isBlank()) emptyList() else s.groups.split('|'),
            openingLines = lines,
        )
    }

    /** Standorte im Umkreis, nächste zuerst */
    fun nearby(c: LatLon, radiusM: Int, minKw: Int, fastOnly: Boolean, limit: Int = 250): List<ChargerHit> =
        candidates(c, radiusM.toDouble())
            .filter { (!fastOnly || it.dc) && it.kw >= minKw }
            .map { it to haversine(LatLon(it.lat, it.lon), c) }
            .filter { it.second <= radiusM }
            .sortedBy { it.second }
            .take(limit)
            .map { toHit(it.first) }
            .toList()

    /** Schnelllader entlang der Route (Korridor), sortiert nach Lage auf der Route */
    fun corridor(r: Route, fromM: Double, toM: Double, widthKm: Int, minKw: Int): List<ChargerHit> {
        val end = minOf(toM, r.cumM.lastOrNull() ?: 0.0)
        val start = max(0.0, fromM)
        if (end <= start || !ready()) return emptyList()
        val seen = HashSet<Site>()
        val radius = widthKm * 1000.0 + 1500
        var m = start
        var i = 0
        while (m <= end) {
            while (i < r.cumM.size - 1 && r.cumM[i + 1] < m) i++
            val p = r.points[i]
            candidates(p, radius).filter { it.dc && it.kw >= max(minKw, 1) }.forEach { seen += it }
            m += 3_000.0
        }
        return seen.mapNotNull { s ->
            val h = toHit(s)
            val (along, off) = TomTom.locateOnRoute(r, h.pos)
            if (off > widthKm * 1000.0 || along < start - 1000 || along > end + 1000) null else h.copy(alongM = along, offsetM = off)
        }.sortedBy { it.alongM }
    }
}
