package de.evroute

import kotlin.math.abs

/**
 * TomTom liefert an vielen Kreuzungen, Auffahrten und Autobahnkreuzen nur „rechts halten“.
 * Hier wird das Manöver anhand von Abbiegewinkel, Kreuzungsart und Straßenart genauer eingeordnet:
 * echtes Abbiegen, Autobahnwechsel am Kreuz, Abfahrt, Auffahrt oder tatsächliches Halten an einer Gabelung.
 */
object ManeuverRefiner {
    data class Result(val type: String, val mod: String?, val phrase: String?, val phraseHasRoad: Boolean = false)

    private val motorway = Regex("^A\\s?\\d")

    fun isMotorway(nums: List<String>) = nums.any { motorway.containsMatchIn(it.trim()) }

    private fun mwNumber(nums: List<String>) = nums.firstOrNull { motorway.containsMatchIn(it.trim()) }?.trim()

    /** Abbiegewinkel aus der Linienführung (positiv = rechts), falls TomTom keinen liefert */
    fun geoAngle(pts: List<LatLon>, cum: DoubleArray, along: Double): Double? {
        if (pts.size < 3 || cum.size != pts.size) return null
        val i = cum.indexOfFirst { it >= along }.takeIf { it > 0 } ?: return null
        val m = if (cum[i] - along < along - cum[i - 1]) i else i - 1
        var a = m
        while (a > 0 && cum[m] - cum[a] < 20) a--
        var b = m
        while (b < pts.lastIndex && cum[b] - cum[m] < 20) b++
        if (a == m || b == m) return null
        var d = bearing(pts[m], pts[b]) - bearing(pts[a], pts[m])
        while (d > 180) d -= 360
        while (d < -180) d += 360
        return d
    }

    private fun side(maneuver: String, angle: Double?, mod: String?): String = when {
        maneuver.contains("LEFT") -> "links"
        maneuver.contains("RIGHT") -> "rechts"
        angle != null && abs(angle) > 3 -> if (angle < 0) "links" else "rechts"
        mod?.contains("left") == true -> "links"
        else -> "rechts"
    }

    private fun turnMod(angle: Double): String {
        val a = abs(angle)
        val s = if (angle < 0) "left" else "right"
        return when {
            a >= 120 -> "sharp $s"
            a >= 35 -> s
            else -> "slight $s"
        }
    }

    fun refine(
        type: String,
        mod: String?,
        maneuver: String,
        junction: String,
        angle: Double?,
        fromNums: List<String>,
        toNumsRaw: List<String>,
        signpost: String,
    ): Result {
        // Rampen haben oft keine Straßennummer: dann die Autobahn aus dem Wegweiser nehmen
        val toNums = if (toNumsRaw.isEmpty()) Regex("\\bA\\s?\\d{1,3}\\b").findAll(signpost).map { it.value }.toList().take(1) else toNumsRaw
        val keep = Result(type, mod, null)
        if (type in listOf("arrive", "depart", "charge", "via", "ferry") || type.startsWith("roundabout") || junction == "ROUNDABOUT") return keep
        val fromMw = isMotorway(fromNums)
        val toMw = isMotorway(toNums)
        val sd = side(maneuver, angle, mod)
        val slight = if (sd == "links") "slight left" else "slight right"
        val toNo = mwNumber(toNums)
        val fromNo = mwNumber(fromNums)

        // Autobahnkreuz/-dreieck: von einer Autobahn auf eine andere
        if (fromMw && toMw && toNo != null && toNo != fromNo &&
            (type == "fork" || type == "off ramp" || type == "turn")
        ) {
            return Result("fork", slight, "$sd halten und auf die $toNo wechseln", true)
        }
        // Am Kreuz auf derselben Autobahn bleiben, die selbst abzweigt
        if (fromMw && toMw && toNo != null && toNo == fromNo && type == "fork") {
            return Result("fork", slight, "$sd halten, um auf der $toNo zu bleiben", true)
        }
        // Abfahrt von der Autobahn (auch wenn TomTom nur „rechts halten“ sagt)
        if (fromMw && !toMw && (type == "fork" || type == "off ramp")) {
            return Result("off ramp", slight, null)
        }
        // Auffahrt auf die Autobahn
        if (!fromMw && toMw && (type == "on ramp" || type == "fork" || type == "turn")) {
            return if (toNo != null) Result("on ramp", slight, "$sd auf die Auffahrt zur $toNo", true) else Result("on ramp", slight, null)
        }
        // Normale Straßen: deutlicher Winkel ist Abbiegen, kein „halten“
        if (!fromMw && (type == "fork" || type == "turn") && angle != null && junction != "BIFURCATION") {
            val a = abs(angle)
            if (a >= 35) return Result("turn", turnMod(angle), null)
            if (type == "fork") return Result("continue", slight, "$sd halten")
        }
        if (type == "fork" && junction != "BIFURCATION") return Result("continue", slight, "$sd halten")
        return keep
    }
}
