package de.evroute

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/** Brücke zur nativen llama.cpp-Bibliothek */
object LlamaNative {
    /** Ordner der nativen Bibliotheken (dort liegen die CPU-Varianten von llama.cpp) */
    @JvmField var libDir: String = ""
    val available: Boolean by lazy { runCatching { System.loadLibrary("evllm"); true }.getOrDefault(false) }
    external fun nativeStats(): String
    external fun nativeCpuInfo(): String
    external fun nativeLoad(path: String, threads: Int, nCtx: Int): Long
    external fun nativeFree(h: Long)
    external fun nativeTemplate(h: Long, system: String, user: String): ByteArray
    external fun nativeGenerate(h: Long, slot: Int, prefix: String, rest: String, grammar: String, maxTokens: Int, temp: Float, cache: String): ByteArray
    external fun nativePrepare(h: Long, slot: Int, prefix: String, cache: String): Boolean
}

/** Ein herunterladbares Modell */
data class LlmModel(val id: String, val name: String, val sizeLabel: String, val url: String, val file: String, val note: String, val format: String)

object LlmModels {
    val ALL = listOf(
        LlmModel(
            "qwen35-2b", "Qwen3.5 2B", "ca. 1,3 GB",
            "https://huggingface.co/unsloth/Qwen3.5-2B-GGUF/resolve/main/Qwen3.5-2B-Q4_K_M.gguf",
            "qwen35-2b-q4km.gguf", "Empfohlen: sehr zuverlässiges JSON, gutes Deutsch", "chatml",
        ),
        LlmModel(
            "gemma4-e2b", "Gemma 4 E2B", "ca. 1,5–3 GB",
            "https://huggingface.co/Hanish/quill-models/resolve/main/gemma-4-E2B-it-Q4_0.gguf",
            "gemma4-e2b-q40.gguf", "Von Google, fürs Handy optimiert (Gemma-Nutzungsbedingungen)", "gemma",
        ),
        LlmModel(
            "qwen35-08b", "Qwen3.5 0.8B", "ca. 0,5 GB",
            "https://huggingface.co/unsloth/Qwen3.5-0.8B-GGUF/resolve/main/Qwen3.5-0.8B-Q4_K_M.gguf",
            "qwen35-08b-q4km.gguf", "Sparsam und schnell, liegt öfter daneben", "chatml",
        ),
    )

    fun byId(id: String) = ALL.firstOrNull { it.id == id } ?: ALL.first()
    fun dir(ctx: Context) = File(ctx.filesDir, "models").apply { mkdirs() }
    fun fileOf(ctx: Context, m: LlmModel) = File(dir(ctx), m.file)
    /** Nur vollständig geprüfte Modelle gelten als heruntergeladen */
    fun isDownloaded(ctx: Context, m: LlmModel) = fileOf(ctx, m).exists() && okFile(ctx, m).exists()
    fun isUnverified(ctx: Context, m: LlmModel) = fileOf(ctx, m).let { it.exists() && it.length() > 50_000_000 } && !okFile(ctx, m).exists()
    fun okFile(ctx: Context, m: LlmModel) = File(dir(ctx), m.file + ".ok")
    fun metaFile(ctx: Context, m: LlmModel) = File(dir(ctx), m.file + ".meta")
}

/** Herunterladen der Modelle mit Fortschritt und anschließender Prüfung (Größe, GGUF-Kennung, SHA-256, Testladen) */
object ModelDownloads {
    data class Progress(
        val modelId: String,
        val doneMb: Double,
        val totalMb: Double,
        val error: String? = null,
        val finished: Boolean = false,
        val verifying: Boolean = false,
        val verifyPct: Int = 0,
    )

    private val scope = MainScope()
    private val _state = MutableStateFlow<Progress?>(null)
    val state: StateFlow<Progress?> = _state.asStateFlow()
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()
    @Volatile private var cancel = false
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).followRedirects(true).build()
    private val noRedirect = client.newBuilder().followRedirects(false).followSslRedirects(false).build()

    private fun busy() = _state.value?.let { !it.finished && it.error == null } == true

    /** Größe und SHA-256 vom Server (Hugging Face nennt beides im Kopf der ersten Antwort) */
    private fun fetchMeta(m: LlmModel): Pair<Long, String?> {
        noRedirect.newCall(Request.Builder().url(m.url).head().header("User-Agent", "ELdoroado").build()).execute().use { r ->
            val size = r.header("X-Linked-Size")?.toLongOrNull() ?: r.header("Content-Length")?.toLongOrNull() ?: -1L
            val sha = r.header("X-Linked-Etag")?.trim('"', ' ')?.lowercase()?.takeIf { it.length == 64 && it.all { c -> c in '0'..'9' || c in 'a'..'f' } }
            return size to sha
        }
    }

    fun start(ctx: Context, m: LlmModel) {
        if (busy()) return
        cancel = false
        _state.value = Progress(m.id, 0.0, 0.0)
        scope.launch {
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    val target = LlmModels.fileOf(ctx, m)
                    LlmModels.okFile(ctx, m).delete()
                    val (expSize, expSha) = runCatching { fetchMeta(m) }.getOrDefault(-1L to null)
                    LlmModels.metaFile(ctx, m).writeText("$expSize;${expSha ?: ""}")
                    val part = File(target.path + ".part")
                    if (expSize > 0 && part.length() > expSize) part.delete()
                    val have = if (part.exists()) part.length() else 0L
                    if (expSize <= 0 || have < expSize) {
                        val req = Request.Builder().url(m.url).header("User-Agent", "ELdoroado").apply { if (have > 0) header("Range", "bytes=$have-") }.build()
                        client.newCall(req).execute().use { r ->
                            if (r.code != 200 && r.code != 206) error("Download fehlgeschlagen (HTTP ${r.code})")
                            val resume = r.code == 206
                            val len = r.body?.contentLength() ?: -1L
                            val total = if (expSize > 0) expSize else if (len > 0) len + (if (resume) have else 0L) else -1L
                            var done = if (resume) have else 0L
                            val input = r.body!!.byteStream()
                            java.io.FileOutputStream(part, resume).use { out ->
                                val buf = ByteArray(256 * 1024)
                                var last = 0L
                                while (true) {
                                    if (cancel) error("Abgebrochen")
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    out.write(buf, 0, n)
                                    done += n
                                    if (done - last > 4_000_000) {
                                        last = done
                                        _state.value = Progress(m.id, done / 1e6, if (total > 0) total / 1e6 else 0.0)
                                    }
                                }
                            }
                        }
                    }
                    target.delete()
                    if (!part.renameTo(target)) error("Datei konnte nicht gespeichert werden")
                    verifyFile(ctx, m, testLoad = true)
                }
            }
            _state.value = res.fold({ Progress(m.id, 0.0, 0.0, finished = true) }, { e -> Progress(m.id, 0.0, 0.0, error = e.message) })
            _version.value++
            if (res.isSuccess) Assistant.prewarm(ctx)
        }
    }

    /** Vorhandene, noch ungeprüfte Datei prüfen (z. B. von älteren Versionen geladen) */
    fun verify(ctx: Context, m: LlmModel) {
        if (busy()) return
        _state.value = Progress(m.id, 0.0, 0.0, verifying = true)
        scope.launch {
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    if (!LlmModels.metaFile(ctx, m).exists()) {
                        val (sz, sha) = runCatching { fetchMeta(m) }.getOrDefault(-1L to null)
                        LlmModels.metaFile(ctx, m).writeText("$sz;${sha ?: ""}")
                    }
                    verifyFile(ctx, m, testLoad = true)
                }
            }
            _state.value = res.fold({ Progress(m.id, 0.0, 0.0, finished = true) }, { e -> Progress(m.id, 0.0, 0.0, error = e.message) })
            _version.value++
        }
    }

    private fun verifyFile(ctx: Context, m: LlmModel, testLoad: Boolean) {
        val f = LlmModels.fileOf(ctx, m)
        val meta = LlmModels.metaFile(ctx, m).takeIf { it.exists() }?.readText()?.split(";")
        val expSize = meta?.getOrNull(0)?.toLongOrNull() ?: -1L
        val expSha = meta?.getOrNull(1)?.takeIf { it.length == 64 }
        fun fail(msg: String): Nothing { f.delete(); LlmModels.okFile(ctx, m).delete(); error(msg) }
        // 1. Größe
        if (expSize > 0 && f.length() != expSize) fail("Beschädigt: Größe stimmt nicht (${f.length() / 1_000_000} statt ${expSize / 1_000_000} MB) – bitte neu laden")
        if (f.length() < 50_000_000) fail("Beschädigt: Datei zu klein – bitte neu laden")
        // 2. GGUF-Kennung
        val magic = ByteArray(4)
        java.io.FileInputStream(f).use { it.read(magic) }
        if (String(magic, Charsets.US_ASCII) != "GGUF") fail("Beschädigt: keine gültige Modelldatei – bitte neu laden")
        // 3. Prüfsumme
        if (expSha != null) {
            val md = java.security.MessageDigest.getInstance("SHA-256")
            val total = f.length().toDouble()
            var done = 0L
            var lastPct = -1
            java.io.FileInputStream(f).use { input ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    if (cancel) error("Abgebrochen")
                    val n = input.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                    done += n
                    val pct = (done / total * 100).toInt()
                    if (pct != lastPct) { lastPct = pct; _state.value = Progress(m.id, 0.0, 0.0, verifying = true, verifyPct = pct) }
                }
            }
            val got = md.digest().joinToString("") { "%02x".format(it) }
            if (got != expSha) fail("Beschädigt: Prüfsumme stimmt nicht – bitte neu laden")
        }
        // 4. Testweise laden
        if (testLoad && LlamaNative.available) {
            LlmEngine.unload()
            LlamaNative.libDir = ctx.applicationInfo.nativeLibraryDir ?: ""
            val h = LlamaNative.nativeLoad(f.path, 2, 512)
            if (h == 0L) fail("Das Modell lässt sich nicht laden – bitte neu laden oder ein anderes wählen")
            LlamaNative.nativeFree(h)
        }
        LlmModels.okFile(ctx, m).writeText(expSha ?: "ohne Prüfsumme")
    }

    fun cancel() { cancel = true }

    fun delete(ctx: Context, m: LlmModel) {
        LlmModels.fileOf(ctx, m).delete()
        File(LlmModels.fileOf(ctx, m).path + ".part").delete()
        LlmModels.okFile(ctx, m).delete()
        LlmModels.metaFile(ctx, m).delete()
        LlmEngine.cacheFile(ctx, m.id, 0).delete()
        LlmEngine.cacheFile(ctx, m.id, 1).delete()
        LlmEngine.unload()
        _version.value++
    }
}

/** Das geladene Sprachmodell (nur eines gleichzeitig) */
object LlmEngine {
    private var handle = 0L
    private var loadedPath: String? = null
    private var loadedModel: String? = null
    private var cacheDir: java.io.File? = null

    /** Datei mit dem vorbereiteten Zwischenstand der Anleitung (je Modell und Slot) */
    fun cacheFile(ctx: Context, modelId: String, slot: Int = 0) = java.io.File(java.io.File(ctx.filesDir, "llm").apply { mkdirs() }, "${modelId}_$slot.state")
    val preparing = MutableStateFlow(false)
    private var format = "chatml"
    private val mutex = Mutex()
    @Volatile var loadMs = 0L

    /** Messwerte der letzten Anfrage für die Anzeige */
    data class Stats(val label: String, val promptMs: Double, val promptN: Int, val genMs: Double, val genN: Int, val fromFile: Boolean = false)
    val stats = MutableStateFlow<List<Stats>>(emptyList())
    val cpu = MutableStateFlow("")

    private fun record(label: String) {
        val p = runCatching { LlamaNative.nativeStats() }.getOrNull()?.split(";") ?: return
        val st = Stats(label, p[0].toDouble(), p[1].toInt(), p[2].toDouble(), p[3].toInt(), p.getOrNull(4) == "1")
        stats.value = (stats.value.filterNot { it.label == label } + st).takeLast(2)
    }

    suspend fun ensure(ctx: Context): String? = withContext(Dispatchers.Default) {
        if (!LlamaNative.available) return@withContext "Der KI-Assistent ist auf diesem Gerät nicht verfügbar (nur 64-Bit-ARM)."
        val m = LlmModels.byId(Settings.state.value.aiModel)
        val f = LlmModels.fileOf(ctx, m)
        if (!LlmModels.isDownloaded(ctx, m)) return@withContext "Bitte zuerst das Modell herunterladen (Einstellungen → KI-Assistent)."
        mutex.withLock {
            if (loadedPath != f.path) {
                if (handle != 0L) LlamaNative.nativeFree(handle)
                LlamaNative.libDir = ctx.applicationInfo.nativeLibraryDir ?: ""
                val t0 = System.currentTimeMillis()
                handle = LlamaNative.nativeLoad(f.path, Settings.state.value.aiThreads.coerceIn(2, 8), 4096)
                loadMs = System.currentTimeMillis() - t0
                loadedPath = if (handle != 0L) f.path else null
                loadedModel = if (handle != 0L) m.id else null
                cacheDir = java.io.File(ctx.filesDir, "llm").apply { mkdirs() }
                format = m.format
                if (handle != 0L) cpu.value = runCatching { LlamaNative.nativeCpuInfo() }.getOrDefault("")
            }
        }
        if (handle == 0L) "Das Modell konnte nicht geladen werden." else null
    }

    fun unload() {
        if (handle != 0L) runCatching { LlamaNative.nativeFree(handle) }
        handle = 0L
        loadedPath = null
        loadedModel = null
    }

    private fun cachePath(slot: Int): String {
        val id = loadedModel ?: return ""
        val dir = cacheDir ?: return ""
        return java.io.File(dir, "${id}_$slot.state").path
    }

    /** Prompt im Chat-Format, an der Markierung in Vorspann (Anleitung) und Rest (Nutzersatz) geteilt */
    private fun split(system: String, user: String): Pair<String, String> {
        val mark = "\u2063\u2063EVLLM\u2063\u2063"
        var prompt = String(LlamaNative.nativeTemplate(handle, system, mark + user), Charsets.UTF_8)
        if (!prompt.contains(mark)) prompt = when (format) {
            "gemma" -> "<start_of_turn>user\n$system\n\n$mark$user<end_of_turn>\n<start_of_turn>model\n"
            else -> "<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$mark$user<|im_end|>\n<|im_start|>assistant\n"
        }
        return prompt.substringBefore(mark) to prompt.substringAfter(mark)
    }

    /** Anleitung einmal einlesen und als Datei ablegen (oder aus der Datei laden) */
    suspend fun prepare(system: String): Boolean = withContext(Dispatchers.Default) {
        mutex.withLock {
            if (handle == 0L) return@withLock false
            preparing.value = true
            try {
                val (prefix, _) = split(system, "x")
                LlamaNative.nativePrepare(handle, 0, prefix, cachePath(0))
            } finally {
                preparing.value = false
            }
        }
    }

    /** Eine Anfrage: Systemanweisung + Nutzertext, optional mit Grammatik */
    suspend fun ask(system: String, user: String, grammar: String?, maxTokens: Int, temp: Float): String = withContext(Dispatchers.Default) {
        mutex.withLock {
            if (handle == 0L) return@withLock ""
            // Vorspann (Anleitung) kommt aus dem Zwischenspeicher bzw. der Datei; gerechnet wird nur der Nutzersatz
            val (prefix, rest) = split(system, user)
            val slot = if (grammar != null) 0 else 1
            val out = String(LlamaNative.nativeGenerate(handle, slot, prefix, rest, grammar ?: "", maxTokens, temp, cachePath(slot)), Charsets.UTF_8)
            record(if (grammar != null) "Verstehen" else "Antwort")
            out
        }
    }
}

// ======================= Der Navi-Assistent =======================

object Assistant {
    data class Msg(val fromUser: Boolean, val text: String, val showRoute: Boolean = false, val choices: List<Place> = emptyList())
    data class State(val messages: List<Msg> = emptyList(), val busy: Boolean = false, val status: String = "")

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    /** Erzwingt gültiges, kompaktes JSON: "aktion" zuerst, danach nur die Felder, die vorkommen */
    private val GRAMMAR = """
root ::= "{" ws "\"aktion\"" ws ":" ws aktion ( ws "," ws pair )* ws "}"
pair ::= strkey ws ":" ws str | arrkey ws ":" ws strarr | intkey ws ":" ws int | "\"mautfrei\"" ws ":" ws bool | "\"frage\"" ws ":" ws frage
strkey ::= "\"ziel\"" | "\"start\"" | "\"pauseUhrzeit\"" | "\"pauseOrt\"" | "\"laden\"" | "\"name\""
arrkey ::= "\"ueber\"" | "\"entfernen\"" | "\"nurAnbieter\"" | "\"ohneAnbieter\""
intkey ::= "\"pauseMinuten\"" | "\"zielAkku\"" | "\"startAkku\""
aktion ::= "\"planen\"" | "\"stopp_hinzu\"" | "\"stopp_weg\"" | "\"laden\"" | "\"pause\"" | "\"anbieter\"" | "\"optionen\"" | "\"los\"" | "\"ueberspringen\"" | "\"frage\"" | "\"speichern\"" | "\"route_laden\"" | "\"abbrechen\"" | "\"unklar\""
frage ::= "\"ankunft\"" | "\"akku\"" | "\"ladestopps\"" | "\"strecke\""
bool ::= "true" | "false"
str ::= "\"" chars "\""
chars ::= [^"\\\n]*
strarr ::= "[" ws str ( ws "," ws str )* ws "]"
int ::= [0-9] [0-9]? [0-9]?
ws ::= [ \t\n]*
""".trim()

    private val SYSTEM_EXTRACT = """
Übersetze die Nachricht eines Fahrers (E-Auto-Navi) in kompaktes JSON. Nur Felder, die vorkommen. Nichts erfinden.
aktion: planen, stopp_hinzu, stopp_weg, laden, pause, anbieter, optionen, los, ueberspringen, frage, speichern, route_laden, abbrechen, unklar.
Felder: ziel (genau, mit Ort: "IKEA, Kamen"), start, ueber[], entfernen[], nurAnbieter[], ohneAnbieter[], pauseUhrzeit ("12:00"), pauseOrt, pauseMinuten, laden (Anbieter/Ort/"nächste"), mautfrei, zielAkku, startAkku, name, frage (ankunft/akku/ladestopps/strecke).
"nach Hause" = ziel "Zuhause", "zur Arbeit" = ziel "Arbeit". Alles ohne Navi-Bezug = unklar.
N: fahre zu IKEA nach Kamen
J: {"aktion":"planen","ziel":"IKEA, Kamen"}
N: von Herdecke nach Varazze, nur Tesla und EnBW, mittags Pause bei Burger King
J: {"aktion":"planen","ziel":"Varazze, Italien","start":"Herdecke","nurAnbieter":["Tesla","EnBW"],"pauseUhrzeit":"12:00","pauseOrt":"Burger King"}
N: noch ein Halt in Basel, Freiburg weglassen
J: {"aktion":"stopp_hinzu","ueber":["Basel"],"entfernen":["Freiburg"]}
N: bring mich zum nächsten Supercharger
J: {"aktion":"laden","laden":"Tesla"}
N: ohne Maut, mit 30 Prozent ankommen
J: {"aktion":"optionen","mautfrei":true,"zielAkku":30}
N: speicher das als Urlaub
J: {"aktion":"speichern","name":"Urlaub"}
N: wie wird das Wetter
J: {"aktion":"unklar"}
""".trim()

    /** Anleitung vorbereiten und Modell vorladen (beim App-Start im Hintergrund, nach Download oder per Knopf) */
    fun prewarm(ctx: Context, delayMs: Long = 0) {
        val app = ctx.applicationContext
        scope.launch {
            if (delayMs > 0) kotlinx.coroutines.delay(delayMs)
            val set = Settings.state.value
            if (!set.aiEnabled || !LlmModels.isDownloaded(app, LlmModels.byId(set.aiModel))) return@launch
            if (LlmEngine.ensure(app) == null) LlmEngine.prepare(SYSTEM_EXTRACT)
        }
    }

    private val SYSTEM_REPLY = """
Du bist der freundliche Navi-Assistent. Formuliere aus den FAKTEN eine kurze Antwort auf Deutsch (2 bis 3 Sätze, Du-Form).
Verwende nur Zahlen, Orte und Namen aus den FAKTEN. Erfinde nichts. Keine Aufzählungszeichen, keine Rückfragen.
""".trim()

    private val OPERATORS = listOf("Tesla", "EnBW", "IONITY", "Fastned", "Aral pulse", "Shell Recharge", "EWE Go", "Allego", "Electra", "E.ON", "Atlante", "Pfalzwerke")

    /** Letzte Wortwechsel als Kontext (Gesprächsgedächtnis) */
    private val history = ArrayDeque<String>()
    private var lastChoices: List<Place> = emptyList()
    private var pendingText: String? = null

    fun clear() { _state.value = State(); history.clear(); lastChoices = emptyList(); pendingText = null }

    fun ask(ctx: Context, text: String) {
        if (text.isBlank() || _state.value.busy) return
        _state.update { it.copy(messages = it.messages + Msg(true, text.trim()), busy = true, status = "Denke nach …") }
        scope.launch {
            val reply = runCatching { handle(ctx, text.trim(), null) }.getOrElse { e ->
                CrashLog.note("KI-Assistent: ${e.message}")
                Msg(false, "Da ist etwas schiefgelaufen: ${e.message}")
            }
            remember(text.trim(), reply.text)
            _state.update { it.copy(messages = it.messages + reply, busy = false, status = "") }
            speak(reply.text)
        }
    }

    /** In der Navigation die Antwort vorlesen (Hände am Lenkrad) */
    private fun speak(text: String) {
        if (NavSession.state.value.navigating && Settings.state.value.voice) {
            runCatching { NavSession.voice.say(text.replace("·", ",").replace("→", "bis")) }
        }
    }

    /** Antippen einer Auswahl bei mehrdeutigem Ort */
    fun choose(ctx: Context, p: Place) {
        val orig = pendingText ?: return
        if (_state.value.busy) return
        _state.update { it.copy(messages = it.messages + Msg(true, p.title), busy = true, status = "Plane Route …") }
        scope.launch {
            val reply = runCatching { handle(ctx, orig, p) }.getOrElse { e -> Msg(false, "Da ist etwas schiefgelaufen: ${e.message}") }
            remember(orig, reply.text)
            _state.update { it.copy(messages = it.messages + reply, busy = false, status = "") }
        }
    }

    private fun remember(user: String, answer: String) {
        history.addLast("Fahrer: $user\nNavi: ${answer.take(160)}")
        while (history.size > 3) history.removeFirst()
    }

    private fun JsonObject.s(k: String) = (this[k] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() && it != "null" }
    private fun JsonObject.list(k: String) = (this[k] as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull?.takeIf { s -> s.isNotBlank() } } ?: emptyList()
    private fun JsonObject.i(k: String) = (this[k] as? JsonPrimitive)?.intOrNull
    private fun JsonObject.b(k: String) = (this[k] as? JsonPrimitive)?.contentOrNull?.toBooleanStrictOrNull()

    // ---------- Regel-Vorstufe (ohne KI): eindeutige Dinge sicher erkennen ----------

    /** Erkennt einfache Befehle ganz ohne KI (schnell) */
    private fun quickAction(t: String): String? {
        val x = t.lowercase().trim().trimEnd('.', '!', '?')
        return when {
            Regex("^(los|los geht'?s|starte?( die)? navigation|navigation starten|fahr los|start)$").matches(x) -> "los"
            Regex("(überspring|skip).*(stopp|zwischen|halt)").containsMatchIn(x) -> "ueberspringen"
            Regex("wann (bin|sind|komme|kommen) (ich|wir)|ankunft(szeit)?\\??$|wie lange (noch|brauche)").containsMatchIn(x) -> "frage:ankunft"
            Regex("(wie ?viel|welchen) (akku|ladung|prozent)|akku am ziel").containsMatchIn(x) -> "frage:akku"
            Regex("wo (lade|laden) (ich|wir)|welche ladestopps|wie ?viele ladestopps").containsMatchIn(x) -> "frage:ladestopps"
            Regex("wie (weit|viele kilometer)").containsMatchIn(x) -> "frage:strecke"
            Regex("^(abbrechen|route (verwerfen|löschen)|vergiss (das|die route))$").matches(x) -> "abbrechen"
            else -> null
        }
    }

    /** Uhrzeit aus Text: „um 12“, „gegen 12:30“, „mittags“ */
    private fun timeFromText(t: String): Int? {
        val x = t.lowercase()
        if ("mittag" in x) return 12 * 60
        Regex("(?:um|gegen|ab|ca\\.?|circa)\\s+(\\d{1,2})(?:[:.](\\d{2}))?\\s*(?:uhr)?").find(x)?.let { m ->
            val h = m.groupValues[1].toInt(); val mi = m.groupValues[2].toIntOrNull() ?: 0
            if (h in 0..23 && mi in 0..59) return h * 60 + mi
        }
        return null
    }

    private fun operatorsIn(t: String, after: String): List<String> {
        val i = t.lowercase().indexOf(after)
        if (i < 0) return emptyList()
        val tail = t.substring(i).lowercase().split(Regex("\\s(?:um|pause|und dann|,)\\s")).first()
        val all = OPERATORS + KnownOperators.items.value
        return all.filter { op -> op.lowercase() in tail || (op == "Tesla" && "supercharger" in tail) }.distinct()
    }

    /** „… nach/zur/zum X in Y …“ → „X, Y“ (ohne KI) */
    fun destinationFromText(text: String): String? {
        val m = Regex("(?i)\\b(?:nach|zur|zum|zu|richtung|ins|in die|in den)\\s+(.+?)(?=\\s*[,.!?]|\\s+(?:aber|und|mit|nur|ohne|um|über|bitte|fahren|navigieren)\\b|$)").find(text) ?: return null
        val raw = m.groupValues[1].trim().removePrefix("dem ").removePrefix("der ").removePrefix("die ").removePrefix("den ")
        if (raw.isBlank()) return null
        val parts = raw.split(Regex("(?i)\\s+in\\s+"), limit = 2)
        return if (parts.size == 2) "${parts[0].trim()}, ${parts[1].trim()}" else raw
    }

    /** Favoriten „Zuhause“/„Arbeit“ oder eigener Favorit mit diesem Namen */
    private fun favorite(name: String): Place? {
        val n = name.lowercase()
        val favs = Favorites.items.value
        return when {
            n.contains("hause") || n == "zuhause" || n == "home" -> favs.firstOrNull { it.kind == FavKind.HOME }?.place
            n.contains("arbeit") || n.contains("büro") -> favs.firstOrNull { it.kind == FavKind.WORK }?.place
            else -> favs.firstOrNull { it.label.equals(name, true) }?.place
        }
    }

    /** Ort finden: bei „Geschäft/Sehenswürdigkeit, Stadt“ den passenden Treffer statt der Stadtmitte nehmen */
    suspend fun resolvePlace(name: String, me: LatLon?): Place? = resolveAll(name, me).firstOrNull()

    /** Alle sinnvollen Treffer (für Rückfragen bei Mehrdeutigkeit) */
    private suspend fun resolveAll(name: String, me: LatLon?): List<Place> {
        favorite(name)?.let { return listOf(it) }
        val hits = runCatching { Geocode.search(name, me) }.getOrDefault(emptyList())
        val poi = name.substringBefore(",").trim()
        val city = name.substringAfter(",", "").trim()
        if (city.isBlank()) return hits
        val word = poi.split(" ").firstOrNull { it.length >= 3 } ?: poi
        hits.filter { it.name.contains(word, true) }.takeIf { it.isNotEmpty() }?.let { return it }
        val c = runCatching { Geocode.search(city, me).firstOrNull() }.getOrNull() ?: return hits
        val set = Settings.state.value
        if (set.hasTomTom) {
            runCatching { TomTom.poiSearch(set.tomtomKey.trim(), poi, c.pos, 20_000) }.getOrNull()
                ?.filter { it.name.contains(word, true) }?.takeIf { it.isNotEmpty() }?.let { return it }
        }
        return hits.ifEmpty { listOf(c) }
    }

    /** Mehrdeutig? Gleicher Name in deutlich verschiedenen Orten (> 30 km auseinander) */
    private fun ambiguous(list: List<Place>): Boolean {
        if (list.size < 2) return false
        val a = list[0]; val b = list[1]
        return a.name.substringBefore(",").equals(b.name.substringBefore(","), true) && haversine(a.pos, b.pos) > 30_000
    }

    private suspend fun waitForPlan(): NavSession.State? =
        withTimeoutOrNull(120_000) { NavSession.state.first { !it.loading && (it.route != null || it.error != null) } }

    private fun answerQuestion(kind: String): Msg {
        val n = NavSession.state.value
        val r = n.route ?: return Msg(false, "Es ist gerade keine Route geplant.")
        val p = n.progress
        val remS = p?.remainingS ?: r.durationS
        val remM = p?.remainingM ?: r.distanceM
        return when (kind) {
            "ankunft" -> {
                val halt = p?.let { nextHalt(r, it, 0.0) }
                Msg(false, "Am Ziel bist du gegen ${fmtEta(remS)}, in ${fmtDuration(remS)}." +
                    (halt?.let { " Vorher ${if (it.charge) "lädst du" else "hältst du"} bei ${it.name} gegen ${fmtEta(it.etaS)}." } ?: ""))
            }
            "akku" -> Msg(false, r.arrivalSoc?.let { "Am Ziel hast du voraussichtlich noch ${it.roundToInt()} % Akku." } ?: "Dazu habe ich keine Prognose.")
            "ladestopps" -> if (r.stops.isEmpty()) Msg(false, "Auf dieser Route musst du nicht laden.")
                else Msg(false, "Du lädst ${r.stops.size}-mal: " + r.stops.joinToString(", ") { "${it.name.substringBefore(",")} (gegen ${fmtEta(WishPlanner.timeAt(r, it.alongM))})" } + ".")
            else -> Msg(false, "Noch ${fmtKm(remM)}, etwa ${fmtDuration(remS)}.")
        }
    }

    private suspend fun handle(ctx: Context, text: String, pinned: Place?): Msg {
        val nav0 = NavSession.state.value
        // 1) Schnelle Befehle ohne KI
        if (pinned == null) quickAction(text)?.let { q ->
            when {
                q == "los" -> {
                    if (nav0.route == null) return Msg(false, "Es ist noch keine Route geplant.")
                    if (!LocationHub.precise(ctx)) return Msg(false, "Für die Navigation brauche ich deinen genauen Standort – bitte in den Einstellungen freigeben.")
                    NavSession.start(ctx)
                    return Msg(false, "Los geht's – gute Fahrt!", showRoute = true)
                }
                q == "ueberspringen" -> {
                    if (NavSession.nextVia() == null) return Msg(false, "Es gibt keinen Zwischenstopp zum Überspringen.")
                    NavSession.skipNextVia(); return Msg(false, "Den nächsten Zwischenstopp habe ich übersprungen.")
                }
                q == "abbrechen" -> {
                    if (nav0.navigating) { NavSession.stop(ctx); return Msg(false, "Navigation beendet.") }
                    NavSession.clear(); return Msg(false, "Alles klar, ich habe die Route verworfen.")
                }
                q.startsWith("frage:") -> return answerQuestion(q.substringAfter(":"))
                else -> {}
            }
        }

        // 2) KI übersetzt in JSON
        LlmEngine.ensure(ctx)?.let { return Msg(false, it) }
        _state.update { it.copy(status = "Verstehe …") }
        val context = buildString {
            append(nav0.dest?.let { d ->
                "Aktuelle Route: nach ${d.title}" + (if (nav0.vias.isNotEmpty()) " über ${nav0.vias.joinToString { it.place.title }}" else "") +
                    (nav0.wishes.breakQuery.takeIf { it.isNotBlank() }?.let { ", Pause bei $it" } ?: "")
            } ?: "Es ist noch keine Route geplant.")
            if (history.isNotEmpty()) append("\nBisheriges Gespräch:\n" + history.joinToString("\n"))
        }
        val raw = LlmEngine.ask(SYSTEM_EXTRACT, "$context\nN: $text\nJ:", GRAMMAR, 110, 0.1f)
        val o = runCatching { json.parseToJsonElement(raw.trim()).jsonObject }.getOrNull()
            ?: return Msg(false, "Das habe ich leider nicht verstanden. Versuch es zum Beispiel mit: „Nach Hamburg, nur Tesla, mittags Pause bei IKEA.“")
        val aktion = o.s("aktion") ?: "unklar"
        val me = LocationHub.fix.value?.pos
        when (aktion) {
            "unklar" -> return Msg(false, "Dabei kann ich dir nicht helfen – ich plane nur deine Route.")
            "abbrechen" -> {
                if (nav0.navigating) { NavSession.stop(ctx); return Msg(false, "Navigation beendet.") }
                NavSession.clear(); return Msg(false, "Alles klar, ich habe die Route verworfen.")
            }
            "los" -> return handle(ctx, "los", null)
            "ueberspringen" -> return handle(ctx, "nächsten Stopp überspringen", null)
            "frage" -> return answerQuestion(o.s("frage") ?: "ankunft")
            "speichern" -> {
                val d = nav0.dest ?: return Msg(false, "Es gibt noch keine Route zum Speichern.")
                val name = o.s("name") ?: d.title.substringBefore(",")
                SavedRoutes.save(SavedRoute(System.currentTimeMillis().toString(), name, nav0.start, if (nav0.start != null) nav0.startSoc else null, d, nav0.vias.filterNot { it.fromWish }, System.currentTimeMillis()))
                return Msg(false, "Gespeichert als „$name“.")
            }
            "route_laden" -> {
                val name = o.s("name") ?: return Msg(false, "Welche gespeicherte Route meinst du?")
                val r = SavedRoutes.items.value.firstOrNull { it.name.contains(name, true) } ?: return Msg(false, "Eine Route „$name“ habe ich nicht gespeichert.")
                NavSession.openSaved(r)
                return finishPlan(r.dest, "Gespeicherte Route „${r.name}“", TripWishes())
            }
        }

        // 2b) Während der Fahrt: Stopps einfügen/streichen, Ladestopp, neues Ziel – die Navigation läuft weiter
        if (nav0.navigating && nav0.route != null) return handleDuringNav(o, aktion, text, me)

        // 3) Regeln ergänzen, was die KI ausgelassen hat
        val nurAnbieter = o.list("nurAnbieter").ifEmpty { if (Regex("(?i)\\bnur\\b").containsMatchIn(text)) operatorsIn(text, "nur") else emptyList() }
        val ohneAnbieter = o.list("ohneAnbieter").ifEmpty { if (Regex("(?i)\\b(ohne|keine?n?)\\b").containsMatchIn(text)) operatorsIn(text, "ohne") else emptyList() }
        val pauseZeit = o.s("pauseUhrzeit")?.let { t -> Regex("(\\d{1,2})(?::(\\d{2}))?").find(t)?.let { m -> m.groupValues[1].toInt() * 60 + (m.groupValues[2].toIntOrNull() ?: 0) } }
            ?: if (Regex("(?i)pause").containsMatchIn(text)) timeFromText(text) else null
        fun norm(list: List<String>) = list.map { n -> (OPERATORS + KnownOperators.items.value).firstOrNull { it.equals(n, true) || it.contains(n, true) || n.contains(it, true) } ?: n }.toSet()

        // Optionen (gelten auch ohne neue Route)
        o.b("mautfrei")?.let { v -> Settings.update { it.copy(avoidToll = v) } }
        o.i("zielAkku")?.let { v -> Settings.update { it.copy(minSocDest = v.toDouble().coerceIn(5.0, 80.0)) } }
        o.i("startAkku")?.let { v -> Settings.update { it.copy(socStart = v.toDouble().coerceIn(5.0, 100.0)) } }
        if (aktion == "optionen" && nav0.dest == null) return Msg(false, "Erledigt – gilt ab der nächsten Planung.")

        // Ziel bestimmen (mit Sicherheitsnetz und Rückfrage bei Mehrdeutigkeit)
        val change = aktion != "planen" && nav0.dest != null
        val fromText = destinationFromText(text)
        val llmDest = o.s("ziel")
        val wanted = when {
            pinned != null -> null
            llmDest == null -> if (aktion == "planen") fromText else null
            fromText != null && fromText.length > llmDest.length && fromText.contains(llmDest.substringBefore(",").trim(), true) -> fromText
            else -> llmDest
        }
        _state.update { it.copy(status = "Suche Orte …") }
        var dest: Place? = pinned
        if (dest == null && wanted != null) {
            val cands = resolveAll(wanted, me)
            if (cands.isEmpty()) return Msg(false, "Den Ort „$wanted“ habe ich nicht gefunden.")
            if (ambiguous(cands)) {
                pendingText = text
                lastChoices = cands.take(4)
                return Msg(false, "Welches „${wanted.substringBefore(",")}“ meinst du?", choices = lastChoices)
            }
            dest = cands.first()
        }

        // Laden: nächster Lader (optional eines Anbieters)
        var vias = if (change) nav0.vias.filterNot { it.fromWish } else emptyList()
        if (aktion == "laden") {
            val what = o.s("laden") ?: "Ladestation"
            val set = Settings.state.value
            if (!set.hasChargerSource) return Msg(false, "Für die Ladersuche brauche ich einen Open-Charge-Map-Schlüssel.")
            val near = nav0.progress?.let { p -> nav0.route?.let { RouteBarData.slice(it, p.alongM + 5000, p.alongM + 5001).first() } } ?: me
                ?: return Msg(false, "Ich kenne deinen Standort noch nicht.")
            val hits = runCatching { Chargers.near(set, if (what.equals("nächste", true)) "Ladestation" else what, near, 40_000) }.getOrDefault(emptyList())
                .filter { it.powerKw <= 0 || it.powerKw >= 50 }
            val h = hits.minByOrNull { haversine(it.pos, near) } ?: return Msg(false, "Ich habe keinen passenden Lader in der Nähe gefunden.")
            if (nav0.dest == null) {
                dest = Place(chargerTitle(h), h.pos)
            } else {
                vias = vias + Via(Place(chargerTitle(h), h.pos), 0, h.availId, true, h.powerKw)
            }
        }
        // Zwischenstopps hinzufügen / entfernen
        val add = o.list("ueber").mapNotNull { resolvePlace(it, me)?.let { p -> Via(p) } }
        val remove = o.list("entfernen")
        vias = vias.filterNot { v -> remove.any { r -> v.place.title.contains(r, true) } } + add
        val finalDest = dest ?: nav0.dest ?: return Msg(false, "Wohin soll es gehen? Nenn mir bitte ein Ziel.")
        val start = o.s("start")?.let { s -> if (s.equals("hier", true)) null else resolvePlace(s, me) } ?: if (change) nav0.start else null

        val w0 = if (change) nav0.wishes else TripWishes()
        val wishes = w0.copy(
            onlyOperators = norm(nurAnbieter).ifEmpty { w0.onlyOperators },
            avoidOperators = norm(ohneAnbieter).ifEmpty { w0.avoidOperators },
            breakAtMin = pauseZeit ?: w0.breakAtMin ?: if (o.s("pauseOrt") != null) 12 * 60 else null,
            breakQuery = o.s("pauseOrt") ?: w0.breakQuery,
            breakMin = o.i("pauseMinuten") ?: w0.breakMin,
        )
        _state.update { it.copy(status = "Plane Route …") }
        NavSession.planFromAssistant(finalDest, vias, start, wishes)
        return finishPlan(finalDest, null, wishes)
    }

    private suspend fun handleDuringNav(o: JsonObject, aktion: String, text: String, me: LatLon?): Msg {
        val nav0 = NavSession.state.value
        fun eta(): String = answerQuestion("ankunft").text
        when (aktion) {
            "stopp_hinzu", "stopp_weg" -> {
                val removed = o.list("entfernen").filter { NavSession.removeViaDuringNav(it) }
                if (removed.isNotEmpty()) NavSession.awaitReroute()
                val added = mutableListOf<String>()
                for (name in o.list("ueber").ifEmpty { if (aktion == "stopp_hinzu") listOfNotNull(destinationFromText(text)) else emptyList() }) {
                    _state.update { it.copy(status = "Suche $name …") }
                    val p = resolvePlace(name, me) ?: continue
                    NavSession.addViaDuringNav(Via(p))
                    NavSession.awaitReroute()
                    added += p.title.substringBefore(",")
                }
                if (added.isEmpty() && removed.isEmpty()) return Msg(false, "Welchen Stopp meinst du? Sag zum Beispiel: „Noch ein Halt bei McDonald’s in Unna“.")
                val parts = listOfNotNull(
                    added.takeIf { it.isNotEmpty() }?.let { "Halt bei ${it.joinToString(" und ")} eingefügt" },
                    removed.takeIf { it.isNotEmpty() }?.let { "${it.joinToString(" und ")} gestrichen" },
                )
                return Msg(false, parts.joinToString(", ") + ". " + eta(), showRoute = false)
            }
            "laden" -> {
                val what = o.s("laden") ?: "Ladestation"
                val set = Settings.state.value
                if (!set.hasChargerSource) return Msg(false, "Für die Ladersuche brauche ich einen Open-Charge-Map-Schlüssel.")
                val r = nav0.route!!
                val p = nav0.progress
                // Lader ein Stück voraus suchen (nicht hinter dem Auto)
                val near = p?.let { RouteBarData.slice(r, it.alongM + 8000, it.alongM + 8001).first() } ?: me ?: return Msg(false, "Ich kenne deinen Standort noch nicht.")
                _state.update { it.copy(status = "Suche Lader …") }
                val hits = runCatching {
                    Chargers.searchSmart(set, if (what.equals("nächste", true)) "Ladestation" else what, near)
                }.getOrDefault(emptyList()).filter { it.powerKw <= 0 || it.powerKw >= 50 }
                val h = hits.minByOrNull { haversine(it.pos, near) } ?: return Msg(false, "Ich habe keinen passenden Lader in der Nähe gefunden.")
                NavSession.addViaDuringNav(Via(Place(chargerTitle(h), h.pos), 0, h.availId, true, h.powerKw))
                NavSession.awaitReroute()
                return Msg(false, "Ladestopp bei ${chargerTitle(h)} eingefügt. " + eta())
            }
            "planen" -> {
                val wanted = o.s("ziel") ?: destinationFromText(text) ?: return Msg(false, "Wohin soll es stattdessen gehen?")
                _state.update { it.copy(status = "Suche Orte …") }
                val p = resolvePlace(wanted, me) ?: return Msg(false, "Den Ort „$wanted“ habe ich nicht gefunden.")
                NavSession.changeDestinationDuringNav(p)
                NavSession.awaitReroute()
                return Msg(false, "Neues Ziel: ${p.title.substringBefore(",")}. " + eta())
            }
            else -> return Msg(false, "Das kann ich während der Fahrt nicht ändern. Ich kann aber Stopps einfügen oder streichen, einen Ladestopp suchen, das Ziel ändern oder dir sagen, wann du ankommst.")
        }
    }

    /** Auf das Planungsergebnis warten und mit echten Zahlen antworten */
    private suspend fun finishPlan(dest: Place, intro: String?, wishes: TripWishes): Msg {
        val done = waitForPlan() ?: return Msg(false, "Die Planung dauert ungewöhnlich lange. Schau gleich im Routenfenster nach.")
        if (done.error != null) return Msg(false, "Die Planung hat nicht geklappt: ${done.error}")
        val r = done.route ?: return Msg(false, "Ich konnte keine Route finden.")
        val facts = buildString {
            intro?.let { appendLine(it) }
            appendLine("Ziel: ${dest.title.substringBefore(",")}")
            appendLine("Dauer: ${fmtDuration(r.durationS)}, Strecke ${fmtKm(r.distanceM)}, Ankunft ${fmtEta(r.durationS)}")
            appendLine("Ladestopps: ${r.stops.size}" + if (r.stops.isNotEmpty()) " (" + r.stops.joinToString { it.name.substringBefore(",") + " gegen " + fmtEta(WishPlanner.timeAt(r, it.alongM)) } + ")" else "")
            if (wishes.onlyOperators.isNotEmpty()) {
                val mine = r.stops.count { operatorMatchesName(it.operator, it.name, wishes.onlyOperators) }
                appendLine("Davon bei ${wishes.onlyOperators.joinToString(", ")}: $mine, bei anderen Anbietern: ${r.stops.size - mine}")
            }
            r.arrivalSoc?.let { appendLine("Akku am Ziel: ${it.roundToInt()} %") }
            done.planNote?.takeIf { it.isNotBlank() }?.let { appendLine("Hinweise: $it") }
        }
        pendingText = null
        val template = buildString {
            intro?.let { append("$it: ") }
            append("Nach ${dest.title.substringBefore(",")} sind es ${fmtKm(r.distanceM)}, etwa ${fmtDuration(r.durationS)}. ")
            append("Ankunft gegen ${fmtEta(r.durationS)}")
            r.arrivalSoc?.let { append(" mit ${it.roundToInt()} % Akku") }
            append(". ")
            if (r.stops.isEmpty()) {
                append("Laden musst du unterwegs nicht.")
            } else {
                append(if (r.stops.size == 1) "Du lädst einmal: " else "Du lädst ${r.stops.size}-mal: ")
                append(r.stops.joinToString(", ") { it.name.substringBefore(",") + " gegen " + fmtEta(WishPlanner.timeAt(r, it.alongM)) })
                append(".")
            }
            if (wishes.onlyOperators.isNotEmpty()) {
                val other = r.stops.count { !operatorMatchesName(it.operator, it.name, wishes.onlyOperators) }
                if (other > 0) append(" $other Stopp${if (other == 1) "" else "s"} nicht bei ${wishes.onlyOperators.joinToString(" oder ")} – dort gab es keinen passenden Lader.")
            }
            done.planNote?.takeIf { it.isNotBlank() }?.let { append(" $it.") }
        }
        if (!Settings.state.value.aiReplyLlm) return Msg(false, template, showRoute = true)
        _state.update { it.copy(status = "Formuliere …") }
        val text2 = LlmEngine.ask(SYSTEM_REPLY, "FAKTEN:\n$facts", null, 160, 0.4f)
            .replace(Regex("(?s)<think>.*?</think>"), "").trim()
        return Msg(false, text2.ifBlank { template }.take(600), showRoute = true)
    }
}
