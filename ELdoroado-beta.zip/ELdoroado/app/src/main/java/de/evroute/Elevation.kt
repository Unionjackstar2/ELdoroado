package de.evroute

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/**
 * Höhenprofil entlang einer Route über die Höhen-API von Open-Meteo (frei, ohne Schlüssel, Copernicus-Höhenmodell 90 m).
 * Etwa alle 1,5 km ein Messpunkt, je Anfrage bis zu 100 Punkte; dazwischen wird linear gerechnet.
 * Ohne Netz bleibt die Route einfach ohne Höhen (die Planung rechnet dann flach).
 */
object Elevation {
    private const val MAX_SAMPLES = 400
    private val cache = TtlCache<FloatArray>(60 * 60_000L, 20)

    suspend fun enrich(r: Route): Route {
        if (r.elevations != null || r.points.size < 2) return r
        val end = r.cumM.lastOrNull() ?: return r
        val step = max(1_500.0, end / MAX_SAMPLES)
        // Messpunkte: Indizes mit ungefähr gleichem Abstand
        val idx = ArrayList<Int>()
        var next = 0.0
        for (i in r.points.indices) if (r.cumM[i] >= next) { idx += i; next = r.cumM[i] + step }
        if (idx.last() != r.points.lastIndex) idx += r.points.lastIndex
        val key = idx.joinToString(",") { String.format(Locale.US, "%.3f,%.3f", r.points[it].lat, r.points[it].lon) }.hashCode().toString()
        val hs = cache.get(key) ?: run {
            val out = FloatArray(idx.size)
            for (chunk in idx.indices.chunked(100)) {
                val lat = chunk.joinToString(",") { String.format(Locale.US, "%.5f", r.points[idx[it]].lat) }
                val lon = chunk.joinToString(",") { String.format(Locale.US, "%.5f", r.points[idx[it]].lon) }
                val body = runCatching { Http.get("https://api.open-meteo.com/v1/elevation?latitude=$lat&longitude=$lon") }.getOrNull() ?: return r
                val arr = runCatching { json.parseToJsonElement(body).jsonObject["elevation"] as? JsonArray }.getOrNull() ?: return r
                chunk.forEachIndexed { k, i -> out[i] = ((arr.getOrNull(k) as? JsonPrimitive)?.doubleOrNull ?: return r).toFloat() }
            }
            cache.put(key, out)
            out
        }
        // auf alle Punkte verteilen
        val ele = FloatArray(r.points.size)
        var k = 0
        for (i in r.points.indices) {
            while (k < idx.size - 2 && r.cumM[idx[k + 1]] < r.cumM[i]) k++
            val a = idx[k]; val b = idx[(k + 1).coerceAtMost(idx.lastIndex)]
            val span = r.cumM[b] - r.cumM[a]
            val f = if (span > 0) ((r.cumM[i] - r.cumM[a]) / span).coerceIn(0.0, 1.0) else 0.0
            ele[i] = (hs[k] + (hs[(k + 1).coerceAtMost(hs.lastIndex)] - hs[k]) * f).toFloat()
        }
        // Auf- und Abstieg (kleine Schwankungen unter 3 m ignorieren)
        var up = 0.0; var down = 0.0; var ref = hs.first().toDouble()
        for (h in hs) {
            val d = h - ref
            if (abs(d) >= 3) { if (d > 0) up += d else down -= d; ref = h.toDouble() }
        }
        return r.copy(elevations = ele, ascentM = up, descentM = down)
    }
}
