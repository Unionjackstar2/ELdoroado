package de.evroute

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeChild

/** Gesetzt, wenn „echte Unschärfe“ an ist: Quelle ist die Karte */
val LocalHaze = staticCompositionLocalOf<HazeState?> { null }

/**
 * Glasfläche im Stil von „Liquid Glass“: leicht transparent, feine helle Lichtkante (oben stärker),
 * zarter Glanz von oben, weicher Schatten. Mit echter Unschärfe verschwimmt die Karte dahinter.
 */
@Composable
fun Modifier.glass(shape: Shape, elevation: Dp = 10.dp, tint: Color? = null): Modifier {
    val pal = LocalPal.current
    val haze = LocalHaze.current
    val dark = pal.dark
    // Hell: leicht kühles Weiß, kräftigerer Schatten und dunklere Unterkante, damit sich das Glas wie im Dunkeln absetzt
    val base = tint ?: if (dark) Color(0xFF171A20) else Color(0xFFF4F6F9)
    val fill = base.copy(alpha = if (haze != null) (if (dark) 0.52f else 0.58f) else (if (dark) 0.80f else 0.82f))
    val elev = if (dark) elevation else elevation * 1.6f
    var m = this
        .shadow(
            elev, shape, clip = false,
            ambientColor = Color.Black.copy(alpha = if (dark) 0.22f else 0.34f),
            spotColor = Color.Black.copy(alpha = if (dark) 0.28f else 0.42f),
        )
        .clip(shape)
    m = if (haze != null) {
        m.hazeChild(haze, HazeStyle(backgroundColor = base, tint = HazeTint(fill), blurRadius = 22.dp, noiseFactor = 0.04f))
    } else {
        m.background(fill)
    }
    return m
        .background(Brush.verticalGradient(0f to Color.White.copy(alpha = if (dark) 0.10f else 0.38f), 0.5f to Color.Transparent))
        .border(
            1.dp,
            Brush.verticalGradient(
                if (dark) {
                    listOf(Color.White.copy(alpha = 0.34f), Color.White.copy(alpha = 0.06f))
                } else {
                    // oben helle Lichtkante, unten feine dunkle Kante (Tiefe)
                    listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.10f))
                },
            ),
            shape,
        )
}
