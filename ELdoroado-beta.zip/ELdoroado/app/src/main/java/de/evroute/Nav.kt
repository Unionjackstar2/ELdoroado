package de.evroute

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------- Standort ----------------

object LocationHub {
    private val _fix = MutableStateFlow<Fix?>(null)
    val fix: StateFlow<Fix?> = _fix.asStateFlow()
    private var lm: android.location.LocationManager? = null
    private val holders = mutableSetOf<String>()

    /** Fahrsimulation aktiv: echte Positionen ignorieren */
    @Volatile var simulating = false

    fun inject(f: Fix) { _fix.value = f }

    // Zeitpunkt der letzten echten GPS-Position: Netzwerk-Positionen nur, wenn GPS gerade schweigt
    @Volatile private var lastGpsMs = 0L

    /** Androids eigener Standortdienst (ohne Google Play Services): GPS, dazu Netz/Fused für den schnellen ersten Fix */
    private val listener = object : android.location.LocationListener {
        override fun onLocationChanged(l: android.location.Location) {
            if (simulating) return
            val gps = l.provider == android.location.LocationManager.GPS_PROVIDER
            val now = System.currentTimeMillis()
            if (gps) lastGpsMs = now
            else if (now - lastGpsMs < 5_000) return
            _fix.value = clean(l)
        }

        // auf Android 10 und älter Pflicht (dort keine Standardmethoden)
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    @SuppressLint("MissingPermission")
    private fun request(ctx: Context, lowPower: Boolean) {
        val m = lm ?: (ctx.applicationContext.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager).also { lm = it }
        runCatching { m.removeUpdates(listener) }
        val providers = m.allProviders
        val looper = Looper.getMainLooper()
        val fine = precise(ctx)
        if (fine && android.location.LocationManager.GPS_PROVIDER in providers) {
            runCatching { m.requestLocationUpdates(android.location.LocationManager.GPS_PROVIDER, if (lowPower) 10_000L else 1000L, 0f, listener, looper) }
        }
        // Netz bzw. Fused (Android 12+ ohne Google) nur ergänzend, z. B. für den ersten Fix oder ohne genaue Freigabe
        val coarse = if (android.os.Build.VERSION.SDK_INT >= 31 && "fused" in providers) "fused" else android.location.LocationManager.NETWORK_PROVIDER
        if (coarse in providers) {
            runCatching { m.requestLocationUpdates(coarse, if (lowPower) 20_000L else 5_000L, 0f, listener, looper) }
        }
        // schneller Start: letzte bekannte Position
        if (_fix.value == null) {
            listOf(android.location.LocationManager.GPS_PROVIDER, coarse).mapNotNull { p -> runCatching { m.getLastKnownLocation(p) }.getOrNull() }
                .maxByOrNull { it.time }?.let { if (!simulating) _fix.value = clean(it) }
        }
    }

    /** Genauer Standort freigegeben (für die Navigation nötig) */
    fun precise(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Irgendein Standort freigegeben (ungefähr reicht für Karte und Planung) */
    fun hasPermission(ctx: Context) = precise(ctx) ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    enum class Perm { NONE, APPROX, PRECISE }
    private val _perm = MutableStateFlow(Perm.NONE)
    val perm: StateFlow<Perm> = _perm.asStateFlow()

    /** Berechtigung neu prüfen (beim Start und nach Rückkehr aus den Einstellungen) */
    fun refreshPermission(ctx: Context) {
        _perm.value = when {
            precise(ctx) -> Perm.PRECISE
            hasPermission(ctx) -> Perm.APPROX
            else -> Perm.NONE
        }
    }

    /**
     * Position aufbereiten: Fehlt das Tempo (z. B. kurz WLAN-/Mobilfunk-Ortung statt GPS), wird es aus Strecke/Zeit berechnet
     * statt 0 zu setzen. Physikalisch unmögliche Sprünge und ungenaue Positionen während der Fahrt ändern Tempo/Richtung nicht.
     */
    private fun clean(l: android.location.Location): Fix {
        val prev = _fix.value
        val pos = LatLon(l.latitude, l.longitude)
        val acc = if (l.hasAccuracy()) l.accuracy.toDouble() else 50.0
        val dt = if (prev != null && prev.elapsedNs > 0) (l.elapsedRealtimeNanos - prev.elapsedNs) / 1e9 else -1.0
        var speed: Double? = if (l.hasSpeed()) l.speed.toDouble() else null
        var bearing: Float? = if (l.hasBearing()) l.bearing else null
        if (speed == null && prev != null && dt in 0.3..5.0) speed = haversine(prev.pos, pos) / dt
        if (speed == null) speed = prev?.speed ?: 0.0
        if (prev != null && dt in 0.2..3.0) {
            val a = (speed - prev.speed) / dt
            // mehr als ~1 g Bremsen bzw. 0,8 g Beschleunigen ist ausgeschlossen: Messfehler
            if (a < -10.0 || a > 8.0) speed = prev.speed
            // ungenaue Position während der Fahrt: Tempo und Richtung vom letzten guten Wert behalten
            if (acc > 40 && prev.accuracy <= 40 && prev.speed > 3) { speed = prev.speed; bearing = prev.bearing }
        }
        if (bearing == null && (speed ?: 0.0) > 2) bearing = prev?.bearing
        // Ungenaue Positionen (z. B. kurz nach dem Start): Tempo nicht springen lassen
        if (prev != null && acc > 25 && dt in 0.2..5.0) speed = prev.speed
        // Leichte Glättung gegen das typische Zittern von 1–3 km/h; große echte Änderungen gehen schneller durch
        if (prev != null && dt in 0.2..3.0) {
            val raw = speed ?: 0.0
            val diff = raw - prev.speed
            val k = when {
                kotlin.math.abs(diff) > 4.0 -> 0.7   // echte Beschleunigung/Bremsung: zügig folgen
                kotlin.math.abs(diff) > 1.5 -> 0.45
                else -> 0.3                           // Zittern: sanft
            }
            speed = if (raw < 0.3) raw else prev.speed + diff * k
        }
        return Fix(
            pos = pos, bearing = bearing, speed = speed ?: 0.0, accuracy = acc, time = l.time,
            elapsedNs = l.elapsedRealtimeNanos, alt = if (l.hasAltitude()) l.altitude else null,
        )
    }

    /** Mehrere Nutzer (Bildschirm, Navigationsdienst) teilen sich ein Abo */
    @SuppressLint("MissingPermission")
    fun acquire(ctx: Context, tag: String) {
        if (!hasPermission(ctx) || tag in holders) return
        val first = holders.isEmpty()
        holders += tag
        if (first) request(ctx, lowPower = false)
    }

    fun release(tag: String) {
        if (holders.remove(tag) && holders.isEmpty()) runCatching { lm?.removeUpdates(listener) }
    }

    /** Während des Ladens reicht grobe, seltene Ortung (schont den Handy-Akku) */
    @android.annotation.SuppressLint("MissingPermission")
    fun setLowPower(ctx: Context, low: Boolean) {
        if (lm == null || holders.isEmpty() || !hasPermission(ctx)) return
        request(ctx, lowPower = low)
    }
}

// ---------------- Position auf der Route ----------------

object NavEngine {
    /** Fortschritt an einer bestimmten Stelle der Route (für den Tunnel-Modus ohne GPS) */
    fun progressAt(r: Route, along: Double): NavProgress? {
        val n = r.points.size
        if (n < 2) return null
        val a = along.coerceIn(0.0, r.cumM.last())
        var i = r.cumM.binarySearch(a)
        if (i < 0) i = -i - 2
        i = i.coerceIn(0, n - 2)
        val seg = r.cumM[i + 1] - r.cumM[i]
        val t = if (seg <= 0) 0.0 else ((a - r.cumM[i]) / seg).coerceIn(0.0, 1.0)
        val pos = lerp(r.points[i], r.points[i + 1], t)
        return update(r, pos, i, false).copy(offRouteM = 0.0)
    }

    /**
     * Position auf der Route finden. [heading]: Fahrtrichtung laut GPS (oder null),
     * [maxAlong]: weiter als bis hier kann man seit der letzten Messung nicht gekommen sein.
     * So springt die Anzeige an Autobahnkreuzen nicht auf den darüber oder daneben liegenden Routenteil.
     */
    fun update(r: Route, p: LatLon, lastSeg: Int, fullSearch: Boolean, heading: Double? = null, maxAlong: Double = Double.MAX_VALUE): NavProgress {
        val n = r.points.size
        if (n < 2) {
            return NavProgress(0, p, 0.0, 0.0, r.steps.lastIndex.coerceAtLeast(0), 0.0, 0.0, 0.0, 0.0)
        }
        val from = if (fullSearch) 0 else max(0, lastSeg - 5)
        val to = if (fullSearch) n - 2 else min(n - 2, lastSeg + 400)
        var best = from
        var bd = Double.MAX_VALUE
        var bScore = Double.MAX_VALUE
        for (i in from..max(from, to)) {
            if (!fullSearch && i > from && r.cumM[i] > maxAlong) break
            val d = distToSeg(p, r.points[i], r.points[i + 1])
            var score = d
            if (heading != null && d < 80 && r.cumM[i + 1] - r.cumM[i] > 1.0) {
                var diff = abs(bearing(r.points[i], r.points[i + 1]) - heading) % 360
                if (diff > 180) diff = 360 - diff
                score += when {
                    diff > 110 -> 70.0
                    diff > 55 -> 25.0
                    else -> 0.0
                }
            }
            if (score < bScore) { bScore = score; bd = d; best = i }
        }
        val a = r.points[best]
        val b = r.points[best + 1]
        val t = projectT(p, a, b)
        val along = r.cumM[best] + t * (r.cumM[best + 1] - r.cumM[best])

        var s = r.steps.indices.firstOrNull { r.stepAlongM[it] > along + 2 } ?: r.steps.lastIndex
        if (s < 0) s = 0
        val toStep = if (r.steps.isEmpty()) 0.0 else max(0.0, r.stepAlongM[s] - along)

        // Restzeit aus den Zeiten an den Manövern, plus noch ausstehende Ladezeiten
        var remS = 0.0
        if (r.stepTimeS.isNotEmpty()) {
            val tNext = r.stepTimeS[s]
            val prevIdx = (s - 1).coerceAtLeast(0)
            val span = r.stepAlongM[s] - r.stepAlongM[prevIdx]
            val tNow = if (s == 0 || span <= 0) tNext
            else r.stepTimeS[prevIdx] + (tNext - r.stepTimeS[prevIdx]) * ((along - r.stepAlongM[prevIdx]) / span).coerceIn(0.0, 1.0)
            remS = max(0.0, r.stepTimeS.last() - tNow)
        }
        if (!r.timesIncludeCharging) remS += r.stops.filter { it.alongM > along + 50 }.sumOf { it.chargeS }

        return NavProgress(
            segIdx = best,
            snapped = lerp(a, b, t),
            routeBearing = bearing(a, b),
            alongM = along,
            stepIdx = s,
            distToStepM = toStep,
            remainingM = max(0.0, r.cumM.last() - along),
            remainingS = remS,
            offRouteM = bd,
        )
    }
}

// ---------------- Sprachansagen ----------------

/**
 * Sprachausgabe: wählbare Sprachausgabe und Stimme, Tempo/Tonhöhe, Ausgabe über Handy oder Bluetooth,
 * kurze Pause vor Ansagen (gegen abgeschnittene erste Silben bei Bluetooth), Du- oder Sie-Ansprache.
 */
class Voice(private val ctx: Context) : TextToSpeech.OnInitListener {
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(attrs)
        .build()
    private val done = mutableSetOf<Int>()
    @Volatile private var ready = false
    private var engine = Settings.state.value.voiceEngine
    private var tts: TextToSpeech = create(engine)
    private var player: android.media.MediaPlayer? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private fun create(pkg: String): TextToSpeech =
        if (pkg.isBlank()) TextToSpeech(ctx.applicationContext, this) else TextToSpeech(ctx.applicationContext, this, pkg)

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts.language = Locale.GERMANY
        tts.setAudioAttributes(attrs)
        applyVoice()
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id?.startsWith("file-") == true) handler.post { playFile(id) } else audio.abandonAudioFocusRequest(focus)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { audio.abandonAudioFocusRequest(focus) }
        })
        ready = true
    }

    /** Stimme, Tempo und Tonhöhe aus den Einstellungen übernehmen */
    fun applyVoice() {
        val set = Settings.state.value
        runCatching {
            if (set.voiceName.isNotBlank()) tts.voices?.firstOrNull { it.name == set.voiceName }?.let { tts.voice = it }
            tts.setSpeechRate(set.voiceRate)
            tts.setPitch(set.voicePitch)
        }
    }

    /** Nach Wechsel der Sprachausgabe neu verbinden */
    fun reload() {
        val pkg = Settings.state.value.voiceEngine
        if (pkg == engine) { applyVoice(); return }
        runCatching { tts.shutdown() }
        ready = false
        engine = pkg
        tts = create(pkg)
    }

    fun engines(): List<TextToSpeech.EngineInfo> = runCatching { tts.engines }.getOrDefault(emptyList())
    fun defaultEngine(): String = runCatching { tts.defaultEngine }.getOrNull().orEmpty()
    fun germanVoices(): List<android.speech.tts.Voice> = runCatching {
        tts.voices.orEmpty().filter { v ->
            // manche Sprachausgaben melden Deutsch als „deu“/„ger“ statt „de“
            val lang = v.locale.language.lowercase()
            val iso3 = runCatching { v.locale.isO3Language }.getOrDefault("")
            (lang == "de" || lang == "deu" || lang == "ger" || iso3 == "deu") && !v.features.orEmpty().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
            .sortedWith(compareBy({ it.isNetworkConnectionRequired }, { -it.quality }, { it.name }))
    }.getOrDefault(emptyList())

    /** Gesprochenes aufbereiten: Straßennummern, Einheiten */
    private fun normalize(t: String): String = t
        .replace(Regex("\\b([ABEKL])\\s?(\\d{1,3})\\b"), "$1 $2")
        .replace("km/h", "Kilometer pro Stunde")
        .replace(" %", " Prozent").replace("%", " Prozent")
        .replace("·", ",")
        .replace("→", "bis")

    fun say(text: String) {
        if (!ready || !Settings.state.value.voice || text.isBlank()) return
        val set = Settings.state.value
        val t = normalize(text)
        audio.requestAudioFocus(focus)
        val device = outputDevice(set.voiceOutput)
        if (device == null) {
            // Standardweg: Android entscheidet über den Ausgang
            if (set.voiceLeadIn) tts.playSilentUtterance(450, TextToSpeech.QUEUE_FLUSH, "lead-${System.nanoTime()}")
            tts.speak(t, if (set.voiceLeadIn) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH, null, "nav-${System.nanoTime()}")
        } else {
            // Bestimmter Ausgang: erst in eine Datei sprechen, dann gezielt dort abspielen
            val id = "file-${System.nanoTime()}"
            val f = java.io.File(ctx.cacheDir, "$id.wav")
            runCatching { tts.synthesizeToFile(t, null, f, id) }
        }
    }

    private fun playFile(id: String) {
        val f = java.io.File(ctx.cacheDir, "$id.wav")
        if (!f.exists()) return
        val set = Settings.state.value
        runCatching {
            player?.release()
            val mp = android.media.MediaPlayer()
            mp.setAudioAttributes(attrs)
            mp.setDataSource(f.path)
            outputDevice(set.voiceOutput)?.let { mp.setPreferredDevice(it) }
            mp.setOnCompletionListener { it.release(); f.delete(); audio.abandonAudioFocusRequest(focus); if (player === it) player = null }
            mp.prepare()
            player = mp
            handler.postDelayed({ runCatching { mp.start() } }, if (set.voiceLeadIn) 450L else 0L)
        }.onFailure { f.delete() }
    }

    /** 0 = automatisch, 1 = Handy-Lautsprecher, 2 = Bluetooth (wenn verbunden) */
    private fun outputDevice(mode: Int): android.media.AudioDeviceInfo? {
        if (mode == 0) return null
        val devices = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        return when (mode) {
            1 -> devices.firstOrNull { it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            2 -> devices.firstOrNull {
                it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    (android.os.Build.VERSION.SDK_INT >= 31 && (it.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET || it.type == android.media.AudioDeviceInfo.TYPE_BLE_SPEAKER))
            }
            else -> null
        }
    }

    /** Kurzer, dezenter Hinweiston (z. B. bei Neuberechnung oder zu hohem Tempo) */
    fun chime(soft: Boolean = true) {
        if (!Settings.state.value.voice) return
        runCatching {
            val tg = android.media.ToneGenerator(AudioManager.STREAM_NOTIFICATION, if (soft) 35 else 60)
            tg.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 140)
            handler.postDelayed({ tg.release() }, 400)
        }
    }

    fun stop() { if (ready) { tts.stop(); runCatching { player?.stop() } } }

    fun reset() { done.clear() }

    /** Du- oder Sie-Form */
    private fun t(sie: String, du: String) = if (Settings.state.value.voiceDu) du else sie

    /** Ansagezeitpunkte nach Zeit statt fester Strecke: etwa 30 s und 10 s vorher (mit sinnvollen Grenzen) */
    private fun stagesFor(speedMs: Double): List<Double> {
        val v = speedMs.coerceAtLeast(8.0)
        val early = (v * 30).coerceIn(300.0, 1500.0)
        val late = (v * 10).coerceIn(110.0, 600.0)
        // auf der Autobahn zusätzlich eine frühe Ankündigung bei 2 km
        return if (speedMs * 3.6 > 95) listOf(2000.0, early, late) else listOf(early, late)
    }

    /** Nach einem stillen Routentausch: bereits fällige Vorankündigungen nicht wiederholen */
    fun prime(p: NavProgress, speedMs: Double) {
        // Manöver vor der aktuellen Position gelten als erledigt
        for (k in 0 until p.stepIdx) for (j in 0..9) done.add(k * 10 + j)
        val base = p.stepIdx * 10
        stagesFor(speedMs).forEachIndexed { i, st -> if (p.distToStepM <= st) done.add(base + i) }
        if (p.distToStepM <= max(35.0, speedMs * 4)) done.add(base + 9)
    }

    /** Ladestopp an diesem Manöver? (TomTom-Ladestopp oder eigener Lader als Zwischenstopp) */
    private fun chargeAt(r: Route, i: Int): ChargeStop? {
        val at = r.stepAlongM.getOrNull(i) ?: return null
        return r.stops.firstOrNull { abs(it.alongM - at) < 300 }
    }

    /** Liegt das Ziel links oder rechts der Straße? */
    private fun destSide(r: Route): String? {
        val dest = NavSession.state.value.dest?.pos ?: return null
        val n = r.points.size
        if (n < 2) return null
        val end = r.points[n - 1]
        if (haversine(dest, end) < 8) return null
        var k = n - 2
        while (k > 0 && haversine(r.points[k], end) < 15) k--
        val a = r.points[k]
        val cross = (end.lon - a.lon) * (dest.lat - a.lat) - (end.lat - a.lat) * (dest.lon - a.lon)
        return if (cross > 0) "links" else "rechts"
    }

    /** Satz für ein Manöver (für Vorankündigung und „Jetzt“) */
    private fun maneuverText(step: Step): String {
        // Autobahnausfahrt mit Nummer und Name: „die Ausfahrt 89, Schwerte nehmen“
        if (step.type == "off ramp") {
            val m = Regex("^Ausfahrt ([^,·]+?)\\s*(?:[,·]\\s*(.*))?$").find(step.towards)
            if (m != null) {
                val name = m.groupValues[2].takeIf { it.isNotBlank() }?.let { ", $it" } ?: ""
                return "die Ausfahrt ${m.groupValues[1]}$name nehmen"
            }
        }
        if (step.isRoundabout && step.exit != null) {
            val dir = if (step.mod == "straight") "geradeaus, " else ""
            return "im Kreisverkehr ${dir}die ${ordinalDe(step.exit)} Ausfahrt nehmen" + if (step.road.isNotBlank()) " auf ${step.road}" else ""
        }
        return step.phrase + step.spokenTarget()
    }

    fun onProgress(r: Route, p: NavProgress, speedMs: Double) {
        // Im Kreisverkehr: kurz vor der eigenen Ausfahrt „Jetzt die Ausfahrt nehmen“
        val prev = r.steps.getOrNull(p.stepIdx - 1)
        if (prev != null && prev.isRoundabout) {
            val exitAt = roundaboutExitAlong(r, p.stepIdx - 1)
            if (exitAt != null && p.alongM < exitAt && exitAt - p.alongM < max(25.0, speedMs * 2.5) && done.add((p.stepIdx - 1) * 10 + 8)) {
                say("Jetzt die Ausfahrt nehmen")
                return
            }
        }
        val step = r.steps.getOrNull(p.stepIdx) ?: return
        val d = p.distToStepM
        val stages = stagesFor(speedMs)
        val nowDist = max(35.0, speedMs * 4)
        val base = p.stepIdx * 10
        val charge = if (step.type == "charge" || step.type == "via") chargeAt(r, p.stepIdx) else null

        if (d <= nowDist) {
            if (done.add(base + 9)) {
                stages.indices.forEach { done.add(base + it) }
                when {
                    step.type == "arrive" -> {
                        val side = destSide(r)
                        say(t("Sie haben Ihr Ziel erreicht", "Du hast dein Ziel erreicht") + (side?.let { t(". Es liegt $it", ". Es liegt $it") } ?: ""))
                        return
                    }
                    charge != null -> { say(t("Sie haben den Ladestopp erreicht", "Du hast den Ladestopp erreicht")); return }
                    step.type == "via" -> { say(t("Sie haben Ihr Zwischenziel erreicht", "Du hast dein Zwischenziel erreicht")); return }
                }
                val next = r.steps.getOrNull(p.stepIdx + 1)
                val then = if (next != null && step.distanceM < 150) {
                    when (next.type) {
                        "arrive" -> t(", dann erreichen Sie Ihr Ziel", ", dann erreichst du dein Ziel")
                        "charge" -> ", dann kommt der Ladestopp"
                        "via" -> ", dann kommt das Zwischenziel"
                        else -> ", dann gleich ${maneuverText(next)}"
                    }.also { (0..2).forEach { j -> done.add(base + 10 + j) } }
                } else {
                    ""
                }
                val text = if (step.isRoundabout && step.exit != null) {
                    "Jetzt in den Kreisverkehr, ${ordinalDe(step.exit)} Ausfahrt"
                } else {
                    "Jetzt ${maneuverText(step)}"
                }
                say(text + then)
            }
            return
        }
        // Spurempfehlung (nur wenn es auch falsche Spuren gibt)
        val lanes = findLaneSection(r, p, p.alongM, speedMs)?.let { lanePhrase(it) }
        val useLanes = lanes?.let { t("Benutzen Sie $it", "Nimm $it") }
        stages.forEachIndexed { i, s ->
            if (d <= s && d > nowDist + 60 && done.add(base + i)) {
                // nicht zwei Ankündigungen direkt hintereinander
                if (i + 1 < stages.size && d < stages[i + 1] + 200) done.add(base + i + 1)
                val text = when {
                    step.type == "arrive" -> {
                        val side = destSide(r)
                        t("In ${spoken(d)} erreichen Sie Ihr Ziel", "In ${spoken(d)} erreichst du dein Ziel") + (side?.let { ", es liegt $it" } ?: "")
                    }
                    charge != null -> "In ${spoken(d)} Ladestopp bei ${charge.name.substringBefore(",")}, laden auf ${charge.targetSoc.roundToInt()} Prozent"
                    step.type == "via" -> t("In ${spoken(d)} erreichen Sie Ihr Zwischenziel", "In ${spoken(d)} erreichst du dein Zwischenziel")
                    else -> "In ${spoken(d)} ${maneuverText(step)}" + if (useLanes != null) { done.add(base + 5); ". $useLanes" } else ""
                }
                say(text)
                return
            }
        }
        // Spuren werden oft erst nach der Vorankündigung bekannt: eigene Ansage, aber mit Entfernung
        // („Benutzen Sie in 500 Metern die rechte Spur“). Steht gleich ohnehin eine Ankündigung an,
        // nimmt diese die Spur mit – dann keine Extra-Ansage kurz davor.
        val nextStage = stages.indices.filter { !done.contains(base + it) && stages[it] < d }.maxOfOrNull { stages[it] }
        val stageSoon = nextStage != null && d - nextStage < 150 && nextStage > nowDist + 60
        if (lanes != null && !stageSoon && d > nowDist + 120 && done.add(base + 5)) {
            say(t("Benutzen Sie in ${spoken(d)} $lanes", "Nimm in ${spoken(d)} $lanes"))
            return
        }
    }

    /** Natürliche Entfernungen: „einem Kilometer“, „eineinhalb Kilometern“, „300 Metern“ */
    private fun spoken(m: Double): String {
        if (m >= 950) {
            val half = (m / 500).roundToInt() // in halben Kilometern
            val whole = half / 2
            val isHalf = half % 2 == 1
            return when {
                half == 2 -> "einem Kilometer"
                half == 3 -> "eineinhalb Kilometern"
                isHalf && whole < 10 -> "${listOf("", "", "zwei", "drei", "vier", "fünf", "sechs", "sieben", "acht", "neun")[whole]}einhalb Kilometern"
                else -> "${(m / 1000).roundToInt()} Kilometern"
            }
        }
        return if (m >= 100) "${(m / 50).roundToInt() * 50} Metern" else "${(m / 10).roundToInt() * 10} Metern"
    }
}

/**
 * Ausfahrt aus einem Kreisverkehr finden: Im Kreisverkehr (gegen den Uhrzeigersinn) dreht die Route nach links,
 * an der Ausfahrt knickt sie nach rechts ab. Gibt die Position entlang der Route zurück.
 */
fun roundaboutExitAlong(r: Route, stepIdx: Int): Double? {
    val at = r.stepAlongM.getOrNull(stepIdx) ?: return null
    var i = r.cumM.indexOfFirst { it >= at }
    if (i < 1) return null
    var leftTurn = 0.0
    var prevB = bearing(r.points[i - 1], r.points[i])
    while (i + 1 < r.points.size && r.cumM[i] - at < 220) {
        if (haversine(r.points[i], r.points[i + 1]) < 2) { i++; continue }
        val b = bearing(r.points[i], r.points[i + 1])
        var d = b - prevB
        while (d > 180) d -= 360
        while (d < -180) d += 360
        if (d < 0) leftTurn += -d
        if (d > 8 && leftTurn >= 20) return r.cumM[i]
        prevB = b
        i++
    }
    return null
}

// ---------------- Navigationssitzung ----------------

private suspend fun <T> safe(block: suspend () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    Result.failure(e)
}

object NavSession {
    data class Offer(val route: Route, val savedS: Double)

    /** Warnung vor Stauende, Baustelle oder Sperrung */
    data class Warning(val kind: String, val title: String, val distM: Double, val delayS: Double, val inside: Boolean, val lengthM: Double)

    /** Ladesäulen-Suche (vor oder während der Fahrt) */
    data class ChargerSearch(
        val loading: Boolean = true,
        val hits: List<ChargerHit> = emptyList(),
        val error: String? = null,
        val replaceUuid: String? = null,
        val focus: LatLon? = null,       // ersetzter Stopp (Mittelpunkt der Suche)
        val focusName: String = "",
        val query: String = "",
    )

    data class State(
        val dest: Place? = null,
        val routes: List<Route> = emptyList(),
        val selected: Int = 0,
        val loading: Boolean = false,
        val error: String? = null,
        val note: String? = null,
        val navigating: Boolean = false,
        val progress: NavProgress? = null,
        val rerouting: Boolean = false,
        val arrived: Boolean = false,
        val availability: Map<String, Availability> = emptyMap(),
        val offer: Offer? = null,
        val fullPark: ChargeStop? = null,
        val vias: List<Via> = emptyList(),
        val chargerSearch: ChargerSearch? = null,
        val hitAvailability: Map<String, Availability> = emptyMap(),
        val warning: Warning? = null,
        val gpsLost: Boolean = false,
        val destChargers: List<ChargerHit> = emptyList(),
        val destParking: List<Place> = emptyList(),
        val destLoading: Boolean = false,
        val destLoadedFor: LatLon? = null,
        val coach: CoachTip? = null,
        val planNote: String? = null,
        val start: Place? = null,     // eigener Startpunkt (null = Mein Standort)
        val startSoc: Double? = null, // Akku beim Start für vorausgeplante Fahrten
        val tripMaxSpeed: Int? = null,
        val charging: ChargeSession? = null,
        val chargeNotice: String? = null,
    ) {
        val route: Route? get() = routes.getOrNull(selected)
    }

    /** Laufender Ladestopp (ohne Live-Daten: Zeit aus der Ladekurve) */
    data class ChargeSession(
        val name: String,
        val pos: LatLon,
        val arriveSoc: Double,
        val targetSoc: Double,
        val chargeS: Double,
        val plannedChargeS: Double,
        val startedAt: Long,
    ) {
        val readyAt: Long get() = startedAt + (chargeS * 1000).toLong()
    }

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private lateinit var app: Context
    lateinit var voice: Voice
        private set

    private var planJob: Job? = null
    private var checkJob: Job? = null
    private var lastSeg = 0
    private var needFull = true
    private var offCount = 0
    private var lastReroute = 0L
    private val avoidedParks = mutableListOf<String>()
    /** Gesperrte Abschnitte, die Valhalla umfahren soll (aus Sperrungs-Meldungen während der Fahrt) */
    private val avoidAreas = mutableListOf<List<LatLon>>()
    private val announcedFull = mutableSetOf<String>()
    private var viasPassed = 0
    private val announcedJams = mutableSetOf<String>()
    private var primeVoice = false
    private var viaAlongs: List<Double> = emptyList()
    private var viaAlongsFor: Route? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        voice = Voice(app)
        scope.launch { LocationHub.fix.filterNotNull().collect { onFix(it) } }
        scope.launch { Obd.values.collect { checkPlanVsActual(); Obd.freshSoc()?.let { LastSoc.note(it) } } }
        scope.launch {
            LocationHub.fix.filterNotNull().collect { f ->
                val st = _state.value
                val p = st.progress
                if (st.navigating && !st.arrived && p != null) EcoRecorder.sample(f, p, st.route)
            }
        }
    }

    // ----- Tempo-Coach -----

    private var coachJob: Job? = null
    private var coachMutedUntil = 0L

    private fun startCoach() {
        coachJob?.cancel()
        coachJob = scope.launch {
            delay(60_000)
            while (isActive) {
                runCatching { checkCoach() }
                delay(120_000)
            }
        }
    }

    private fun checkCoach() {
        val s = _state.value
        val set = Settings.state.value
        // Hinweis nur, wenn der Akku bis zum Ladestopp/Ziel knapp wird (kein Schalter mehr nötig)
        if (!s.navigating || s.rerouting || s.arrived || s.coach != null) return
        if (System.currentTimeMillis() < coachMutedUntil) return
        val f = LocationHub.fix.value ?: return
        if (f.speed * 3.6 < 80) return                       // nur auf schnellen Straßen
        val r = s.route ?: return
        val p = s.progress ?: return
        val soc = Obd.freshSoc() ?: r.socAt(p.alongM) ?: return
        val tip = TempoCoach.evaluate(r, p.alongM, soc, set.copy(maxSpeedKmh = s.tripMaxSpeed ?: set.maxSpeedKmh)) ?: return
        if (s.tripMaxSpeed != null && tip.capKmh >= s.tripMaxSpeed) return
        _state.update { it.copy(coach = tip) }
        voice.say(tip.spoken)
    }

    /** Tipp übernehmen: Route mit dieser Höchstgeschwindigkeit neu planen */
    fun acceptCoach() {
        val tip = _state.value.coach ?: return
        _state.update { it.copy(coach = null, tripMaxSpeed = tip.capKmh) }
        voice.say("Neue Planung mit höchstens ${tip.capKmh} Kilometern pro Stunde")
        rerouteNow()
    }

    /** Höchsttempo nur für diese Fahrt (Routenfenster); null = Einstellung aus „Fahrzeug“ */
    fun setTripMaxSpeed(kmh: Int?) {
        _state.update { it.copy(tripMaxSpeed = kmh) }
        if (_state.value.navigating) rerouteNow() else replan()
    }

    fun dismissCoach() {
        coachMutedUntil = System.currentTimeMillis() + 20 * 60_000
        _state.update { it.copy(coach = null) }
    }

    // ----- Vorausberechnung: wo ist das Auto *jetzt* (zwischen zwei GPS-Messungen)? -----
    /** Fahrzeug im (oder kurz vor einem) Tunnel – schaltet bei „Automatisch“ tagsüber auf dunkel */
    private val _inTunnel = MutableStateFlow(false)
    private var tunnelChangedAt = 0L
    val inTunnel: StateFlow<Boolean> = _inTunnel.asStateFlow()
    private val _liveAlong = MutableStateFlow<Double?>(null)
    val liveAlong: StateFlow<Double?> = _liveAlong.asStateFlow()
    private var lastAlong = 0.0
    private var lastSpeed = 0.0
    private var lastFixNs = 0L
    private var liveJob: Job? = null

    private fun startLive() {
        liveJob?.cancel()
        liveJob = scope.launch {
            var tick = 0
            while (isActive) {
                if (lastFixNs > 0L) {
                    val age = (SystemClock.elapsedRealtimeNanos() - lastFixNs) / 1e9
                    // Tunnel-Modus: ohne GPS bis zu 45 s mit dem letzten Tempo weiterfahren
                    val lost = age > 3.0 && lastSpeed > 3.0
                    val dt = age.coerceIn(0.0, if (lost) 45.0 else 3.0)
                    val along = lastAlong + lastSpeed * dt
                    _liveAlong.value = along
                    val st = _state.value
                    if (lost != st.gpsLost) _state.update { it.copy(gpsLost = lost) }
                    if (lost && tick % 5 == 0 && age <= 45.0) {
                        val r = st.route
                        val p = r?.let { NavEngine.progressAt(it, along) }
                        if (r != null && p != null) {
                            _state.update { it.copy(progress = p) }
                            voice.onProgress(r, p, lastSpeed)
                        }
                    }
                } else {
                    _liveAlong.value = null
                }
                tick++
                delay(200)
            }
        }
    }

    private fun stopLive() {
        liveJob?.cancel()
        lastFixNs = 0L
        _liveAlong.value = null
        _state.update { it.copy(gpsLost = false) }
    }

    private fun isDark(): Boolean = when (Settings.state.value.mapMode) {
        MapMode.DAY -> false
        MapMode.NIGHT -> true
        MapMode.AUTO -> (app.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
    }

    /** Offline-Karte für die gewählte Route jetzt speichern */
    fun saveOffline() {
        val s = _state.value
        val r = s.route ?: return
        OfflineMaps.download(app, r, s.dest?.title ?: "Route", isDark())
    }

    private var deviationSince = 0L
    private var lastSocReplan = 0L

    /** Weicht der echte Akkustand deutlich vom Plan ab, wird neu geplant (wie bei ABRP) */
    private fun checkPlanVsActual() {
        val s = _state.value
        if (!s.navigating || s.rerouting || s.arrived || !Settings.state.value.obdReplan) return
        val r = s.route ?: return
        val p = s.progress ?: return
        val actual = Obd.freshSoc() ?: return
        val planned = r.socAt(p.alongM) ?: return
        val now = System.currentTimeMillis()
        if (kotlin.math.abs(actual - planned) < 4.0) { deviationSince = 0L; return }
        if (deviationSince == 0L) { deviationSince = now; return }
        if (now - deviationSince < 60_000 || now - lastSocReplan < 180_000) return
        lastSocReplan = now
        deviationSince = 0L
        val f = LocationHub.fix.value ?: return
        voice.say(if (actual > planned) "Der Akku ist voller als geplant. Route wird angepasst." else "Der Akku leert sich schneller als geplant. Route wird angepasst.")
        reroute(f, manual = false)
    }

    /** Routen zum Ziel planen (mit TomTom inkl. Ladestopps und Verkehr) */
    fun plan(dest: Place, vias: List<Via> = emptyList(), keepAvoided: Boolean = false, start: Place? = null, startSoc: Double? = null) {
        val fix = LocationHub.fix.value
        planJob?.cancel()
        if (!keepAvoided) avoidedParks.clear()
        avoidAreas.clear()
        handledClosures.clear()
        handledJams.clear()
        pendingOfferAreas = emptyList()
        // eigener Start bleibt bei Änderungen erhalten (Stopps, Akku), bei einem neuen Ziel aus der Suche nicht
        val st = start ?: if (keepAvoided) _state.value.start else null
        val stSoc = startSoc ?: if (keepAvoided && st != null) _state.value.startSoc else null
        if (fix == null && st == null) {
            _state.value = State(dest = dest, vias = vias, error = "Standort noch nicht verfügbar – GPS aktiv?")
            return
        }
        val keepAvail = _state.value.availability
        val keepTrip = if (keepAvoided) _state.value.tripMaxSpeed else null
        _state.value = State(dest = dest, vias = vias, loading = true, availability = keepAvail, start = st, startSoc = stSoc, tripMaxSpeed = keepTrip)
        planJob = scope.launch {
            val res = safe {
                val fromPos = st?.pos ?: fix!!.pos
                val heading = if (st == null && fix != null && fix.speed > 3) fix.bearing else null
                val soc = when {
                    st != null -> stSoc ?: Settings.state.value.socStart
                    else -> Obd.freshSoc() ?: Settings.state.value.socStart
                }
                computeOptions(fromPos, heading, dest.pos, soc, alternatives = 2, withTollFree = vias.isEmpty(), noToll = false, vias = vias)
            }
            res.onSuccess { opts ->
                _state.update { it.copy(routes = opts, selected = 0, loading = false) }
                opts.firstOrNull()?.let { loadAvailability(it) }
                opts.firstOrNull()?.let { r -> runCatching { OfflineMaps.auto(app, r, dest.title, isDark()) } }
                loadDestInfo()
                compareBefore?.let { (n0, d0) ->
                    compareBefore = null
                    opts.firstOrNull()?.let { r ->
                        val dn = r.stops.size - n0
                        val parts = mutableListOf<String>()
                        if (dn > 0) parts += "$dn Ladestopp${if (dn > 1) "s" else ""} hinzugefügt"
                        if (dn < 0) parts += "${-dn} Ladestopp${if (dn < -1) "s" else ""} entfallen"
                        val diffMin = ((r.durationS - d0) / 60).roundToInt()
                        if (kotlin.math.abs(diffMin) >= 2) parts += "Ankunft ${fmtEta(r.durationS)} statt ${fmtEta(d0)}"
                        val note = if (parts.isEmpty()) "Geprüft: Planung passt, keine Änderung" else "Geprüft: " + parts.joinToString(" · ")
                        _state.update { it.copy(planNote = note) }
                    }
                }
            }.onFailure { e ->
                CrashLog.note("Routing fehlgeschlagen: ${e.message}")
                _state.update { it.copy(loading = false, error = "Keine Route gefunden: ${e.message}") }
            }
        }
    }

    /** Neu planen, z. B. nachdem der Akkustand geändert wurde */
    fun replan() { _state.value.dest?.let { plan(it, _state.value.vias, keepAvoided = true) } }

    /** Eigenen Startpunkt setzen (null = Mein Standort) und neu planen */
    fun setStart(p: Place?) {
        val s = _state.value
        val dest = s.dest ?: return
        if (p == null) {
            _state.update { it.copy(start = null, startSoc = null) }
            plan(dest, s.vias, keepAvoided = false)
        } else {
            plan(dest, s.vias, keepAvoided = true, start = p, startSoc = s.startSoc ?: Settings.state.value.socStart)
        }
    }

    /** Akku beim eigenen Start ändern */
    fun setStartSoc(v: Double) {
        val s = _state.value
        val dest = s.dest ?: return
        plan(dest, s.vias, keepAvoided = true, start = s.start, startSoc = v.coerceIn(5.0, 100.0))
    }

    /** Gespeicherte Route aufrufen: mit aktuellen Daten neu berechnen */
    fun openSaved(r: SavedRoute) = plan(r.dest, r.vias, keepAvoided = false, start = r.start, startSoc = r.startSoc)

    // ----- Zwischenstopps -----

    fun addVia(p: Place) {
        val s = _state.value
        if (s.navigating) { insertViaDuringNav(Via(p)); return }
        val dest = s.dest ?: return
        // an der passenden Stelle der Strecke einsortieren, nicht hinten anhängen
        plan(dest, insertSorted(s.route, s.vias, Via(p)), keepAvoided = true)
    }

    fun removeVia(i: Int) {
        val s = _state.value
        val dest = s.dest ?: return
        if (i !in s.vias.indices) return
        plan(dest, s.vias.filterIndexed { k, _ -> k != i }, keepAvoided = true)
    }

    /** Neue Reihenfolge aus der Stopp-Liste: erster Eintrag = Start, letzter = Ziel, dazwischen Zwischenstopps */
    fun reorder(start: Place?, vias: List<Via>, dest: Place) {
        if (start == null) _state.update { it.copy(start = null, startSoc = null) }
        val soc = if (start != null) _state.value.startSoc ?: Settings.state.value.socStart else null
        plan(dest, vias, keepAvoided = true, start = start, startSoc = soc)
    }

    /** Nächster noch nicht erreichter Zwischenstopp (während der Navigation) */
    fun nextVia(): Via? = _state.value.vias.getOrNull(viasPassed)

    /** Nächsten Zwischenstopp überspringen, Navigation läuft weiter */
    fun skipNextVia() {
        val s = _state.value
        if (viasPassed !in s.vias.indices) return
        val list = s.vias.toMutableList().apply { removeAt(viasPassed) }
        _state.update { it.copy(vias = list) }
        voice.say("Zwischenstopp übersprungen")
        rerouteNow()
    }

    /** Planung mit aktuellen Daten prüfen und danach kurz zeigen, was sich geändert hat */
    private var compareBefore: Pair<Int, Double>? = null

    fun recheck() {
        val s = _state.value
        val dest = s.dest ?: return
        compareBefore = s.route?.let { it.stops.size to it.durationS }
        plan(dest, s.vias, keepAvoided = true)
    }

    fun cyclePause(i: Int) {
        val s = _state.value
        val dest = s.dest ?: return
        val v = s.vias.getOrNull(i) ?: return
        val next = when (v.pauseMin) { 0 -> 15; 15 -> 30; 30 -> 45; 45 -> 60; else -> 0 }
        plan(dest, s.vias.mapIndexed { k, x -> if (k == i) x.copy(pauseMin = next) else x }, keepAvoided = true)
    }

    /** Position eines Ortes entlang der Route (Meter ab Start) */
    private fun alongOf(r: Route, p: LatLon): Double {
        var best = 0
        var bd = Double.MAX_VALUE
        r.points.forEachIndexed { i, q -> val d = haversine(p, q); if (d < bd) { bd = d; best = i } }
        return r.cumM.getOrElse(best) { 0.0 }
    }

    private fun insertSorted(r: Route?, list: List<Via>, v: Via): List<Via> {
        if (r == null) return list + v
        val a = alongOf(r, v.place.pos)
        val idx = list.indexOfFirst { alongOf(r, it.place.pos) > a }
        return if (idx < 0) list + v else list.toMutableList().apply { add(idx, v) }
    }

    // ----- Änderungen während der Fahrt (für den Assistenten) -----

    fun addViaDuringNav(v: Via) = insertViaDuringNav(v)

    /** Zwischenstopp, dessen Name passt, während der Fahrt streichen */
    fun removeViaDuringNav(name: String): Boolean {
        val s = _state.value
        val remaining = s.vias.drop(viasPassed)
        val keep = remaining.filterNot { it.place.title.contains(name, true) }
        if (keep.size == remaining.size) return false
        viasPassed = 0
        _state.update { it.copy(vias = keep) }
        rerouteNow()
        return true
    }

    /** Neues Ziel während der Fahrt (Zwischenstopps bleiben) */
    fun changeDestinationDuringNav(p: Place) {
        val s = _state.value
        val remaining = s.vias.drop(viasPassed)
        viasPassed = 0
        _state.update { it.copy(dest = p, vias = remaining, destLoadedFor = null, destChargers = emptyList(), destParking = emptyList()) }
        rerouteNow()
    }

    /** Auf das Ende einer Neuberechnung warten */
    suspend fun awaitReroute() {
        delay(400)
        withTimeoutOrNull(60_000) { state.first { !it.rerouting } }
    }

    private fun insertViaDuringNav(v: Via) {
        val s = _state.value
        val remaining = s.vias.drop(viasPassed)
        val list = insertSorted(s.route, remaining, v)
        viasPassed = 0
        val dest = s.dest?.title?.substringBefore(",")?.trim().orEmpty()
        val via = v.place.title.substringBefore(",").trim()
        _state.update { it.copy(vias = list, chargeNotice = "Zwischenstopp eingefügt: $via – danach weiter nach $dest") }
        voice.say("Zwischenstopp eingefügt: $via. Danach weiter nach $dest.")
        rerouteNow()
        scope.launch {
            delay(10_000)
            _state.update { if (it.chargeNotice?.startsWith("Zwischenstopp eingefügt") == true) it.copy(chargeNotice = null) else it }
        }
    }

    // ----- Ladesäulen-Suche -----

    /** Ladesäulen entlang der Route suchen (vor der Fahrt: ganze Route, während der Fahrt: nächste 250 km) */
    fun openChargerSearch(replaceUuid: String? = null) {
        val s = _state.value
        val set = Settings.state.value
        val r = s.route ?: return
        if (!set.hasChargerSource) {
            _state.update { it.copy(chargerSearch = ChargerSearch(loading = false, error = "Dafür wird ein Open-Charge-Map-Schlüssel benötigt (Einstellungen → Ladesäulen).")) }
            return
        }
        // Wird ein bestimmter Stopp ersetzt, nur um diesen herum suchen
        val stop = replaceUuid?.let { id -> r.stops.firstOrNull { it.uuid == id } }
        _state.update { it.copy(chargerSearch = ChargerSearch(replaceUuid = replaceUuid, focus = stop?.pos, focusName = stop?.name ?: "")) }
        val here = if (s.navigating) s.progress?.alongM ?: 0.0 else 0.0
        val startAlong = if (stop != null) maxOf(here, stop.alongM - 50_000) else here
        val endAlong = when {
            stop != null -> stop.alongM + 50_000
            s.navigating -> here + 250_000
            else -> Double.MAX_VALUE
        }
        scope.launch {
            val res = safe { Chargers.corridor(set, r, startAlong, endAlong, set.corridorKm, set.searchMinKw) }
            res.onSuccess { hits ->
                var list = hits.filter { it.alongM >= here - 500 }
                if (stop != null) list = list.filter { it.availId != stop.uuid && haversine(it.pos, stop.pos) > 150 }.sortedBy { kotlin.math.abs(it.alongM - stop.alongM) }
                    .map { it.copy(stopAlongRef = stop.alongM) }
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, hits = list)) } ?: st }
                loadHitAvailability(list)
            }.onFailure { e ->
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, error = e.message)) } ?: st }
            }
        }
    }

    /** Eigene Suche im Ersatz-Fenster, z. B. „IONITY Lüneburg“ */
    fun searchChargerText(q: String) {
        val cs = _state.value.chargerSearch ?: return
        val r = _state.value.route ?: return
        val set = Settings.state.value
        if (q.trim().length < 3) { openChargerSearch(cs.replaceUuid); return }
        _state.update { it.copy(chargerSearch = cs.copy(loading = true, query = q, error = null)) }
        val near = cs.focus ?: LocationHub.fix.value?.pos
        scope.launch {
            val res = safe { Chargers.searchSmart(set, q, near) }
            res.onSuccess { hits ->
                val list = hits.map { h ->
                    val (along, off) = TomTom.locateOnRoute(r, h.pos)
                    h.copy(alongM = along, offsetM = off)
                }
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, hits = list)) } ?: st }
                loadHitAvailability(list)
            }.onFailure { e ->
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, error = e.message)) } ?: st }
            }
        }
    }

    /** Ladestationen und Parkplätze rund ums Ziel laden (einmal je Ziel) */
    fun loadDestInfo() {
        val s = _state.value
        val d = s.dest ?: return
        val set = Settings.state.value
        if (!set.hasChargerSource || s.destLoading || s.destLoadedFor == d.pos) return
        _state.update { it.copy(destLoading = true, destLoadedFor = d.pos) }
        scope.launch {
            val key = set.tomtomKey.trim()
            val ch = async { safe { Chargers.nearby(set, d.pos, 1500, 0, false) }.getOrDefault(emptyList()) }
            val pk = async { emptyList<Place>() } // Parkplatzsuche lief über TomTom (entfällt, TomTom nur noch Verkehr)
            val chargers = ch.await().sortedBy { haversine(it.pos, d.pos) }.take(6)
            val parking = pk.await().sortedBy { haversine(it.pos, d.pos) }.take(6)
            _state.update { st -> if (st.dest?.pos == d.pos) st.copy(destChargers = chargers, destParking = parking, destLoading = false) else st }
            loadHitAvailability(chargers)
        }
    }

    /** Neues Ziel während der Fahrt (z. B. Parkplatz oder Ladestation am Ziel), Navigation läuft weiter */
    fun setDestination(p: Place) {
        val s = _state.value
        if (!s.navigating) { plan(p, s.vias); return }
        _state.update { it.copy(dest = p, destChargers = emptyList(), destParking = emptyList(), destLoadedFor = null) }
        voice.say("Neues Ziel: ${p.title}")
        rerouteNow()
    }

    fun closeChargerSearch() { _state.update { it.copy(chargerSearch = null) } }

    /** Gewählte Ladestation als festen Ladestopp in die Route nehmen */
    fun pickCharger(h: ChargerHit) {
        val s = _state.value
        val replace = s.chargerSearch?.replaceUuid
        if (replace != null) avoidedParks += replace
        val v = Via(Place(chargerTitle(h), h.pos), chargeParkId = h.availId, isCharger = true, powerKw = h.powerKw)
        _state.update { it.copy(chargerSearch = null) }
        if (s.navigating) {
            insertViaDuringNav(v)
        } else {
            val dest = s.dest ?: return
            plan(dest, insertSorted(s.route, s.vias, v), keepAvoided = true)
        }
    }

    private fun loadHitAvailability(hits: List<ChargerHit>) {
        val ids = hits.mapNotNull { it.availId }.filter { it !in _state.value.hitAvailability }.take(8)
        if (!LiveStatus.available() || ids.isEmpty()) return
        scope.launch {
            val found = ids.map { id -> async { id to safe { LiveStatus.availability(id) }.getOrNull() } }
                .mapNotNull { d -> d.await().let { (id, a) -> if (a != null) id to a else null } }
            if (found.isNotEmpty()) _state.update { it.copy(hitAvailability = it.hitAvailability + found) }
        }
    }

    fun select(i: Int) {
        _state.update { if (i in it.routes.indices) it.copy(selected = i) else it }
        _state.value.route?.let { loadAvailability(it) }
    }

    fun clear() {
        stopLive()
        planJob?.cancel()
        checkJob?.cancel()
        _state.value = State()
    }

    // Für das Lernen ohne OBD: Akku und Wetter beim Losfahren
    private var tripStartSoc: Double? = null
    private var tripTempC: Double = 15.0
    private var tripKm: Double = 0.0

    fun start(ctx: Context) {
        chargesDone.clear()
        tripStartSoc = Obd.freshSoc() ?: _state.value.route?.socProfile?.firstOrNull()?.second
        tripTempC = _state.value.route?.weather?.tempC ?: 15.0
        tripKm = (_state.value.route?.distanceM ?: 0.0) / 1000
        _state.update { it.copy(charging = null, chargeNotice = null) }
        val s = _state.value
        val r = s.route ?: return
        lastSeg = 0; needFull = true; offCount = 0; viasPassed = 0
        announcedFull.clear()
        voice.reset()
        _state.value = s.copy(routes = listOf(r), selected = 0, navigating = true, arrived = false, offer = null, fullPark = null)
        EvModel.carWarm = true
        runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, NavigationService::class.java)) }
        val first = r.steps.getOrNull(1)
        val stopsText = when (r.stops.size) {
            0 -> ""
            1 -> " Ein Ladestopp ist eingeplant."
            else -> " ${r.stops.size} Ladestopps sind eingeplant."
        }
        voice.say("Route gestartet.$stopsText " + if (first != null) "${first.phrase.cap()}${first.spokenTarget()}" else "")
        _state.value.route?.let { r0 -> EcoRecorder.start(r0, _state.value.dest?.title ?: "Ziel", _state.value.progress?.alongM ?: 0.0) }
        // vorausgeplanter Start: beim Losfahren gilt der echte Standort (weicht er ab, wird automatisch neu berechnet)
        if (_state.value.start != null) _state.update { it.copy(start = null, startSoc = null) }
        LocationHub.fix.value?.let { onFix(it) }
        startChecks()
        startLive()
        coachMutedUntil = 0L
        startCoach()
        runCatching { OfflineMaps.auto(app, r, s.dest?.title ?: "Route", isDark()) }
    }

    fun stop(ctx: Context) {
        _inTunnel.value = false
        EvModel.carWarm = false
        JamWatch.reset()
        if (_state.value.charging != null) {
            LocationHub.setLowPower(ctx, false)
            _state.update { it.copy(charging = null) }
        }
        EcoRecorder.finish(arrived = false)
        Simulator.stop()
        coachJob?.cancel()
        stopLive()
        voice.stop()
        checkJob?.cancel()
        ctx.stopService(Intent(ctx, NavigationService::class.java))
        planJob?.cancel()
        _state.value = State()
    }

    fun rerouteNow() { LocationHub.fix.value?.let { reroute(it, manual = true) } }

    // ---------------- Hinweiston bei zu hohem Tempo ----------------
    private var overSince = 0L
    private var chimedLimit = -1

    private fun checkSpeedChime(f: Fix, r: Route, p: NavProgress) {
        if (!Settings.state.value.speedChime) return
        val limit = SpeedLimits.at(r, p.alongM).first ?: return
        val kmh = f.speed * 3.6
        if (kmh > limit + 5) {
            if (overSince == 0L) overSince = System.currentTimeMillis()
            // einmal je Limit-Abschnitt, nach 3 s am Stück
            if (System.currentTimeMillis() - overSince > 3000 && chimedLimit != limit) {
                voice.chime(soft = false)
                chimedLimit = limit
            }
        } else if (kmh < limit) {
            overSince = 0L
            if (chimedLimit != limit) chimedLimit = -1
        }
    }

    // ---------------- Ladestopp ----------------
    private var chargeStillSince = 0L
    private val chargesDone = mutableSetOf<String>()

    /** Am geplanten Schnelllader angekommen? (20 s im Umkreis von 80 m stehen) – bzw. losgefahren ohne „Weiterfahren“ */
    private fun checkCharging(f: Fix, r: Route, p: NavProgress) {
        val cur = _state.value.charging
        if (cur != null) {
            if (haversine(f.pos, cur.pos) > 200) finishCharging(auto = true)
            return
        }
        val st = r.stops.firstOrNull { it.name !in chargesDone && it.alongM > p.alongM - 300 } ?: return
        val near = haversine(f.pos, st.pos) < 80
        if (!near || f.speed > 1.5) { chargeStillSince = 0L; return }
        if (chargeStillSince == 0L) { chargeStillSince = System.currentTimeMillis(); return }
        if (System.currentTimeMillis() - chargeStillSince < 20_000) return
        chargeStillSince = 0L
        val set = Settings.state.value
        // Akku bei Ankunft: letzter OBD-Wert vor dem Ausschalten, sonst der Plan
        val arrive = Obd.freshSoc() ?: st.arriveSoc
        val target = max(st.targetSoc, arrive)
        val secs = UserCharging.chargeSeconds(arrive, target, st.powerKw, set.usableKwh)
        _state.update {
            it.copy(charging = ChargeSession(st.name, st.pos, arrive, target, secs, st.chargeS, System.currentTimeMillis()))
        }
        LocationHub.setLowPower(app, true)
        voice.say("Ladestopp erreicht. Laden auf ${target.roundToInt()} Prozent, etwa ${(secs / 60).roundToInt()} Minuten.")
    }

    /** „Weiterfahren“ (oder einfach losgefahren): weiter auf der Route, dann Akku per OBD prüfen und bei Abweichung neu planen */
    fun finishCharging(auto: Boolean = false) {
        val cs = _state.value.charging ?: return
        chargesDone += cs.name
        _state.update { it.copy(charging = null) }
        LocationHub.setLowPower(app, false)
        scope.launch {
            // Beim Einschalten des Autos meldet OBD gleich den echten Stand (bis zu 90 s warten)
            val soc = withTimeoutOrNull(90_000) {
                var found: Double? = null
                while (found == null) {
                    val v = Obd.freshSoc()
                    if (v != null && (auto || System.currentTimeMillis() - cs.startedAt > 60_000 || v > cs.arriveSoc + 2)) found = v else delay(2000)
                }
                found
            }
            val msg = when {
                soc == null -> null
                abs(soc - cs.targetSoc) <= 5 -> "Akku ${soc.roundToInt()} % – passt zum Plan, gute Fahrt!"
                else -> {
                    val before = _state.value.route?.stops?.count { it.name !in chargesDone } ?: 0
                    LocationHub.fix.value?.let { reroute(it, manual = true) }
                    withTimeoutOrNull(60_000) { state.first { !it.rerouting } }
                    val after = _state.value.route?.stops?.size ?: before
                    "Akku ${soc.roundToInt()} % statt geplant ${cs.targetSoc.roundToInt()} % – Route neu berechnet" + when {
                        after > before -> ", ein zusätzlicher Ladestopp nötig."
                        after < before -> ", ein Ladestopp fällt weg."
                        else -> "."
                    }
                }
            }
            if (msg != null) {
                _state.update { it.copy(chargeNotice = msg) }
                delay(10_000)
                _state.update { if (it.chargeNotice == msg) it.copy(chargeNotice = null) else it }
            }
        }
    }

    fun acceptOffer() {
        val o = _state.value.offer ?: return
        // Umfahrung beibehalten, auch wenn später neu berechnet wird
        avoidAreas += pendingOfferAreas
        pendingOfferAreas = emptyList()
        lastSeg = 0; needFull = true; offCount = 0
        voice.reset()
        lastFixNs = 0L
        _state.update { it.copy(routes = listOf(o.route), selected = 0, offer = null, vias = it.vias.drop(viasPassed), progress = null) }
        viasPassed = 0
        LocationHub.fix.value?.let { onFix(it) }
        loadAvailability(o.route)
        voice.chime()
    }

    fun dismissOffer() {
        pendingOfferAreas = emptyList()
        _state.update { it.copy(offer = null) }
    }

    /** Belegten Ladepark meiden und neu planen */
    fun avoidFullPark() {
        val p = _state.value.fullPark ?: return
        p.uuid?.let { avoidedParks += it }
        _state.update { it.copy(fullPark = null) }
        rerouteNow()
    }

    fun dismissFullPark() { _state.update { it.copy(fullPark = null) } }

    private fun currentSoc(): Double {
        Obd.freshSoc()?.let { return it }
        val s = _state.value
        val r = s.route
        val p = s.progress
        return if (r != null && p != null) r.socAt(p.alongM) ?: Settings.state.value.socStart else Settings.state.value.socStart
    }

    private fun onFix(f: Fix) {
        val s = _state.value
        if (!s.navigating || s.arrived) return
        val r = s.route ?: return
        val fixNs = if (f.elapsedNs > 0) f.elapsedNs else SystemClock.elapsedRealtimeNanos()
        val maxAlong = if (!needFull && lastFixNs > 0L) {
            val dt = ((fixNs - lastFixNs) / 1e9).coerceIn(0.5, 600.0)
            lastAlong + max(80.0, max(f.speed, lastSpeed) * dt * 1.6 + 40.0 + f.accuracy)
        } else {
            Double.MAX_VALUE
        }
        val heading = f.bearing?.takeIf { f.speed > 4 }?.toDouble()
        val p = NavEngine.update(r, f.pos, lastSeg, needFull, heading, maxAlong)
        lastSeg = p.segIdx
        val off = p.offRouteM > max(50.0, f.accuracy * 1.5)
        needFull = off
        offCount = if (off && f.accuracy < 60) offCount + 1 else 0
        _state.update { it.copy(progress = p) }
        checkCharging(f, r, p)
        // Während des Ladens keine Abweichungs- oder Ansagelogik (man steht oft neben der Route)
        if (_state.value.charging != null) return
        checkSpeedChime(f, r, p)
        SpeedLimits.onFix(f, r, p)
        if (viaAlongsFor !== r) {
            viaAlongs = s.vias.map { alongOf(r, it.place.pos) }
            viaAlongsFor = r
        }
        viasPassed = viaAlongs.count { it < p.alongM - 30 }

        // Alter der GPS-Messung (meist einige Zehntelsekunden) ausgleichen
        val age = if (f.elapsedNs > 0) ((SystemClock.elapsedRealtimeNanos() - f.elapsedNs) / 1e9).coerceIn(0.0, 2.0) else 0.0
        if (!off) {
            lastAlong = p.alongM
            lastSpeed = f.speed
            lastFixNs = if (f.elapsedNs > 0) f.elapsedNs else SystemClock.elapsedRealtimeNanos()
        }
        val pv = p.copy(distToStepM = max(0.0, p.distToStepM - f.speed * age))
        if (primeVoice && !off) { voice.prime(pv, f.speed); primeVoice = false }
        if (!off) updateWarning(r, p.alongM + f.speed * age, f.speed)
        if (p.remainingM < 5000 && s.destLoadedFor != s.dest?.pos) loadDestInfo()
        if (offCount >= 3 && !s.rerouting && System.currentTimeMillis() - lastReroute > 8000) {
            reroute(f, manual = false)
        } else if (!off) {
            voice.onProgress(r, pv, f.speed)
        }
        // Ankunft: knapp vor dem Ende der Route, nahe am Ziel (auch neben der Straße) oder kurz am Ziel stehen geblieben
        val destPos = s.dest?.pos
        val direct = destPos?.let { haversine(f.pos, it) } ?: Double.MAX_VALUE
        // Rückfall bei ungenauem GPS: in Zielnähe (60 m) 10 Sekunden stehen geblieben
        if (f.speed < 2.0 && direct < 60) { if (stoppedNearDestSince == 0L) stoppedNearDestSince = System.currentTimeMillis() } else stoppedNearDestSince = 0L
        val stoppedLongEnough = stoppedNearDestSince > 0 && System.currentTimeMillis() - stoppedNearDestSince > 10_000
        // Ankunft 20 m vor dem Zielpunkt entlang der Route (oder direkt am Ziel, falls es neben der Straße liegt)
        if ((!off && p.remainingM < 20) || direct < 20 || stoppedLongEnough) arrive()
        else if (!off) {
            checkConsumption(r, p)
            // Stau-Erkennung: Straße des aktuellen Abschnitts (Name/Nummer des zuletzt passierten Manövers)
            val road = r.steps.getOrNull((p.stepIdx - 1).coerceAtLeast(0))?.road.orEmpty()
            val reported = r.jams.any { j -> j.category == "JAM" && p.segIdx in (j.startIdx - 40)..(j.endIdx + 10) }
            JamWatch.onFix(f.speed, JamWatch.isMotorway(road), p.offRouteM, reported, f.pos, road) { voice.say(it) }
        }
        // Tunnel: ~5 s vor der Einfahrt dunkel, ~3 s nach der Ausfahrt wieder hell (nach Tempo umgerechnet)
        val ahead = (f.speed * 5).coerceIn(60.0, 250.0)
        val after = (f.speed * 3).coerceIn(30.0, 120.0)
        val inTun = !off && r.tunnels.any { t -> p.alongM >= t.start - ahead && p.alongM <= t.endInclusive + after }
        // mindestens 8 s zwischen zwei Wechseln, damit es an der Tunnelgrenze nicht flackert (Kartenstil wird neu geladen)
        if (_inTunnel.value != inTun && System.currentTimeMillis() - tunnelChangedAt > 8_000) {
            _inTunnel.value = inTun
            tunnelChangedAt = System.currentTimeMillis()
        }
    }

    private var stoppedNearDestSince = 0L

    /** Ziel erreicht: Navigation im Hintergrund beenden, Benachrichtigung sofort entfernen */
    private fun arrive() {
        if (_state.value.arrived) return
        checkJob?.cancel()
        coachJob?.cancel()
        stopLive()
        stoppedNearDestSince = 0L
        _state.update { it.copy(arrived = true) }
        // Ohne OBD: nach dem angezeigten Akku fragen, um den Verbrauch zu lernen (keine Ladestopps unterwegs)
        val r = _state.value.route
        val st = tripStartSoc
        if (Obd.freshSoc() == null && r != null && st != null && r.stops.isEmpty() && chargesDone.isEmpty()) {
            r.arrivalSoc?.let { arr -> ManualLearn.offer(st, arr, tripKm, tripTempC) }
        } else {
            ManualLearn.skip()
        }
        EcoRecorder.finish(arrived = true)
        TripRecorder.finishNow()
        app.stopService(Intent(app, NavigationService::class.java))
        app.getSystemService(NotificationManager::class.java)?.cancel(NavigationService.ID)
    }

    /** Stauende, Baustelle oder Sperrung auf den nächsten Kilometern? */
    private fun updateWarning(r: Route, along: Double, speedMs: Double) {
        val kmh = speedMs * 3.6
        var best: Warning? = null
        var bestKey = ""
        for (j in r.jams) {
            if (j.magnitude <= 0 && j.category != "ROAD_CLOSURE" && j.category != "ROAD_WORK") continue
            if (j.startIdx !in r.cumM.indices) continue
            val a = r.cumM[j.startIdx]
            val b = if (j.endIdx in r.cumM.indices) r.cumM[j.endIdx] else a
            if (b < along) continue
            val dist = a - along
            if (dist > 3000) continue
            val inside = dist <= 0
            val title = when {
                j.category == "ROAD_CLOSURE" -> "Sperrung"
                j.category == "ROAD_WORK" -> "Baustelle"
                inside -> "Stau"
                else -> "Stauende"
            }
            if (best == null || dist < best.distM) {
                best = Warning(j.category, title, max(0.0, dist), j.delayS, inside, b - max(a, along))
                val pt = r.points.getOrElse(j.startIdx) { r.points.first() }
                bestKey = String.format(Locale.US, "%.3f,%.3f", pt.lat, pt.lon)
            }
        }
        _state.update { it.copy(warning = best) }
        val w = best ?: return
        if (w.inside) return
        val first = if (kmh > 80) 1500.0 else 700.0
        if (w.distM <= first && announcedJams.add("$bestKey/1")) {
            val km = (w.distM / 500).roundToInt() / 2.0
            val d = when {
                w.distM < 950 -> "${(w.distM / 50).roundToInt() * 50} Metern"
                abs(km - 1.0) < 0.01 -> "einem Kilometer"
                km % 1.0 == 0.0 -> "${km.toInt()} Kilometern"
                else -> "${km.toString().replace('.', ',')} Kilometern"
            }
            val extra = if (w.delayS > 120) ", etwa ${(w.delayS / 60).roundToInt()} Minuten Verzögerung" else ""
            voice.say("Achtung, ${w.title} in $d$extra")
        } else if (w.distM <= 400 && kmh > 60 && announcedJams.add("$bestKey/2")) {
            voice.say("Achtung, ${w.title} voraus")
        }
    }

    private var consCheckAt = 0L
    private var consLegKey = ""

    /**
     * Mit OBD: Verbrauch seit dem letzten Ladestopp gegen die Planung vergleichen und auf den Rest der Etappe hochrechnen.
     * Reicht der Akku so nicht mehr bis zum nächsten Ladestopp bzw. Ziel, wird mit dem echten Akkustand neu geplant –
     * die Ladeplanung wählt dann rechtzeitig einen früheren Lader.
     */
    private fun checkConsumption(r: Route, p: NavProgress) {
        val now = System.currentTimeMillis()
        if (now - consCheckAt < 60_000) return
        consCheckAt = now
        val s = _state.value
        if (s.rerouting || s.charging != null || now - lastReroute < 120_000) return
        val real = Obd.freshSoc() ?: return
        val plan = r.socAt(p.alongM) ?: return
        val set = Settings.state.value
        val prevStop = r.stops.lastOrNull { it.alongM <= p.alongM }
        val legStartSoc = prevStop?.targetSoc ?: r.socProfile.firstOrNull()?.second ?: return
        val plannedDrop = legStartSoc - plan
        if (plannedDrop < 3) return // noch zu früh für eine belastbare Hochrechnung
        val ratio = ((legStartSoc - real) / plannedDrop).coerceIn(0.7, 1.8)
        val next = r.stops.firstOrNull { it.alongM > p.alongM + 300 }
        val arrivePlan = next?.arriveSoc ?: r.arrivalSoc ?: return
        val reserve = if (next != null) set.minSocStop else set.minSocDest
        val projected = real - (plan - arrivePlan) * ratio
        val key = "${System.identityHashCode(r)}:${next?.name}"
        if (projected < reserve - 1 && p.remainingM > 5_000 && key != consLegKey) {
            consLegKey = key
            voice.say(
                if (next != null) "Der Verbrauch liegt über der Planung. Ich plane einen früheren Ladestopp."
                else "Der Verbrauch liegt über der Planung. Ich plane einen Ladestopp ein.",
            )
            _state.update { it.copy(chargeNotice = "Verbrauch ${((ratio - 1) * 100).roundToInt()} % über Plan – Ankunft wäre bei ${projected.roundToInt()} %. Ladestopp wird neu geplant.") }
            LocationHub.fix.value?.let { reroute(it, manual = false) }
            scope.launch {
                delay(15_000)
                _state.update { if (it.chargeNotice?.startsWith("Verbrauch") == true) it.copy(chargeNotice = null) else it }
            }
        }
    }

    private fun reroute(f: Fix, manual: Boolean) {
        val s = _state.value
        val dest = s.dest ?: return
        val vias = s.vias.drop(viasPassed)
        val noToll = s.route?.tag == "Mautfrei"
        val soc = currentSoc()
        lastReroute = System.currentTimeMillis()
        _state.update { it.copy(rerouting = true, offer = null) }
        if (manual) voice.say("Route wird neu berechnet") else voice.chime()
        scope.launch {
            val res = safe {
                computeOptions(f.pos, if (f.speed > 3) f.bearing else null, dest.pos, soc,
                    alternatives = 0, withTollFree = false, noToll = noToll, vias = vias).first()
            }
            res.onSuccess { r ->
                lastSeg = 0; needFull = true; offCount = 0; viasPassed = 0
                lastFixNs = 0L
                voice.reset()
                _state.update { it.copy(routes = listOf(r.copy(tag = "Neu berechnet")), selected = 0, rerouting = false, vias = vias, progress = null) }
                LocationHub.fix.value?.let { onFix(it) }
                loadAvailability(r)
            }.onFailure {
                _state.update { it.copy(rerouting = false) }
                if (manual) voice.say("Neuberechnung fehlgeschlagen")
            }
        }
    }

    /** Meldungen der Autobahn-API für die laufende Route auffrischen (gleiche Strecke, neue Staus/Sperrungen) */
    private suspend fun refreshAutobahn() {
        val s = _state.value
        val r = s.route ?: return
        if (!s.navigating) return
        val e = runCatching { AutobahnApi.enrich(r, Settings.state.value) }.getOrNull() ?: return
        if (e.jams == r.jams && e.durationS == r.durationS) return
        _state.update { st -> if (st.route === r) st.copy(routes = st.routes.mapIndexed { i, x -> if (i == st.selected) e else x }) else st }
    }

    /** Alle 10 Minuten: frische Verkehrslage auf der Route, schnellere Route? Nächster Ladepark belegt? */
    private fun startChecks() {
        checkJob?.cancel()
        checkJob = scope.launch {
            while (isActive) {
                delay(10 * 60_000L)
                refreshAutobahn()
                checkAvailabilityAhead()
                checkBetterRoute()
            }
        }
    }

    private val handledClosures = mutableSetOf<String>()
    private val handledJams = mutableSetOf<String>()
    /** Sperrflächen der angebotenen Stau-Umfahrung (werden beim Annehmen übernommen) */
    private var pendingOfferAreas: List<List<LatLon>> = emptyList()

    /**
     * Alle 10 Minuten: Störungen (TomTom, falls Key) für den Rest der Route auffrischen.
     * Liegt eine Sperrung voraus, plant Valhalla mit Sperrflächen eine Umfahrung.
     */
    private suspend fun checkBetterRoute() {
        val s = _state.value
        if (!s.navigating || s.rerouting || s.arrived || s.charging != null) return
        val r = s.route ?: return
        val p = s.progress ?: return
        if (p.offRouteM > 50 || p.remainingM < 3_000) return
        val set = Settings.state.value
        val e = runCatching { TrafficIncidents.enrich(r, set, p.alongM) }.getOrNull() ?: r
        if (e !== r) _state.update { st -> if (st.route === r) st.copy(routes = st.routes.mapIndexed { i, x -> if (i == st.selected) e else x }) else st }
        // Großer Stau voraus (ab 10 Minuten)? Umfahrung rechnen und anbieten, wenn sie schneller ist
        if (s.offer == null) {
            val jam = e.jams.firstOrNull { j ->
                j.category == "JAM" && j.delayS >= 600 && j.startIdx in e.points.indices &&
                    e.cumM[j.startIdx] - p.alongM in 2_000.0..80_000.0
            }
            val jamKey = jam?.let { j -> e.points[j.startIdx].let { "%.3f,%.3f".format(java.util.Locale.US, it.lat, it.lon) } }
            if (jam != null && jamKey != null && handledJams.add(jamKey)) {
                val areas = TrafficIncidents.closureAreas(e, jam)
                val dest = s.dest
                val f = LocationHub.fix.value
                if (areas.isNotEmpty() && dest != null && f != null) {
                    val cand = safe {
                        computeOptions(f.pos, if (f.speed > 3) f.bearing else null, dest.pos, currentSoc(),
                            alternatives = 0, withTollFree = false, noToll = false, vias = s.vias.drop(viasPassed), extraAvoid = areas).first()
                    }.getOrNull()
                    // Restzeit der jetzigen Route enthält die Staus bereits (Zeiten an den Manövern)
                    val nowP = _state.value.progress
                    val remaining = nowP?.remainingS ?: p.remainingS
                    if (cand != null && cand.feasible) {
                        val saved = remaining - cand.durationS
                        if (saved > max(300.0, 0.05 * remaining)) {
                            pendingOfferAreas = areas
                            _state.update { it.copy(offer = Offer(cand.copy(tag = "Schneller"), saved)) }
                            voice.say("Stau voraus. Eine Umfahrung ist etwa ${(saved / 60).roundToInt()} Minuten schneller.")
                        }
                    }
                }
            }
        }
        val ahead = e.jams.firstOrNull { j ->
            j.category == "ROAD_CLOSURE" && j.startIdx in e.points.indices &&
                e.cumM[j.startIdx] - p.alongM in 300.0..80_000.0
        } ?: return
        val key = e.points[ahead.startIdx].let { "%.3f,%.3f".format(java.util.Locale.US, it.lat, it.lon) }
        if (!handledClosures.add(key)) return
        val areas = TrafficIncidents.closureAreas(e, ahead)
        if (areas.isEmpty()) return
        avoidAreas += areas
        voice.say("Sperrung auf der Route. Ich plane eine Umfahrung.")
        LocationHub.fix.value?.let { reroute(it, manual = false) }
    }

    private suspend fun checkAvailabilityAhead() {
        val s = _state.value
        if (!LiveStatus.available()) return
        val r = s.route ?: return
        val p = s.progress ?: return
        val next = r.stops.firstOrNull { it.alongM > p.alongM } ?: return
        val uuid = next.uuid ?: return
        if (next.alongM - p.alongM > 60_000) return
        val a = safe { LiveStatus.availability(uuid) }.getOrNull() ?: return
        _state.update { it.copy(availability = it.availability + (uuid to a)) }
        if (a.known && a.total > 0 && a.available == 0 && announcedFull.add(uuid)) {
            _state.update { it.copy(fullPark = next) }
            voice.say("Der nächste Ladepark ist gerade voll belegt.")
        }
    }

    /** Belegung der ersten Ladestopps einer Route laden */
    private fun loadAvailability(r: Route) {
        if (!LiveStatus.available()) return
        val ids = r.stops.mapNotNull { it.uuid }.filter { it !in _state.value.availability }.take(5)
        if (ids.isEmpty()) return
        scope.launch {
            val found = ids.map { id -> async { id to safe { LiveStatus.availability(id) }.getOrNull() } }
                .mapNotNull { d -> d.await().let { (id, a) -> if (a != null) id to a else null } }
            if (found.isNotEmpty()) _state.update { it.copy(availability = it.availability + found) }
        }
    }

    /** Routen berechnen und um Meldungen der Autobahn-API ergänzen */
    private suspend fun computeOptions(
        from: LatLon,
        heading: Float?,
        to: LatLon,
        socPct: Double,
        alternatives: Int,
        withTollFree: Boolean,
        noToll: Boolean,
        vias: List<Via> = emptyList(),
        extraAvoid: List<List<LatLon>> = emptyList(),
    ): List<Route> {
        val set = Settings.state.value
        suspend fun withTraffic(list: List<Route>) = list.map { r ->
            PlanProgress.set("Prüfe Verkehrsmeldungen …")
            val a = runCatching { AutobahnApi.enrich(r, set) }.getOrDefault(r)
            runCatching { TrafficIncidents.enrich(a, set) }.getOrDefault(a)
        }
        var list = withTraffic(computeOptionsRaw(from, heading, to, socPct, alternatives, withTollFree, noToll, vias, extraAvoid))
        // Sperrungen schon beim Planen umfahren: Sperrflächen setzen und einmal neu rechnen
        val newAreas = list.flatMap { r ->
            r.jams.filter { it.category == "ROAD_CLOSURE" }.flatMap { j ->
                val key = r.points.getOrNull(j.startIdx)?.let { "%.3f,%.3f".format(java.util.Locale.US, it.lat, it.lon) }
                if (key == null || !handledClosures.add(key)) emptyList() else TrafficIncidents.closureAreas(r, j)
            }
        }
        if (newAreas.isNotEmpty()) {
            avoidAreas += newAreas
            PlanProgress.set("Sperrung gemeldet – plane Umfahrung …")
            list = runCatching { withTraffic(computeOptionsRaw(from, heading, to, socPct, alternatives, withTollFree, noToll, vias, extraAvoid)) }.getOrDefault(list)
        }
        // Nach der echten Zeit sortieren (Fahrzeit + Stau + Laden); die schnellste ist „Empfohlen“
        val sorted = list.sortedBy { if (it.feasible) it.durationS else it.durationS + 1e7 }
        return sorted.mapIndexed { i, r ->
            if (r.tag == "Mautfrei") r else r.copy(tag = if (i == 0) "Empfohlen" else "Alternative")
        }.also { PlanProgress.set(null) }
    }

    private suspend fun computeOptionsRaw(
        from: LatLon,
        heading: Float?,
        to: LatLon,
        socPct: Double,
        alternatives: Int,
        withTollFree: Boolean,
        noToll: Boolean,
        vias: List<Via> = emptyList(),
        extraAvoid: List<List<LatLon>> = emptyList(),
    ): List<Route> = coroutineScope {
        val avoid = avoidAreas.toList() + extraAvoid
        val trip = _state.value.tripMaxSpeed
        val set = Settings.state.value.let { if (trip != null) it.copy(maxSpeedKmh = trip) else it }
        PlanProgress.prefix = ""
        PlanProgress.set("Hole Wetter für die Strecke …")
        val weather = safe { Weather.along(from, to) }.getOrNull()
        // Routing: ausschließlich Valhalla offline, Ladestopps aus der eigenen Ladeplanung
        if (!ValhallaRouter.ready()) {
            throw java.io.IOException("Keine Kartendaten für das Offline-Routing. Bitte unter Einstellungen → Routing herunterladen.")
        }
        PlanProgress.set("Berechne Route offline …")
        val list0 = ValhallaRouter.routes(from, heading, to, alternatives, vias.map { it.place.pos }, set, avoid)
        if (list0.isEmpty()) throw java.io.IOException("Valhalla hat keine Route gefunden.")
        PlanProgress.set("Lese Tempolimits und Steigungen aus den Kartendaten …")
        val list = list0.map { runCatching { ValhallaRouter.attributes(it) }.getOrDefault(it) }
        list.mapIndexed { i, r ->
            PlanProgress.prefix = if (list.size > 1) "Route ${i + 1} von ${list.size}: " else ""
            LocalCharging.plan(r, set, socPct, weather, vias) { v ->
                ValhallaRouter.routes(from, heading, to, 0, v, set, avoid).firstOrNull()?.let { runCatching { ValhallaRouter.attributes(it) }.getOrDefault(it) }
            }
                .let { if (noToll) it.copy(tag = "Mautfrei") else it }
        }.also { PlanProgress.prefix = "" }
    }

    /** Ohne TomTom bzw. als Rückfall: Valhalla offline – sonst gibt es keine Route */
    private suspend fun freeOptions(set: AppSettings, from: LatLon, bearing: Float?, to: LatLon, alts: Int, vias: List<LatLon>): List<Route> {
        if (!ValhallaRouter.ready()) {
            throw java.io.IOException("Keine Kartendaten für das Offline-Routing. Bitte unter Einstellungen → Routing herunterladen.")
        }
        return ValhallaRouter.routes(from, bearing, to, alts, vias, set, avoidAreas)
    }

    private fun similar(a: Route, b: Route) =
        abs(a.distanceM - b.distanceM) / max(1.0, a.distanceM) < 0.01 &&
            abs(a.durationS - b.durationS) / max(1.0, a.durationS) < 0.01
}

// ---------------- Vordergrund-Dienst (Navigation im Hintergrund) ----------------

class NavigationService : Service() {
    private val scope = MainScope()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Navigation", NotificationManager.IMPORTANCE_LOW))
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, ID, build("Navigation läuft", ""), type)
        LocationHub.acquire(this, "nav")
        Obd.acquire("nav")
        scope.launch {
            NavSession.state
                .map { s ->
                    val r = s.route
                    val p = s.progress
                    if (r == null || p == null) {
                        "Navigation läuft" to ""
                    } else {
                        val step = r.steps.getOrNull(p.stepIdx)
                        "${fmtDistShort(p.distToStepM)} · ${step?.bannerText() ?: ""}" to
                            "Ankunft ${fmtEta(p.remainingS)} · ${fmtKm(p.remainingM)}"
                    }
                }
                .distinctUntilChanged()
                .collect { (title, text) -> nm.notify(ID, build(title, text)) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        scope.cancel()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java)?.cancel(ID)
        LocationHub.release("nav")
        Obd.release("nav")
        super.onDestroy()
    }

    private fun build(title: String, text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(R.drawable.ic_nav)
        .setContentTitle(title)
        .setContentText(text)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        )
        .build()

    companion object {
        private const val CHANNEL = "nav"
        const val ID = 42
    }
}
