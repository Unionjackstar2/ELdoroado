import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Release-Schlüssel kommt (falls hinterlegt) aus den GitHub-Secrets, siehe build.yml
val releaseKs: String? = System.getenv("EVR_KEYSTORE")

android {
    // gleiche NDK-Version wie valhalla-mobile, damit beide dieselbe C++-Laufzeit (libc++_shared) nutzen
    ndkVersion = "29.0.14206865"
    // Native Bibliotheken entpacken, damit llama.cpp die CPU-Varianten zur Laufzeit im Ordner findet
    packaging {
        jniLibs {
            useLegacyPackaging = true
            pickFirsts += listOf("**/libc++_shared.so")
        }
    }
    // Tests auf dem Build-Rechner: Android-Funktionen liefern dort Standardwerte statt Fehler
    testOptions { unitTests.isReturnDefaultValues = true }
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    namespace = "de.evroute"
    compileSdk = 36
    defaultConfig {
        applicationId = "de.evroute"
        minSdk = 26
        targetSdk = 34
        versionCode = 104
        versionName = "0.80"
        // Beta-Fassung: eigene Paketkennung, läuft neben der normalen App (gradle -Pbeta=true)
        val beta = (project.findProperty("beta") as String?) == "true"
        manifestPlaceholders["appLabel"] = if (beta) "ELdoroado Beta" else "ELdoroado"
        if (beta) {
            applicationIdSuffix = ".beta"
            versionNameSuffix = "-beta"
        }
        // Nur 64-Bit-ARM (alle aktuellen Handys, auch Pixel 4a): Valhalla und llama.cpp bringen große native Bibliotheken mit
        ndk { abiFilters += listOf("arm64-v8a") }
        // Kartenkacheln für Valhalla (eigener Server); Token kommt nur beim Bauen aus dem GitHub-Secret, nie in den Quellcode
        buildConfigField("String", "TILES_BASE", "\"https://eldorado.tedoki.de\"")
        buildConfigField("String", "TILES_TOKEN", "\"${System.getenv("ELD_TILES_TOKEN") ?: ""}\"")
        // KI-Assistent (llama.cpp) nur für 64-Bit-ARM
        externalNativeBuild {
            cmake {
                abiFilters += listOf("arm64-v8a")
                arguments += listOf("-DCMAKE_BUILD_TYPE=Release", "-DANDROID_STL=c++_shared")
            }
        }
    }
    signingConfigs {
        // Fester Schlüssel, damit neue Builds sich über die alte App installieren lassen
        getByName("debug") {
            storeFile = file("evroute-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    if (releaseKs != null) {
        signingConfigs.create("release") {
            storeFile = file(releaseKs!!)
            storePassword = System.getenv("EVR_KEYSTORE_PASSWORD")
            keyAlias = "evroute"
            keyPassword = System.getenv("EVR_KEYSTORE_PASSWORD")
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = if (releaseKs != null) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    // Offline-Routing: Valhalla als Android-Bibliothek (MIT), Kacheln vom eigenen Server
    implementation("io.github.rallista:valhalla-mobile:0.6.1")
    implementation("io.github.rallista:valhalla-models:0.5.2")
    implementation("io.github.rallista:valhalla-models-config:0.5.2")
    implementation("com.stadiamaps:osrm-openapi:0.0.10")
    implementation("com.squareup.moshi:moshi-kotlin:1.15.1")
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.maplibre.gl:android-sdk:11.5.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    // Android Auto
}
