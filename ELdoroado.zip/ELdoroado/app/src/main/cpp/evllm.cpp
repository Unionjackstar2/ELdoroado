// Kleine JNI-Brücke zu llama.cpp: Modell laden, Chat-Vorlage anwenden, Text erzeugen (optional mit Grammatik)
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <ctime>
#include "llama.h"
#include "ggml-backend.h"

// Messwerte der letzten Anfrage (für die Anzeige in den Einstellungen)
static double g_prompt_ms = 0, g_gen_ms = 0;
static int g_prompt_n = 0, g_gen_n = 0;

#define LOG_TAG "evllm"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

struct Slot {
    llama_context *ctx = nullptr;
    std::string prefix;              // zuletzt vorgerechneter Vorspann (Anleitung)
    std::vector<uint8_t> state;      // gespeicherter Zustand nach dem Vorspann
};

struct Holder {
    llama_model *model;
    int threads;
    int nctx;
    Slot slots[2];
};

static llama_context *make_ctx(Holder *h, int nctx) {
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = nctx;
    cp.n_batch = 512;
    cp.n_ubatch = 512;
    cp.n_threads = h->threads;
    cp.n_threads_batch = h->threads;
    return llama_init_from_model(h->model, cp);
}

static std::vector<llama_token> tokenize(const llama_vocab *vocab, const std::string &text, bool add_special) {
    int n = -llama_tokenize(vocab, text.c_str(), (int) text.size(), nullptr, 0, add_special, true);
    std::vector<llama_token> toks(n > 0 ? n : 0);
    if (n > 0) llama_tokenize(vocab, text.c_str(), (int) text.size(), toks.data(), (int) toks.size(), add_special, true);
    return toks;
}

static bool decode_all(llama_context *ctx, std::vector<llama_token> &toks) {
    for (size_t i = 0; i < toks.size(); i += 512) {
        int len = (int) std::min<size_t>(512, toks.size() - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, len);
        if (llama_decode(ctx, b) != 0) return false;
    }
    return true;
}

static std::string jstr(JNIEnv *env, jstring s) {
    if (!s) return "";
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string r(c);
    env->ReleaseStringUTFChars(s, c);
    return r;
}

static jbyteArray bytes(JNIEnv *env, const std::string &s) {
    jbyteArray a = env->NewByteArray((jsize) s.size());
    env->SetByteArrayRegion(a, 0, (jsize) s.size(), (const jbyte *) s.data());
    return a;
}

extern "C" JNIEXPORT jlong JNICALL
Java_de_evroute_LlamaNative_nativeLoad(JNIEnv *env, jobject, jstring path, jint threads, jint nctx) {
    static bool init = false;
    if (!init) {
        // CPU-Varianten aus dem Bibliotheksordner laden; ggml wählt die schnellste, die der Prozessor kann
        jclass sys = env->FindClass("de/evroute/LlamaNative");
        jfieldID fid = env->GetStaticFieldID(sys, "libDir", "Ljava/lang/String;");
        auto jdir = (jstring) env->GetStaticObjectField(sys, fid);
        std::string dir = jstr(env, jdir);
        if (!dir.empty()) ggml_backend_load_all_from_path(dir.c_str()); else ggml_backend_load_all();
        llama_backend_init();
        init = true;
    }
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    llama_model *m = llama_model_load_from_file(jstr(env, path).c_str(), mp);
    if (!m) return 0;
    auto *h = new Holder();
    h->model = m;
    h->threads = threads;
    h->nctx = nctx;
    return (jlong) h;
}

extern "C" JNIEXPORT void JNICALL
Java_de_evroute_LlamaNative_nativeFree(JNIEnv *, jobject, jlong hh) {
    auto *h = (Holder *) hh;
    if (!h) return;
    for (auto &sl : h->slots) if (sl.ctx) llama_free(sl.ctx);
    llama_model_free(h->model);
    delete h;
}

// Chat-Vorlage des Modells anwenden; leer = Vorlage unbekannt (Kotlin baut dann selbst)
extern "C" JNIEXPORT jbyteArray JNICALL
Java_de_evroute_LlamaNative_nativeTemplate(JNIEnv *env, jobject, jlong hh, jstring sys, jstring user) {
    auto *h = (Holder *) hh;
    std::string s = jstr(env, sys), u = jstr(env, user);
    const char *tmpl = llama_model_chat_template(h->model, nullptr);
    if (!tmpl) return bytes(env, "");
    std::vector<llama_chat_message> msgs = {{"system", s.c_str()}, {"user", u.c_str()}};
    std::vector<char> buf(s.size() + u.size() + 4096);
    int n = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int) buf.size());
    if (n > (int) buf.size()) {
        buf.resize(n + 16);
        n = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int) buf.size());
    }
    if (n < 0) return bytes(env, "");
    return bytes(env, std::string(buf.data(), n));
}

// Text erzeugen. prefix (die Anleitung) wird pro Slot nur einmal gerechnet und danach aus dem gespeicherten Zustand wiederhergestellt.
extern "C" JNIEXPORT jbyteArray JNICALL
Java_de_evroute_LlamaNative_nativeGenerate(JNIEnv *env, jobject, jlong hh, jint slotNo, jstring jprefix, jstring jrest, jstring jgrammar, jint maxTokens, jfloat temp) {
    auto *h = (Holder *) hh;
    if (!h) return bytes(env, "");
    Slot &sl = h->slots[slotNo == 1 ? 1 : 0];
    const llama_vocab *vocab = llama_model_get_vocab(h->model);
    std::string prefix = jstr(env, jprefix);
    std::string rest = jstr(env, jrest);
    std::string grammar = jstr(env, jgrammar);
    if (!sl.ctx) {
        sl.ctx = make_ctx(h, slotNo == 1 ? 2048 : h->nctx);
        if (!sl.ctx) return bytes(env, "");
    }
    llama_context *ctx = sl.ctx;
    llama_memory_t mem = llama_get_memory(ctx);
    int64_t t0 = ggml_time_us();
    int processed = 0;

    if (sl.prefix == prefix && !sl.state.empty()) {
        // Vorspann bekannt: gespeicherten Zustand zurückholen (spart das erneute Lesen der Anleitung)
        llama_memory_clear(mem, true);
        if (llama_state_seq_set_data(ctx, sl.state.data(), sl.state.size(), 0) == 0) sl.prefix.clear();
    }
    if (sl.prefix != prefix) {
        llama_memory_clear(mem, true);
        auto ptoks = tokenize(vocab, prefix, true);
        if ((int) ptoks.size() >= llama_n_ctx(ctx) - 64 || !decode_all(ctx, ptoks)) { sl.prefix.clear(); return bytes(env, ""); }
        processed += (int) ptoks.size();
        size_t n = llama_state_seq_get_size(ctx, 0);
        sl.state.resize(n);
        llama_state_seq_get_data(ctx, sl.state.data(), n, 0);
        sl.prefix = prefix;
    }
    auto rtoks = tokenize(vocab, rest, false);
    if (rtoks.empty() || !decode_all(ctx, rtoks)) return bytes(env, "");
    processed += (int) rtoks.size();

    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (!grammar.empty()) llama_sampler_chain_add(smpl, llama_sampler_init_grammar(vocab, grammar.c_str(), "root"));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist((uint32_t) time(nullptr)));

    int64_t t1 = ggml_time_us();
    g_prompt_ms = (t1 - t0) / 1000.0;
    g_prompt_n = processed;
    int gen = 0;
    std::string out;
    char piece[256];
    for (int i = 0; i < maxTokens; i++) {
        llama_token tok = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;
        int pn = llama_token_to_piece(vocab, tok, piece, sizeof(piece), 0, false);
        if (pn > 0) out.append(piece, pn);
        gen++;
        llama_batch b = llama_batch_get_one(&tok, 1);
        if (llama_decode(ctx, b) != 0) break;
    }
    g_gen_ms = (ggml_time_us() - t1) / 1000.0;
    g_gen_n = gen;
    llama_sampler_free(smpl);
    return bytes(env, out);
}

// "prompt_ms;prompt_n;gen_ms;gen_n"
extern "C" JNIEXPORT jstring JNICALL
Java_de_evroute_LlamaNative_nativeStats(JNIEnv *env, jobject) {
    char buf[128];
    snprintf(buf, sizeof(buf), "%.0f;%d;%.0f;%d", g_prompt_ms, g_prompt_n, g_gen_ms, g_gen_n);
    return env->NewStringUTF(buf);
}

// Fähigkeiten der geladenen CPU-Variante, z. B. "NEON DOTPROD MATMUL_INT8"
extern "C" JNIEXPORT jstring JNICALL
Java_de_evroute_LlamaNative_nativeCpuInfo(JNIEnv *env, jobject) {
    std::string out;
    ggml_backend_reg_t reg = ggml_backend_reg_by_name("CPU");
    if (reg) {
        auto get = (ggml_backend_get_features_t) ggml_backend_reg_get_proc_address(reg, "ggml_backend_get_features");
        if (get) {
            for (ggml_backend_feature *f = get(reg); f && f->name; f++) {
                if (std::string(f->value) == "1") { if (!out.empty()) out += " "; out += f->name; }
            }
        }
    }
    return env->NewStringUTF(out.c_str());
}
