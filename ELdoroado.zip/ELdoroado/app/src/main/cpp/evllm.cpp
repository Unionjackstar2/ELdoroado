// Kleine JNI-Brücke zu llama.cpp: Modell laden, Chat-Vorlage anwenden, Text erzeugen (optional mit Grammatik)
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <ctime>
#include "llama.h"
#include "ggml-backend.h"

// Messwerte der letzten Anfrage (für die Anzeige in den Einstellungen)
static double g_prompt_ms = 0, g_gen_ms = 0;
static int g_prompt_n = 0, g_gen_n = 0;

#define LOG_TAG "evllm"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

struct Holder {
    llama_model *model;
    int threads;
    int nctx;
};

static std::string jstr(JNIEnv *env, jstring s) {
    if (!s) return "";
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string r(c);
    env->ReleaseStringUTFChars(s, c);
    return r;
}

static jbyteArray bytes(JNIEnv *env, const std::string &s) {
    jbyteArray a = env->NewByteArray((jsize) s.size());
    env->SetByteArrayRegion(a, 0, (jsize) s.size(), (const jbyte *) s.data());
    return a;
}

extern "C" JNIEXPORT jlong JNICALL
Java_de_evroute_LlamaNative_nativeLoad(JNIEnv *env, jobject, jstring path, jint threads, jint nctx) {
    static bool init = false;
    if (!init) {
        // CPU-Varianten aus dem Bibliotheksordner laden; ggml wählt die schnellste, die der Prozessor kann
        jclass sys = env->FindClass("de/evroute/LlamaNative");
        jfieldID fid = env->GetStaticFieldID(sys, "libDir", "Ljava/lang/String;");
        auto jdir = (jstring) env->GetStaticObjectField(sys, fid);
        std::string dir = jstr(env, jdir);
        if (!dir.empty()) ggml_backend_load_all_from_path(dir.c_str()); else ggml_backend_load_all();
        llama_backend_init();
        init = true;
    }
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    llama_model *m = llama_model_load_from_file(jstr(env, path).c_str(), mp);
    if (!m) return 0;
    auto *h = new Holder{m, threads, nctx};
    return (jlong) h;
}

extern "C" JNIEXPORT void JNICALL
Java_de_evroute_LlamaNative_nativeFree(JNIEnv *, jobject, jlong hh) {
    auto *h = (Holder *) hh;
    if (!h) return;
    llama_model_free(h->model);
    delete h;
}

// Chat-Vorlage des Modells anwenden; leer = Vorlage unbekannt (Kotlin baut dann selbst)
extern "C" JNIEXPORT jbyteArray JNICALL
Java_de_evroute_LlamaNative_nativeTemplate(JNIEnv *env, jobject, jlong hh, jstring sys, jstring user) {
    auto *h = (Holder *) hh;
    std::string s = jstr(env, sys), u = jstr(env, user);
    const char *tmpl = llama_model_chat_template(h->model, nullptr);
    if (!tmpl) return bytes(env, "");
    std::vector<llama_chat_message> msgs = {{"system", s.c_str()}, {"user", u.c_str()}};
    std::vector<char> buf(s.size() + u.size() + 4096);
    int n = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int) buf.size());
    if (n > (int) buf.size()) {
        buf.resize(n + 16);
        n = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int) buf.size());
    }
    if (n < 0) return bytes(env, "");
    return bytes(env, std::string(buf.data(), n));
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_de_evroute_LlamaNative_nativeGenerate(JNIEnv *env, jobject, jlong hh, jstring jprompt, jstring jgrammar, jint maxTokens, jfloat temp) {
    auto *h = (Holder *) hh;
    if (!h) return bytes(env, "");
    const llama_vocab *vocab = llama_model_get_vocab(h->model);
    std::string prompt = jstr(env, jprompt);
    std::string grammar = jstr(env, jgrammar);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = h->nctx;
    cp.n_batch = 512;
    cp.n_ubatch = 512;
    cp.n_threads = h->threads;
    cp.n_threads_batch = h->threads;
    llama_context *ctx = llama_init_from_model(h->model, cp);
    if (!ctx) return bytes(env, "");

    // Eingabe in Tokens umwandeln
    int n = -llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, true, true);
    std::vector<llama_token> toks(n > 0 ? n : 0);
    if (n > 0) llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), toks.data(), (int) toks.size(), true, true);
    if ((int) toks.size() >= h->nctx - 8) { llama_free(ctx); return bytes(env, ""); }

    int64_t t0 = ggml_time_us();
    // Eingabe in Blöcken verarbeiten
    for (size_t i = 0; i < toks.size(); i += 512) {
        int len = (int) std::min<size_t>(512, toks.size() - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, len);
        if (llama_decode(ctx, b) != 0) { llama_free(ctx); return bytes(env, ""); }
    }

    // Auswahl der Tokens: optional Grammatik (erzwingt gültiges JSON), dann Temperatur
    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (!grammar.empty()) llama_sampler_chain_add(smpl, llama_sampler_init_grammar(vocab, grammar.c_str(), "root"));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist((uint32_t) time(nullptr)));

    int64_t t1 = ggml_time_us();
    g_prompt_ms = (t1 - t0) / 1000.0;
    g_prompt_n = (int) toks.size();
    int gen = 0;
    std::string out;
    char piece[256];
    for (int i = 0; i < maxTokens; i++) {
        llama_token tok = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;
        int pn = llama_token_to_piece(vocab, tok, piece, sizeof(piece), 0, false);
        if (pn > 0) out.append(piece, pn);
        gen++;
        llama_batch b = llama_batch_get_one(&tok, 1);
        if (llama_decode(ctx, b) != 0) break;
    }
    g_gen_ms = (ggml_time_us() - t1) / 1000.0;
    g_gen_n = gen;
    llama_sampler_free(smpl);
    llama_free(ctx);
    return bytes(env, out);
}

// "prompt_ms;prompt_n;gen_ms;gen_n"
extern "C" JNIEXPORT jstring JNICALL
Java_de_evroute_LlamaNative_nativeStats(JNIEnv *env, jobject) {
    char buf[128];
    snprintf(buf, sizeof(buf), "%.0f;%d;%.0f;%d", g_prompt_ms, g_prompt_n, g_gen_ms, g_gen_n);
    return env->NewStringUTF(buf);
}

// Fähigkeiten der geladenen CPU-Variante, z. B. "NEON DOTPROD MATMUL_INT8"
extern "C" JNIEXPORT jstring JNICALL
Java_de_evroute_LlamaNative_nativeCpuInfo(JNIEnv *env, jobject) {
    std::string out;
    ggml_backend_reg_t reg = ggml_backend_reg_by_name("CPU");
    if (reg) {
        auto get = (ggml_backend_get_features_t) ggml_backend_reg_get_proc_address(reg, "ggml_backend_get_features");
        if (get) {
            for (ggml_backend_feature *f = get(reg); f && f->name; f++) {
                if (std::string(f->value) == "1") { if (!out.empty()) out += " "; out += f->name; }
            }
        }
    }
    return env->NewStringUTF(out.c_str());
}
