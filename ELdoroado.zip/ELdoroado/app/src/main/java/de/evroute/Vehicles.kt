package de.evroute

/** OBD-Unterstützung eines Fahrzeugs */
enum class ObdSupport(val label: String) {
    TESTED("OBD ✓"),          // Abfragen wie beim ë-C4 bestätigt
    LIKELY("OBD ungetestet"),  // gleiche Plattform, Abfragen sehr wahrscheinlich gleich
    NONE("kein OBD"),          // eigenes System, keine Abfragen hinterlegt
}

/** Fahrzeugprofil: Akku, Ladeleistung, Verbrauchsfaktor gegenüber dem ë-C4 (2022), Ladekurve, OBD */
data class VehicleProfile(
    val id: String,
    val brand: String,
    val model: String,
    val years: String,
    val grossKwh: Double,
    val usableKwh: Double,
    val maxDcKw: Double,
    val eff: Double,
    val curve: String,      // "ecmp1", "ecmp2" oder "generic"
    val obd: ObdSupport,
    val note: String = "",
) {
    val name get() = "$brand $model"
    val group get() = when (curve) {
        "ecmp1" -> "Stellantis e-CMP, 1. Generation (50 kWh)"
        "ecmp2" -> "Stellantis e-CMP, 2. Generation (54 kWh)"
        else -> brand
    }
}

object Vehicles {
    private fun g1(id: String, brand: String, model: String, years: String, eff: Double, obd: ObdSupport = ObdSupport.TESTED, note: String = "") =
        VehicleProfile(id, brand, model, years, 50.0, 46.0, 100.0, eff, "ecmp1", obd, note)

    private fun g2(id: String, brand: String, model: String, years: String, eff: Double, note: String = "") =
        VehicleProfile(id, brand, model, years, 54.0, 51.0, 100.0, eff, "ecmp2", ObdSupport.LIKELY, note)

    val ALL = listOf(
        // 1. Generation: 50 kWh brutto, ~46 kWh netto, 100 kW Motor, bis 100 kW DC
        g1("citroen-ec4-1", "Citroën", "ë-C4 / ë-C4 X", "2020–2022", 1.00),
        g1("peugeot-e208-1", "Peugeot", "e-208", "2019–2022", 0.94),
        g1("peugeot-e2008-1", "Peugeot", "e-2008", "2019–2022", 1.04),
        g1("opel-corsae-1", "Opel", "Corsa-e", "2019–2022", 0.95),
        g1("opel-mokkae-1", "Opel", "Mokka-e", "2020–2022", 1.00),
        g1("ds3-etense-1", "DS", "3 Crossback E-Tense", "2019–2022", 1.02),
        g1(
            "van-small-1", "Citroën/Peugeot/Opel/Toyota", "ë-Berlingo, e-Rifter, Combo-e, Proace City", "2021–2023", 1.30,
            ObdSupport.LIKELY, "Hochdachkombi: deutlich mehr Verbrauch auf der Autobahn",
        ),
        // 2. Generation: 54 kWh brutto, ~51 kWh netto, 115 kW Motor, bis 100 kW DC
        g2("citroen-ec4-2", "Citroën", "ë-C4 / ë-C4 X", "ab 2023", 0.93),
        g2("peugeot-e208-2", "Peugeot", "e-208", "ab 2023", 0.88, "Je nach Baujahr 48–51 kWh netto, bitte prüfen"),
        g2("peugeot-e2008-2", "Peugeot", "e-2008", "ab 2023", 0.96),
        g2("peugeot-e308-2", "Peugeot/Opel", "e-308, Astra Electric", "ab 2023", 0.90),
        g2("opel-corsa-2", "Opel", "Corsa Electric", "ab 2023", 0.89, "Je nach Baujahr 48–51 kWh netto, bitte prüfen"),
        g2("opel-mokka-2", "Opel", "Mokka Electric", "ab 2023", 0.93),
        g2("ds3-etense-2", "DS", "3 E-Tense", "ab 2023", 0.94),
        g2("jeep-avenger", "Jeep", "Avenger Elektro", "ab 2023", 0.96),
        g2("fiat-600e", "Fiat", "600e", "ab 2023", 0.94),
        g2("alfa-junior", "Alfa Romeo", "Junior Elettrica", "ab 2024", 0.94),
        g2("lancia-ypsilon", "Lancia", "Ypsilon", "ab 2024", 0.89),
        // Leapmotor: eigenes System, keine OBD-Abfragen hinterlegt; Werte ohne Gewähr
        VehicleProfile("leap-t03", "Leapmotor", "T03", "ab 2024", 37.3, 36.0, 48.0, 0.85, "generic", ObdSupport.NONE, "Eigenes System; Werte bitte prüfen"),
        VehicleProfile("leap-c10", "Leapmotor", "C10", "ab 2024", 69.9, 67.0, 84.0, 1.15, "generic", ObdSupport.NONE, "Eigenes System; Werte bitte prüfen"),
        // Eigene Werte
        VehicleProfile("custom", "Anderes Fahrzeug", "(eigene Werte)", "", 0.0, 50.0, 100.0, 1.0, "generic", ObdSupport.NONE),
    )

    fun byId(id: String): VehicleProfile = ALL.firstOrNull { it.id == id } ?: ALL.first()

    fun current(): VehicleProfile = byId(Settings.state.value.vehicleId)

    /** Höchste DC-Ladeleistung (bei „eigene Werte“ aus den Einstellungen) */
    fun maxDc(s: AppSettings): Double = byId(s.vehicleId).let { if (it.id == "custom") s.customDcKw.toDouble() else it.maxDcKw }
}
