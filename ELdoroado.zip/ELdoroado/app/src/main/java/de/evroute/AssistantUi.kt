package de.evroute

import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Gesprächsfenster des Navi-Assistenten */
@Composable
fun AssistantSheet(vm: MainViewModel, maxH: Dp) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val st by Assistant.state.collectAsState()
    var input by remember { mutableStateOf("") }
    val scroll = rememberScrollState()
    LaunchedEffect(st.messages.size, st.busy) { scroll.animateScrollTo(scroll.maxValue) }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val t = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) Assistant.ask(ctx, t)
    }
    GlassCard(Modifier.fillMaxWidth(), corner = 28.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, null, tint = Color(0xFF7C4DFF))
                Spacer(Modifier.width(8.dp))
                Text("Navi-Assistent", color = pal.text, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (st.messages.isNotEmpty()) Text("Neu", color = pal.blue, fontSize = 14.sp, modifier = Modifier.clickable { Assistant.clear() }.padding(8.dp))
                CloseDot(vm::closeAssistant)
            }
            Column(Modifier.heightIn(max = maxH * 0.42f).verticalScroll(scroll).padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (st.messages.isEmpty()) {
                    Text(
                        "Sag mir, wohin es gehen soll, zum Beispiel:\n„Von Herdecke nach Varazze, nur EnBW und Tesla, um 12 Uhr Pause bei Burger King.“",
                        color = pal.sub, fontSize = 14.sp,
                    )
                }
                st.messages.forEach { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                        Column(
                            Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp))
                                .background(if (m.fromUser) pal.blue else pal.field).padding(horizontal = 14.dp, vertical = 10.dp),
                        ) {
                            Text(m.text, color = if (m.fromUser) Color.White else pal.text, fontSize = 15.sp)
                            if (m.showRoute) {
                                Text(
                                    "Route ansehen", color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(10.dp)).background(Color.White)
                                        .clickable { vm.closeAssistant() }.padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                            }
                        }
                    }
                }
                if (st.busy) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(16.dp), color = Color(0xFF7C4DFF), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(st.status.ifBlank { "Denke nach …" }, color = pal.sub, fontSize = 14.sp)
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(pal.field).padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f).padding(vertical = 8.dp)) {
                    if (input.isEmpty()) Text("Was hast du vor?", color = pal.sub, fontSize = 16.sp)
                    BasicTextField(
                        value = input, onValueChange = { input = it },
                        textStyle = TextStyle(color = pal.text, fontSize = 16.sp, fontFamily = NotoSans),
                        cursorBrush = SolidColor(pal.blue), modifier = Modifier.fillMaxWidth(),
                    )
                }
                Box(
                    Modifier.size(40.dp).clip(CircleShape).clickable {
                        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
                            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Wohin soll es gehen?")
                        try { speech.launch(i) } catch (_: ActivityNotFoundException) {}
                    },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Mic, "Spracheingabe", tint = pal.blue) }
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(if (input.isNotBlank() && !st.busy) pal.blue else pal.sub.copy(alpha = 0.3f))
                        .clickable(enabled = input.isNotBlank() && !st.busy) { Assistant.ask(ctx, input); input = "" },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.AutoMirrored.Filled.Send, "Senden", tint = Color.White, modifier = Modifier.size(18.dp)) }
            }
            Spacer(Modifier.height(2.dp))
        }
    }
}
