package de.evroute

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------- Standort ----------------

object LocationHub {
    private val _fix = MutableStateFlow<Fix?>(null)
    val fix: StateFlow<Fix?> = _fix.asStateFlow()
    private var client: FusedLocationProviderClient? = null
    private val holders = mutableSetOf<String>()

    /** Fahrsimulation aktiv: echte Positionen ignorieren */
    @Volatile var simulating = false

    fun inject(f: Fix) { _fix.value = f }

    private val callback = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) {
            if (simulating) return
            val l = r.lastLocation ?: return
            _fix.value = clean(l)
        }
    }

    /** Genauer Standort freigegeben (für die Navigation nötig) */
    fun precise(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Irgendein Standort freigegeben (ungefähr reicht für Karte und Planung) */
    fun hasPermission(ctx: Context) = precise(ctx) ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    enum class Perm { NONE, APPROX, PRECISE }
    private val _perm = MutableStateFlow(Perm.NONE)
    val perm: StateFlow<Perm> = _perm.asStateFlow()

    /** Berechtigung neu prüfen (beim Start und nach Rückkehr aus den Einstellungen) */
    fun refreshPermission(ctx: Context) {
        _perm.value = when {
            precise(ctx) -> Perm.PRECISE
            hasPermission(ctx) -> Perm.APPROX
            else -> Perm.NONE
        }
    }

    /**
     * Position aufbereiten: Fehlt das Tempo (z. B. kurz WLAN-/Mobilfunk-Ortung statt GPS), wird es aus Strecke/Zeit berechnet
     * statt 0 zu setzen. Physikalisch unmögliche Sprünge und ungenaue Positionen während der Fahrt ändern Tempo/Richtung nicht.
     */
    private fun clean(l: android.location.Location): Fix {
        val prev = _fix.value
        val pos = LatLon(l.latitude, l.longitude)
        val acc = if (l.hasAccuracy()) l.accuracy.toDouble() else 50.0
        val dt = if (prev != null && prev.elapsedNs > 0) (l.elapsedRealtimeNanos - prev.elapsedNs) / 1e9 else -1.0
        var speed: Double? = if (l.hasSpeed()) l.speed.toDouble() else null
        var bearing: Float? = if (l.hasBearing()) l.bearing else null
        if (speed == null && prev != null && dt in 0.3..5.0) speed = haversine(prev.pos, pos) / dt
        if (speed == null) speed = prev?.speed ?: 0.0
        if (prev != null && dt in 0.2..3.0) {
            val a = (speed - prev.speed) / dt
            // mehr als ~1 g Bremsen bzw. 0,8 g Beschleunigen ist ausgeschlossen: Messfehler
            if (a < -10.0 || a > 8.0) speed = prev.speed
            // ungenaue Position während der Fahrt: Tempo und Richtung vom letzten guten Wert behalten
            if (acc > 40 && prev.accuracy <= 40 && prev.speed > 3) { speed = prev.speed; bearing = prev.bearing }
        }
        if (bearing == null && (speed ?: 0.0) > 2) bearing = prev?.bearing
        return Fix(
            pos = pos, bearing = bearing, speed = speed ?: 0.0, accuracy = acc, time = l.time,
            elapsedNs = l.elapsedRealtimeNanos, alt = if (l.hasAltitude()) l.altitude else null,
        )
    }

    /** Mehrere Nutzer (Bildschirm, Navigationsdienst) teilen sich ein Abo */
    @SuppressLint("MissingPermission")
    fun acquire(ctx: Context, tag: String) {
        if (!hasPermission(ctx) || tag in holders) return
        val first = holders.isEmpty()
        holders += tag
        if (first) {
            val c = client ?: LocationServices.getFusedLocationProviderClient(ctx.applicationContext).also { client = it }
            // Bei nur ungefährem Standort liefert Android ohnehin grobe Positionen
            val prio = if (precise(ctx)) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
            val req = LocationRequest.Builder(prio, 1000L)
                .setMinUpdateIntervalMillis(500L)
                .build()
            c.requestLocationUpdates(req, callback, Looper.getMainLooper())
        }
    }

    fun release(tag: String) {
        if (holders.remove(tag) && holders.isEmpty()) client?.removeLocationUpdates(callback)
    }
}

// ---------------- Position auf der Route ----------------

object NavEngine {
    /** Fortschritt an einer bestimmten Stelle der Route (für den Tunnel-Modus ohne GPS) */
    fun progressAt(r: Route, along: Double): NavProgress? {
        val n = r.points.size
        if (n < 2) return null
        val a = along.coerceIn(0.0, r.cumM.last())
        var i = r.cumM.binarySearch(a)
        if (i < 0) i = -i - 2
        i = i.coerceIn(0, n - 2)
        val seg = r.cumM[i + 1] - r.cumM[i]
        val t = if (seg <= 0) 0.0 else ((a - r.cumM[i]) / seg).coerceIn(0.0, 1.0)
        val pos = lerp(r.points[i], r.points[i + 1], t)
        return update(r, pos, i, false).copy(offRouteM = 0.0)
    }

    fun update(r: Route, p: LatLon, lastSeg: Int, fullSearch: Boolean): NavProgress {
        val n = r.points.size
        if (n < 2) {
            return NavProgress(0, p, 0.0, 0.0, r.steps.lastIndex.coerceAtLeast(0), 0.0, 0.0, 0.0, 0.0)
        }
        val from = if (fullSearch) 0 else max(0, lastSeg - 5)
        val to = if (fullSearch) n - 2 else min(n - 2, lastSeg + 400)
        var best = from
        var bd = Double.MAX_VALUE
        for (i in from..max(from, to)) {
            val d = distToSeg(p, r.points[i], r.points[i + 1])
            if (d < bd) { bd = d; best = i }
        }
        val a = r.points[best]
        val b = r.points[best + 1]
        val t = projectT(p, a, b)
        val along = r.cumM[best] + t * (r.cumM[best + 1] - r.cumM[best])

        var s = r.steps.indices.firstOrNull { r.stepAlongM[it] > along + 2 } ?: r.steps.lastIndex
        if (s < 0) s = 0
        val toStep = if (r.steps.isEmpty()) 0.0 else max(0.0, r.stepAlongM[s] - along)

        // Restzeit aus den Zeiten an den Manövern, plus noch ausstehende Ladezeiten
        var remS = 0.0
        if (r.stepTimeS.isNotEmpty()) {
            val tNext = r.stepTimeS[s]
            val prevIdx = (s - 1).coerceAtLeast(0)
            val span = r.stepAlongM[s] - r.stepAlongM[prevIdx]
            val tNow = if (s == 0 || span <= 0) tNext
            else r.stepTimeS[prevIdx] + (tNext - r.stepTimeS[prevIdx]) * ((along - r.stepAlongM[prevIdx]) / span).coerceIn(0.0, 1.0)
            remS = max(0.0, r.stepTimeS.last() - tNow)
        }
        if (!r.timesIncludeCharging) remS += r.stops.filter { it.alongM > along + 50 }.sumOf { it.chargeS }

        return NavProgress(
            segIdx = best,
            snapped = lerp(a, b, t),
            routeBearing = bearing(a, b),
            alongM = along,
            stepIdx = s,
            distToStepM = toStep,
            remainingM = max(0.0, r.cumM.last() - along),
            remainingS = remS,
            offRouteM = bd,
        )
    }
}

// ---------------- Sprachansagen ----------------

class Voice(ctx: Context) : TextToSpeech.OnInitListener {
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(attrs)
        .build()
    private val done = mutableSetOf<Int>()
    @Volatile private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext, this)

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts.language = Locale.GERMANY
        tts.setAudioAttributes(attrs)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { audio.abandonAudioFocusRequest(focus) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { audio.abandonAudioFocusRequest(focus) }
        })
        ready = true
    }

    fun say(text: String) {
        if (!ready || !Settings.state.value.voice || text.isBlank()) return
        audio.requestAudioFocus(focus)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav-${System.nanoTime()}")
    }

    fun stop() { if (ready) tts.stop() }

    fun reset() { done.clear() }

    /** Nach einem stillen Routentausch: bereits fällige Vorankündigungen nicht wiederholen */
    fun prime(p: NavProgress, speedMs: Double) {
        val stages = if (speedMs * 3.6 > 80) listOf(2000.0, 800.0) else listOf(500.0, 150.0)
        val base = p.stepIdx * 10
        stages.forEachIndexed { i, st -> if (p.distToStepM <= st) done.add(base + i) }
    }

    /** Ansagen abhängig vom Tempo: Autobahn 2 km / 800 m, Stadt 500 m / 150 m, dann „Jetzt“ */
    fun onProgress(r: Route, p: NavProgress, speedMs: Double) {
        val step = r.steps.getOrNull(p.stepIdx) ?: return
        val d = p.distToStepM
        val kmh = speedMs * 3.6
        val stages = if (kmh > 80) listOf(2000.0, 800.0) else listOf(500.0, 150.0)
        val nowDist = max(35.0, speedMs * 4)
        val base = p.stepIdx * 10

        if (d <= nowDist) {
            if (done.add(base + 9)) {
                done.add(base); done.add(base + 1)
                when (step.type) {
                    "arrive" -> { say("Sie haben Ihr Ziel erreicht"); return }
                    "charge" -> { say("Sie haben den Ladestopp erreicht. ${step.note}"); return }
                    "via" -> { say("Sie haben Ihr Zwischenziel erreicht"); return }
                }
                val next = r.steps.getOrNull(p.stepIdx + 1)
                val then = if (next != null && step.distanceM < 150) {
                    when (next.type) {
                        "arrive" -> ", dann erreichen Sie Ihr Ziel"
                        "charge" -> ", dann erreichen Sie den Ladestopp"
                        "via" -> ", dann erreichen Sie Ihr Zwischenziel"
                        else -> ", dann ${next.phrase}"
                    }
                } else {
                    ""
                }
                say("Jetzt ${step.phrase}${step.spokenTarget()}$then")
            }
            return
        }
        // Spurempfehlung (nur wenn es auch falsche Spuren gibt)
        val lanes = findLaneSection(r, p, p.alongM, speedMs)?.let { lanePhrase(it) }
        stages.forEachIndexed { i, s ->
            if (d <= s && d > nowDist + 60 && done.add(base + i)) {
                if (i == 0 && d < stages[1] + 200) done.add(base + 1)
                val text = when (step.type) {
                    "arrive" -> "In ${spoken(d)} erreichen Sie Ihr Ziel"
                    "charge" -> "In ${spoken(d)} erreichen Sie den Ladestopp ${step.road}"
                    "via" -> "In ${spoken(d)} erreichen Sie Ihr Zwischenziel"
                    else -> "In ${spoken(d)} ${step.phrase}${step.spokenTarget()}" +
                        if (lanes != null) { done.add(base + 5); ". Benutzen Sie $lanes" } else ""
                }
                say(text)
                return
            }
        }
        // Spuren werden erst später bekannt als die Vorankündigung: eigene kurze Ansage
        if (lanes != null && d > nowDist + 120 && done.add(base + 5)) {
            say("Benutzen Sie $lanes")
            return
        }
    }

    private fun spoken(m: Double): String = when {
        m >= 950 -> {
            val km = (m / 500).roundToInt() / 2.0
            if (abs(km - 1.0) < 0.01) "einem Kilometer"
            else if (km % 1.0 == 0.0) "${km.toInt()} Kilometern"
            else "${km.toString().replace('.', ',')} Kilometern"
        }
        m >= 100 -> "${(m / 50).roundToInt() * 50} Metern"
        else -> "${(m / 10).roundToInt() * 10} Metern"
    }
}

// ---------------- Navigationssitzung ----------------

private suspend fun <T> safe(block: suspend () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    Result.failure(e)
}

object NavSession {
    data class Offer(val route: Route, val savedS: Double)

    /** Warnung vor Stauende, Baustelle oder Sperrung */
    data class Warning(val kind: String, val title: String, val distM: Double, val delayS: Double, val inside: Boolean, val lengthM: Double)

    /** Ladesäulen-Suche (vor oder während der Fahrt) */
    data class ChargerSearch(
        val loading: Boolean = true,
        val hits: List<ChargerHit> = emptyList(),
        val error: String? = null,
        val replaceUuid: String? = null,
        val focus: LatLon? = null,       // ersetzter Stopp (Mittelpunkt der Suche)
        val focusName: String = "",
        val query: String = "",
    )

    data class State(
        val dest: Place? = null,
        val routes: List<Route> = emptyList(),
        val selected: Int = 0,
        val loading: Boolean = false,
        val error: String? = null,
        val note: String? = null,
        val navigating: Boolean = false,
        val progress: NavProgress? = null,
        val rerouting: Boolean = false,
        val arrived: Boolean = false,
        val availability: Map<String, Availability> = emptyMap(),
        val offer: Offer? = null,
        val fullPark: ChargeStop? = null,
        val vias: List<Via> = emptyList(),
        val chargerSearch: ChargerSearch? = null,
        val hitAvailability: Map<String, Availability> = emptyMap(),
        val warning: Warning? = null,
        val gpsLost: Boolean = false,
        val destChargers: List<ChargerHit> = emptyList(),
        val destParking: List<Place> = emptyList(),
        val destLoading: Boolean = false,
        val destLoadedFor: LatLon? = null,
        val coach: CoachTip? = null,
        val planNote: String? = null,
        val start: Place? = null,     // eigener Startpunkt (null = Mein Standort)
        val wishes: TripWishes = TripWishes(),
        val startSoc: Double? = null, // Akku beim Start für vorausgeplante Fahrten
        val tripMaxSpeed: Int? = null,
    ) {
        val route: Route? get() = routes.getOrNull(selected)
    }

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private lateinit var app: Context
    lateinit var voice: Voice
        private set

    private var planJob: Job? = null
    private var checkJob: Job? = null
    private var lastSeg = 0
    private var needFull = true
    private var offCount = 0
    private var lastReroute = 0L
    private val avoidedParks = mutableListOf<String>()
    private val announcedFull = mutableSetOf<String>()
    private var viasPassed = 0
    private val announcedJams = mutableSetOf<String>()
    private var primeVoice = false
    private var viaAlongs: List<Double> = emptyList()
    private var viaAlongsFor: Route? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        voice = Voice(app)
        scope.launch { LocationHub.fix.filterNotNull().collect { onFix(it) } }
        scope.launch { Obd.values.collect { checkPlanVsActual(); Obd.freshSoc()?.let { LastSoc.note(it) } } }
        scope.launch { LocationHub.fix.filterNotNull().collect { Reach.maybeRefresh() } }
        scope.launch {
            LocationHub.fix.filterNotNull().collect { f ->
                val st = _state.value
                val p = st.progress
                if (st.navigating && !st.arrived && p != null) EcoRecorder.sample(f, p, st.route)
            }
        }
    }

    // ----- Tempo-Coach -----

    private var coachJob: Job? = null
    private var coachMutedUntil = 0L

    private fun startCoach() {
        coachJob?.cancel()
        coachJob = scope.launch {
            delay(60_000)
            while (isActive) {
                runCatching { checkCoach() }
                delay(120_000)
            }
        }
    }

    private fun checkCoach() {
        val s = _state.value
        val set = Settings.state.value
        if (!set.coachEnabled || !s.navigating || s.rerouting || s.arrived || s.coach != null) return
        if (System.currentTimeMillis() < coachMutedUntil) return
        val f = LocationHub.fix.value ?: return
        if (f.speed * 3.6 < 80) return                       // nur auf schnellen Straßen
        val r = s.route ?: return
        val p = s.progress ?: return
        val soc = Obd.freshSoc() ?: r.socAt(p.alongM) ?: return
        val tip = TempoCoach.evaluate(r, p.alongM, soc, set.copy(maxSpeedKmh = s.tripMaxSpeed ?: set.maxSpeedKmh)) ?: return
        if (s.tripMaxSpeed != null && tip.capKmh >= s.tripMaxSpeed) return
        _state.update { it.copy(coach = tip) }
        if (set.coachVoice) voice.say(tip.spoken)
    }

    /** Tipp übernehmen: Route mit dieser Höchstgeschwindigkeit neu planen */
    fun acceptCoach() {
        val tip = _state.value.coach ?: return
        _state.update { it.copy(coach = null, tripMaxSpeed = tip.capKmh) }
        voice.say("Neue Planung mit höchstens ${tip.capKmh} Kilometern pro Stunde")
        rerouteNow()
    }

    fun dismissCoach() {
        coachMutedUntil = System.currentTimeMillis() + 20 * 60_000
        _state.update { it.copy(coach = null) }
    }

    // ----- Vorausberechnung: wo ist das Auto *jetzt* (zwischen zwei GPS-Messungen)? -----
    private val _liveAlong = MutableStateFlow<Double?>(null)
    val liveAlong: StateFlow<Double?> = _liveAlong.asStateFlow()
    private var lastAlong = 0.0
    private var lastSpeed = 0.0
    private var lastFixNs = 0L
    private var liveJob: Job? = null

    private fun startLive() {
        liveJob?.cancel()
        liveJob = scope.launch {
            var tick = 0
            while (isActive) {
                if (lastFixNs > 0L) {
                    val age = (SystemClock.elapsedRealtimeNanos() - lastFixNs) / 1e9
                    // Tunnel-Modus: ohne GPS bis zu 45 s mit dem letzten Tempo weiterfahren
                    val lost = age > 3.0 && lastSpeed > 3.0
                    val dt = age.coerceIn(0.0, if (lost) 45.0 else 3.0)
                    val along = lastAlong + lastSpeed * dt
                    _liveAlong.value = along
                    val st = _state.value
                    if (lost != st.gpsLost) _state.update { it.copy(gpsLost = lost) }
                    if (lost && tick % 5 == 0 && age <= 45.0) {
                        val r = st.route
                        val p = r?.let { NavEngine.progressAt(it, along) }
                        if (r != null && p != null) {
                            _state.update { it.copy(progress = p) }
                            voice.onProgress(r, p, lastSpeed)
                        }
                    }
                } else {
                    _liveAlong.value = null
                }
                tick++
                delay(200)
            }
        }
    }

    private fun stopLive() {
        liveJob?.cancel()
        lastFixNs = 0L
        _liveAlong.value = null
        _state.update { it.copy(gpsLost = false) }
    }

    private fun isDark(): Boolean = when (Settings.state.value.mapMode) {
        MapMode.DAY -> false
        MapMode.NIGHT -> true
        MapMode.AUTO -> (app.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
    }

    /** Offline-Karte für die gewählte Route jetzt speichern */
    fun saveOffline() {
        val s = _state.value
        val r = s.route ?: return
        OfflineMaps.download(app, r, s.dest?.title ?: "Route", isDark())
    }

    private var deviationSince = 0L
    private var lastSocReplan = 0L

    /** Weicht der echte Akkustand deutlich vom Plan ab, wird neu geplant (wie bei ABRP) */
    private fun checkPlanVsActual() {
        val s = _state.value
        if (!s.navigating || s.rerouting || s.arrived || !Settings.state.value.obdReplan) return
        val r = s.route ?: return
        val p = s.progress ?: return
        val actual = Obd.freshSoc() ?: return
        val planned = r.socAt(p.alongM) ?: return
        val now = System.currentTimeMillis()
        if (kotlin.math.abs(actual - planned) < 4.0) { deviationSince = 0L; return }
        if (deviationSince == 0L) { deviationSince = now; return }
        if (now - deviationSince < 60_000 || now - lastSocReplan < 180_000) return
        lastSocReplan = now
        deviationSince = 0L
        val f = LocationHub.fix.value ?: return
        voice.say(if (actual > planned) "Der Akku ist voller als geplant. Route wird angepasst." else "Der Akku leert sich schneller als geplant. Route wird angepasst.")
        reroute(f, manual = false)
    }

    /** Routen zum Ziel planen (mit TomTom inkl. Ladestopps und Verkehr) */
    fun plan(dest: Place, vias: List<Via> = emptyList(), keepAvoided: Boolean = false, start: Place? = null, startSoc: Double? = null) {
        val fix = LocationHub.fix.value
        planJob?.cancel()
        if (!keepAvoided) avoidedParks.clear()
        // eigener Start bleibt bei Änderungen erhalten (Stopps, Akku), bei einem neuen Ziel aus der Suche nicht
        val st = start ?: if (keepAvoided) _state.value.start else null
        val stSoc = startSoc ?: if (keepAvoided && st != null) _state.value.startSoc else null
        if (fix == null && st == null) {
            _state.value = State(dest = dest, vias = vias, error = "Standort noch nicht verfügbar – GPS aktiv?")
            return
        }
        val keepAvail = _state.value.availability
        val wishes = if (keepAvoided) _state.value.wishes else TripWishes()
        _state.value = State(dest = dest, vias = vias, loading = true, availability = keepAvail, start = st, startSoc = stSoc, wishes = wishes)
        if (wishes.active && Settings.state.value.hasTomTom) {
            planJob = scope.launch { planWithWishes(dest, vias.filterNot { it.fromWish }, st, stSoc, fix, wishes) }
            return
        }
        planJob = scope.launch {
            val res = safe {
                val fromPos = st?.pos ?: fix!!.pos
                val heading = if (st == null && fix != null && fix.speed > 3) fix.bearing else null
                val soc = when {
                    st != null -> stSoc ?: Settings.state.value.socStart
                    else -> Obd.freshSoc() ?: Settings.state.value.socStart
                }
                computeOptions(fromPos, heading, dest.pos, soc, alternatives = 2, withTollFree = vias.isEmpty(), noToll = false, vias = vias)
            }
            res.onSuccess { opts ->
                _state.update { it.copy(routes = opts, selected = 0, loading = false) }
                opts.firstOrNull()?.let { loadAvailability(it) }
                opts.firstOrNull()?.let { r -> runCatching { OfflineMaps.auto(app, r, dest.title, isDark()) } }
                loadDestInfo()
                compareBefore?.let { (n0, d0) ->
                    compareBefore = null
                    opts.firstOrNull()?.let { r ->
                        val dn = r.stops.size - n0
                        val parts = mutableListOf<String>()
                        if (dn > 0) parts += "$dn Ladestopp${if (dn > 1) "s" else ""} hinzugefügt"
                        if (dn < 0) parts += "${-dn} Ladestopp${if (dn < -1) "s" else ""} entfallen"
                        val diffMin = ((r.durationS - d0) / 60).roundToInt()
                        if (kotlin.math.abs(diffMin) >= 2) parts += "Ankunft ${fmtEta(r.durationS)} statt ${fmtEta(d0)}"
                        val note = if (parts.isEmpty()) "Geprüft: Planung passt, keine Änderung" else "Geprüft: " + parts.joinToString(" · ")
                        _state.update { it.copy(planNote = note) }
                    }
                }
            }.onFailure { e ->
                CrashLog.note("Routing fehlgeschlagen: ${e.message}")
                _state.update { it.copy(loading = false, error = "Keine Route gefunden: ${e.message}") }
            }
        }
    }

    /** Neu planen, z. B. nachdem der Akkustand geändert wurde */
    fun replan() { _state.value.dest?.let { plan(it, _state.value.vias, keepAvoided = true) } }

    /** Eigenen Startpunkt setzen (null = Mein Standort) und neu planen */
    fun setStart(p: Place?) {
        val s = _state.value
        val dest = s.dest ?: return
        if (p == null) {
            _state.update { it.copy(start = null, startSoc = null) }
            plan(dest, s.vias, keepAvoided = false)
        } else {
            plan(dest, s.vias, keepAvoided = true, start = p, startSoc = s.startSoc ?: Settings.state.value.socStart)
        }
    }

    /** Akku beim eigenen Start ändern */
    fun setStartSoc(v: Double) {
        val s = _state.value
        val dest = s.dest ?: return
        plan(dest, s.vias, keepAvoided = true, start = s.start, startSoc = v.coerceIn(5.0, 100.0))
    }

    /** Gespeicherte Route aufrufen: mit aktuellen Daten neu berechnen */
    fun openSaved(r: SavedRoute) = plan(r.dest, r.vias, keepAvoided = false, start = r.start, startSoc = r.startSoc)

    // ----- Zwischenstopps -----

    fun addVia(p: Place) {
        val s = _state.value
        if (s.navigating) { insertViaDuringNav(Via(p)); return }
        val dest = s.dest ?: return
        // an der passenden Stelle der Strecke einsortieren, nicht hinten anhängen
        plan(dest, insertSorted(s.route, s.vias, Via(p)), keepAvoided = true)
    }

    fun removeVia(i: Int) {
        val s = _state.value
        val dest = s.dest ?: return
        if (i !in s.vias.indices) return
        plan(dest, s.vias.filterIndexed { k, _ -> k != i }, keepAvoided = true)
    }

    /** Vom KI-Assistenten: Ziel, Stopps, Start und Wünsche auf einmal setzen und planen */
    fun planFromAssistant(dest: Place, vias: List<Via>, start: Place?, w: TripWishes) {
        _state.update { it.copy(wishes = w, start = start, startSoc = if (start != null) it.startSoc ?: Settings.state.value.socStart else null) }
        plan(dest, vias, keepAvoided = true, start = start)
    }

    /** Wünsche setzen und neu planen */
    fun setWishes(w: TripWishes) {
        val s = _state.value
        val dest = s.dest ?: return
        _state.update { it.copy(wishes = w) }
        plan(dest, s.vias.filterNot { it.fromWish }, keepAvoided = true)
    }

    /** Planen mit Wünschen: Grundroute, Pause einfügen, nur gewünschte Anbieter als Ladestopps, dann genau rechnen */
    private suspend fun planWithWishes(dest: Place, userVias: List<Via>, st: Place?, stSoc: Double?, fix: Fix?, w: TripWishes) {
        val set = Settings.state.value
        val key = set.tomtomKey.trim()
        val fromPos = st?.pos ?: fix?.pos ?: return
        val heading = if (st == null && fix != null && fix.speed > 3) fix.bearing else null
        val soc = if (st != null) stSoc ?: set.socStart else Obd.freshSoc() ?: set.socStart
        val notes = mutableListOf<String>()
        val res = safe {
            // 1. Grundroute (ohne eigene Ladestopps), dient als Gerüst für Zeit und Lage
            val base = computeOptions(fromPos, heading, dest.pos, soc, alternatives = 0, withTollFree = false, noToll = false, vias = userVias.filterNot { it.isCharger }).first()
            var vias = userVias
            // 2. Pause zur Uhrzeit
            if (w.breakAtMin != null && w.breakQuery.isNotBlank()) {
                val now = java.time.LocalTime.now()
                var dt = (w.breakAtMin - (now.hour * 60 + now.minute)) * 60.0
                if (dt < 0) dt += 24 * 3600.0
                val at = WishPlanner.alongAt(base, dt)
                if (at == null) {
                    notes += "Um ${"%02d:%02d".format(w.breakAtMin / 60, w.breakAtMin % 60)} bist du schon am Ziel – keine Pause eingeplant."
                } else {
                    val near = RouteBarData.slice(base, at, at + 1).first()
                    val hits = TomTom.poiSearch(key, w.breakQuery, near, 25_000)
                    val best = hits.map { it to TomTom.locateOnRoute(base, it.pos) }
                        .filter { it.second.second < 8_000 }
                        .minByOrNull { (_, lo) -> kotlin.math.abs(lo.first - at) / 1000 + lo.second / 250 }
                    if (best == null) {
                        notes += "Kein „${w.breakQuery}“ nahe der Strecke um diese Zeit gefunden."
                    } else {
                        vias = insertSorted(base, vias, Via(best.first, pauseMin = w.breakMin, fromWish = true))
                        notes += "Pause gegen ${"%02d:%02d".format(w.breakAtMin / 60, w.breakAtMin % 60)} bei ${best.first.title}"
                    }
                }
            }
            // 3. Nur gewünschte Anbieter als Ladestopps
            if (w.onlyOperators.isNotEmpty()) {
                val cands = TomTom.corridorBrands(key, base, w.onlyOperators, set.corridorKm.coerceAtLeast(10), set.searchMinKw)
                    .filter { operatorMatches(it, w.onlyOperators) }
                val (chosen, problem) = WishPlanner.pickChargers(base, cands, soc, set)
                chosen.forEach { h ->
                    vias = insertSorted(base, vias, Via(Place(h.name, h.pos), 0, h.availId, true, h.powerKw, fromWish = true))
                }
                notes += "Nur ${w.onlyOperators.joinToString(", ")}: ${chosen.size} Ladestopp${if (chosen.size == 1) "" else "s"}"
                problem?.let { notes += it }
            }
            // 4. Genau rechnen (eigene Ladestopps → Routen-Teilung); gemiedene Anbieter ggf. ersetzen
            var r = computeOptions(fromPos, heading, dest.pos, soc, alternatives = 0, withTollFree = false, noToll = false, vias = vias).first()
            if (w.avoidOperators.isNotEmpty()) {
                repeat(2) {
                    val bad = r.stops.filter { s -> operatorMatchesName("", s.name, w.avoidOperators) && s.uuid != null }
                    if (bad.isEmpty()) return@repeat
                    bad.forEach { avoidedParks += it.uuid!! }
                    r = computeOptions(fromPos, heading, dest.pos, soc, alternatives = 0, withTollFree = false, noToll = false, vias = vias).first()
                }
                notes += "Ohne ${w.avoidOperators.joinToString(", ")}"
            }
            if (w.onlyOperators.isNotEmpty()) {
                val cands2 = TomTom.corridorBrands(key, base, w.onlyOperators, set.corridorKm.coerceAtLeast(10), set.searchMinKw)
                    .filter { operatorMatches(it, w.onlyOperators) }
                repeat(3) {
                    val foreign = r.stops.filter { st2 -> vias.none { v -> v.isCharger && haversine(v.place.pos, st2.pos) < 300 } }
                    if (foreign.isEmpty()) return@repeat
                    var changed = false
                    foreign.forEach { f ->
                        // passenden Lader etwas VOR dem fremden Stopp nehmen (bis 60 km früher, höchstens 10 km danach)
                        val (fAlong, _) = TomTom.locateOnRoute(base, f.pos)
                        val alt = cands2.filter { c -> c.alongM in (fAlong - 60_000)..(fAlong + 10_000) && vias.none { v -> haversine(v.place.pos, c.pos) < 300 } }
                            .maxByOrNull { it.alongM }
                        if (alt != null) {
                            vias = insertSorted(base, vias, Via(Place(alt.name, alt.pos), 0, alt.availId, true, alt.powerKw, fromWish = true))
                            changed = true
                        }
                    }
                    if (!changed) return@repeat
                    r = computeOptions(fromPos, heading, dest.pos, soc, alternatives = 0, withTollFree = false, noToll = false, vias = vias).first()
                }
                val extra = r.stops.count { st2 -> vias.none { v -> v.isCharger && haversine(v.place.pos, st2.pos) < 300 } }
                val own = r.stops.size - extra
                notes.removeAll { it.startsWith("Nur ") }
                notes += "Nur ${w.onlyOperators.joinToString(", ")}: $own Ladestopp${if (own == 1) "" else "s"}" +
                    if (extra > 0) ", dazu $extra bei anderem Anbieter (kein passender Lader in Reichweite)" else ""
            }
            r to vias
        }
        res.onSuccess { (r, vias) ->
            _state.update { it.copy(routes = listOf(r.copy(tag = "Mit Wünschen")), selected = 0, loading = false, vias = vias, planNote = notes.joinToString(" · ")) }
            loadAvailability(r)
            loadDestInfo()
        }.onFailure { e ->
            CrashLog.note("Planung mit Wünschen fehlgeschlagen: ${e.message}")
            _state.update { it.copy(loading = false, error = "Planung mit Wünschen fehlgeschlagen: ${e.message}") }
        }
    }

    /** Neue Reihenfolge aus der Stopp-Liste: erster Eintrag = Start, letzter = Ziel, dazwischen Zwischenstopps */
    fun reorder(start: Place?, vias: List<Via>, dest: Place) {
        if (start == null) _state.update { it.copy(start = null, startSoc = null) }
        val soc = if (start != null) _state.value.startSoc ?: Settings.state.value.socStart else null
        plan(dest, vias, keepAvoided = true, start = start, startSoc = soc)
    }

    /** Nächster noch nicht erreichter Zwischenstopp (während der Navigation) */
    fun nextVia(): Via? = _state.value.vias.getOrNull(viasPassed)

    /** Nächsten Zwischenstopp überspringen, Navigation läuft weiter */
    fun skipNextVia() {
        val s = _state.value
        if (viasPassed !in s.vias.indices) return
        val list = s.vias.toMutableList().apply { removeAt(viasPassed) }
        _state.update { it.copy(vias = list) }
        voice.say("Zwischenstopp übersprungen")
        rerouteNow()
    }

    /** Planung mit aktuellen Daten prüfen und danach kurz zeigen, was sich geändert hat */
    private var compareBefore: Pair<Int, Double>? = null

    fun recheck() {
        val s = _state.value
        val dest = s.dest ?: return
        compareBefore = s.route?.let { it.stops.size to it.durationS }
        plan(dest, s.vias, keepAvoided = true)
    }

    fun cyclePause(i: Int) {
        val s = _state.value
        val dest = s.dest ?: return
        val v = s.vias.getOrNull(i) ?: return
        val next = when (v.pauseMin) { 0 -> 15; 15 -> 30; 30 -> 45; 45 -> 60; else -> 0 }
        plan(dest, s.vias.mapIndexed { k, x -> if (k == i) x.copy(pauseMin = next) else x }, keepAvoided = true)
    }

    /** Position eines Ortes entlang der Route (Meter ab Start) */
    private fun alongOf(r: Route, p: LatLon): Double {
        var best = 0
        var bd = Double.MAX_VALUE
        r.points.forEachIndexed { i, q -> val d = haversine(p, q); if (d < bd) { bd = d; best = i } }
        return r.cumM.getOrElse(best) { 0.0 }
    }

    private fun insertSorted(r: Route?, list: List<Via>, v: Via): List<Via> {
        if (r == null) return list + v
        val a = alongOf(r, v.place.pos)
        val idx = list.indexOfFirst { alongOf(r, it.place.pos) > a }
        return if (idx < 0) list + v else list.toMutableList().apply { add(idx, v) }
    }

    private fun insertViaDuringNav(v: Via) {
        val s = _state.value
        val remaining = s.vias.drop(viasPassed)
        val list = insertSorted(s.route, remaining, v)
        viasPassed = 0
        _state.update { it.copy(vias = list) }
        rerouteNow()
    }

    // ----- Ladesäulen-Suche -----

    /** Ladesäulen entlang der Route suchen (vor der Fahrt: ganze Route, während der Fahrt: nächste 250 km) */
    fun openChargerSearch(replaceUuid: String? = null) {
        val s = _state.value
        val set = Settings.state.value
        val r = s.route ?: return
        if (!set.hasTomTom) {
            _state.update { it.copy(chargerSearch = ChargerSearch(loading = false, error = "Dafür wird der TomTom-Key benötigt (Einstellungen).")) }
            return
        }
        // Wird ein bestimmter Stopp ersetzt, nur um diesen herum suchen
        val stop = replaceUuid?.let { id -> r.stops.firstOrNull { it.uuid == id } }
        _state.update { it.copy(chargerSearch = ChargerSearch(replaceUuid = replaceUuid, focus = stop?.pos, focusName = stop?.name ?: "")) }
        val here = if (s.navigating) s.progress?.alongM ?: 0.0 else 0.0
        val startAlong = if (stop != null) maxOf(here, stop.alongM - 50_000) else here
        val endAlong = when {
            stop != null -> stop.alongM + 50_000
            s.navigating -> here + 250_000
            else -> Double.MAX_VALUE
        }
        scope.launch {
            val res = safe { TomTom.corridor(set.tomtomKey.trim(), r, startAlong, endAlong, set.corridorKm, set.searchMinKw) }
            res.onSuccess { hits ->
                var list = hits.filter { it.alongM >= here - 500 }
                if (stop != null) list = list.filter { it.availId != stop.uuid }.sortedBy { kotlin.math.abs(it.alongM - stop.alongM) }
                    .map { it.copy(stopAlongRef = stop.alongM) }
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, hits = list)) } ?: st }
                loadHitAvailability(list)
            }.onFailure { e ->
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, error = e.message)) } ?: st }
            }
        }
    }

    /** Eigene Suche im Ersatz-Fenster, z. B. „IONITY Lüneburg“ */
    fun searchChargerText(q: String) {
        val cs = _state.value.chargerSearch ?: return
        val r = _state.value.route ?: return
        val set = Settings.state.value
        if (q.trim().length < 3) { openChargerSearch(cs.replaceUuid); return }
        _state.update { it.copy(chargerSearch = cs.copy(loading = true, query = q, error = null)) }
        val near = cs.focus ?: LocationHub.fix.value?.pos
        scope.launch {
            val res = safe { TomTom.searchChargers(set.tomtomKey.trim(), q, near) }
            res.onSuccess { hits ->
                val list = hits.map { h ->
                    val (along, off) = TomTom.locateOnRoute(r, h.pos)
                    h.copy(alongM = along, offsetM = off)
                }
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, hits = list)) } ?: st }
                loadHitAvailability(list)
            }.onFailure { e ->
                _state.update { st -> st.chargerSearch?.let { st.copy(chargerSearch = it.copy(loading = false, error = e.message)) } ?: st }
            }
        }
    }

    /** Ladestationen und Parkplätze rund ums Ziel laden (einmal je Ziel) */
    fun loadDestInfo() {
        val s = _state.value
        val d = s.dest ?: return
        val set = Settings.state.value
        if (!set.hasTomTom || s.destLoading || s.destLoadedFor == d.pos) return
        _state.update { it.copy(destLoading = true, destLoadedFor = d.pos) }
        scope.launch {
            val key = set.tomtomKey.trim()
            val ch = async { safe { TomTom.nearby(key, d.pos, 1500, 0, false) }.getOrDefault(emptyList()) }
            val pk = async { safe { TomTom.nearbyParking(key, d.pos, 1000) }.getOrDefault(emptyList()) }
            val chargers = ch.await().sortedBy { haversine(it.pos, d.pos) }.take(6)
            val parking = pk.await().sortedBy { haversine(it.pos, d.pos) }.take(6)
            _state.update { st -> if (st.dest?.pos == d.pos) st.copy(destChargers = chargers, destParking = parking, destLoading = false) else st }
            loadHitAvailability(chargers)
        }
    }

    /** Neues Ziel während der Fahrt (z. B. Parkplatz oder Ladestation am Ziel), Navigation läuft weiter */
    fun setDestination(p: Place) {
        val s = _state.value
        if (!s.navigating) { plan(p, s.vias); return }
        _state.update { it.copy(dest = p, destChargers = emptyList(), destParking = emptyList(), destLoadedFor = null) }
        voice.say("Neues Ziel: ${p.title}")
        rerouteNow()
    }

    fun closeChargerSearch() { _state.update { it.copy(chargerSearch = null) } }

    /** Gewählte Ladestation als festen Ladestopp in die Route nehmen */
    fun pickCharger(h: ChargerHit) {
        val s = _state.value
        val replace = s.chargerSearch?.replaceUuid
        if (replace != null) avoidedParks += replace
        val v = Via(Place(h.name, h.pos), chargeParkId = h.availId, isCharger = true, powerKw = h.powerKw)
        _state.update { it.copy(chargerSearch = null) }
        if (s.navigating) {
            insertViaDuringNav(v)
        } else {
            val dest = s.dest ?: return
            plan(dest, insertSorted(s.route, s.vias, v), keepAvoided = true)
        }
    }

    private fun loadHitAvailability(hits: List<ChargerHit>) {
        val key = Settings.state.value.tomtomKey.trim()
        val ids = hits.mapNotNull { it.availId }.filter { it !in _state.value.hitAvailability }.take(8)
        if (key.isBlank() || ids.isEmpty()) return
        scope.launch {
            val found = ids.map { id -> async { id to safe { TomTom.availability(key, id) }.getOrNull() } }
                .mapNotNull { d -> d.await().let { (id, a) -> if (a != null) id to a else null } }
            if (found.isNotEmpty()) _state.update { it.copy(hitAvailability = it.hitAvailability + found) }
        }
    }

    fun select(i: Int) {
        _state.update { if (i in it.routes.indices) it.copy(selected = i) else it }
        _state.value.route?.let { loadAvailability(it) }
    }

    fun clear() {
        stopLive()
        planJob?.cancel()
        checkJob?.cancel()
        _state.value = State()
    }

    fun start(ctx: Context) {
        val s = _state.value
        val r = s.route ?: return
        lastSeg = 0; needFull = true; offCount = 0; viasPassed = 0
        announcedFull.clear()
        voice.reset()
        _state.value = s.copy(routes = listOf(r), selected = 0, navigating = true, arrived = false, offer = null, fullPark = null)
        runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, NavigationService::class.java)) }
        val first = r.steps.getOrNull(1)
        val stopsText = when (r.stops.size) {
            0 -> ""
            1 -> " Ein Ladestopp ist eingeplant."
            else -> " ${r.stops.size} Ladestopps sind eingeplant."
        }
        voice.say("Route gestartet.$stopsText " + if (first != null) "${first.phrase.cap()}${first.spokenTarget()}" else "")
        _state.value.route?.let { r0 -> EcoRecorder.start(r0, _state.value.dest?.title ?: "Ziel", _state.value.progress?.alongM ?: 0.0) }
        // vorausgeplanter Start: beim Losfahren gilt der echte Standort (weicht er ab, wird automatisch neu berechnet)
        if (_state.value.start != null) _state.update { it.copy(start = null, startSoc = null) }
        LocationHub.fix.value?.let { onFix(it) }
        startChecks()
        startLive()
        coachMutedUntil = 0L
        startCoach()
        runCatching { OfflineMaps.auto(app, r, s.dest?.title ?: "Route", isDark()) }
    }

    fun stop(ctx: Context) {
        EcoRecorder.finish(arrived = false)
        Simulator.stop()
        coachJob?.cancel()
        stopLive()
        voice.stop()
        checkJob?.cancel()
        ctx.stopService(Intent(ctx, NavigationService::class.java))
        planJob?.cancel()
        _state.value = State()
    }

    fun rerouteNow() { LocationHub.fix.value?.let { reroute(it, manual = true) } }

    fun acceptOffer() {
        val o = _state.value.offer ?: return
        lastSeg = 0; needFull = true; offCount = 0
        voice.reset()
        lastFixNs = 0L
        _state.update { it.copy(routes = listOf(o.route), selected = 0, offer = null, vias = it.vias.drop(viasPassed), progress = null) }
        viasPassed = 0
        LocationHub.fix.value?.let { onFix(it) }
        loadAvailability(o.route)
        voice.say("Neue Route übernommen")
    }

    fun dismissOffer() { _state.update { it.copy(offer = null) } }

    /** Belegten Ladepark meiden und neu planen */
    fun avoidFullPark() {
        val p = _state.value.fullPark ?: return
        p.uuid?.let { avoidedParks += it }
        _state.update { it.copy(fullPark = null) }
        rerouteNow()
    }

    fun dismissFullPark() { _state.update { it.copy(fullPark = null) } }

    private fun currentSoc(): Double {
        Obd.freshSoc()?.let { return it }
        val s = _state.value
        val r = s.route
        val p = s.progress
        return if (r != null && p != null) r.socAt(p.alongM) ?: Settings.state.value.socStart else Settings.state.value.socStart
    }

    private fun onFix(f: Fix) {
        val s = _state.value
        if (!s.navigating || s.arrived) return
        val r = s.route ?: return
        val p = NavEngine.update(r, f.pos, lastSeg, needFull)
        lastSeg = p.segIdx
        val off = p.offRouteM > max(50.0, f.accuracy * 1.5)
        needFull = off
        offCount = if (off && f.accuracy < 60) offCount + 1 else 0
        _state.update { it.copy(progress = p) }
        if (viaAlongsFor !== r) {
            viaAlongs = s.vias.map { alongOf(r, it.place.pos) }
            viaAlongsFor = r
        }
        viasPassed = viaAlongs.count { it < p.alongM - 30 }

        // Alter der GPS-Messung (meist einige Zehntelsekunden) ausgleichen
        val age = if (f.elapsedNs > 0) ((SystemClock.elapsedRealtimeNanos() - f.elapsedNs) / 1e9).coerceIn(0.0, 2.0) else 0.0
        if (!off) {
            lastAlong = p.alongM
            lastSpeed = f.speed
            lastFixNs = if (f.elapsedNs > 0) f.elapsedNs else SystemClock.elapsedRealtimeNanos()
        }
        val pv = p.copy(distToStepM = max(0.0, p.distToStepM - f.speed * age))
        if (primeVoice && !off) { voice.prime(pv, f.speed); primeVoice = false }
        if (!off) updateWarning(r, p.alongM + f.speed * age, f.speed)
        if (p.remainingM < 5000 && s.destLoadedFor != s.dest?.pos) loadDestInfo()
        if (offCount >= 3 && !s.rerouting && System.currentTimeMillis() - lastReroute > 8000) {
            reroute(f, manual = false)
        } else if (!off) {
            voice.onProgress(r, pv, f.speed)
        }
        // Ankunft: knapp vor dem Ende der Route, nahe am Ziel (auch neben der Straße) oder kurz am Ziel stehen geblieben
        val destPos = s.dest?.pos
        val direct = destPos?.let { haversine(f.pos, it) } ?: Double.MAX_VALUE
        if (f.speed < 2.0 && direct < 150) { if (stoppedNearDestSince == 0L) stoppedNearDestSince = System.currentTimeMillis() } else stoppedNearDestSince = 0L
        val stoppedLongEnough = stoppedNearDestSince > 0 && System.currentTimeMillis() - stoppedNearDestSince > 10_000
        if ((!off && p.remainingM < 40) || direct < 60 || stoppedLongEnough) arrive()
    }

    private var stoppedNearDestSince = 0L

    /** Ziel erreicht: Navigation im Hintergrund beenden, Benachrichtigung sofort entfernen */
    private fun arrive() {
        if (_state.value.arrived) return
        checkJob?.cancel()
        coachJob?.cancel()
        stopLive()
        stoppedNearDestSince = 0L
        _state.update { it.copy(arrived = true) }
        EcoRecorder.finish(arrived = true)
        app.stopService(Intent(app, NavigationService::class.java))
        app.getSystemService(NotificationManager::class.java)?.cancel(NavigationService.ID)
    }

    /** Stauende, Baustelle oder Sperrung auf den nächsten Kilometern? */
    private fun updateWarning(r: Route, along: Double, speedMs: Double) {
        val kmh = speedMs * 3.6
        var best: Warning? = null
        var bestKey = ""
        for (j in r.jams) {
            if (j.magnitude <= 0 && j.category != "ROAD_CLOSURE" && j.category != "ROAD_WORK") continue
            if (j.startIdx !in r.cumM.indices) continue
            val a = r.cumM[j.startIdx]
            val b = if (j.endIdx in r.cumM.indices) r.cumM[j.endIdx] else a
            if (b < along) continue
            val dist = a - along
            if (dist > 3000) continue
            val inside = dist <= 0
            val title = when {
                j.category == "ROAD_CLOSURE" -> "Sperrung"
                j.category == "ROAD_WORK" -> "Baustelle"
                inside -> "Stau"
                else -> "Stauende"
            }
            if (best == null || dist < best.distM) {
                best = Warning(j.category, title, max(0.0, dist), j.delayS, inside, b - max(a, along))
                val pt = r.points.getOrElse(j.startIdx) { r.points.first() }
                bestKey = String.format(Locale.US, "%.3f,%.3f", pt.lat, pt.lon)
            }
        }
        _state.update { it.copy(warning = best) }
        val w = best ?: return
        if (w.inside) return
        val first = if (kmh > 80) 1500.0 else 700.0
        if (w.distM <= first && announcedJams.add("$bestKey/1")) {
            val km = (w.distM / 500).roundToInt() / 2.0
            val d = when {
                w.distM < 950 -> "${(w.distM / 50).roundToInt() * 50} Metern"
                abs(km - 1.0) < 0.01 -> "einem Kilometer"
                km % 1.0 == 0.0 -> "${km.toInt()} Kilometern"
                else -> "${km.toString().replace('.', ',')} Kilometern"
            }
            val extra = if (w.delayS > 120) ", etwa ${(w.delayS / 60).roundToInt()} Minuten Verzögerung" else ""
            voice.say("Achtung, ${w.title} in $d$extra")
        } else if (w.distM <= 400 && kmh > 60 && announcedJams.add("$bestKey/2")) {
            voice.say("Achtung, ${w.title} voraus")
        }
    }

    private fun reroute(f: Fix, manual: Boolean) {
        val s = _state.value
        val dest = s.dest ?: return
        val vias = s.vias.drop(viasPassed)
        val noToll = s.route?.tag == "Mautfrei"
        val soc = currentSoc()
        lastReroute = System.currentTimeMillis()
        _state.update { it.copy(rerouting = true, offer = null) }
        voice.say("Route wird neu berechnet")
        scope.launch {
            val res = safe {
                computeOptions(f.pos, if (f.speed > 3) f.bearing else null, dest.pos, soc,
                    alternatives = 0, withTollFree = false, noToll = noToll, vias = vias).first()
            }
            res.onSuccess { r ->
                lastSeg = 0; needFull = true; offCount = 0; viasPassed = 0
                lastFixNs = 0L
                voice.reset()
                _state.update { it.copy(routes = listOf(r.copy(tag = "Neu berechnet")), selected = 0, rerouting = false, vias = vias, progress = null) }
                LocationHub.fix.value?.let { onFix(it) }
                loadAvailability(r)
            }.onFailure {
                _state.update { it.copy(rerouting = false) }
                if (manual) voice.say("Neuberechnung fehlgeschlagen")
            }
        }
    }

    /** Alle 5 Minuten: schnellere Route? Nächster Ladepark belegt? */
    private fun startChecks() {
        checkJob?.cancel()
        checkJob = scope.launch {
            while (isActive) {
                delay(5 * 60_000L)
                checkAvailabilityAhead()
                checkBetterRoute()
            }
        }
    }

    private suspend fun checkBetterRoute() {
        val s = _state.value
        val set = Settings.state.value
        if (!set.hasTomTom || !s.navigating || s.rerouting || s.offer != null || s.arrived) return
        val f = LocationHub.fix.value ?: return
        val p = s.progress ?: return
        val dest = s.dest ?: return
        if (p.offRouteM > 50 || p.remainingM < 5_000) return
        val cand = safe {
            computeOptions(f.pos, if (f.speed > 3) f.bearing else null, dest.pos, currentSoc(),
                alternatives = 0, withTollFree = false, noToll = s.route?.tag == "Mautfrei", vias = s.vias.drop(viasPassed)).first()
        }.getOrNull() ?: return
        if (cand.source != "TomTom" || !cand.feasible) return
        val saved = p.remainingS - cand.durationS
        if (saved > max(300.0, 0.05 * p.remainingS)) {
            _state.update { it.copy(offer = Offer(cand.copy(tag = "Schneller"), saved)) }
            voice.say("Schnellere Route gefunden, etwa ${(saved / 60).roundToInt()} Minuten schneller.")
        } else if (abs(cand.distanceM - p.remainingM) / max(1.0, p.remainingM) < 0.02) {
            // Gleiche Strecke, aber frische Verkehrs-, Stau- und Spurdaten: still übernehmen
            lastSeg = 0; needFull = true; lastFixNs = 0L; primeVoice = true
            _state.update { it.copy(routes = listOf(cand.copy(tag = s.route?.tag ?: cand.tag)), selected = 0, vias = it.vias.drop(viasPassed), progress = null) }
            viasPassed = 0
            LocationHub.fix.value?.let { onFix(it) }
        }
    }

    private suspend fun checkAvailabilityAhead() {
        val s = _state.value
        val key = Settings.state.value.tomtomKey
        if (key.isBlank()) return
        val r = s.route ?: return
        val p = s.progress ?: return
        val next = r.stops.firstOrNull { it.alongM > p.alongM } ?: return
        val uuid = next.uuid ?: return
        if (next.alongM - p.alongM > 60_000) return
        val a = safe { TomTom.availability(key, uuid) }.getOrNull() ?: return
        _state.update { it.copy(availability = it.availability + (uuid to a)) }
        if (a.known && a.total > 0 && a.available == 0 && announcedFull.add(uuid)) {
            _state.update { it.copy(fullPark = next) }
            voice.say("Der nächste Ladepark ist gerade voll belegt.")
        }
    }

    /** Belegung der ersten Ladestopps einer Route laden */
    private fun loadAvailability(r: Route) {
        val key = Settings.state.value.tomtomKey
        if (key.isBlank()) return
        val ids = r.stops.mapNotNull { it.uuid }.filter { it !in _state.value.availability }.take(5)
        if (ids.isEmpty()) return
        scope.launch {
            val found = ids.map { id -> async { id to safe { TomTom.availability(key, id) }.getOrNull() } }
                .mapNotNull { d -> d.await().let { (id, a) -> if (a != null) id to a else null } }
            if (found.isNotEmpty()) _state.update { it.copy(availability = it.availability + found) }
        }
    }

    /** Routenoptionen: TomTom (Verkehr + Ladestopps), sonst OSRM mit einfacher Akku-Schätzung */
    private suspend fun computeOptions(
        from: LatLon,
        heading: Float?,
        to: LatLon,
        socPct: Double,
        alternatives: Int,
        withTollFree: Boolean,
        noToll: Boolean,
        vias: List<Via> = emptyList(),
    ): List<Route> = coroutineScope {
        val trip = _state.value.tripMaxSpeed
        val set = Settings.state.value.let { if (trip != null) it.copy(maxSpeedKmh = trip) else it }
        val weather = safe { Weather.along(from, to) }.getOrNull()
        // Eigene Ladestopps: Route an jeder dieser Stationen teilen und das Laden selbst rechnen
        if (set.hasTomTom && vias.any { it.isCharger }) {
            val avoid = TomTom.avoids(set, noToll)
            val res = safe { UserCharging.plan(set, from, heading, to, socPct, vias, avoid, avoidedParks.toList(), weather) }
            res.getOrNull()?.let { return@coroutineScope listOf(it.copy(tag = if (noToll) "Mautfrei" else "Empfohlen")) }
            CrashLog.note("Planung mit eigenem Ladestopp fehlgeschlagen: ${res.exceptionOrNull()?.message}")
        }
        if (set.hasTomTom) {
            val avoid = TomTom.avoids(set, noToll)
            val main: Deferred<Result<List<Route>>> = async {
                safe { TomTom.ldev(set, from, heading, to, socPct, weather, avoid, alternatives, avoidedParks.toList(), vias) }
            }
            val tollFree: Deferred<Result<List<Route>>>? = if (withTollFree && "tollRoads" !in avoid) {
                async { safe { TomTom.ldev(set, from, heading, to, socPct, weather, avoid + "tollRoads", 0, avoidedParks.toList(), vias) } }
            } else {
                null
            }
            val mainRes = main.await()
            val mainList = mainRes.getOrNull()
            if (mainList != null) {
                val out = mutableListOf<Route>()
                mainList.forEachIndexed { i, r -> out += r.copy(tag = if (noToll) "Mautfrei" else if (i == 0) "Empfohlen" else "Alternative") }
                tollFree?.await()?.getOrNull()?.firstOrNull()?.let { t ->
                    if (out.none { similar(it, t) }) out += t.copy(tag = "Mautfrei")
                }
                return@coroutineScope out.take(3)
            }
            _state.update {
                it.copy(note = "TomTom nicht verfügbar (${mainRes.exceptionOrNull()?.message}). Route ohne Verkehr und ohne Ladeplanung.")
            }
        } else {
            _state.update { it.copy(note = "Für Verkehr und automatische Ladestopps den TomTom-Key in den Einstellungen eintragen.") }
        }
        osrmOptions(from, heading, to, alternatives, vias.map { it.place.pos }).map { EvModel.estimateSimple(it, set, socPct, weather) }
    }

    private suspend fun osrmOptions(from: LatLon, bearing: Float?, to: LatLon, alts: Int, vias: List<LatLon>): List<Route> {
        val ex = Settings.osrmExcludes()
        val list = try {
            Routing.routes(from, bearing, to, ex, alts, vias)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (ex.isEmpty()) throw e
            Routing.routes(from, bearing, to, emptyList(), alts, vias)
        }
        return list.mapIndexed { i, r -> r.copy(tag = if (i == 0) "Empfohlen" else "Alternative") }.take(3)
    }

    private fun similar(a: Route, b: Route) =
        abs(a.distanceM - b.distanceM) / max(1.0, a.distanceM) < 0.01 &&
            abs(a.durationS - b.durationS) / max(1.0, a.durationS) < 0.01
}

// ---------------- Vordergrund-Dienst (Navigation im Hintergrund) ----------------

class NavigationService : Service() {
    private val scope = MainScope()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Navigation", NotificationManager.IMPORTANCE_LOW))
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, ID, build("Navigation läuft", ""), type)
        LocationHub.acquire(this, "nav")
        Obd.acquire("nav")
        scope.launch {
            NavSession.state
                .map { s ->
                    val r = s.route
                    val p = s.progress
                    if (r == null || p == null) {
                        "Navigation läuft" to ""
                    } else {
                        val step = r.steps.getOrNull(p.stepIdx)
                        "${fmtDistShort(p.distToStepM)} · ${step?.bannerText() ?: ""}" to
                            "Ankunft ${fmtEta(p.remainingS)} · ${fmtKm(p.remainingM)}"
                    }
                }
                .distinctUntilChanged()
                .collect { (title, text) -> nm.notify(ID, build(title, text)) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        scope.cancel()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java)?.cancel(ID)
        LocationHub.release("nav")
        Obd.release("nav")
        super.onDestroy()
    }

    private fun build(title: String, text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(R.drawable.ic_nav)
        .setContentTitle(title)
        .setContentText(text)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        )
        .build()

    companion object {
        private const val CHANNEL = "nav"
        const val ID = 42
    }
}
