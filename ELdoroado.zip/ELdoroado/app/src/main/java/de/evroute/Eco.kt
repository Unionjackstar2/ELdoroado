package de.evroute

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** Auswertung einer navigierten Fahrt */
data class TripSummary(
    val start: Long,
    val end: Long,
    val dest: String,
    val km: Double,
    val durationS: Double,
    val avgKmh: Double,
    val kwhUsed: Double?,          // gemessen (OBD)
    val expectedKwh: Double,       // laut Modell bei deinen Tempi und Temperaturen
    val socPlanEnd: Double?,
    val socActualEnd: Double?,
    val stopDiffs: List<Pair<String, Double>>, // Ladestopp: Ist − Plan (Prozentpunkte)
    val speedingShare: Double?,    // Anteil der Zeit über Limit + 5
    val speedingCity: Double?,
    val speedingRural: Double?,
    val speedingMotorway: Double?,
    val accelEvents: Int,
    val brakeEvents: Int,
    val regenShare: Double?,
    val score: Int,
    val tips: List<String>,
) {
    val per100: Double? get() = kwhUsed?.takeIf { km > 1 }?.let { it / km * 100 }
}

/**
 * Sammelt während einer Navigation alle Sekunde Tempo, Limit, Energie und Strom
 * und berechnet am Ende das Resümee mit Eco-Score.
 */
object EcoRecorder {
    private data class Sample(
        val tMs: Long, val kmh: Double, val limit: Int?, val along: Double, val kwh: Double?, val power: Double?,
        val planSoc: Double?, val routeId: Int,
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val samples = ArrayList<Sample>()
    private var route: Route? = null
    private var destName = ""
    private var startMs = 0L
    private var startWall = 0L
    private var startAlong = 0.0
    private val stopActual = mutableMapOf<String, Double>()
    @Volatile private var active = false

    /** null = keine Auswertung, true = wird berechnet, Ergebnis in [last] */
    private val _computing = MutableStateFlow(false)
    val computing: StateFlow<Boolean> = _computing.asStateFlow()
    private val _last = MutableStateFlow<TripSummary?>(null)
    val last: StateFlow<TripSummary?> = _last.asStateFlow()

    fun start(r: Route, dest: String, along: Double) {
        samples.clear(); stopActual.clear()
        route = r; destName = dest; startMs = System.currentTimeMillis(); startWall = startMs; startAlong = along
        _last.value = null
        active = Settings.state.value.ecoSummary
    }

    /** Neue Route während der Fahrt (Neuberechnung): Zählung läuft weiter */
    fun routeChanged(r: Route) { if (active) route = r }

    fun sample(f: Fix, p: NavProgress, current: Route?) {
        if (!active) return
        if (current != null) route = current
        val r = route ?: return
        // GPS-Tempo: kommt jede Sekunde frisch (das OBD-Tempo nur alle paar Sekunden und springt dann)
        val kmh = f.speed * 3.6
        val volt = Obd.value("volt")
        val curr = Obd.value("curr")
        val t = if (f.elapsedNs > 0) f.elapsedNs / 1_000_000 else System.currentTimeMillis()
        if (samples.isNotEmpty() && t <= samples.last().tMs) return
        samples += Sample(
            t, kmh, r.limitAt(p.alongM), p.alongM, Obd.value("kwh"), if (volt != null && curr != null) volt * curr / 1000 else null,
            r.socAt(p.alongM), System.identityHashCode(r),
        )
        if (samples.size > 40_000) samples.subList(0, 10_000).clear()
        // Akku beim Erreichen eines Ladestopps merken (Ist gegen Plan)
        r.stops.forEach { st ->
            if (st.name !in stopActual && abs(p.alongM - st.alongM) < 150 && f.speed < 2) Obd.freshSoc()?.let { stopActual[st.name] = it - st.arriveSoc }
        }
    }

    /** Fahrt beendet (angekommen oder abgebrochen): im Hintergrund auswerten */
    fun finish(arrived: Boolean) {
        if (!active) return
        active = false
        val r = route ?: return
        val data = ArrayList(samples)
        if (data.size < 30) return
        _computing.value = true
        scope.launch {
            val s = runCatching { evaluate(r, data, arrived) }.getOrNull()
            if (s != null) { EcoStore.add(s); _last.value = s }
            _computing.value = false
        }
    }

    fun dismiss() { _last.value = null }

    private fun evaluate(r: Route, d: List<Sample>, arrived: Boolean): TripSummary {
        val set = Settings.state.value
        // Strecke aus den Fortschritten aufsummieren (übersteht Neuberechnungen, bei denen die Zählung neu beginnt)
        var meters = 0.0
        var expected = 0.0 // wird unten durch die TomTom-Planung ersetzt, wenn vorhanden
        val aux = EvModel.auxKw(r.weather)
        for (i in 1 until d.size) {
            val dm = d[i].along - d[i - 1].along
            if (dm in 0.0..2000.0) {
                meters += dm
                expected += EvModel.kwhPer100(d[i].kmh.coerceAtLeast(5.0), set, r.weather) / 100 * dm / 1000
            }
            expected += aux * ((d[i].tMs - d[i - 1].tMs) / 3_600_000.0).coerceIn(0.0, 0.01)
        }
        val km = meters / 1000
        val dur = (d.last().tMs - d.first().tMs) / 1000.0
        // Energie: Abnahmen der Akku-Energie aufsummieren (Laden ignorieren)
        var used = 0.0; var haveKwh = false
        for (i in 1 until d.size) {
            val a = d[i - 1].kwh; val b = d[i].kwh
            if (a != null && b != null) { haveKwh = true; if (b < a && a - b < 1.0) used += a - b }
        }
        // Erwartung aus TomTom-Planung (enthält Steigungen); Laden und Routenwechsel überspringen
        var planPct = 0.0; var havePlan = false
        for (i in 1 until d.size) {
            val a = d[i - 1]; val b = d[i]
            if (a.routeId != b.routeId || a.planSoc == null || b.planSoc == null) continue
            val drop = a.planSoc - b.planSoc
            if (drop in 0.0..5.0) { planPct += drop; havePlan = true }
        }
        if (havePlan && planPct > 0.3) expected = planPct / 100 * set.usableKwh

        // Tempolimits: Toleranz wie bei Bußgeldern, nur Phasen ab 10 s, nach Strecke gewichtet
        fun tol(limit: Int) = if (limit <= 100) 10.0 else limit * 0.10
        val overFlag = BooleanArray(d.size) { i -> val l = d[i].limit; l != null && l > 0 && d[i].kmh > l + tol(l) }
        // zusammenhängende Phasen bestimmen
        val counted = BooleanArray(d.size)
        val suspicious = mutableSetOf<Int>()
        var i0 = 0
        while (i0 < d.size) {
            if (!overFlag[i0]) { i0++; continue }
            var j = i0
            while (j + 1 < d.size && overFlag[j + 1] && d[j + 1].limit == d[i0].limit) j++
            val durS = (d[j].tMs - d[i0].tMs) / 1000.0
            val distM = d[j].along - d[i0].along
            val lim = d[i0].limit ?: 0
            val avg = (i0..j).map { d[it].kmh }.average()
            val spread = (i0..j).maxOf { d[it].kmh } - (i0..j).minOf { d[it].kmh }
            // lange, gleichmäßig deutlich über dem Limit: eher falsches Limit in den Kartendaten
            if (distM >= 500 && avg > lim + 15 && spread < 25) {
                suspicious += lim
            } else if (durS >= 10) {
                for (k in i0..j) counted[k] = true
            }
            i0 = j + 1
        }
        fun share(filter: (Sample) -> Boolean): Double? {
            var all = 0.0; var over = 0.0
            for (k in 1 until d.size) {
                val sm = d[k]
                val l = sm.limit ?: continue
                if (l <= 0 || !filter(sm) || l in suspicious) continue
                val dm = sm.along - d[k - 1].along
                if (dm !in 0.0..2000.0) continue
                all += dm
                if (counted[k]) over += dm
            }
            return if (all < 500) null else over / all
        }
        val speeding = share { true }
        val city = share { it.limit!! <= 50 }
        val rural = share { it.limit!! in 51..100 }
        val motorway = share { it.limit!! > 100 }

        // Anfahren/Bremsen: GPS-Tempo über 3 Messpunkte geglättet, nur wenn es ≥ 2 s anhält
        var acc = 0; var brk = 0
        val v = DoubleArray(d.size) { k -> (maxOf(0, k - 1)..minOf(d.size - 1, k + 1)).map { d[it].kmh }.average() / 3.6 }
        var accRun = 0.0; var brkRun = 0.0
        var accCounted = false; var brkCounted = false
        for (k in 1 until d.size - 1) {
            val dt = (d[k + 1].tMs - d[k - 1].tMs) / 1000.0
            if (dt <= 0.5 || dt > 6) { accRun = 0.0; brkRun = 0.0; accCounted = false; brkCounted = false; continue }
            val a = (v[k + 1] - v[k - 1]) / dt
            val step = (d[k].tMs - d[k - 1].tMs) / 1000.0
            if (a > 3.0) { accRun += step; if (accRun >= 2.0 && !accCounted) { acc++; accCounted = true } } else { accRun = 0.0; accCounted = false }
            if (a < -4.0) { brkRun += step; if (brkRun >= 2.0 && !brkCounted) { brk++; brkCounted = true } } else { brkRun = 0.0; brkCounted = false }
        }
        // Rekuperation: Energie mit „falschem“ Vorzeichen während der Fahrt
        var pos = 0.0; var neg = 0.0
        for (i in 1 until d.size) {
            val p = d[i].power ?: continue
            if (d[i].kmh < 5) continue
            val dt = (d[i].tMs - d[i - 1].tMs) / 3_600_000.0
            if (p >= 0) pos += p * dt else neg += -p * dt
        }
        var regen = if (pos + neg > 0.2) neg / (pos + neg) else null
        if (regen != null && regen > 0.6) regen = 1 - regen // Vorzeichen beim Auto andersherum
        // Mehrkosten über 125 km/h
        var extraFast = 0.0
        for (i in 1 until d.size) {
            val v = d[i].kmh
            if (v <= 125) continue
            val dtH = (d[i].tMs - d[i - 1].tMs) / 3_600_000.0
            extraFast += (EvModel.kwhPer100(v, set, r.weather) - EvModel.kwhPer100(120.0, set, r.weather)) / 100 * v * dtH
        }
        val socEnd = if (arrived) Obd.freshSoc() else null
        val socPlan = if (arrived) r.arrivalSoc else null

        // Eco-Score: Verbrauch 40, gleichmäßig 30, Limits 20, Rekuperation 10 (fehlende Teile neu gewichtet)
        val parts = mutableListOf<Pair<Double, Double>>()
        if (haveKwh && expected > 0.5) {
            val ratio = used / expected
            parts += 40.0 to ((1.4 - ratio) / 0.5 * 100).coerceIn(0.0, 100.0)
        }
        val per10 = if (km > 0.5) (acc + brk) / (km / 10) else 0.0
        parts += 30.0 to (100 - per10 * 15).coerceIn(0.0, 100.0)
        speeding?.let { parts += 20.0 to (100 - it * 300).coerceIn(0.0, 100.0) }
        regen?.let { parts += 10.0 to (it / 0.2 * 100).coerceIn(0.0, 100.0) }
        val score = (parts.sumOf { it.first * it.second } / parts.sumOf { it.first }).roundToInt()

        val tips = mutableListOf<String>()
        if (haveKwh && expected > 0.5) {
            val pct = ((used / expected - 1) * 100).roundToInt()
            if (pct > 12) tips += "Verbrauch $pct % über der Planung."
            else if (pct < -5) tips += "Sparsam gefahren: ${-pct} % unter der Planung."
            else tips += "Verbrauch wie geplant."
        }
        suspicious.sorted().forEach { tips += "Tempolimit $it in den Kartendaten vermutlich falsch – dieser Abschnitt wurde nicht gewertet." }
        if (extraFast > 0.4) tips += "Über 125 km/h kostete etwa ${"%.1f".format(extraFast)} kWh mehr."
        motorway?.takeIf { it > 0.15 }?.let { tips += "Auf der Autobahn ${(it * 100).roundToInt()} % der Zeit schneller als erlaubt." }
        city?.takeIf { it > 0.1 }?.let { tips += "In der Stadt ${(it * 100).roundToInt()} % der Zeit zu schnell." }
        if (acc + brk >= 3 && per10 > 2) tips += "$acc-mal kräftig beschleunigt, $brk-mal stark gebremst – vorausschauend fahren spart Energie."
        if (acc + brk == 0 && (speeding ?: 0.0) < 0.05) tips += "Gleichmäßig und regelkonform gefahren – weiter so!"

        return TripSummary(
            startWall, startWall + (dur * 1000).toLong(), destName, km, dur, if (dur > 0) km / (dur / 3600) else 0.0,
            if (haveKwh) used else null, expected, socPlan, socEnd,
            stopActual.map { it.key.substringBefore(",") to it.value },
            speeding, city, rural, motorway, acc, brk, regen, score, tips,
        )
    }
}

/** Gespeicherte Auswertungen (Datei eco.json) */
object EcoStore {
    private lateinit var file: File
    private val _items = MutableStateFlow<List<TripSummary>>(emptyList())
    val items: StateFlow<List<TripSummary>> = _items.asStateFlow()

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "eco.json")
        _items.value = runCatching { json.parseToJsonElement(file.readText()).jsonArray.mapNotNull { fromJson(it as? JsonObject) } }.getOrDefault(emptyList())
    }

    fun add(s: TripSummary) {
        val list = (listOf(s) + _items.value).take(200)
        _items.value = list
        runCatching { file.writeText(buildJsonArray { list.forEach { add(toJson(it)) } }.toString()) }
    }

    fun clear() { _items.value = emptyList(); runCatching { file.delete() } }

    private fun toJson(s: TripSummary) = buildJsonObject {
        put("start", s.start); put("end", s.end); put("dest", s.dest); put("km", s.km); put("dur", s.durationS); put("avg", s.avgKmh)
        s.kwhUsed?.let { put("kwh", it) }; put("exp", s.expectedKwh)
        s.socPlanEnd?.let { put("socPlan", it) }; s.socActualEnd?.let { put("socAct", it) }
        put("stops", buildJsonArray { s.stopDiffs.forEach { (n, v) -> add(buildJsonObject { put("n", n); put("v", v) }) } })
        s.speedingShare?.let { put("sp", it) }; s.speedingCity?.let { put("spC", it) }; s.speedingRural?.let { put("spR", it) }; s.speedingMotorway?.let { put("spM", it) }
        put("acc", s.accelEvents); put("brk", s.brakeEvents); s.regenShare?.let { put("regen", it) }
        put("score", s.score); put("tips", buildJsonArray { s.tips.forEach { add(JsonPrimitive(it)) } })
    }

    private fun fromJson(o: JsonObject?): TripSummary? {
        o ?: return null
        fun d(k: String) = (o[k] as? JsonPrimitive)?.doubleOrNull
        return TripSummary(
            (o["start"] as? JsonPrimitive)?.longOrNull ?: return null, (o["end"] as? JsonPrimitive)?.longOrNull ?: 0L,
            (o["dest"] as? JsonPrimitive)?.contentOrNull ?: "", d("km") ?: 0.0, d("dur") ?: 0.0, d("avg") ?: 0.0,
            d("kwh"), d("exp") ?: 0.0, d("socPlan"), d("socAct"),
            (o["stops"] as? JsonArray)?.mapNotNull { e -> (e as? JsonObject)?.let { x -> ((x["n"] as? JsonPrimitive)?.contentOrNull ?: "") to ((x["v"] as? JsonPrimitive)?.doubleOrNull ?: 0.0) } } ?: emptyList(),
            d("sp"), d("spC"), d("spR"), d("spM"),
            (o["acc"] as? JsonPrimitive)?.intOrNull ?: 0, (o["brk"] as? JsonPrimitive)?.intOrNull ?: 0, d("regen"),
            (o["score"] as? JsonPrimitive)?.intOrNull ?: 0,
            (o["tips"] as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull } ?: emptyList(),
        )
    }
}

// ======================= Fahrsimulation (Test ohne Auto) =======================

/** Fährt eine geplante Route virtuell ab: mit Tempo der Route, optional GPS-Ausfall (Tunnel) und Abweichung */
object Simulator {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: kotlinx.coroutines.Job? = null
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    fun start(ctx: Context, speedFactor: Double, tunnel: Boolean, detour: Boolean) {
        val r = NavSession.state.value.route ?: return
        stop()
        LocationHub.simulating = true
        _running.value = true
        NavSession.start(ctx)
        job = scope.launch {
            val end = r.cumM.last()
            var along = 0.0
            var lastBearing = 0f
            val tunnelAt = end * 0.2
            val detourAt = end * 0.35
            var detourLeft = if (detour) 20 else 0
            while (along < end && _running.value) {
                val cur = NavSession.state.value.route ?: r
                val i = RouteBarData.nearestIdx(cur, along).coerceAtMost(cur.points.lastIndex - 1)
                val step = cur.steps.indices.lastOrNull { cur.stepAlongM[it] <= along }?.let { cur.steps[it] }
                val v = (step?.let { if (it.durationS > 1) it.distanceM / it.durationS else 13.0 } ?: 13.0).coerceIn(5.0, 36.0)
                val a = cur.points[i]; val b = cur.points[i + 1]
                lastBearing = bearing(a, b).toFloat()
                var pos = RouteBarData.slice(cur, along, along + 1).first()
                // Abweichung: 20 s lang 250 m neben der Route
                if (detour && along >= detourAt && detourLeft > 0) {
                    val br = Math.toRadians(lastBearing + 90.0)
                    pos = LatLon(pos.lat + kotlin.math.cos(br) * 250 / 110540.0, pos.lon + kotlin.math.sin(br) * 250 / (111320.0 * kotlin.math.cos(Math.toRadians(pos.lat))))
                    detourLeft--
                }
                // Tunnel: 30 s keine Positionen
                val inTunnel = tunnel && along in tunnelAt..(tunnelAt + v * 30)
                if (!inTunnel) {
                    LocationHub.inject(Fix(pos, lastBearing, v, 5.0, System.currentTimeMillis(), android.os.SystemClock.elapsedRealtimeNanos()))
                }
                along += v * speedFactor
                kotlinx.coroutines.delay(1000)
                if (NavSession.state.value.arrived || !NavSession.state.value.navigating) break
            }
            // am Ende kurz am Ziel stehen
            repeat(12) {
                LocationHub.inject(Fix(r.points.last(), lastBearing, 0.0, 5.0, System.currentTimeMillis(), android.os.SystemClock.elapsedRealtimeNanos()))
                kotlinx.coroutines.delay(1000)
            }
            stop()
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        LocationHub.simulating = false
        _running.value = false
    }
}
