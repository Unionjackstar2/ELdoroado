package de.evroute

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put

/** Eine gespeicherte Route: nur die Planungsangaben, gerechnet wird beim Aufrufen neu (aktueller Verkehr, Wetter, Akku) */
data class SavedRoute(
    val id: String,
    val name: String,
    val start: Place?,      // null = Mein Standort
    val startSoc: Double?,  // null = aktueller Akku (OBD bzw. Regler)
    val dest: Place,
    val vias: List<Via>,
    val savedAt: Long,
)

object SavedRoutes {
    private lateinit var prefs: SharedPreferences
    private val _items = MutableStateFlow<List<SavedRoute>>(emptyList())
    val items: StateFlow<List<SavedRoute>> = _items.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("routes", Context.MODE_PRIVATE)
        load()
    }

    fun load() {
        val raw = prefs.getString("list", null) ?: run { _items.value = emptyList(); return }
        _items.value = runCatching { json.parseToJsonElement(raw).jsonArray.mapNotNull { fromJson(it as? JsonObject) } }.getOrDefault(emptyList())
    }

    fun save(r: SavedRoute) {
        val list = listOf(r) + _items.value.filter { it.id != r.id }
        _items.value = list
        persist(list)
    }

    fun remove(id: String) {
        val list = _items.value.filter { it.id != id }
        _items.value = list
        persist(list)
    }

    private fun persist(list: List<SavedRoute>) {
        prefs.edit().putString("list", buildJsonArray { list.forEach { add(toJson(it)) } }.toString()).apply()
    }

    private fun placeJson(p: Place) = buildJsonObject {
        put("name", p.name); put("lat", p.pos.lat); put("lon", p.pos.lon)
        p.osm?.let { put("osm", it) }; put("kind", p.kind)
    }

    private fun placeOf(o: JsonObject?): Place? {
        o ?: return null
        val lat = (o["lat"] as? JsonPrimitive)?.doubleOrNull ?: return null
        val lon = (o["lon"] as? JsonPrimitive)?.doubleOrNull ?: return null
        return Place(
            (o["name"] as? JsonPrimitive)?.contentOrNull ?: "Ort", LatLon(lat, lon),
            (o["osm"] as? JsonPrimitive)?.contentOrNull, (o["kind"] as? JsonPrimitive)?.contentOrNull ?: "",
        )
    }

    private fun toJson(r: SavedRoute) = buildJsonObject {
        put("id", r.id); put("name", r.name); put("savedAt", r.savedAt)
        r.start?.let { put("start", placeJson(it)) }
        r.startSoc?.let { put("startSoc", it) }
        put("dest", placeJson(r.dest))
        put("vias", buildJsonArray {
            r.vias.forEach { v ->
                add(buildJsonObject {
                    put("place", placeJson(v.place)); put("pause", v.pauseMin)
                    v.chargeParkId?.let { put("park", it) }
                    put("charger", v.isCharger); put("kw", v.powerKw)
                })
            }
        })
    }

    private fun fromJson(o: JsonObject?): SavedRoute? {
        o ?: return null
        val dest = placeOf(o["dest"] as? JsonObject) ?: return null
        val vias = (o["vias"] as? JsonArray)?.mapNotNull { e ->
            val v = e as? JsonObject ?: return@mapNotNull null
            val p = placeOf(v["place"] as? JsonObject) ?: return@mapNotNull null
            Via(
                p, (v["pause"] as? JsonPrimitive)?.intOrNull ?: 0, (v["park"] as? JsonPrimitive)?.contentOrNull,
                (v["charger"] as? JsonPrimitive)?.booleanOrNull ?: false, (v["kw"] as? JsonPrimitive)?.doubleOrNull ?: 0.0,
            )
        } ?: emptyList()
        return SavedRoute(
            (o["id"] as? JsonPrimitive)?.contentOrNull ?: System.nanoTime().toString(),
            (o["name"] as? JsonPrimitive)?.contentOrNull ?: dest.title,
            placeOf(o["start"] as? JsonObject),
            (o["startSoc"] as? JsonPrimitive)?.doubleOrNull,
            dest, vias,
            (o["savedAt"] as? JsonPrimitive)?.longOrNull ?: 0L,
        )
    }
}
