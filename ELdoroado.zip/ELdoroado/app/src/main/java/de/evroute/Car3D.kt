package de.evroute

import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.view.TextureView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.sin

/** Die 3D-Autos für die Fahrzeugkarte (Kenney „Car Kit“, CC0) */
object CarModels {
    data class M(val id: String, val label: String, val paint: Int)
    val all = listOf(
        M("car_compact", "Kompakt", 0xFF42AB7C.toInt()),
        M("car_suv", "SUV", 0xFF3DA679.toInt()),
        M("car_sport", "Sportwagen", 0xFFEA6246.toInt()),
        M("car_future", "Renner", 0xFF607ACD.toInt()),
    )
    fun byId(id: String) = all.firstOrNull { it.id == id }
}

/**
 * Kleiner OpenGL-ES-2-Renderer für Low-Poly-Modelle: flache Schattierung, transparenter Hintergrund,
 * gezeichnet wird nur bei Änderungen (Drehen, Farbe) – im Stillstand kein Verbrauch.
 */
class Car3DView(context: Context) : TextureView(context), TextureView.SurfaceTextureListener {
    @Volatile var yaw = 35f
    @Volatile var pitch = 16f
    @Volatile private var modelId = ""
    @Volatile private var tint = floatArrayOf(1f, 1f, 1f)

    private val thread = HandlerThread("car3d").apply { start() }
    private val gl = Handler(thread.looper)
    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglCtx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var surface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var prog = 0
    private var vbo = 0
    private var count = 0
    private var loaded = ""
    private var w = 1
    private var h = 1
    private val drawTask = Runnable { draw() }

    init {
        isOpaque = false
        surfaceTextureListener = this
    }

    fun setModel(id: String, color: Int) {
        modelId = id
        tint = floatArrayOf(((color shr 16) and 0xFF) / 255f, ((color shr 8) and 0xFF) / 255f, (color and 0xFF) / 255f)
        requestRender()
    }

    fun requestRender() {
        gl.removeCallbacks(drawTask)
        gl.post(drawTask)
    }

    fun dispose() {
        gl.post { release() }
        thread.quitSafely()
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
        gl.post {
            w = width; h = height
            if (initEgl(st)) draw()
        }
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {
        gl.post { w = width; h = height; draw() }
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        gl.post { release() }
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    private fun chooseConfig(msaa: Boolean): EGLConfig? {
        val attrs = mutableListOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_DEPTH_SIZE, 16,
        )
        if (msaa) attrs += listOf(EGL14.EGL_SAMPLE_BUFFERS, 1, EGL14.EGL_SAMPLES, 4)
        attrs += EGL14.EGL_NONE
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        return if (EGL14.eglChooseConfig(display, attrs.toIntArray(), 0, configs, 0, 1, num, 0) && num[0] > 0) configs[0] else null
    }

    private fun initEgl(st: SurfaceTexture): Boolean = runCatching {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        EGL14.eglInitialize(display, ver, 0, ver, 1)
        // Kantenglättung (4× MSAA), falls das Gerät es kann
        val config = chooseConfig(true) ?: chooseConfig(false) ?: return@runCatching false
        eglCtx = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        surface = EGL14.eglCreateWindowSurface(display, config, st, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(display, surface, surface, eglCtx)
        prog = program(VS, FS)
        loaded = ""
        true
    }.getOrElse { CrashLog.note("3D-Ansicht: ${it.message}"); false }

    private fun loadModel(id: String) {
        val bytes = context.assets.open("models/$id.bin").use { it.readBytes() }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        bb.position(4)
        count = bb.int
        val data = ByteBuffer.allocateDirect(bytes.size - 8).order(ByteOrder.nativeOrder())
        data.put(bytes, 8, bytes.size - 8)
        data.position(0)
        if (vbo != 0) GLES20.glDeleteBuffers(1, intArrayOf(vbo), 0)
        val ids = IntArray(1)
        GLES20.glGenBuffers(1, ids, 0)
        vbo = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, bytes.size - 8, data, GLES20.GL_STATIC_DRAW)
        loaded = id
    }

    private fun draw() {
        if (surface == EGL14.EGL_NO_SURFACE || prog == 0) return
        runCatching {
            val id = modelId
            if (id.isNotEmpty() && id != loaded) loadModel(id)
            GLES20.glViewport(0, 0, w, h)
            GLES20.glClearColor(0f, 0f, 0f, 0f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            if (loaded.isNotEmpty() && count > 0) {
                GLES20.glEnable(GLES20.GL_DEPTH_TEST)
                GLES20.glUseProgram(prog)
                val proj = FloatArray(16); val view = FloatArray(16); val model = FloatArray(16)
                val vp = FloatArray(16); val mvp = FloatArray(16)
                Matrix.perspectiveM(proj, 0, 24f, w.toFloat() / h.coerceAtLeast(1), 0.5f, 30f)
                val p = Math.toRadians(pitch.toDouble())
                val dist = 4.6
                Matrix.setLookAtM(view, 0, 0f, (-dist * cos(p)).toFloat(), (dist * sin(p) + 0.32).toFloat(), 0f, 0f, 0.32f, 0f, 0f, 1f)
                Matrix.setRotateM(model, 0, yaw, 0f, 0f, 1f)
                Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
                Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
                GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMvp"), 1, false, mvp, 0)
                GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uModel"), 1, false, model, 0)
                GLES20.glUniform3fv(GLES20.glGetUniformLocation(prog, "uTint"), 1, tint, 0)
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
                val aPos = GLES20.glGetAttribLocation(prog, "aPos")
                val aNor = GLES20.glGetAttribLocation(prog, "aNor")
                val aCol = GLES20.glGetAttribLocation(prog, "aCol")
                GLES20.glEnableVertexAttribArray(aPos)
                GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 28, 0)
                GLES20.glEnableVertexAttribArray(aNor)
                GLES20.glVertexAttribPointer(aNor, 3, GLES20.GL_FLOAT, false, 28, 12)
                GLES20.glEnableVertexAttribArray(aCol)
                GLES20.glVertexAttribPointer(aCol, 4, GLES20.GL_UNSIGNED_BYTE, true, 28, 24)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
            }
            EGL14.eglSwapBuffers(display, surface)
        }.onFailure { CrashLog.note("3D-Ansicht: ${it.message}") }
    }

    private fun release() {
        if (display != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (surface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surface)
            if (eglCtx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, eglCtx)
            // Wichtig: KEIN eglTerminate – die EGL-Anzeige teilt sich die ganze App (auch die Karte).
            // Ein Terminate würde der Karte den Grafikkontext wegziehen (Hänger und Absturz).
        }
        display = EGL14.EGL_NO_DISPLAY; eglCtx = EGL14.EGL_NO_CONTEXT; surface = EGL14.EGL_NO_SURFACE
        prog = 0; vbo = 0; loaded = ""
    }

    private fun program(vs: String, fs: String): Int {
        fun shader(type: Int, src: String) = GLES20.glCreateShader(type).also { GLES20.glShaderSource(it, src); GLES20.glCompileShader(it) }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }

    companion object {
        private const val VS = """
uniform mat4 uMvp;
uniform mat4 uModel;
attribute vec3 aPos;
attribute vec3 aNor;
attribute vec4 aCol;
varying vec3 vNor;
varying vec4 vCol;
void main() {
    vNor = (uModel * vec4(aNor, 0.0)).xyz;
    vCol = aCol;
    gl_Position = uMvp * vec4(aPos, 1.0);
}
"""
        private const val FS = """
precision mediump float;
uniform vec3 uTint;
varying vec3 vNor;
varying vec4 vCol;
void main() {
    vec3 n = normalize(vNor);
    // Lack: weiß gerenderte Helligkeit × Lackfarbe; alles andere in Originalfarbe
    vec3 base = vCol.a > 0.5 ? vCol.rgb * uTint : vCol.rgb;
    vec3 key = normalize(vec3(-0.35, -0.75, 0.75));
    vec3 fill = normalize(vec3(0.6, -0.3, 0.35));
    float d = max(dot(n, key), 0.0);
    float f = max(dot(n, fill), 0.0) * 0.35;
    float top = max(n.z, 0.0) * 0.12;
    vec3 c = base * (0.34 + 0.72 * d + f + top);
    gl_FragColor = vec4(min(c, vec3(1.0)), 1.0);
}
"""
    }
}

/** Frei drehbares 3D-Auto mit Schwung beim Loslassen und weichem Bodenschatten */
@Composable
fun Car3D(modelId: String, color: Int, modifier: Modifier = Modifier) {
    val holder = remember { arrayOfNulls<Car3DView>(1) }
    val yaw = remember { Animatable(35f) }
    val scope = rememberCoroutineScope()
    DisposableEffect(Unit) { onDispose { holder[0]?.dispose() } }
    Box(modifier) {
        // Schatten am Boden
        Canvas(Modifier.fillMaxSize()) {
            val cw = size.width * 0.62f
            val ch = size.height * 0.16f
            drawOval(
                Brush.radialGradient(listOf(Color.Black.copy(alpha = 0.28f), Color.Transparent), center = Offset(size.width / 2, size.height * 0.8f), radius = cw / 2),
                topLeft = Offset((size.width - cw) / 2, size.height * 0.8f - ch / 2), size = Size(cw, ch),
            )
        }
        AndroidView(
            factory = { ctx -> Car3DView(ctx).also { holder[0] = it; it.setModel(modelId, color) } },
            update = { it.setModel(modelId, color) },
            modifier = Modifier.fillMaxSize(),
        )
        // waagerecht wischen dreht das Auto (senkrecht bleibt fürs Scrollen frei)
        Box(
            Modifier.fillMaxWidth().fillMaxHeight().align(Alignment.Center).pointerInput(Unit) {
                val tracker = VelocityTracker()
                detectHorizontalDragGestures(
                    onDragStart = { tracker.resetTracking(); scope.launch { yaw.stop() } },
                    onDragEnd = {
                        val v = tracker.calculateVelocity().x * 0.35f
                        scope.launch {
                            yaw.animateDecay(v, exponentialDecay(frictionMultiplier = 1.4f)) {
                                holder[0]?.let { view -> view.yaw = value; view.requestRender() }
                            }
                        }
                    },
                ) { change, dx ->
                    tracker.addPosition(change.uptimeMillis, change.position)
                    change.consume()
                    scope.launch { yaw.snapTo(yaw.value + dx * 0.45f) }
                    holder[0]?.let { view -> view.yaw = yaw.value + dx * 0.45f; view.requestRender() }
                }
            },
        )
    }
}
