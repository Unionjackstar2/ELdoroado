package de.evroute

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Ladestationen direkt auf der Karte (im sichtbaren Ausschnitt) */
object MapChargers {
    data class State(
        val active: Boolean = false,
        val loading: Boolean = false,
        val hits: List<ChargerHit> = emptyList(),
        val error: String? = null,
        val selected: ChargerHit? = null,
        val availability: Map<String, Availability> = emptyMap(),
        val searchedAt: LatLon? = null,
        val searchedRadius: Int = 0,
        val tooFar: Boolean = false,
        val nearby: NearbyInfo? = null,
        val nearbyLoading: Boolean = false,
    )

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    // letzter Kartenausschnitt (Mitte und Radius bis zur Ecke)
    @Volatile var viewCenter: LatLon? = null
    @Volatile var viewRadius: Int = 5000
    private val _moved = MutableStateFlow(false)
    val moved: StateFlow<Boolean> = _moved.asStateFlow()

    fun onCameraIdle(center: LatLon, radiusM: Int) {
        viewCenter = center
        viewRadius = radiusM
        val s = _state.value
        val at = s.searchedAt
        _moved.value = s.active && at != null && (haversine(at, center) > s.searchedRadius * 0.35 || radiusM > s.searchedRadius * 1.6)
    }

    fun toggle() {
        if (_state.value.active) {
            _state.value = State()
            _moved.value = false
        } else {
            _state.value = State(active = true)
            searchHere()
        }
    }

    /** Im aktuellen Ausschnitt suchen */
    fun searchHere() {
        val set = Settings.state.value
        val c = viewCenter ?: LocationHub.fix.value?.pos ?: return
        if (!set.hasTomTom) {
            _state.update { it.copy(active = true, loading = false, error = "Dafür wird der TomTom-Key benötigt (Einstellungen → TomTom).") }
            return
        }
        val radius = viewRadius.coerceAtLeast(1000)
        if (radius > 40_000) {
            _state.update { it.copy(active = true, loading = false, tooFar = true, hits = emptyList(), searchedAt = c, searchedRadius = radius) }
            _moved.value = false
            return
        }
        _state.update { it.copy(active = true, loading = true, error = null, tooFar = false) }
        _moved.value = false
        scope.launch {
            val minKw = if (set.mapFastOnly) 50 else 0
            val res = runCatching { TomTom.nearby(set.tomtomKey.trim(), c, radius, minKw, set.mapFastOnly) }
            _state.update { s ->
                res.fold(
                    { hits -> s.copy(loading = false, hits = hits.sortedByDescending { it.powerKw }, searchedAt = c, searchedRadius = radius) },
                    { e -> s.copy(loading = false, error = e.message, searchedAt = c, searchedRadius = radius) },
                )
            }
        }
    }

    fun setFastOnly(b: Boolean) {
        Settings.update { it.copy(mapFastOnly = b) }
        if (_state.value.active) searchHere()
    }

    /** Treffer aus anderen Listen (Suchvorschläge), damit sie auf der Karte antippbar sind */
    @Volatile var extraHits: List<ChargerHit> = emptyList()

    /** Station per Kennung (aus Karte) öffnen */
    fun select(id: String) {
        val h = _state.value.hits.firstOrNull { it.id == id }
            ?: NavSession.state.value.chargerSearch?.hits?.firstOrNull { it.id == id }
            ?: extraHits.firstOrNull { it.id == id }
            ?: return
        show(h)
    }

    /** Ladestations-Fenster öffnen: Belegung und Umgebung nachladen */
    fun show(h: ChargerHit) {
        _state.update { it.copy(selected = h, nearby = null, nearbyLoading = true) }
        val key = Settings.state.value.tomtomKey.trim()
        val av = h.availId
        if (av != null && key.isNotBlank()) {
            scope.launch {
                val a = runCatching { TomTom.availability(key, av) }.getOrNull() ?: return@launch
                _state.update { it.copy(availability = it.availability + (av to a)) }
            }
        }
        scope.launch {
            val n = runCatching { Nearby.around(h.pos) }.getOrNull()
            _state.update { st -> if (st.selected?.id == h.id) st.copy(nearby = n, nearbyLoading = false) else st }
        }
    }

    fun closeInfo() { _state.update { it.copy(selected = null, nearby = null, nearbyLoading = false) } }

    /** Farbe nach Leistung: grün ab 150 kW, blau ab 50 kW, grau darunter */
    fun iconFor(kw: Double) = when {
        kw >= 150 -> "mc-fast"
        kw >= 50 -> "mc-mid"
        else -> "mc-slow"
    }

    fun addIcons(ctx: Context, s: org.maplibre.android.maps.Style) {
        s.addImage("mc-fast", VehicleIcons.chargerColored(ctx, 0xFF30D158.toInt()))
        s.addImage("mc-mid", VehicleIcons.chargerColored(ctx, 0xFF0A84FF.toInt()))
        s.addImage("mc-slow", VehicleIcons.chargerColored(ctx, 0xFF8E8E93.toInt()))
    }
}

/** Hinweis oben: „In diesem Bereich suchen“, Filter, Ladeanzeige */
@Composable
fun MapChargerPill(st: MapChargers.State, moved: Boolean, fastOnly: Boolean) {
    val pal = LocalPal.current
    Surface(shape = RoundedCornerShape(18.dp), color = pal.card, shadowElevation = 8.dp) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            when {
                st.loading -> {
                    CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Suche Ladestationen …", color = pal.text, fontSize = 14.sp)
                }
                st.tooFar -> Text("Weiter hineinzoomen", color = pal.text, fontSize = 14.sp)
                moved -> Text(
                    "In diesem Bereich suchen", color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { MapChargers.searchHere() },
                )
                st.error != null -> Text(st.error, color = pal.red, fontSize = 13.sp, maxLines = 2)
                else -> Text("${st.hits.size} Ladestationen", color = pal.text, fontSize = 14.sp)
            }
            Spacer(Modifier.width(10.dp))
            Text(
                if (fastOnly) "Schnelllader" else "Alle",
                color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(pal.blue)
                    .clickable { MapChargers.setFastOnly(!fastOnly) }.padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

/** Ladestations-Fenster: Lage, Ladepunkte, Belegung, Öffnungszeiten, Umgebung */
@Composable
fun ChargerCard(
    h: ChargerHit,
    st: MapChargers.State,
    me: LatLon?,
    nav: NavSession.State,
    maxH: androidx.compose.ui.unit.Dp,
    onClose: () -> Unit = { MapChargers.closeInfo() },
) {
    val pal = LocalPal.current
    val a = h.availId?.let { st.availability[it] }
    val replacing = nav.chargerSearch != null
    val route = nav.route
    val onRoute = route?.let { r -> TomTom.locateOnRoute(r, h.pos).takeIf { it.second < 15_000 } }
    GlassCard(Modifier.fillMaxWidth(), corner = 26.dp) {
        Column(
            Modifier.heightIn(max = maxH * 0.62f).verticalScroll(rememberScrollState()).padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(38.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(operatorColor(h.operator.ifBlank { h.name }))),
                    contentAlignment = Alignment.Center,
                ) { Text("⚡", color = Color.White, fontSize = 18.sp) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(chargerTitle(h), color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    val sub = listOfNotNull(
                        h.operator.ifBlank { null },
                        onRoute?.let { "km ${(it.first / 1000).roundToInt()} auf deiner Route" } ?: me?.let { fmtKm(haversine(it, h.pos)) },
                    ).joinToString(" · ")
                    if (sub.isNotBlank()) Text(sub, color = pal.sub, fontSize = 14.sp)
                }
                CloseDot(onClose)
            }
            st.nearby?.location?.let { Text("📍 $it", color = pal.text, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp)) }

            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoChip(if (h.powerKw > 0) "bis ${h.powerKw.roundToInt()} kW" else "kW unbekannt", if (h.powerKw >= 150) pal.green else pal.blue)
                if (a != null && a.known) InfoChip("${a.available}/${a.total} frei", if (a.available > 0) pal.green else pal.red)
                else if (h.availId != null) InfoChip("Belegung unbekannt", pal.sub)
                onRoute?.let { (along, _) -> route?.socAt(along)?.let { soc -> InfoChip("Ankunft ca. ${fmtPct(soc)}", if (soc < Settings.state.value.minSocStop) pal.red else pal.text) } }
            }

            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (replacing) {
                    Button(
                        onClick = { MapChargers.closeInfo(); NavSession.pickCharger(h) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = pal.green, contentColor = Color.White),
                    ) { Text("Diesen Ladestopp nehmen", fontWeight = FontWeight.Bold) }
                } else {
                    if (!nav.navigating) {
                        Button(
                            onClick = { MapChargers.closeInfo(); NavSession.plan(Place(h.name + if (h.address.isNotBlank()) ", ${h.address}" else "", h.pos)) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                        ) { Text("Route hierhin", fontWeight = FontWeight.Bold) }
                    }
                    if (nav.navigating) {
                        Button(
                            onClick = { MapChargers.closeInfo(); NavSession.setDestination(Place(h.name + if (h.address.isNotBlank()) ", ${h.address}" else "", h.pos)) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                        ) { Text("Als Ziel", fontWeight = FontWeight.Bold) }
                    }
                    if (nav.dest != null || nav.navigating) {
                        Button(
                            onClick = { MapChargers.closeInfo(); NavSession.pickCharger(h) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = pal.green, contentColor = Color.White),
                        ) { Text(if (nav.navigating) "Hier laden" else "Als Ladestopp", fontWeight = FontWeight.Bold) }
                    }
                }
            }

            // Ladepunkte
            Section2("Ladepunkte")
            if (a != null && a.lines.isNotEmpty()) {
                a.lines.forEach { Text(it, color = pal.text, fontSize = 15.sp) }
            } else if (h.connectorGroups.isNotEmpty()) {
                h.connectorGroups.forEach { Text(it, color = pal.text, fontSize = 15.sp) }
            } else if (h.connectors.isNotBlank()) {
                Text(h.connectors, color = pal.text, fontSize = 15.sp)
            } else {
                Text("keine Angaben", color = pal.sub, fontSize = 14.sp)
            }
            if (h.teslaOnly || h.operator.contains("Tesla", true) || h.name.contains("Tesla", true)) {
                Text(
                    "Tesla: in der Tesla-App prüfen, ob der Standort für andere Autos freigegeben ist.",
                    color = Color(0xFFFF9500), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
                )
            }

            // Öffnungszeiten
            if (h.openingLines.isNotEmpty()) {
                Section2("Öffnungszeiten")
                h.openingLines.forEach { Text(it, color = pal.text, fontSize = 15.sp) }
            }

            // Umgebung
            Section2("In der Nähe")
            val n = st.nearby
            if (st.nearbyLoading) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(14.dp), color = pal.blue, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Suche Toiletten, Essen, Einkauf …", color = pal.sub, fontSize = 14.sp)
                }
            } else if (n == null) {
                Text("Umgebung konnte nicht geladen werden.", color = pal.sub, fontSize = 14.sp)
            } else {
                Text("🚻 " + (n.toilets ?: "keine Toiletten eingetragen"), color = if (n.toilets != null) pal.text else pal.sub, fontSize = 15.sp)
                if (n.food.isEmpty()) Text("🍴 kein Essen in Laufweite eingetragen", color = pal.sub, fontSize = 15.sp)
                n.food.forEach { Text("🍴 $it", color = pal.text, fontSize = 15.sp) }
                n.shops.forEach { Text("🛒 $it", color = pal.text, fontSize = 15.sp) }
            }
            if (h.address.isNotBlank()) {
                Section2("Adresse")
                Text(h.address, color = pal.text, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun Section2(t: String) {
    Text(t, color = LocalPal.current.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp, bottom = 2.dp))
}

@Composable
private fun InfoChip(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.14f)).padding(horizontal = 8.dp, vertical = 4.dp),
    )
}
