package de.evroute

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Kurzfassung in den Einstellungen */
@Composable
fun LearnSettingsSection(s: AppSettings, onOpen: () -> Unit) {
    val pal = LocalPal.current
    val trips by TripRecorder.trips.collectAsState()
    val rec by TripRecorder.recording.collectAsState()
    val ver by Learner.version.collectAsState()
    @Suppress("UNUSED_VARIABLE") val v = ver
    val avg = TripRecorder.average()
    Text(
        "${trips.size} Fahrten · ${Learner.totalKm().roundToInt()} km gelernt" +
            (avg?.let { " · Ø ${String.format(Locale.GERMANY, "%.1f", it)} kWh/100 km" } ?: "") +
            if (rec) " · zeichnet gerade auf" else "",
        color = pal.text, fontSize = 15.sp,
    )
    Text(
        "Aufgezeichnet wird automatisch, wenn der OBD-Adapter verbunden ist und das Auto fährt.",
        color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp),
    )
    ToggleRow("Fahrten aufzeichnen und lernen", s.learnEnabled) { b -> Settings.update { it.copy(learnEnabled = b) } }
    ToggleRow("Gelerntes für die Planung verwenden", s.useLearned) { b -> Settings.update { it.copy(useLearned = b) } }
    TextButton(onClick = onOpen) { Text("Fahrten und gelernte Werte ansehen", color = pal.blue, fontWeight = FontWeight.SemiBold) }
}

/** Vollbild: gelernter Verbrauch, gelernte Ladekurve, Fahrtenliste */
@Composable
fun TripsScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val trips by TripRecorder.trips.collectAsState()
    val ver by Learner.version.collectAsState()
    @Suppress("UNUSED_VARIABLE") val v = ver
    val df = SimpleDateFormat("dd.MM. HH:mm", Locale.GERMANY)

    Surface(Modifier.fillMaxSize(), color = pal.screen) {
        Column(
            Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Fahrten & Lernen", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = vm::closeTrips) { Text("Fertig", color = pal.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
            }

            Section("Gelernter Verbrauch (kWh/100 km)") {
                Text(
                    "Je Tempo und Außentemperatur: Modell → gelernt (Kilometer Basis). Grün = sparsamer als das Modell.",
                    color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp),
                )
                Row {
                    Text("Tempo", color = pal.sub, fontSize = 12.sp, modifier = Modifier.weight(0.9f))
                    Learner.TEMP_LABELS.forEach { Text(it, color = pal.sub, fontSize = 12.sp, modifier = Modifier.weight(1f)) }
                }
                Learner.SPEED_LABELS.forEachIndexed { si, label ->
                    val vMid = when (si) { 0 -> 30.0; 1 -> 55.0; 2 -> 85.0; 3 -> 110.0; else -> 130.0 }
                    Row(Modifier.padding(vertical = 4.dp)) {
                        Text("$label km/h", color = pal.text, fontSize = 13.sp, modifier = Modifier.weight(0.9f))
                        (0 until 3).forEach { ti ->
                            val tMid = when (ti) { 0 -> 0.0; 1 -> 10.0; else -> 20.0 }
                            val (r, k) = Learner.cell(si, ti)
                            val model = EvModel.basePer100(vMid, tMid)
                            Column(Modifier.weight(1f)) {
                                if (k < 1) {
                                    Text(String.format(Locale.GERMANY, "%.1f", model), color = pal.sub, fontSize = 13.sp)
                                    Text("–", color = pal.sub, fontSize = 11.sp)
                                } else {
                                    Text(
                                        String.format(Locale.GERMANY, "%.1f → %.1f", model, model * r),
                                        color = if (r < 0.97) pal.green else if (r > 1.03) pal.red else pal.text,
                                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                    )
                                    Text("${k.roundToInt()} km", color = pal.sub, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
                Text(
                    "Heizung bzw. Klima ist im Wert enthalten. Ab etwa 30 km pro Feld wird das Gelernte voll verwendet.",
                    color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                )
            }

            Section("Gelernte Ladekurve") {
                val bins = Learner.chargeBins()
                if (bins.none { it.third >= 3 }) {
                    Text(
                        "Noch keine Ladedaten. Lass die App beim Schnellladen geöffnet (oder die Navigation laufen), dann lernt sie die Ladeleistung deines ë-C4.",
                        color = pal.sub, fontSize = 13.sp,
                    )
                }
                ChargeChart(bins)
                Text("Höchste gemessene Leistung je 5 % Akkustand (blau) gegenüber dem Startwert (grau).", color = pal.sub, fontSize = 12.sp)
            }

            EcoSummariesSection()
            Section("Fahrten") {
                Row {
                    TextButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "EVRoute Fahrten")
                            putExtra(Intent.EXTRA_TEXT, TripRecorder.csv())
                        }
                        ctx.startActivity(Intent.createChooser(send, "Fahrten teilen"))
                    }) { Text("Als Tabelle teilen") }
                }
                if (trips.isEmpty()) Text("Noch keine Fahrten aufgezeichnet.", color = pal.sub, fontSize = 13.sp)
                trips.reversed().take(50).forEach { t ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(df.format(Date(t.start)), color = pal.text, fontSize = 15.sp)
                            Text(
                                String.format(Locale.GERMANY, "%.1f km · %.0f km/h", t.km, t.avgKmh) +
                                    (t.tempC?.let { " · ${it.roundToInt()} °C" } ?: ""),
                                color = pal.sub, fontSize = 13.sp,
                            )
                        }
                        Text(String.format(Locale.GERMANY, "%.1f kWh/100 km", t.per100), color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Section("Zurücksetzen") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { Learner.reset() }, shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = pal.field, contentColor = pal.red),
                    ) { Text("Gelerntes löschen") }
                    Button(
                        onClick = { TripRecorder.clear() }, shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = pal.field, contentColor = pal.red),
                    ) { Text("Fahrten löschen") }
                }
            }
        }
    }
}

@Composable
private fun ChargeChart(bins: List<Triple<Int, Double, Int>>) {
    val pal = LocalPal.current
    val defaults = EvModel.batteryCurve(Settings.state.value.usableKwh)
    val usable = Settings.state.value.usableKwh
    Canvas(Modifier.fillMaxWidth().height(110.dp).padding(vertical = 6.dp)) {
        val w = size.width
        val h = size.height
        fun x(soc: Double) = (soc / 100.0 * w).toFloat()
        fun y(kw: Double) = (h - (kw.coerceIn(0.0, 110.0) / 110.0) * h).toFloat()
        // Startwerte (grau)
        val p = Path()
        defaults.forEachIndexed { i, (kwh, kw) ->
            val soc = kwh / usable * 100
            if (i == 0) p.moveTo(x(soc), y(kw)) else p.lineTo(x(soc), y(kw))
        }
        drawPath(p, Color.Gray.copy(alpha = 0.6f), style = Stroke(width = 4f))
        // Gelernt (blau)
        bins.filter { it.third >= 3 && it.second > 0 }.forEach { (soc, kw, _) ->
            drawLine(pal.blue, Offset(x(soc.toDouble()), y(kw)), Offset(x(soc + 5.0), y(kw)), 8f)
        }
    }
    Spacer(Modifier.width(1.dp))
}
