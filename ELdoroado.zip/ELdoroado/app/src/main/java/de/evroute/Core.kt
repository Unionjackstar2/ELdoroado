package de.evroute

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------- Modelle ----------------

data class LatLon(val lat: Double, val lon: Double)

data class Place(
    val name: String,
    val pos: LatLon,
    val osm: String? = null,  // OpenStreetMap-Kennung, z. B. "N123456" (für Öffnungszeiten usw.)
    val kind: String = "",    // OSM-Kategorie, z. B. "shop=supermarket"
) {
    val title: String get() = name.substringBefore(", ")
    val subtitle: String get() = if (name.contains(", ")) name.substringAfter(", ") else ""
}

/** GPS-Position */
data class Fix(
    val pos: LatLon,
    val bearing: Float?,
    val speed: Double,
    val accuracy: Double,
    val time: Long,
    val elapsedNs: Long = 0L, // Zeitpunkt der Messung (SystemClock.elapsedRealtimeNanos), um das Alter auszugleichen
    val alt: Double? = null,  // Höhe über Meer (GPS)
)

data class Step(
    val type: String,        // turn, continue, fork, on ramp, off ramp, roundabout, arrive, charge, ferry, depart …
    val mod: String?,        // left, right, slight left … straight, uturn
    val exit: Int?,
    val road: String,
    val towards: String,
    val distanceM: Double,   // Strecke von diesem Manöver bis zum nächsten
    val durationS: Double,
    val phrase: String,      // z. B. "rechts abbiegen" (klein, ohne Straße)
    val note: String = "",   // Zusatz, z. B. beim Ladestopp
) {
    val isRamp: Boolean get() = type == "on ramp" || type == "off ramp" || type == "fork"
    val isRoundabout: Boolean get() = type == "roundabout" || type == "rotary" || type == "roundabout turn"

    /** Zeile im Banner (wie Apple Maps: Straße bzw. Richtung) */
    fun bannerText(): String = when {
        type == "arrive" -> "Ziel"
        type == "charge" -> if (road.isNotBlank()) "Ladestopp · $road" else "Ladestopp"
        isRoundabout && exit != null -> "$exit. Ausfahrt" + if (road.isNotBlank()) " · $road" else ""
        isRamp && towards.isNotBlank() -> "Richtung $towards"
        road.isNotBlank() -> road
        else -> phrase.cap()
    }

    /** Ansage-Ziel: "auf A 1" oder "Richtung Porto" */
    fun spokenTarget(): String = when {
        type == "arrive" || type == "charge" -> ""
        isRamp && towards.isNotBlank() -> " Richtung $towards"
        road.isNotBlank() && !isRoundabout -> " auf $road"
        else -> ""
    }
}

data class ChargeStop(
    val name: String,
    val operator: String,
    val pos: LatLon,
    val alongM: Double,
    val powerKw: Double,
    val arriveSoc: Double,
    val targetSoc: Double,
    val chargeS: Double,
    val uuid: String?,
)

data class Jam(
    val startIdx: Int,
    val endIdx: Int,
    val delayS: Double,
    val magnitude: Int,
    val category: String,
    val cause: Int? = null,      // TPEG-TEC Hauptursache: 2 Unfall, 3 Baustelle, 10 Gegenstand, 13 Pannenfahrzeug …
    val speedKmh: Double? = null, // Tempo im Stau
)

/** Eine Fahrspur: mögliche Richtungen (STRAIGHT, SLIGHT_RIGHT …) und die empfohlene */
data class Lane(val directions: List<String>, val follow: String?)

/** Abschnitt mit Spurinformationen (Spuren von links nach rechts) */
data class LaneSection(val startIdx: Int, val endIdx: Int, val lanes: List<Lane>)

data class WeatherInfo(val tempC: Double, val headwindKmh: Double, val rain: Boolean)

data class Availability(
    val available: Int,
    val total: Int,
    val known: Boolean,
    val lines: List<String> = emptyList(), // z. B. "CCS 300 kW: 4 von 6 frei"
)

data class Route(
    val points: List<LatLon>,
    val cumM: DoubleArray,         // kumulierte Strecke je Punkt
    val stepAlongM: DoubleArray,   // Position jedes Manövers entlang der Route
    val stepTimeS: DoubleArray,    // Fahrzeit bis zu jedem Manöver
    val distanceM: Double,
    val durationS: Double,         // gesamt inkl. Laden
    val driveS: Double,            // reine Fahrzeit
    val steps: List<Step>,
    val summary: String,
    val tag: String = "",
    val source: String = "OSRM",
    val stops: List<ChargeStop> = emptyList(),
    val socProfile: List<Pair<Double, Double>> = emptyList(), // (Strecke m, Akku %)
    val arrivalSoc: Double? = null,
    val chargeS: Double = 0.0,
    val trafficDelayS: Double = 0.0,
    val jams: List<Jam> = emptyList(),
    val timesIncludeCharging: Boolean = true,
    val feasible: Boolean = true,
    val reason: String? = null,
    val weather: WeatherInfo? = null,
    val note: String? = null,
    val speedLimits: IntArray? = null, // km/h je Abschnitt zwischen zwei Punkten, 0 = unbekannt
    val laneSections: List<LaneSection> = emptyList(),
) {
    /** Tempolimit an einer Stelle der Route (km/h) oder null */
    fun limitAt(along: Double): Int? {
        val lim = speedLimits ?: return null
        if (lim.isEmpty() || cumM.isEmpty()) return null
        var i = cumM.binarySearch(along)
        if (i < 0) i = -i - 2
        return lim[i.coerceIn(0, lim.lastIndex)].takeIf { it > 0 }
    }

    /** Erwarteter Akkustand (%) an einer Stelle der Route */
    fun socAt(along: Double): Double? {
        if (socProfile.isEmpty()) return null
        var prev = socProfile.first()
        for (p in socProfile.drop(1)) {
            if (along < p.first) {
                val span = p.first - prev.first
                return if (span <= 0) p.second else prev.second + (p.second - prev.second) * (along - prev.first) / span
            }
            prev = p
        }
        return socProfile.last().second
    }
}

data class NavProgress(
    val segIdx: Int,
    val snapped: LatLon,
    val routeBearing: Double,
    val alongM: Double,
    val stepIdx: Int,
    val distToStepM: Double,
    val remainingM: Double,
    val remainingS: Double,
    val offRouteM: Double,
)

// ---------------- Geometrie ----------------

fun haversine(a: LatLon, b: LatLon): Double {
    val r = 6371000.0
    val dLat = Math.toRadians(b.lat - a.lat)
    val dLon = Math.toRadians(b.lon - a.lon)
    val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
    return 2 * r * asin(sqrt(h.coerceIn(0.0, 1.0)))
}

/** Anteil t (0..1) der Projektion von p auf a–b */
fun projectT(p: LatLon, a: LatLon, b: LatLon): Double {
    val kx = 111320.0 * cos(Math.toRadians(p.lat))
    val ky = 110540.0
    val ax = (a.lon - p.lon) * kx
    val ay = (a.lat - p.lat) * ky
    val dx = (b.lon - a.lon) * kx
    val dy = (b.lat - a.lat) * ky
    val len2 = dx * dx + dy * dy
    return if (len2 == 0.0) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
}

fun lerp(a: LatLon, b: LatLon, t: Double) = LatLon(a.lat + (b.lat - a.lat) * t, a.lon + (b.lon - a.lon) * t)

fun distToSeg(p: LatLon, a: LatLon, b: LatLon): Double {
    val q = lerp(a, b, projectT(p, a, b))
    val kx = 111320.0 * cos(Math.toRadians(p.lat))
    return hypot((q.lon - p.lon) * kx, (q.lat - p.lat) * 110540.0)
}

fun bearing(a: LatLon, b: LatLon): Double {
    val la1 = Math.toRadians(a.lat)
    val la2 = Math.toRadians(b.lat)
    val dl = Math.toRadians(b.lon - a.lon)
    val y = sin(dl) * cos(la2)
    val x = cos(la1) * sin(la2) - sin(la1) * cos(la2) * cos(dl)
    return (atan2(y, x) * 180 / PI + 360) % 360
}

// ---------------- Formatierung ----------------

fun String.cap(): String = replaceFirstChar { it.titlecase(Locale.GERMANY) }

fun Double.f6(): String = String.format(Locale.US, "%.6f", this)

fun fmtDuration(sec: Double): String {
    val m = (sec / 60).roundToInt()
    return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
}

fun fmtKm(m: Double): String = when {
    m < 1000 -> "${((m / 10).roundToInt() * 10)} m"
    m < 100_000 -> String.format(Locale.GERMANY, "%.1f km", m / 1000)
    else -> "${(m / 1000).roundToInt()} km"
}

/** Distanz im Banner: "350 m", "1,2 km", "18 km" */
fun fmtDistShort(m: Double): String = when {
    m < 100 -> "${((m / 10).roundToInt() * 10)} m"
    m < 1000 -> "${((m / 50).roundToInt() * 50)} m"
    m < 10_000 -> String.format(Locale.GERMANY, "%.1f km", m / 1000)
    else -> "${(m / 1000).roundToInt()} km"
}

fun fmtEta(remainingS: Double): String =
    LocalTime.now().plusSeconds(remainingS.toLong()).format(DateTimeFormatter.ofPattern("HH:mm"))

fun fmtPct(p: Double): String = "${p.roundToInt()} %"

/** Echter Akkustand vom Auto: auf Wunsch abgerundet wie im Kombiinstrument */
fun fmtSoc(p: Double): String =
    if (Settings.state.value.socFloor) "${kotlin.math.floor(p + 1e-6).toInt()} %" else fmtPct(p)

// ---------------- Einstellungen ----------------

enum class MapMode { AUTO, DAY, NIGHT }
enum class VehicleIcon { ARROW, CAR, DOT }

data class AppSettings(
    val mapMode: MapMode = MapMode.AUTO,
    val vehicle: VehicleIcon = VehicleIcon.ARROW,
    val carColor: Long = 0xFF0A84FF,
    val voice: Boolean = true,
    val avoidToll: Boolean = false,
    val avoidMotorway: Boolean = false,
    val avoidFerry: Boolean = false,
    // Runde 2
    val tomtomKey: String = "",
    val showTraffic: Boolean = true,
    val usableKwh: Double = 46.0,
    val socStart: Double = 80.0,
    val minSocStop: Double = 10.0,
    val minSocDest: Double = 15.0,
    val style: Int = 1, // 0 sparsam, 1 normal, 2 zügig
    // Runde 2b
    val preferOperators: Set<String> = emptySet(),
    val avoidOperators: Set<String> = emptySet(),
    val preferredMsps: Set<String> = emptySet(),
    val searchMinKw: Int = 50,
    // Runde 3: OBD2
    val obdAddress: String = "",
    val obdName: String = "",
    val obdAuto: Boolean = true,
    val obdSocSource: Int = 0, // 0 = D810, 1 = D410 (kalibriert)
    val obdVoltFactor: Double = 1.0 / 512.0,
    val obdCurrFactor: Double = 1.0,
    val obdCurrOffset: Double = 0.0,
    val obdCurrSigned: Boolean = true,
    val obdPowerEnabled: Boolean = false,
    val obdReplan: Boolean = true,
    val obdLogPolling: Boolean = false,
    // Runde 4: Lernen und ABRP-artige Einstellungen
    val learnEnabled: Boolean = true,
    val useLearned: Boolean = true,
    val refConsumptionPct: Int = 100, // Referenzverbrauch in % des Modells
    val maxSpeedKmh: Int = 0,         // 0 = keine Begrenzung
    val extraWeightKg: Int = 0,
    val socFloor: Boolean = true,     // Akkustand abrunden wie im Auto
    val corridorKm: Int = 10,         // Suchbreite neben der Route
    val mapFastOnly: Boolean = true,  // Karte: nur Schnelllader
    val offlineAuto: Boolean = true,      // Karte der Route automatisch speichern
    val offlineWifiOnly: Boolean = true,  // nur im WLAN
    val offlineDetail: Boolean = true,    // Zoom bis 14 (sonst 12)
    val mapStyle: Int = 0,                // 0 = Bright, 1 = Positron (hell, schlicht), 2 = TomTom
    val nightStyle: Int = 0,              // 0 = Fiord (dunkelblau, heller), 1 = Dunkel (fast schwarz)
    val poiEnabled: Boolean = true,       // Orte (POI) auf der Karte
    val poiCats: Set<String> = setOf("food", "shop", "wc"),
    val poiInNav: Boolean = false,        // auch während der Navigation
    val coachEnabled: Boolean = true,     // Tempo-Coach
    val coachVoice: Boolean = true,
    val reachEnabled: Boolean = true,     // Reichweiten-Blase
    val reachRoundTrip: Boolean = true,
    val routeBar: Boolean = true,         // Streckenleiste rechts in der Navigation
    val routeBarKm: Int = 50,
    val vehicleId: String = "citroen-ec4-1",
    val customDcKw: Int = 100,
    val carPhoto: Boolean = true,          // Fahrzeugkarte: eigenes Foto statt Grafik
    val ecoSummary: Boolean = true,        // Resümee mit Eco-Score nach jeder navigierten Fahrt
    val aiEnabled: Boolean = false,        // KI-Assistent
    val aiModel: String = "qwen35-2b",
    val aiThreads: Int = 4,
    val aiWifiOnly: Boolean = true,
) {
    val hasTomTom: Boolean get() = tomtomKey.isNotBlank()
}

object Settings {
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(AppSettings())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        SecureStore.init(ctx)
        // Alter Klartext-Key: einmalig verschlüsselt übernehmen und löschen
        prefs.getString("tomtomKey", null)?.let { old ->
            if (old.isNotBlank()) SecureStore.put("tomtomKey", old.trim())
            prefs.edit().remove("tomtomKey").commit()
        }
        val d = AppSettings()
        _state.value = AppSettings(
            mapMode = runCatching { MapMode.valueOf(prefs.getString("mapMode", d.mapMode.name)!!) }.getOrDefault(d.mapMode),
            vehicle = runCatching { VehicleIcon.valueOf(prefs.getString("vehicle", d.vehicle.name)!!) }.getOrDefault(d.vehicle),
            carColor = prefs.getLong("carColor", d.carColor),
            voice = prefs.getBoolean("voice", d.voice),
            avoidToll = prefs.getBoolean("avoidToll", d.avoidToll),
            avoidMotorway = prefs.getBoolean("avoidMotorway", d.avoidMotorway),
            avoidFerry = prefs.getBoolean("avoidFerry", d.avoidFerry),
            tomtomKey = SecureStore.get("tomtomKey"),
            showTraffic = prefs.getBoolean("showTraffic", d.showTraffic),
            usableKwh = prefs.getFloat("usableKwh", d.usableKwh.toFloat()).toDouble(),
            socStart = prefs.getFloat("socStart", d.socStart.toFloat()).toDouble(),
            minSocStop = prefs.getFloat("minSocStop", d.minSocStop.toFloat()).toDouble(),
            minSocDest = prefs.getFloat("minSocDest", d.minSocDest.toFloat()).toDouble(),
            style = prefs.getInt("style", d.style),
            preferOperators = prefs.getStringSet("preferOperators", emptySet())?.toSet() ?: emptySet(),
            avoidOperators = prefs.getStringSet("avoidOperators", emptySet())?.toSet() ?: emptySet(),
            preferredMsps = prefs.getStringSet("preferredMsps", emptySet())?.toSet() ?: emptySet(),
            searchMinKw = prefs.getInt("searchMinKw", d.searchMinKw),
            obdAddress = prefs.getString("obdAddress", "") ?: "",
            obdName = prefs.getString("obdName", "") ?: "",
            obdAuto = prefs.getBoolean("obdAuto", d.obdAuto),
            obdSocSource = prefs.getInt("obdSocSource", d.obdSocSource),
            obdVoltFactor = prefs.getFloat("obdVoltFactor", d.obdVoltFactor.toFloat()).toDouble(),
            obdCurrFactor = prefs.getFloat("obdCurrFactor", d.obdCurrFactor.toFloat()).toDouble(),
            obdCurrOffset = prefs.getFloat("obdCurrOffset", d.obdCurrOffset.toFloat()).toDouble(),
            obdCurrSigned = prefs.getBoolean("obdCurrSigned", d.obdCurrSigned),
            obdPowerEnabled = prefs.getBoolean("obdPowerEnabled", d.obdPowerEnabled),
            obdReplan = prefs.getBoolean("obdReplan", d.obdReplan),
            obdLogPolling = prefs.getBoolean("obdLogPolling", d.obdLogPolling),
            learnEnabled = prefs.getBoolean("learnEnabled", d.learnEnabled),
            useLearned = prefs.getBoolean("useLearned", d.useLearned),
            refConsumptionPct = prefs.getInt("refConsumptionPct", d.refConsumptionPct),
            maxSpeedKmh = prefs.getInt("maxSpeedKmh", d.maxSpeedKmh),
            extraWeightKg = prefs.getInt("extraWeightKg", d.extraWeightKg),
            socFloor = prefs.getBoolean("socFloor", d.socFloor),
            corridorKm = prefs.getInt("corridorKm", d.corridorKm),
            mapFastOnly = prefs.getBoolean("mapFastOnly", d.mapFastOnly),
            offlineAuto = prefs.getBoolean("offlineAuto", d.offlineAuto),
            offlineWifiOnly = prefs.getBoolean("offlineWifiOnly", d.offlineWifiOnly),
            offlineDetail = prefs.getBoolean("offlineDetail", d.offlineDetail),
            mapStyle = prefs.getInt("mapStyle", d.mapStyle),
            nightStyle = prefs.getInt("nightStyle", d.nightStyle),
            poiEnabled = prefs.getBoolean("poiEnabled", d.poiEnabled),
            poiCats = prefs.getStringSet("poiCats", d.poiCats)?.toSet() ?: d.poiCats,
            poiInNav = prefs.getBoolean("poiInNav", d.poiInNav),
            coachEnabled = prefs.getBoolean("coachEnabled", d.coachEnabled),
            coachVoice = prefs.getBoolean("coachVoice", d.coachVoice),
            reachEnabled = prefs.getBoolean("reachEnabled", d.reachEnabled),
            reachRoundTrip = prefs.getBoolean("reachRoundTrip", d.reachRoundTrip),
            vehicleId = prefs.getString("vehicleId", d.vehicleId) ?: d.vehicleId,
            routeBar = prefs.getBoolean("routeBar", d.routeBar),
            routeBarKm = prefs.getInt("routeBarKm", d.routeBarKm),
            customDcKw = prefs.getInt("customDcKw", d.customDcKw),
            carPhoto = prefs.getBoolean("carPhoto", d.carPhoto),
            ecoSummary = prefs.getBoolean("ecoSummary", d.ecoSummary),
            aiEnabled = prefs.getBoolean("aiEnabled", d.aiEnabled),
            aiModel = prefs.getString("aiModel", d.aiModel) ?: d.aiModel,
            aiThreads = prefs.getInt("aiThreads", d.aiThreads),
            aiWifiOnly = prefs.getBoolean("aiWifiOnly", d.aiWifiOnly),
        )
    }

    fun update(f: (AppSettings) -> AppSettings) {
        val old = _state.value
        val s = f(old)
        _state.value = s
        if (s.tomtomKey.trim() != old.tomtomKey.trim()) SecureStore.put("tomtomKey", s.tomtomKey.trim())
        prefs.edit()
            .putString("mapMode", s.mapMode.name)
            .putString("vehicle", s.vehicle.name)
            .putLong("carColor", s.carColor)
            .putBoolean("voice", s.voice)
            .putBoolean("avoidToll", s.avoidToll)
            .putBoolean("avoidMotorway", s.avoidMotorway)
            .putBoolean("avoidFerry", s.avoidFerry)
            .putBoolean("showTraffic", s.showTraffic)
            .putFloat("usableKwh", s.usableKwh.toFloat())
            .putFloat("socStart", s.socStart.toFloat())
            .putFloat("minSocStop", s.minSocStop.toFloat())
            .putFloat("minSocDest", s.minSocDest.toFloat())
            .putInt("style", s.style)
            .putStringSet("preferOperators", s.preferOperators)
            .putStringSet("avoidOperators", s.avoidOperators)
            .putStringSet("preferredMsps", s.preferredMsps)
            .putInt("searchMinKw", s.searchMinKw)
            .putString("obdAddress", s.obdAddress)
            .putString("obdName", s.obdName)
            .putBoolean("obdAuto", s.obdAuto)
            .putInt("obdSocSource", s.obdSocSource)
            .putFloat("obdVoltFactor", s.obdVoltFactor.toFloat())
            .putFloat("obdCurrFactor", s.obdCurrFactor.toFloat())
            .putFloat("obdCurrOffset", s.obdCurrOffset.toFloat())
            .putBoolean("obdCurrSigned", s.obdCurrSigned)
            .putBoolean("obdPowerEnabled", s.obdPowerEnabled)
            .putBoolean("obdReplan", s.obdReplan)
            .putBoolean("obdLogPolling", s.obdLogPolling)
            .putBoolean("learnEnabled", s.learnEnabled)
            .putBoolean("useLearned", s.useLearned)
            .putInt("refConsumptionPct", s.refConsumptionPct)
            .putInt("maxSpeedKmh", s.maxSpeedKmh)
            .putInt("extraWeightKg", s.extraWeightKg)
            .putBoolean("socFloor", s.socFloor)
            .putInt("corridorKm", s.corridorKm)
            .putBoolean("mapFastOnly", s.mapFastOnly)
            .putBoolean("offlineAuto", s.offlineAuto)
            .putBoolean("offlineWifiOnly", s.offlineWifiOnly)
            .putBoolean("offlineDetail", s.offlineDetail)
            .putInt("mapStyle", s.mapStyle)
            .putInt("nightStyle", s.nightStyle)
            .putBoolean("poiEnabled", s.poiEnabled)
            .putStringSet("poiCats", s.poiCats)
            .putBoolean("poiInNav", s.poiInNav)
            .putBoolean("coachEnabled", s.coachEnabled)
            .putBoolean("coachVoice", s.coachVoice)
            .putBoolean("reachEnabled", s.reachEnabled)
            .putBoolean("reachRoundTrip", s.reachRoundTrip)
            .putString("vehicleId", s.vehicleId)
            .putBoolean("routeBar", s.routeBar)
            .putInt("routeBarKm", s.routeBarKm)
            .putInt("customDcKw", s.customDcKw)
            .putBoolean("carPhoto", s.carPhoto)
            .putBoolean("ecoSummary", s.ecoSummary)
            .putBoolean("aiEnabled", s.aiEnabled)
            .putString("aiModel", s.aiModel)
            .putInt("aiThreads", s.aiThreads)
            .putBoolean("aiWifiOnly", s.aiWifiOnly)
            .apply()
    }

    /** Vermeiden-Optionen für OSRM */
    fun osrmExcludes(): List<String> {
        val s = _state.value
        return buildList {
            if (s.avoidToll) add("toll")
            if (s.avoidMotorway) add("motorway")
            if (s.avoidFerry) add("ferry")
        }
    }
}

/** Zähler für TomTom-Anfragen (frei: 2.500 pro Tag) */
object ApiCounter {
    private lateinit var prefs: SharedPreferences
    private val _today = MutableStateFlow(0)
    val today: StateFlow<Int> = _today.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("api", Context.MODE_PRIVATE)
        _today.value = if (prefs.getString("day", "") == LocalDate.now().toString()) prefs.getInt("count", 0) else 0
    }

    @Synchronized
    fun hit() {
        val day = LocalDate.now().toString()
        val n = if (prefs.getString("day", "") == day) prefs.getInt("count", 0) + 1 else 1
        prefs.edit().putString("day", day).putInt("count", n).apply()
        _today.value = n
    }
}

/** Zuletzt gesuchte Ziele */
object Recents {
    private lateinit var prefs: SharedPreferences
    private val _items = MutableStateFlow<List<Place>>(emptyList())
    val items: StateFlow<List<Place>> = _items.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("recents", Context.MODE_PRIVATE)
        val v2 = prefs.getString("list2", null)
        _items.value = if (v2 != null) {
            v2.lines().mapNotNull { line ->
                val p = line.split('\t')
                if (p.size < 5) null else runCatching {
                    Place(p[2], LatLon(p[0].toDouble(), p[1].toDouble()), p[3].ifBlank { null }, p[4])
                }.getOrNull()
            }
        } else {
            (prefs.getString("list", "") ?: "").lines().mapNotNull { line ->
                val p = line.split(';', limit = 3)
                if (p.size < 3) null else runCatching { Place(p[2], LatLon(p[0].toDouble(), p[1].toDouble())) }.getOrNull()
            }
        }
    }

    fun add(place: Place) {
        val list = (listOf(place) + _items.value.filter { it.name != place.name }).take(8)
        _items.value = list
        prefs.edit().putString(
            "list2",
            list.joinToString("\n") { "${it.pos.lat}\t${it.pos.lon}\t${it.name.replace('\t', ' ')}\t${it.osm ?: ""}\t${it.kind}" },
        ).apply()
    }
}

// ---------------- Runde 2b: Favoriten, Zwischenstopps, Ladestationen ----------------

enum class FavKind { HOME, WORK, OTHER }

data class Favorite(val id: String, val kind: FavKind, val label: String, val place: Place)

/** Zuhause, Arbeit und weitere Favoriten (nur auf dem Handy gespeichert) */
object Favorites {
    private lateinit var prefs: SharedPreferences
    private val _items = MutableStateFlow<List<Favorite>>(emptyList())
    val items: StateFlow<List<Favorite>> = _items.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("favorites", Context.MODE_PRIVATE)
        _items.value = (prefs.getString("list", "") ?: "").lines().mapNotNull { line ->
            val p = line.split('\t')
            if (p.size < 6) return@mapNotNull null
            runCatching {
                Favorite(p[0], FavKind.valueOf(p[1]), p[2], Place(p[5], LatLon(p[3].toDouble(), p[4].toDouble())))
            }.getOrNull()
        }
    }

    private fun save(list: List<Favorite>) {
        _items.value = list
        prefs.edit().putString(
            "list",
            list.joinToString("\n") { f ->
                listOf(f.id, f.kind.name, f.label.replace('\t', ' '), f.place.pos.lat, f.place.pos.lon, f.place.name.replace('\t', ' '))
                    .joinToString("\t")
            },
        ).apply()
    }

    fun get(kind: FavKind): Favorite? = _items.value.firstOrNull { it.kind == kind }

    fun set(kind: FavKind, place: Place, label: String? = null) {
        val list = _items.value.toMutableList()
        if (kind != FavKind.OTHER) list.removeAll { it.kind == kind }
        val name = label ?: when (kind) {
            FavKind.HOME -> "Zuhause"
            FavKind.WORK -> "Arbeit"
            FavKind.OTHER -> place.title
        }
        list += Favorite(System.nanoTime().toString(), kind, name, place)
        save(list)
    }

    fun rename(id: String, label: String) = save(_items.value.map { if (it.id == id) it.copy(label = label) else it })

    fun remove(id: String) = save(_items.value.filter { it.id != id })

/** Zwischenstopp; bei Ladestationen mit Ladepark-ID für TomTom */
data class Via(
    val place: Place,
    val pauseMin: Int = 0,
    val chargeParkId: String? = null,
    val isCharger: Boolean = false,
    val powerKw: Double = 0.0,
    val fromWish: Boolean = false, // automatisch aus den Wünschen erzeugt (wird beim Neuplanen ersetzt)
)

/** Wünsche für die Planung: nur/ohne bestimmte Ladeanbieter, Pause zu einer Uhrzeit an einem Ort */
data class TripWishes(
    val onlyOperators: Set<String> = emptySet(),
    val avoidOperators: Set<String> = emptySet(),
    val breakAtMin: Int? = null,     // Minuten nach Mitternacht, z. B. 12:00 = 720
    val breakQuery: String = "",     // z. B. „Burger King“
    val breakMin: Int = 30,
) {
    val active get() = onlyOperators.isNotEmpty() || avoidOperators.isNotEmpty() || (breakAtMin != null && breakQuery.isNotBlank())
}

/** Passt eine Ladestation zu einem der Anbieter-Namen? */
fun operatorMatches(h: ChargerHit, names: Set<String>): Boolean = names.any { n ->
    h.operator.contains(n, true) || h.name.contains(n, true) ||
        (n.equals("Tesla", true) && h.name.contains("Supercharger", true))
}

fun operatorMatchesName(operator: String, name: String, names: Set<String>): Boolean = names.any { n ->
    operator.contains(n, true) || name.contains(n, true) || (n.equals("Tesla", true) && name.contains("Supercharger", true))
}

/** Treffer der Ladesäulen-Suche entlang der Route */
data class ChargerHit(
    val name: String,
    val operator: String,
    val pos: LatLon,
    val powerKw: Double,
    val detourS: Double,
    val alongM: Double,
    val availId: String?,
    val id: String = "",
    val offsetM: Double = 0.0,      // Abstand zur Route
    val connectors: String = "",    // z. B. "4× CCS · 2× Typ 2"
    val teslaOnly: Boolean = false, // nur Tesla-Stecker gemeldet
    val address: String = "",
    val connectorGroups: List<String> = emptyList(), // z. B. "6× CCS · 300 kW"
    val openingLines: List<String> = emptyList(),
    val stopAlongRef: Double? = null,               // Lage des ersetzten Stopps (für Sortierung)
)

/** Betreiber, die in Routen und Suchen auftauchen (für die Auswahl in den Einstellungen) */
object KnownOperators {
    private lateinit var prefs: SharedPreferences
    private val _items = MutableStateFlow<Set<String>>(emptySet())
    val items: StateFlow<Set<String>> = _items.asStateFlow()

    val PRESET = listOf(
        "IONITY", "Tesla", "EnBW", "Fastned", "Allego", "Aral pulse", "Shell Recharge", "E.ON Drive",
        "EWE Go", "Pfalzwerke", "Electra", "Atlante", "Iberdrola", "Endesa X", "Repsol", "Powerdot",
        "Zunder", "TotalEnergies",
    )
    val MSPS = listOf(
        "EnBW mobility+", "Maingau EinfachStromLaden", "ADAC e-Charge", "Shell Recharge", "Plugsurfing",
        "Elli", "Electroverse", "IONITY", "Tesla", "Chargemap",
    )

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("operators", Context.MODE_PRIVATE)
        _items.value = prefs.getStringSet("seen", emptySet())?.toSet() ?: emptySet()
    }

    fun note(names: Collection<String>) {
        val add = names.map { it.trim() }.filter { it.isNotBlank() && it.length < 60 }.toSet()
        if (add.isEmpty() || _items.value.containsAll(add)) return
        val all = (_items.value + add).take(80).toSet()
        _items.value = all
        prefs.edit().putStringSet("seen", all).apply()
    }
}
