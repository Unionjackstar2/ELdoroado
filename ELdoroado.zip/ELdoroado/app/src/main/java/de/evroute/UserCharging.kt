package de.evroute

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Eigene Ladestopps (z. B. eine selbst gewählte Tesla-Station):
 * Die Route wird an jeder dieser Stationen geteilt, jeder Teil von TomTom geplant,
 * das Laden an der Station selbst berechnet und alles wieder zu einer Route zusammengefügt.
 */
object UserCharging {
    private const val TARGET = 80.0 // höchstens bis hierhin an eigenen Stopps laden

    /** Ladezeit (s) von→bis Prozent mit der (ggf. gelernten) Ladekurve und der Stationsleistung */
    fun chargeSeconds(fromPct: Double, toPct: Double, stationKw: Double, usable: Double): Double {
        if (toPct <= fromPct) return 0.0
        val curve = EvModel.batteryCurve(usable).map { (kwh, kw) -> kwh / usable * 100 to kw }
        fun curveAt(soc: Double): Double {
            val i = curve.indexOfFirst { it.first >= soc }
            if (i <= 0) return curve.first().second
            val (a, pa) = curve[i - 1]
            val (b, pb) = curve[i]
            return pa + (pb - pa) * ((soc - a) / (b - a).coerceAtLeast(0.01))
        }
        val station = if (stationKw > 0) stationKw else 50.0
        var s = fromPct
        var sec = 0.0
        while (s < toPct) {
            val step = min(1.0, toPct - s)
            val p = (min(curveAt(s), station) * 0.92).coerceAtLeast(3.0)
            sec += usable * step / 100 / p * 3600
            s += step
        }
        return sec + 120 // An- und Abstecken
    }

    /** Route mit eigenen Ladestopps planen */
    suspend fun plan(
        set: AppSettings,
        from: LatLon,
        heading: Float?,
        to: LatLon,
        socPct: Double,
        vias: List<Via>,
        avoid: List<String>,
        avoidParks: List<String>,
        w: WeatherInfo?,
    ): Route {
        // Abschnitte: jeweils bis zur nächsten eigenen Ladestation (dazwischenliegende normale Stopps bleiben drin)
        data class Leg(val start: LatLon, val end: LatLon, val vias: List<Via>, val charger: Via?)
        val legs = mutableListOf<Leg>()
        var start = from
        var pending = mutableListOf<Via>()
        for (v in vias) {
            if (v.isCharger) {
                legs += Leg(start, v.place.pos, pending.toList(), v)
                start = v.place.pos
                pending = mutableListOf()
            } else {
                pending += v
            }
        }
        legs += Leg(start, to, pending.toList(), null)

        val parts = mutableListOf<Route>()
        val userStops = mutableListOf<ChargeStop?>()
        var soc = socPct
        legs.forEachIndexed { k, leg ->
            // Abschnitte, die an einer Ladestation enden, brauchen dort nur die Lade-Reserve
            val legSet = if (leg.charger != null) set.copy(minSocDest = set.minSocStop) else set
            var r = TomTom.ldev(legSet, leg.start, if (k == 0) heading else null, leg.end, soc, w, avoid, 0, avoidParks, leg.vias, 0).first()

            if (k > 0) {
                // Am vorherigen eigenen Stopp nur so weit laden wie nötig
                val prevStop = userStops.last()!!
                val needAtEnd = if (leg.charger != null) set.minSocStop else set.minSocDest
                val arrival = r.arrivalSoc ?: needAtEnd
                if (r.stops.isEmpty() && arrival > needAtEnd + 3) {
                    val lower = max(prevStop.arriveSoc + 5, soc - (arrival - needAtEnd - 3))
                    val delta = lower - soc
                    r = shiftSoc(r, delta)
                    soc = lower
                    val newStop = prevStop.copy(
                        targetSoc = soc,
                        chargeS = chargeSeconds(prevStop.arriveSoc, soc, prevStop.powerKw, set.usableKwh),
                    )
                    userStops[userStops.lastIndex] = newStop
                }
            }
            parts += r

            if (leg.charger != null) {
                val arrive = r.arrivalSoc ?: set.minSocStop
                val target = max(TARGET, arrive + 5).coerceAtMost(100.0)
                val c = leg.charger
                userStops += ChargeStop(
                    name = c.place.title,
                    operator = "",
                    pos = c.place.pos,
                    alongM = 0.0, // wird beim Zusammenfügen gesetzt
                    powerKw = if (c.powerKw > 0) c.powerKw else 50.0,
                    arriveSoc = arrive,
                    targetSoc = target,
                    chargeS = chargeSeconds(arrive, target, c.powerKw, set.usableKwh),
                    uuid = c.chargeParkId,
                )
                soc = target
            }
        }
        return merge(parts, userStops)
    }

    /** Akkustand einer Teilroute verschieben (wenn mit anderem Start-Akku geladen wurde) */
    private fun shiftSoc(r: Route, d: Double): Route = r.copy(
        socProfile = r.socProfile.map { (m, p) -> m to p + d },
        arrivalSoc = r.arrivalSoc?.plus(d),
        stops = r.stops.map { it.copy(arriveSoc = it.arriveSoc + d) },
    )

    /** Teilrouten zu einer Route zusammenfügen; zwischen den Teilen liegen die eigenen Ladestopps */
    private fun merge(parts: List<Route>, userStops: List<ChargeStop?>): Route {
        val points = mutableListOf<LatLon>()
        val cum = mutableListOf<Double>()
        val steps = mutableListOf<Step>()
        val stepAlong = mutableListOf<Double>()
        val stepTime = mutableListOf<Double>()
        val stops = mutableListOf<ChargeStop>()
        val profile = mutableListOf<Pair<Double, Double>>()
        val jams = mutableListOf<Jam>()
        val lanes = mutableListOf<LaneSection>()
        val limits = mutableListOf<Int>()
        var anyLimits = false
        var offM = 0.0
        var offT = 0.0
        var driveS = 0.0
        var chargeS = 0.0
        var delay = 0.0
        var feasible = true
        var reason: String? = null

        parts.forEachIndexed { k, r ->
            val offIdx = points.size
            // Punkte und Strecke
            if (k > 0 && limits.isNotEmpty()) limits += 0 // Übergangsstück zwischen zwei Teilen
            points += r.points
            r.cumM.forEach { cum += it + offM }
            r.speedLimits?.let { anyLimits = true; limits += it.toList() } ?: run { limits += List(max(0, r.points.size - 1)) { 0 } }
            // Ladezeiten innerhalb des Teils in die Zeiten einrechnen, falls TomTom sie nicht enthält
            fun timeAt(i: Int): Double {
                var t = r.stepTimeS[i]
                if (!r.timesIncludeCharging) t += r.stops.filter { it.alongM <= r.stepAlongM[i] + 1 }.sumOf { it.chargeS }
                return t + offT
            }
            val userStop = userStops.getOrNull(k)
            r.steps.forEachIndexed { i, st ->
                if (k > 0 && i == 0 && st.type == "depart") return@forEachIndexed
                var step = st
                if (st.type == "arrive" && k < parts.lastIndex && userStop != null) {
                    step = st.copy(
                        type = "charge", mod = null, road = userStop.name,
                        phrase = Phrases.build("charge", null, null),
                        note = "Laden auf ${userStop.targetSoc.roundToInt()} Prozent, etwa ${(userStop.chargeS / 60).roundToInt()} Minuten.",
                    )
                }
                steps += step
                stepAlong += r.stepAlongM[i] + offM
                stepTime += timeAt(i)
            }
            r.stops.forEach { stops += it.copy(alongM = it.alongM + offM) }
            r.socProfile.forEach { (m, p) -> profile += (m + offM) to p }
            r.jams.forEach { jams += it.copy(startIdx = it.startIdx + offIdx, endIdx = it.endIdx + offIdx) }
            r.laneSections.forEach { lanes += it.copy(startIdx = it.startIdx + offIdx, endIdx = it.endIdx + offIdx) }

            val partTime = (r.stepTimeS.lastOrNull() ?: r.driveS) + if (!r.timesIncludeCharging) r.chargeS else 0.0
            driveS += r.driveS
            chargeS += r.chargeS
            delay += r.trafficDelayS
            if (!r.feasible) { feasible = false; if (reason == null) reason = r.reason }
            offM += r.cumM.lastOrNull() ?: 0.0
            offT += partTime

            // eigener Ladestopp am Ende dieses Teils
            if (userStop != null && k < parts.lastIndex) {
                stops += userStop.copy(alongM = offM)
                profile += offM to userStop.targetSoc
                chargeS += userStop.chargeS
                offT += userStop.chargeS
            }
        }
        val first = parts.first()
        val last = parts.last()
        return Route(
            points = points,
            cumM = cum.toDoubleArray(),
            stepAlongM = stepAlong.toDoubleArray(),
            stepTimeS = stepTime.toDoubleArray(),
            distanceM = parts.sumOf { it.distanceM },
            durationS = driveS + chargeS,
            driveS = driveS,
            steps = steps,
            summary = parts.map { it.summary }.filter { it.isNotBlank() }.joinToString(", ").split(", ").distinct().take(4).joinToString(", "),
            source = "TomTom",
            stops = stops,
            socProfile = profile,
            arrivalSoc = last.arrivalSoc,
            chargeS = chargeS,
            trafficDelayS = delay,
            jams = jams,
            timesIncludeCharging = true,
            feasible = feasible,
            reason = reason,
            weather = first.weather,
            speedLimits = if (anyLimits && limits.size == points.size - 1) limits.toIntArray() else null,
            laneSections = lanes,
        )
    }
}
