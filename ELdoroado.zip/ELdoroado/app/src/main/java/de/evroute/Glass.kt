package de.evroute

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeChild

/** Gesetzt, wenn „echte Unschärfe“ an ist: Quelle ist die Karte */
val LocalHaze = staticCompositionLocalOf<HazeState?> { null }

/**
 * Glasfläche im Stil von „Liquid Glass“: leicht transparent, feine helle Lichtkante (oben stärker),
 * zarter Glanz von oben, weicher Schatten. Mit echter Unschärfe verschwimmt die Karte dahinter.
 */
@Composable
fun Modifier.glass(shape: Shape, elevation: Dp = 10.dp, tint: Color? = null): Modifier {
    val pal = LocalPal.current
    val haze = LocalHaze.current
    val dark = pal.dark
    val base = tint ?: if (dark) Color(0xFF171A20) else Color.White
    val fill = base.copy(alpha = if (haze != null) (if (dark) 0.52f else 0.46f) else (if (dark) 0.80f else 0.76f))
    var m = this
        .shadow(elevation, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.22f), spotColor = Color.Black.copy(alpha = 0.28f))
        .clip(shape)
    m = if (haze != null) {
        m.hazeChild(haze, HazeStyle(backgroundColor = base, tint = HazeTint(fill), blurRadius = 22.dp, noiseFactor = 0.04f))
    } else {
        m.background(fill)
    }
    return m
        .background(Brush.verticalGradient(0f to Color.White.copy(alpha = if (dark) 0.10f else 0.38f), 0.5f to Color.Transparent))
        .border(
            1.dp,
            Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.34f else 0.90f), Color.White.copy(alpha = if (dark) 0.06f else 0.30f))),
            shape,
        )
}
