package de.evroute

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/** Brücke zur nativen llama.cpp-Bibliothek */
object LlamaNative {
    val available: Boolean by lazy { runCatching { System.loadLibrary("evllm"); true }.getOrDefault(false) }
    external fun nativeLoad(path: String, threads: Int, nCtx: Int): Long
    external fun nativeFree(h: Long)
    external fun nativeTemplate(h: Long, system: String, user: String): ByteArray
    external fun nativeGenerate(h: Long, prompt: String, grammar: String, maxTokens: Int, temp: Float): ByteArray
}

/** Ein herunterladbares Modell */
data class LlmModel(val id: String, val name: String, val sizeLabel: String, val url: String, val file: String, val note: String, val format: String)

object LlmModels {
    val ALL = listOf(
        LlmModel(
            "qwen35-2b", "Qwen3.5 2B", "ca. 1,3 GB",
            "https://huggingface.co/unsloth/Qwen3.5-2B-GGUF/resolve/main/Qwen3.5-2B-Q4_K_M.gguf",
            "qwen35-2b-q4km.gguf", "Empfohlen: sehr zuverlässiges JSON, gutes Deutsch", "chatml",
        ),
        LlmModel(
            "gemma4-e2b", "Gemma 4 E2B", "ca. 1,5–3 GB",
            "https://huggingface.co/Hanish/quill-models/resolve/main/gemma-4-E2B-it-Q4_0.gguf",
            "gemma4-e2b-q40.gguf", "Von Google, fürs Handy optimiert (Gemma-Nutzungsbedingungen)", "gemma",
        ),
        LlmModel(
            "qwen35-08b", "Qwen3.5 0.8B", "ca. 0,5 GB",
            "https://huggingface.co/unsloth/Qwen3.5-0.8B-GGUF/resolve/main/Qwen3.5-0.8B-Q4_K_M.gguf",
            "qwen35-08b-q4km.gguf", "Sparsam und schnell, liegt öfter daneben", "chatml",
        ),
    )

    fun byId(id: String) = ALL.firstOrNull { it.id == id } ?: ALL.first()
    fun dir(ctx: Context) = File(ctx.filesDir, "models").apply { mkdirs() }
    fun fileOf(ctx: Context, m: LlmModel) = File(dir(ctx), m.file)
    fun isDownloaded(ctx: Context, m: LlmModel) = fileOf(ctx, m).let { it.exists() && it.length() > 50_000_000 }
}

/** Herunterladen der Modelle mit Fortschritt */
object ModelDownloads {
    data class Progress(val modelId: String, val doneMb: Double, val totalMb: Double, val error: String? = null, val finished: Boolean = false)

    private val scope = MainScope()
    private val _state = MutableStateFlow<Progress?>(null)
    val state: StateFlow<Progress?> = _state.asStateFlow()
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()
    private var cancel = false
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).followRedirects(true).build()

    fun start(ctx: Context, m: LlmModel) {
        if (_state.value?.let { !it.finished && it.error == null } == true) return
        cancel = false
        _state.value = Progress(m.id, 0.0, 0.0)
        scope.launch {
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    val target = LlmModels.fileOf(ctx, m)
                    val part = File(target.path + ".part")
                    val have = if (part.exists()) part.length() else 0L
                    val req = Request.Builder().url(m.url).header("User-Agent", "EVRoute").apply { if (have > 0) header("Range", "bytes=$have-") }.build()
                    client.newCall(req).execute().use { r ->
                        if (r.code != 200 && r.code != 206) error("Download fehlgeschlagen (${r.code})")
                        val resume = r.code == 206
                        val len = (r.body?.contentLength() ?: -1L)
                        val total = if (len > 0) len + (if (resume) have else 0L) else -1L
                        var done = if (resume) have else 0L
                        val input = r.body!!.byteStream()
                        java.io.FileOutputStream(part, resume).use { out ->
                            val buf = ByteArray(256 * 1024)
                            var last = 0L
                            while (true) {
                                if (cancel) error("Abgebrochen")
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                if (done - last > 4_000_000) {
                                    last = done
                                    _state.value = Progress(m.id, done / 1e6, if (total > 0) total / 1e6 else 0.0)
                                }
                            }
                        }
                        if (total > 0 && done < total) error("Download unvollständig")
                        part.renameTo(target)
                    }
                }
            }
            _state.value = res.fold({ Progress(m.id, 0.0, 0.0, finished = true) }, { e -> Progress(m.id, 0.0, 0.0, error = e.message) })
            _version.value++
        }
    }

    fun cancel() { cancel = true }

    fun delete(ctx: Context, m: LlmModel) {
        LlmModels.fileOf(ctx, m).delete()
        File(LlmModels.fileOf(ctx, m).path + ".part").delete()
        LlmEngine.unload()
        _version.value++
    }
}

/** Das geladene Sprachmodell (nur eines gleichzeitig) */
object LlmEngine {
    private var handle = 0L
    private var loadedPath: String? = null
    private var format = "chatml"
    private val mutex = Mutex()

    suspend fun ensure(ctx: Context): String? = withContext(Dispatchers.Default) {
        if (!LlamaNative.available) return@withContext "Der KI-Assistent ist auf diesem Gerät nicht verfügbar (nur 64-Bit-ARM)."
        val m = LlmModels.byId(Settings.state.value.aiModel)
        val f = LlmModels.fileOf(ctx, m)
        if (!LlmModels.isDownloaded(ctx, m)) return@withContext "Bitte zuerst das Modell herunterladen (Einstellungen → KI-Assistent)."
        mutex.withLock {
            if (loadedPath != f.path) {
                if (handle != 0L) LlamaNative.nativeFree(handle)
                handle = LlamaNative.nativeLoad(f.path, Settings.state.value.aiThreads.coerceIn(2, 8), 4096)
                loadedPath = if (handle != 0L) f.path else null
                format = m.format
            }
        }
        if (handle == 0L) "Das Modell konnte nicht geladen werden." else null
    }

    fun unload() {
        if (handle != 0L) runCatching { LlamaNative.nativeFree(handle) }
        handle = 0L
        loadedPath = null
    }

    /** Eine Anfrage: Systemanweisung + Nutzertext, optional mit Grammatik */
    suspend fun ask(system: String, user: String, grammar: String?, maxTokens: Int, temp: Float): String = withContext(Dispatchers.Default) {
        mutex.withLock {
            if (handle == 0L) return@withLock ""
            var prompt = String(LlamaNative.nativeTemplate(handle, system, user), Charsets.UTF_8)
            if (prompt.isBlank()) prompt = when (format) {
                "gemma" -> "<start_of_turn>user\n$system\n\n$user<end_of_turn>\n<start_of_turn>model\n"
                else -> "<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n"
            }
            String(LlamaNative.nativeGenerate(handle, prompt, grammar ?: "", maxTokens, temp), Charsets.UTF_8)
        }
    }
}

// ======================= Der Navi-Assistent =======================

object Assistant {
    data class Msg(val fromUser: Boolean, val text: String, val showRoute: Boolean = false)
    data class State(val messages: List<Msg> = emptyList(), val busy: Boolean = false, val status: String = "")

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    /** Erzwingt gültiges JSON in genau diesem Format */
    private val GRAMMAR = """
root ::= "{" ws "\"aktion\"" ws ":" ws aktion ws "," ws "\"start\"" ws ":" ws strnull ws "," ws "\"ziel\"" ws ":" ws strnull ws "," ws "\"ueber\"" ws ":" ws strarr ws "," ws "\"nurAnbieter\"" ws ":" ws strarr ws "," ws "\"ohneAnbieter\"" ws ":" ws strarr ws "," ws "\"pauseUhrzeit\"" ws ":" ws strnull ws "," ws "\"pauseOrt\"" ws ":" ws strnull ws "," ws "\"pauseMinuten\"" ws ":" ws intnull ws "}"
aktion ::= "\"planen\"" | "\"aendern\"" | "\"abbrechen\"" | "\"unklar\""
strnull ::= str | "null"
str ::= "\"" chars "\""
chars ::= [^"\\\n]*
strarr ::= "[" ws ( str ( ws "," ws str )* )? ws "]"
intnull ::= [0-9] [0-9]? [0-9]? | "null"
ws ::= [ \t\n]*
""".trim()

    private val SYSTEM_EXTRACT = """
Du bist der Übersetzer eines Navigationssystems. Wandle die Nachricht des Fahrers in JSON um. Erfinde nichts.
Felder:
- aktion: "planen" (neue Route), "aendern" (bestehende Route anpassen), "abbrechen" (Route verwerfen), "unklar" (keine Routenanfrage, z. B. Wetter, Strand, Smalltalk)
- start: Startort oder null (null = aktueller Standort)
- ziel: das GENAUE Ziel mit Ort, z. B. "Dechenhöhle, Iserlohn", "IKEA, Dortmund", "Varazze, Italien". Geschäfte, Sehenswürdigkeiten und Adressen nie weglassen. Sonst null
- ueber: Zwischenstopps (Orte)
- nurAnbieter: Ladeanbieter, die ausschließlich genutzt werden sollen (z. B. "Tesla", "EnBW", "IONITY")
- ohneAnbieter: Ladeanbieter, die gemieden werden sollen
- pauseUhrzeit: "HH:MM" oder null; "mittags" = "12:00"
- pauseOrt: Ort/Marke der Pause, z. B. "Burger King", "IKEA", "Raststätte", oder null
- pauseMinuten: Dauer in Minuten oder null
Beispiele:
Nachricht: Route von Herdecke nach Varazze, aber nur EnBW und Tesla Lader und um ca. 12 Uhr Pause bei Burger King
JSON: {"aktion":"planen","start":"Herdecke","ziel":"Varazze, Italien","ueber":[],"nurAnbieter":["EnBW","Tesla"],"ohneAnbieter":[],"pauseUhrzeit":"12:00","pauseOrt":"Burger King","pauseMinuten":null}
Nachricht: navigieren zur Dechenhöhle in Iserlohn
JSON: {"aktion":"planen","start":null,"ziel":"Dechenhöhle, Iserlohn","ueber":[],"nurAnbieter":[],"ohneAnbieter":[],"pauseUhrzeit":null,"pauseOrt":null,"pauseMinuten":null}
Nachricht: navigieren nach IKEA in Dortmund
JSON: {"aktion":"planen","start":null,"ziel":"IKEA, Dortmund","ueber":[],"nurAnbieter":[],"ohneAnbieter":[],"pauseUhrzeit":null,"pauseOrt":null,"pauseMinuten":null}
Nachricht: Ich will nach Hamburg über Bremen, ohne IONITY
JSON: {"aktion":"planen","start":null,"ziel":"Hamburg","ueber":["Bremen"],"nurAnbieter":[],"ohneAnbieter":["IONITY"],"pauseUhrzeit":null,"pauseOrt":null,"pauseMinuten":null}
Nachricht: Statt Burger King lieber McDonald's, eine Stunde
JSON: {"aktion":"aendern","start":null,"ziel":null,"ueber":[],"nurAnbieter":[],"ohneAnbieter":[],"pauseUhrzeit":null,"pauseOrt":"McDonald's","pauseMinuten":60}
Nachricht: Wie ist das Wetter in Varazze?
JSON: {"aktion":"unklar","start":null,"ziel":null,"ueber":[],"nurAnbieter":[],"ohneAnbieter":[],"pauseUhrzeit":null,"pauseOrt":null,"pauseMinuten":null}
""".trim()

    private val SYSTEM_REPLY = """
Du bist der freundliche Navi-Assistent. Formuliere aus den FAKTEN eine kurze Antwort auf Deutsch (2 bis 3 Sätze, Du-Form).
Verwende nur Zahlen, Orte und Namen aus den FAKTEN. Erfinde nichts. Keine Aufzählungszeichen, keine Rückfragen.
""".trim()

    fun clear() { _state.value = State() }

    fun ask(ctx: Context, text: String) {
        if (text.isBlank() || _state.value.busy) return
        _state.update { it.copy(messages = it.messages + Msg(true, text.trim()), busy = true, status = "Lade Modell …") }
        scope.launch {
            val reply = runCatching { handle(ctx, text.trim()) }.getOrElse { e ->
                CrashLog.note("KI-Assistent: ${e.message}")
                Msg(false, "Da ist etwas schiefgelaufen: ${e.message}")
            }
            _state.update { it.copy(messages = it.messages + reply, busy = false, status = "") }
        }
    }

    private fun JsonObject.s(k: String) = (this[k] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() && it != "null" }
    private fun JsonObject.list(k: String) = (this[k] as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull?.takeIf { s -> s.isNotBlank() } } ?: emptyList()

    /** „… nach/zur/zum X in Y …“ → „X, Y“ (ohne KI) */
    fun destinationFromText(text: String): String? {
        val m = Regex("(?i)\\b(?:nach|zur|zum|zu|richtung|ins|in die|in den)\\s+(.+?)(?=\\s*[,.!?]|\\s+(?:aber|und|mit|nur|ohne|um|über|bitte|fahren|navigieren)\\b|$)").find(text) ?: return null
        val raw = m.groupValues[1].trim().removePrefix("dem ").removePrefix("der ").removePrefix("die ").removePrefix("den ")
        if (raw.isBlank()) return null
        val parts = raw.split(Regex("(?i)\\s+in\\s+"), limit = 2)
        return if (parts.size == 2) "${parts[0].trim()}, ${parts[1].trim()}" else raw
    }

    /** Ort finden: bei „Geschäft/Sehenswürdigkeit, Stadt“ den passenden Treffer statt der Stadtmitte nehmen */
    suspend fun resolvePlace(name: String, me: LatLon?): Place? {
        val hits = runCatching { Geocode.search(name, me) }.getOrDefault(emptyList())
        val poi = name.substringBefore(",").trim()
        val city = name.substringAfter(",", "").trim()
        if (city.isBlank()) return hits.firstOrNull()
        val word = poi.split(" ").firstOrNull { it.length >= 3 } ?: poi
        hits.firstOrNull { it.name.contains(word, true) }?.let { return it }
        // Fallback: Stadt finden, dort gezielt nach dem Ort suchen (TomTom)
        val c = runCatching { Geocode.search(city, me).firstOrNull() }.getOrNull() ?: return hits.firstOrNull()
        val set = Settings.state.value
        if (set.hasTomTom) {
            runCatching { TomTom.poiSearch(set.tomtomKey.trim(), poi, c.pos, 20_000) }.getOrNull()
                ?.firstOrNull { it.name.contains(word, true) }?.let { return it }
        }
        return hits.firstOrNull() ?: c
    }

    private suspend fun handle(ctx: Context, text: String): Msg {
        LlmEngine.ensure(ctx)?.let { return Msg(false, it) }
        _state.update { it.copy(status = "Verstehe …") }
        val nav0 = NavSession.state.value
        val context = nav0.dest?.let { d ->
            "Aktuelle Route: nach ${d.title}" + (if (nav0.vias.isNotEmpty()) " über ${nav0.vias.joinToString { it.place.title }}" else "") +
                (nav0.wishes.breakQuery.takeIf { it.isNotBlank() }?.let { ", Pause bei $it" } ?: "")
        } ?: "Es ist noch keine Route geplant."
        val raw = LlmEngine.ask(SYSTEM_EXTRACT, "$context\nNachricht: $text\nJSON:", GRAMMAR, 220, 0.1f)
        val o = runCatching { json.parseToJsonElement(raw.trim()).jsonObject }.getOrNull()
            ?: return Msg(false, "Das habe ich leider nicht verstanden. Versuch es zum Beispiel mit: „Nach Hamburg, nur Tesla, mittags Pause bei IKEA.“")
        when (o.s("aktion")) {
            "unklar" -> return Msg(false, "Dabei kann ich dir nicht helfen – ich plane nur deine Route.")
            "abbrechen" -> { NavSession.clear(); return Msg(false, "Alles klar, ich habe die Route verworfen.") }
        }

        _state.update { it.copy(status = "Suche Orte …") }
        val me = LocationHub.fix.value?.pos
        suspend fun find(name: String): Place? = resolvePlace(name, me)
        val change = o.s("aktion") == "aendern" && nav0.dest != null
        // Sicherheitsnetz: Ziel direkt aus dem Satz lesen, falls die KI es weglässt oder kürzt
        val fromText = destinationFromText(text)
        val llmDest = o.s("ziel")
        val wanted = when {
            llmDest == null -> fromText
            fromText != null && fromText.length > llmDest.length && fromText.contains(llmDest.substringBefore(",").trim(), true) -> fromText
            else -> llmDest
        }
        val dest = wanted?.let { find(it) ?: return Msg(false, "Den Ort „$it“ habe ich nicht gefunden.") } ?: nav0.dest
            ?: return Msg(false, "Wohin soll es gehen? Nenn mir bitte ein Ziel.")
        val start = o.s("start")?.let { s -> if (me != null && s.equals("hier", true)) null else find(s) }
        val viaNames = o.list("ueber")
        val vias = if (viaNames.isNotEmpty()) viaNames.mapNotNull { find(it)?.let { p -> Via(p) } } else if (change) nav0.vias.filterNot { it.fromWish } else emptyList()

        val known = (KnownOperators.items.value + listOf("Tesla", "EnBW", "IONITY", "Fastned", "Aral pulse", "Shell Recharge", "EWE Go", "Allego", "Electra", "E.ON", "Atlante"))
        fun norm(list: List<String>) = list.map { n -> known.firstOrNull { it.equals(n, true) || it.contains(n, true) || n.contains(it, true) } ?: n }.toSet()
        val w0 = if (change) nav0.wishes else TripWishes()
        val time = o.s("pauseUhrzeit")?.let { t -> Regex("(\\d{1,2})(?::(\\d{2}))?").find(t)?.let { m -> m.groupValues[1].toInt() * 60 + (m.groupValues[2].toIntOrNull() ?: 0) } }
        val wishes = w0.copy(
            onlyOperators = norm(o.list("nurAnbieter")).ifEmpty { w0.onlyOperators },
            avoidOperators = norm(o.list("ohneAnbieter")).ifEmpty { w0.avoidOperators },
            breakAtMin = time ?: w0.breakAtMin ?: if (o.s("pauseOrt") != null) 12 * 60 else null,
            breakQuery = o.s("pauseOrt") ?: w0.breakQuery,
            breakMin = (o["pauseMinuten"] as? JsonPrimitive)?.intOrNull ?: w0.breakMin,
        )

        _state.update { it.copy(status = "Plane Route …") }
        NavSession.planFromAssistant(dest, vias, start, wishes)
        val done = withTimeoutOrNull(120_000) { NavSession.state.first { !it.loading && (it.route != null || it.error != null) } }
            ?: return Msg(false, "Die Planung dauert ungewöhnlich lange. Schau gleich im Routenfenster nach.")
        if (done.error != null) return Msg(false, "Die Planung hat nicht geklappt: ${done.error}")
        val r = done.route ?: return Msg(false, "Ich konnte keine Route finden.")

        // Fakten aus der App (nur diese darf die KI nennen)
        val facts = buildString {
            appendLine("Ziel: ${dest.title.substringBefore(",")}")
            appendLine("Dauer: ${fmtDuration(r.durationS)}, Strecke ${fmtKm(r.distanceM)}, Ankunft ${fmtEta(r.durationS)}")
            appendLine("Ladestopps: ${r.stops.size}" + if (r.stops.isNotEmpty()) " (" + r.stops.joinToString { it.name.substringBefore(",") } + ")" else "")
            if (wishes.onlyOperators.isNotEmpty()) {
                val mine = r.stops.count { operatorMatchesName(it.operator, it.name, wishes.onlyOperators) }
                appendLine("Davon bei ${wishes.onlyOperators.joinToString(", ")}: $mine, bei anderen Anbietern: ${r.stops.size - mine}")
            }
            r.arrivalSoc?.let { appendLine("Akku am Ziel: ${it.roundToInt()} %") }
            done.planNote?.takeIf { it.isNotBlank() }?.let { appendLine("Hinweise: $it") }
        }
        _state.update { it.copy(status = "Formuliere …") }
        val text2 = LlmEngine.ask(SYSTEM_REPLY, "FAKTEN:\n$facts", null, 160, 0.4f)
            .replace(Regex("(?s)<think>.*?</think>"), "").trim()
        val fallback = "Route nach ${dest.title.substringBefore(",")}: ${fmtDuration(r.durationS)}, ${r.stops.size} Ladestopps, Ankunft ${fmtEta(r.durationS)}" +
            (r.arrivalSoc?.let { " mit ${it.roundToInt()} %" } ?: "") + "." + (done.planNote?.let { " $it." } ?: "")
        return Msg(false, text2.ifBlank { fallback }.take(600), showRoute = true)
    }
}
