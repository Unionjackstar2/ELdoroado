@file:OptIn(ExperimentalMaterial3Api::class)

package de.evroute

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import dev.chrisbanes.haze.haze
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.ZoomOutMap
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Adjust
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.animation.core.animate
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.speech.RecognizerIntent
import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.material.icons.filled.Mic
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.roundToInt

// ---------------- Farben im Apple-Stil ----------------

/** Farbschema: TomTom-Klarheit, Apple-Ruhe, Material-3-Expressive-Formen */
class Pal(val dark: Boolean) {
    val card = if (dark) Color(0xFF1E2126) else Color(0xFFFFFFFF)
    val cardSolid = if (dark) Color(0xFF1E2126) else Color.White
    val screen = if (dark) Color(0xFF0F1114) else Color(0xFFF4F6F9)
    val field = if (dark) Color(0xFF2A2E35) else Color(0xFFEEF1F5)
    val text = if (dark) Color(0xFFF2F4F7) else Color(0xFF1B1F24)
    val sub = if (dark) Color(0xFF9AA3AE) else Color(0xFF5B636E)
    val blue = if (dark) Color(0xFF5B9BFF) else Color(0xFF2F6FE0)
    val green = if (dark) Color(0xFF34C76F) else Color(0xFF1F9D55)
    val red = Color(0xFFE5332A)
    val banner = if (dark) Color(0xFF2558BE) else Color(0xFF2F6FE0)
    val bannerDeep = if (dark) Color(0xFF1C469C) else Color(0xFF1F56C2)
    val divider = if (dark) Color(0x26FFFFFF) else Color(0x1A000000)
    val selectedSeg = if (dark) Color(0xFF636366) else Color.White
}

val LocalPal = staticCompositionLocalOf { Pal(false) }

/** Noto Sans in fünf Stärken (freie OFL-Lizenz) */
val NotoSans = androidx.compose.ui.text.font.FontFamily(
    androidx.compose.ui.text.font.Font(R.font.noto_sans_400, FontWeight.Normal),
    androidx.compose.ui.text.font.Font(R.font.noto_sans_500, FontWeight.Medium),
    androidx.compose.ui.text.font.Font(R.font.noto_sans_600, FontWeight.SemiBold),
    androidx.compose.ui.text.font.Font(R.font.noto_sans_700, FontWeight.Bold),
    androidx.compose.ui.text.font.Font(R.font.noto_sans_800, FontWeight.ExtraBold),
)

val NotoTypography: androidx.compose.material3.Typography = androidx.compose.material3.Typography().let { t ->
    fun TextStyle.n() = copy(fontFamily = NotoSans)
    t.copy(
        displayLarge = t.displayLarge.n(), displayMedium = t.displayMedium.n(), displaySmall = t.displaySmall.n(),
        headlineLarge = t.headlineLarge.n(), headlineMedium = t.headlineMedium.n(), headlineSmall = t.headlineSmall.n(),
        titleLarge = t.titleLarge.n(), titleMedium = t.titleMedium.n(), titleSmall = t.titleSmall.n(),
        bodyLarge = t.bodyLarge.n(), bodyMedium = t.bodyMedium.n(), bodySmall = t.bodySmall.n(),
        labelLarge = t.labelLarge.n(), labelMedium = t.labelMedium.n(), labelSmall = t.labelSmall.n(),
    )
}

private val CAR_COLORS = listOf(
    0xFF0A84FF, 0xFFF2F2F7, 0xFFFF3B30, 0xFF8E8E93, 0xFF1C1C1E, 0xFF30D158, 0xFFFF9F0A,
)

// ---------------- Hauptbildschirm ----------------

@Composable
fun EvRouteApp(vm: MainViewModel) {
    val settings by Settings.state.collectAsState()
    val nav by NavSession.state.collectAsState()
    val fix by LocationHub.fix.collectAsState()
    val ui by vm.ui.collectAsState()
    val recents by Recents.items.collectAsState()
    val mc by MapChargers.state.collectAsState()
    val view = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.DisposableEffect(nav.navigating) {
        view.keepScreenOn = nav.navigating
        onDispose { view.keepScreenOn = false }
    }
    val mcMoved by MapChargers.moved.collectAsState()
    val reach by Reach.state.collectAsState()
    val ctx = LocalContext.current
    val dark = when (settings.mapMode) {
        MapMode.AUTO -> isSystemInDarkTheme()
        MapMode.DAY -> false
        MapMode.NIGHT -> true
    }
    val pal = remember(dark) { Pal(dark) }

    BackHandler(enabled = ui.showSettings && !ui.showObd && !ui.showTrips) { vm.closeSettings() }
    BackHandler(enabled = ui.showTrips) { vm.closeTrips() }
    BackHandler(enabled = ui.showObd) { vm.closeObd() }
    if (ui.saveDialog) {
        val d = nav.dest
        var name by remember { mutableStateOf(listOfNotNull(nav.start?.title?.substringBefore(","), d?.title?.substringBefore(",")).joinToString(" → ")) }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = vm::closeSaveDialog,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Route speichern", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Gespeichert werden Start, Ziel, Zwischenstopps und deine festen Ladestopps. Beim Aufrufen wird mit aktuellem Verkehr, Wetter und Akku neu gerechnet.", fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }, shape = RoundedCornerShape(16.dp))
                }
            },
            confirmButton = { TextButton(onClick = { vm.saveRoute(name) }) { Text("Speichern", fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = vm::closeSaveDialog) { Text("Abbrechen") } },
        )
    }
    ui.deleteSaved?.let { r ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { vm.askDeleteSaved(null) },
            shape = RoundedCornerShape(28.dp),
            title = { Text("Route löschen?", fontWeight = FontWeight.Bold) },
            text = { Text("„${r.name}“ wird aus den gespeicherten Routen entfernt.") },
            confirmButton = { TextButton(onClick = { SavedRoutes.remove(r.id); vm.askDeleteSaved(null) }) { Text("Löschen", color = pal.red, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { vm.askDeleteSaved(null) }) { Text("Abbrechen") } },
        )
    }

    if (ui.askPrecise) {
        val req = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()) {
            LocationHub.refreshPermission(ctx)
            LocationHub.acquire(ctx, "ui")
            vm.setAskPrecise(false)
        }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { vm.setAskPrecise(false) },
            shape = RoundedCornerShape(28.dp),
            title = { Text("Genauer Standort nötig", fontWeight = FontWeight.Bold) },
            text = { Text("Du hast nur den ungefähren Standort freigegeben (auf etwa 2 km genau). Für Abbiegehinweise braucht die Navigation deinen genauen Standort.") },
            confirmButton = {
                TextButton(onClick = { req.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)) }) {
                    Text("Genauen Standort erlauben", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { vm.setAskPrecise(false) }) { Text("Abbrechen") } },
        )
    }

    // Rückfrage: Zwischenstopp überspringen oder Navigation beenden
    if (ui.askEnd && nav.navigating) {
        val next = NavSession.nextVia()
        androidx.compose.material3.AlertDialog(
            onDismissRequest = vm::closeAskEnd,
            shape = RoundedCornerShape(28.dp),
            title = { Text(if (next != null) "Was möchtest du beenden?" else "Navigation beenden?", fontWeight = FontWeight.Bold) },
            text = {
                if (next != null) {
                    Column {
                        Text("Nächster Zwischenstopp: ${next.place.title}")
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = { vm.closeAskEnd(); NavSession.skipNextVia() },
                            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
                        ) { Text("Zwischenstopp überspringen", fontWeight = FontWeight.Bold) }
                    }
                } else {
                    Text("Die laufende Navigation wird beendet.")
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.closeAskEnd(); NavSession.stop(ctx) }) {
                    Text("Navigation beenden", color = pal.red, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = vm::closeAskEnd) { Text(if (next != null) "Abbrechen" else "Weiterfahren") } },
        )
    }

    // Zurück-Geste: immer nur EINEN Schritt zurück, vom obersten Fenster aus (feste Reihenfolge)
    val overlay = ui.showSettings || ui.showObd || ui.showTrips
    val canBack = !overlay && (
        mc.selected != null || nav.chargerSearch != null || ui.mode != SearchMode.DEST || ui.card != null ||
            ui.longPress != null || ui.searchActive || ui.query.isNotEmpty() || (!nav.navigating && nav.dest != null)
        )
    BackHandler(enabled = canBack) {
        when {
            ui.assistant -> vm.closeAssistant()
            mc.selected != null -> vm.closeChargerCard()          // Ladestations-Fenster -> zurück zur Liste/Suche
            ui.destInfo != null -> vm.closeDestInfo()
            nav.chargerSearch != null -> NavSession.closeChargerSearch() // Alternativen -> zurück zur Route
            ui.mode != SearchMode.DEST -> vm.cancelSearch()
            ui.card != null -> vm.closeCard()                      // Ortsfenster -> zurück zu den Suchergebnissen
            ui.longPress != null -> vm.closeLongPress()
            ui.searchActive || ui.query.isNotEmpty() -> vm.collapseSearch()
            !nav.navigating && nav.dest != null -> vm.backFromRoute() // Routen -> zurück zum Ortsfenster
        }
    }

    // Symbole der Statusleiste passend zur Karte: dunkel auf heller Karte, hell im Dunkeln
    androidx.compose.runtime.SideEffect {
        (view.context as? android.app.Activity)?.window?.let { w ->
            androidx.core.view.WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    val baseDensity = LocalDensity.current
    val hazeState = remember { dev.chrisbanes.haze.HazeState() }
    // echte Unschärfe nur, wenn die Karte beim Start im passenden Modus angelegt wurde
    val blurOn = remember { Settings.state.value.glassBlur } && android.os.Build.VERSION.SDK_INT >= 31
    CompositionLocalProvider(
        LocalPal provides pal,
        LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density, baseDensity.fontScale * 0.88f),
        LocalHaze provides if (blurOn) hazeState else null,
    ) {
        MaterialTheme(
            colorScheme = if (dark) darkColorScheme(primary = pal.blue) else lightColorScheme(primary = pal.blue),
            typography = NotoTypography,
            shapes = androidx.compose.material3.Shapes(
                extraSmall = RoundedCornerShape(10.dp), small = RoundedCornerShape(14.dp), medium = RoundedCornerShape(20.dp),
                large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(32.dp),
            ),
        ) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val hPx = with(LocalDensity.current) { maxHeight.toPx() }.toDouble()
                val sheetMax = maxHeight
                val route = nav.route
                val progress = nav.progress

                EvMap(
                    routes = nav.routes,
                    selected = nav.selected,
                    navigating = nav.navigating,
                    progress = progress,
                    fix = fix,
                    vehicle = settings.vehicle,
                    carColor = settings.carColor,
                    dark = dark,
                    follow = ui.follow,
                    recenterTick = ui.recenter,
                    topPadPx = hPx * 0.40,
                    bottomPadPx = hPx * 0.12,
                    sheetPadPx = if (ui.card != null || mc.selected != null || nav.chargerSearch != null) (hPx * 0.55).toInt() else if (ui.sheetPx > 0 && nav.dest != null) ui.sheetPx + with(LocalDensity.current) { 40.dp.roundToPx() } else (hPx * 0.50).toInt(),
                    onGesture = vm::onGesture,
                    onTap = vm::onMapTap,
                    mapStyleChoice = settings.mapStyle * 10 + if (settings.hasTomTom) 1 else 0,
                    nightStyleChoice = settings.nightStyle,
                    onLongPress = vm::onLongPress,
                    mapChargers = nav.chargerSearch?.hits?.take(60) ?: if (mc.active) mc.hits else emptyList(),
                    pin = ui.card?.pos ?: mc.selected?.pos,
                    reach = reach,
                    overviewPts = ui.overviewPts,
                    overviewKey = ui.overviewKey,
                    poiEnabled = settings.poiEnabled && (!nav.navigating || settings.poiInNav),
                    poiCats = settings.poiCats,
                    onPoiTap = { p -> vm.openCard(Place(p.name, p.pos, null, p.kind)) },
                    fitPoints = nav.chargerSearch?.takeIf { !it.loading && it.hits.isNotEmpty() && mc.selected == null }
                        ?.let { cs -> cs.hits.take(25).map { it.pos } + listOfNotNull(cs.focus) },
                    onChargerTap = { id -> MapChargers.select(id) },
                    trafficUrl = if (settings.hasTomTom && settings.showTraffic) TomTom.trafficTileUrl(settings.tomtomKey.trim(), dark) else null,
                    modifier = Modifier.fillMaxSize().then(if (blurOn) Modifier.haze(hazeState) else Modifier),
                )

                // ----- Fahrzeug als festes Bild über der Karte (Kamera folgt, daher immer gleiche Stelle) -----
                if (nav.navigating && ui.follow && progress != null && !nav.arrived) {
                    val vctx = LocalContext.current
                    val sprite = VehicleSprites.isSprite(settings.vehicle)
                    val bmp = remember(settings.vehicle, settings.carColor, settings.modelOrigColor) {
                        when (settings.vehicle) {
                            VehicleIcon.ARROW -> VehicleIcons.arrow(vctx)
                            VehicleIcon.CAR -> VehicleIcons.car(vctx, settings.carColor.toInt())
                            VehicleIcon.DOT -> VehicleIcons.dot(vctx)
                            else -> VehicleSprites.frames(vctx, settings.vehicle, if (settings.modelOrigColor) null else settings.carColor.toInt())?.get(0)
                                ?: VehicleIcons.arrow(vctx)
                        }.asImageBitmap()
                    }
                    val size = when (settings.vehicle) {
                        VehicleIcon.ARROW -> 50.dp
                        VehicleIcon.CAR -> 54.dp
                        VehicleIcon.DOT -> 34.dp
                        else -> 74.dp
                    }
                    // Mitte des freien Kartenbereichs (oben 40 %, unten 12 % Abstand, wie bei der Kamera)
                    val cy = maxHeight * 0.64f
                    Image(
                        bmp, null,
                        Modifier.offset(x = maxWidth / 2 - size / 2, y = cy - size / 2).size(size)
                            .graphicsLayer {
                                if (settings.vehicle != VehicleIcon.DOT && !sprite) {
                                    rotationX = 45f
                                    cameraDistance = 14f * density
                                }
                            },
                    )
                }

                // ----- oben -----
                val bannerOn = ui.mode == SearchMode.DEST && nav.navigating && route != null && progress != null && !nav.arrived && nav.charging == null
                var bannerH by remember { mutableStateOf(0) }
                if (bannerOn) Box(Modifier.align(Alignment.TopCenter).onSizeChanged { bannerH = it.height }) { NavBanner(route!!, progress!!) }
                Column(
                    Modifier.align(Alignment.TopCenter)
                        .then(if (bannerOn) Modifier.padding(top = with(LocalDensity.current) { bannerH.toDp() }) else Modifier.statusBarsPadding())
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    nav.chargeNotice?.let { msg ->
                        GlassCard(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.BatteryChargingFull, null, tint = pal.green, modifier = Modifier.size(22.dp))
                                Spacer(Modifier.width(10.dp))
                                Text(msg, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    if (bannerOn && route != null && progress != null && nav.charging == null) {
                        // federnd ein- und ausblenden (Material 3 Expressive)
                        val springIn = androidx.compose.animation.slideInVertically(
                            androidx.compose.animation.core.spring(dampingRatio = 0.62f, stiffness = 380f),
                        ) { -it / 2 } + androidx.compose.animation.fadeIn()
                        val springOut = androidx.compose.animation.slideOutVertically { -it / 2 } + androidx.compose.animation.fadeOut()
                        val lastWarn = remember { mutableStateOf<NavSession.Warning?>(null) }
                        if (nav.warning != null) lastWarn.value = nav.warning
                        androidx.compose.animation.AnimatedVisibility(nav.warning != null, enter = springIn, exit = springOut) {
                            lastWarn.value?.let { WarningCard(it) }
                        }
                        val chargeSoon = nav.warning == null && route.stops.any { it.alongM > progress.alongM + 50 && it.alongM - progress.alongM <= 5000 }
                        androidx.compose.animation.AnimatedVisibility(chargeSoon, enter = springIn, exit = springOut) {
                            ChargeApproachCard(route, progress, nav.availability)
                        }
                        val lastCoach = remember { mutableStateOf<CoachTip?>(null) }
                        if (nav.coach != null) lastCoach.value = nav.coach
                        androidx.compose.animation.AnimatedVisibility(nav.coach != null, enter = springIn, exit = springOut) {
                            lastCoach.value?.let { CoachCard(it) }
                        }
                        if (nav.gpsLost) InfoPill("Kein GPS (Tunnel?) – Position wird geschätzt", spinner = false)
                    }
                    if (!nav.navigating && ui.mode == SearchMode.DEST) LocationBanner()
                    if (reach.active && !nav.navigating && ui.mode == SearchMode.DEST) {
                        Box(Modifier.fillMaxWidth().padding(end = 64.dp), contentAlignment = Alignment.CenterStart) { ReachLegend(reach) }
                    }
                    if (mc.active && !nav.navigating && ui.mode == SearchMode.DEST) {
                        Box(Modifier.fillMaxWidth().padding(end = 64.dp), contentAlignment = Alignment.CenterStart) { MapChargerPill(mc, mcMoved, settings.mapFastOnly) }
                    }
                    if (nav.rerouting) InfoPill("Route wird neu berechnet …", spinner = true)
                    nav.offer?.let { o ->
                        ActionCard(
                            "Schnellere Route: ${fmtDuration(o.savedS)} gespart",
                            "Übernehmen", NavSession::acceptOffer, NavSession::dismissOffer,
                        )
                    }
                    nav.fullPark?.let { p ->
                        ActionCard(
                            "Ladepark „${p.name}“ ist gerade voll belegt",
                            "Anderen suchen", NavSession::avoidFullPark, NavSession::dismissFullPark,
                        )
                    }
                    if (nav.navigating && progress != null && progress.offRouteM > 60 && !nav.rerouting) {
                        InfoPill("Abseits der Route", spinner = false)
                    }
                }

                // ----- rechts: Kartenknöpfe -----
                Column(
                    if (nav.navigating) Modifier.align(Alignment.CenterEnd).padding(end = 12.dp)
                    else Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 8.dp, end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (!nav.navigating) MapButton(Icons.Filled.Settings, "Einstellungen") { vm.openSettings() }
                    if (!nav.navigating) {
                        MapButton(Icons.Filled.EvStation, "Ladestationen auf der Karte", tint = if (mc.active) pal.green else pal.blue) { MapChargers.toggle() }
                    }
                    if (!nav.navigating && settings.reachEnabled) {
                        MapButton(Icons.Filled.Adjust, "Reichweite anzeigen", tint = if (reach.active) pal.green else pal.blue) { Reach.toggle() }
                    }
                    if (!nav.navigating) MapButton(Icons.Filled.NearMe, "Zentrieren") { vm.recenter() }
                }

                // ----- unten -----
                val footerMode = nav.navigating && route != null && progress != null && !nav.arrived && !ui.assistant && mc.selected == null &&
                    ui.destInfo == null && nav.chargerSearch == null && ui.mode == SearchMode.DEST && ui.card == null && ui.longPress == null
                Column(
                    if (footerMode) Modifier.align(Alignment.BottomCenter) else Modifier.align(Alignment.BottomCenter).navigationBarsPadding().imePadding().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    val lp = ui.longPress
                    val sel = mc.selected
                    when {
                        ui.assistant -> AssistantSheet(vm, sheetMax)
                        sel != null -> ChargerCard(sel, mc, fix?.pos, nav, sheetMax, onClose = vm::closeChargerCard)
                        ui.destInfo != null && nav.navigating -> DestInfoSheet(vm, ui, nav, fix?.pos, sheetMax)
                        nav.chargerSearch != null -> ChargerSheet(nav, settings, sheetMax)
                        ui.mode != SearchMode.DEST -> SearchSheet(ui, recents, vm, sheetMax)
                        ui.card != null -> PlaceCard(vm, ui, nav, fix?.pos, sheetMax)
                        lp != null && ui.mode == SearchMode.DEST -> LongPressCard(lp, nav.dest != null || nav.navigating, vm)
                        nav.arrived -> ArrivedWithSummary(nav.dest, sheetMax) { NavSession.stop(ctx) }
                        nav.navigating && route != null && nav.charging != null -> ChargingCard(nav.charging!!, route, progress)
                        nav.navigating && route != null && progress != null -> {
                            if (ui.navMore) Box(Modifier.padding(horizontal = 12.dp)) { NavMoreButtons(vm, settings) }
                            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.Bottom) {
                                SpeedRow(fix, route, progress)
                                Spacer(Modifier.weight(1f))
                                NavControls(vm, ui)
                            }
                            NavFooter(route, progress, nav.availability, onDestInfo = vm::openDestInfo) { vm.askEnd() }
                        }
                        nav.navigating -> GlassCard { Text("Warte auf GPS …", Modifier.padding(18.dp), color = pal.text) }
                        nav.dest != null -> RouteSheet(nav, settings, sheetMax, vm, onGo = {
                            if (!LocationHub.precise(ctx)) {
                                vm.setAskPrecise(true)
                            } else {
                                vm.recenter()
                                NavSession.start(ctx)
                            }
                        })
                        else -> SearchSheet(ui, recents, vm, sheetMax)
                    }
                }
            }
            if (ui.showSettings) SettingsScreen(settings, vm::closeSettings, vm::openObd, vm::openTrips)
            if (ui.showObd) ObdScreen(vm)
            if (ui.showTrips) TripsScreen(vm)
            ui.editFav?.let { f -> FavEditDialog(f) { vm.editFavorite(null) } }
        }
    }
}

// ---------------- Bausteine ----------------

@Composable
fun GlassCard(modifier: Modifier = Modifier, corner: Dp = 28.dp, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.glass(RoundedCornerShape(corner.coerceAtLeast(26.dp))), content = content)
}

@Composable
fun MapButton(icon: ImageVector, desc: String, tint: Color = LocalPal.current.text, onClick: () -> Unit) {
    Box(
        Modifier.size(54.dp).glass(CircleShape, 6.dp).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = tint, modifier = Modifier.size(24.dp)) }
}

@Composable
fun InfoPill(text: String, spinner: Boolean) {
    val pal = LocalPal.current
    Surface(shape = RoundedCornerShape(16.dp), color = pal.card, shadowElevation = 6.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (spinner) {
                CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
            }
            Text(text, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ---------------- Suche ----------------

/** Hinweis, wenn der Standort nur ungefähr oder gar nicht freigegeben ist */
@Composable
fun LocationBanner() {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val perm by LocationHub.perm.collectAsState()
    if (perm == LocationHub.Perm.PRECISE) return
    val activity = ctx as? android.app.Activity
    val req = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()) {
        LocationHub.refreshPermission(ctx)
        LocationHub.acquire(ctx, "ui")
    }
    // Hat der Nutzer dauerhaft abgelehnt, hilft nur noch der Weg über die Einstellungen
    val blocked = perm == LocationHub.Perm.NONE && activity != null &&
        !androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.ACCESS_FINE_LOCATION)
    Surface(Modifier.fillMaxWidth().padding(end = 64.dp), shape = RoundedCornerShape(20.dp), color = pal.card, shadowElevation = 8.dp) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (perm == LocationHub.Perm.APPROX) "📍" else "⚠", fontSize = 20.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (perm == LocationHub.Perm.APPROX) "Nur ungefährer Standort" else "Kein Standort freigegeben",
                    color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    if (perm == LocationHub.Perm.APPROX) "Karte und Planung gehen – für die Navigation den genauen Standort erlauben."
                    else "Ohne Standort kann die App weder planen noch navigieren.",
                    color = pal.sub, fontSize = 12.sp,
                )
            }
            Text(
                if (blocked) "Einstellungen" else "Erlauben", color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                    if (blocked) {
                        ctx.startActivity(
                            Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.fromParts("package", ctx.packageName, null))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    } else {
                        req.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION))
                    }
                }.padding(8.dp),
            )
        }
    }
}

/** Gespeicherte Routen in der Suche */
@Composable
fun SavedRoutesList(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by SavedRoutes.items.collectAsState()
    if (list.isEmpty()) return
    Text("Gespeicherte Routen", color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 4.dp))
    list.forEach { r ->
        Row(
            Modifier.fillMaxWidth().clickable { vm.openSaved(r) }.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(pal.blue.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Route, null, tint = pal.blue, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val stops = r.vias.size
                val chargers = r.vias.count { it.isCharger }
                Text(
                    listOfNotNull(
                        "${r.start?.title?.substringBefore(",") ?: "Mein Standort"} → ${r.dest.title.substringBefore(",")}",
                        if (stops > 0) "$stops Stopp${if (stops > 1) "s" else ""}" + if (chargers > 0) " ($chargers ⚡)" else "" else null,
                        r.startSoc?.let { "Start ${it.roundToInt()} %" },
                    ).joinToString(" · "),
                    color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Box(Modifier.size(40.dp).clip(CircleShape).clickable { vm.askDeleteSaved(r) }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, "Löschen", tint = pal.sub, modifier = Modifier.size(18.dp))
            }
        }
    }
}

/** Fahrzeugkarte wie bei ABRP: Akku live vom OBD oder per Schieberegler */
@Composable
fun VehicleCard(vm: MainViewModel) {
    val pal = LocalPal.current
    val set by Settings.state.collectAsState()
    val conn by Obd.conn.collectAsState()
    val values by Obd.values.collectAsState()
    val last by LastSoc.state.collectAsState()
    // jede halbe Minute neu zeichnen, damit „vor x min“ stimmt
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(30_000); tick++ } }
    val live = remember(values, tick) { Obd.freshSoc() }
    // beim Drehen am Ring läuft der Wert (und die Reichweite) in Echtzeit mit
    var editing by remember { mutableStateOf<Double?>(null) }
    val soc = live ?: editing ?: set.socStart
    val rangeKm = remember(soc, set) {
        val per100 = EvModel.kwhPer100(80.0, set, null)
        (set.usableKwh * (soc - set.minSocStop).coerceAtLeast(0.0) / 100 / (per100 / 100)).roundToInt()
    }
    Surface(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp), color = pal.field.copy(alpha = 0.55f),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(Vehicles.byId(set.vehicleId).name, color = pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${set.usableKwh.roundToInt()} kWh · Reichweite ca. $rangeKm km", color = pal.sub, fontSize = 14.sp)
                }
                Box(Modifier.size(36.dp).clip(CircleShape).clickable { vm.openSettings() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Settings, "Fahrzeug-Einstellungen", tint = pal.text, modifier = Modifier.size(22.dp))
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp, bottom = 6.dp)) {
                // links: eigenes Bild oder frei drehbares 3D-Modell
                Box(Modifier.weight(1f).height(124.dp), contentAlignment = Alignment.Center) {
                    val model = CarModels.byId(set.carView)
                    if (model != null) {
                        Car3D(model.id, if (set.modelOrigColor) model.paint else set.carColor.toInt(), Modifier.fillMaxSize())
                    } else {
                        VehiclePhoto(set.carPhotoVersion, Modifier.fillMaxSize())
                    }
                }
                Spacer(Modifier.width(10.dp))
                // rechts: Akku als Ring zum Drehen
                BatteryRing(
                    value = soc, editable = live == null, live = live != null,
                    onChange = { editing = it },
                    onCommit = { v -> Settings.update { it.copy(socStart = v) }; editing = null },
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                val (dot, text) = when {
                    live != null -> pal.green to "Live über OBD"
                    Vehicles.byId(set.vehicleId).obd == ObdSupport.NONE -> pal.sub to "Kein OBD für dieses Fahrzeug · Akku am Ring einstellen"
                    conn == Obd.Conn.CONNECTING || conn == Obd.Conn.INIT -> Color(0xFFFF9500) to "Verbinde mit OBD …"
                    last != null -> pal.sub to "Zuletzt gesehen ${agoText(last!!.second)}: ${last!!.first.roundToInt()} % · Akku am Ring einstellen"
                    else -> pal.sub to "Kein OBD · Akku am Ring einstellen"
                }
                Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Spacer(Modifier.width(8.dp))
                Text(text, color = pal.sub, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 2)
                Text(
                    "Live-Daten", color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { vm.openObd() }.padding(horizontal = 6.dp, vertical = 4.dp),
                )
            }
        }
    }
}

/** Eigenes Fahrzeugbild (Datei im App-Speicher) oder das mitgelieferte Foto */
@Composable
fun VehiclePhoto(version: Long, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val custom = remember(version) {
        val f = java.io.File(ctx.filesDir, "vehicle_photo.png")
        if (f.exists()) runCatching { android.graphics.BitmapFactory.decodeFile(f.path)?.asImageBitmap() }.getOrNull() else null
    }
    if (custom != null) {
        androidx.compose.foundation.Image(custom, null, modifier, contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    } else {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(R.drawable.ev_car_own), null, modifier,
            contentScale = androidx.compose.ui.layout.ContentScale.Fit,
        )
    }
}

/** Eigenes Bild übernehmen: verkleinert (max. 1200 px) als PNG im App-Speicher ablegen */
fun saveVehiclePhoto(ctx: android.content.Context, uri: android.net.Uri): Boolean = runCatching {
    val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
    var sample = 1
    while (opts.outWidth / sample > 2400 || opts.outHeight / sample > 2400) sample *= 2
    val bmp = ctx.contentResolver.openInputStream(uri)?.use {
        android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
    } ?: return@runCatching false
    val scale = minOf(1f, 1200f / maxOf(bmp.width, bmp.height))
    val out = if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
    java.io.File(ctx.filesDir, "vehicle_photo.png").outputStream().use { out.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
    true
}.getOrDefault(false)

/**
 * Akkustand als Ring: Prozent in der Mitte, Anfasser im Kreis ziehen – der Wert ändert sich in Echtzeit.
 * Mit Live-Daten (OBD) nur Anzeige.
 */
@Composable
fun BatteryRing(value: Double, editable: Boolean, live: Boolean, onChange: (Double) -> Unit, onCommit: (Double) -> Unit) {
    val pal = LocalPal.current
    var v by remember { mutableFloatStateOf(value.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(value) { if (!dragging) v = value.toFloat() }
    val color = when {
        v < 15 -> pal.red
        v < 30 -> Color(0xFFF2A900)
        else -> pal.green
    }
    fun pctAt(pos: Offset, size: androidx.compose.ui.unit.IntSize): Float {
        val dx = pos.x - size.width / 2f
        val dy = pos.y - size.height / 2f
        var deg = Math.toDegrees(kotlin.math.atan2(dx.toDouble(), -dy.toDouble())).toFloat()
        if (deg < 0) deg += 360f
        var p = deg / 3.6f
        // nicht über 100 % auf 0 % springen (und umgekehrt)
        if (v > 85 && p < 15) p = 100f
        if (v < 15 && p > 85) p = 0f
        return p.coerceIn(0f, 100f).let { kotlin.math.round(it) }
    }
    Box(
        Modifier.size(128.dp).then(
            if (editable) {
                Modifier.pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { pos -> dragging = true; v = pctAt(pos, size); onChange(v.toDouble()) },
                        onDragEnd = { dragging = false; onCommit(v.toDouble()) },
                        onDragCancel = { dragging = false; onCommit(v.toDouble()) },
                    ) { change, _ ->
                        change.consume()
                        v = pctAt(change.position, size)
                        onChange(v.toDouble())
                    }
                }
            } else {
                Modifier
            },
        ),
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx()
            val r = (size.minDimension - stroke) / 2 - 6.dp.toPx()
            val tl = Offset(center.x - r, center.y - r)
            val sz = androidx.compose.ui.geometry.Size(r * 2, r * 2)
            drawArc(pal.sub.copy(alpha = 0.18f), -90f, 360f, false, tl, sz, style = androidx.compose.ui.graphics.drawscope.Stroke(stroke))
            drawArc(color, -90f, v * 3.6f, false, tl, sz, style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round))
            if (editable) {
                val a = Math.toRadians((v * 3.6f - 90f).toDouble())
                val c = Offset(center.x + r * kotlin.math.cos(a).toFloat(), center.y + r * kotlin.math.sin(a).toFloat())
                drawCircle(Color.Black.copy(alpha = 0.22f), radius = stroke * 0.95f, center = c + Offset(0f, 1.5.dp.toPx()))
                drawCircle(Color.White, radius = stroke * 0.85f, center = c)
                drawCircle(color, radius = stroke * 0.35f, center = c)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${v.roundToInt()} %", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text(if (live) "Live" else "Akku", color = if (live) pal.green else pal.sub, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun agoText(at: Long): String {
    val min = ((System.currentTimeMillis() - at) / 60_000).toInt()
    return when {
        min < 1 -> "gerade eben"
        min < 60 -> "vor $min min"
        min < 60 * 24 -> "vor ${min / 60} h"
        else -> "vor ${min / (60 * 24)} Tagen"
    }
}

/** Suche als Fenster am unteren Rand: zu sieht man nur die Suchleiste, hochgezogen Favoriten und Zuletzt */
@Composable
fun SearchSheet(ui: MainViewModel.Ui, recents: List<Place>, vm: MainViewModel, screenH: Dp) {
    val pal = LocalPal.current
    val focus = LocalFocusManager.current
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val peek = with(density) { (if (ui.mode == SearchMode.DEST) 92.dp else 132.dp).toPx() }
    val full = with(density) { (screenH * 0.62f).toPx() }
    var h by remember { mutableFloatStateOf(peek) }
    val open = ui.searchActive || ui.query.isNotEmpty() || ui.mode != SearchMode.DEST
    LaunchedEffect(open) {
        if (open && h < full * 0.9f) animate(h, full) { v, _ -> h = v }
        if (!open && h > peek + 1f) animate(h, peek) { v, _ -> h = v }
    }
    LaunchedEffect(peek) { if (!open) h = peek }
    val drag = rememberDraggableState { d -> h = (h - d).coerceIn(peek, full) }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) { vm.setSearchActive(true); vm.onQuery(text) }
    }

    GlassCard(Modifier.fillMaxWidth().height(with(density) { h.toDp() }), corner = 26.dp) {
        Column(
            Modifier.fillMaxWidth().draggable(
                state = drag,
                orientation = Orientation.Vertical,
                onDragStopped = { v ->
                    val target = when {
                        v < -1000f -> full
                        v > 1000f -> peek
                        else -> if (h > (peek + full) / 2) full else peek
                    }
                    if (target == peek) { focus.clearFocus(); vm.setSearchActive(false) }
                    animate(h, target, initialVelocity = -v) { value, _ -> h = value }
                },
            ).padding(top = 8.dp),
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(pal.sub.copy(alpha = 0.5f)))
            }
            if (ui.mode != SearchMode.DEST) {
                Row(Modifier.padding(start = 16.dp, end = 10.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when (ui.mode) {
                            SearchMode.HOME -> "Zuhause festlegen"
                            SearchMode.WORK -> "Arbeit festlegen"
                            SearchMode.FAV -> "Favorit hinzufügen"
                            SearchMode.START -> "Start festlegen"
                            else -> "Stopp hinzufügen"
                        },
                        color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                    )
                    CloseDot(vm::cancelSearch)
                }
            }
            Row(
                Modifier.padding(horizontal = 12.dp, vertical = 10.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.field)
                    .padding(start = 12.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Search, null, tint = pal.sub, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f).padding(vertical = 6.dp)) {
                    if (ui.query.isEmpty()) Text(if (ui.chargerOnly) "Ladestation suchen" else "Suche nach Ort oder Adresse", color = pal.sub, fontSize = 17.sp)
                    BasicTextField(
                        value = ui.query,
                        onValueChange = vm::onQuery,
                        singleLine = true,
                        textStyle = TextStyle(color = pal.text, fontSize = 17.sp, fontFamily = NotoSans),
                        cursorBrush = SolidColor(pal.blue),
                        modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) vm.setSearchActive(true) },
                    )
                }
                if (ui.query.isNotEmpty()) {
                    Box(Modifier.size(36.dp).clip(CircleShape).clickable { vm.onQuery("") }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Close, "Löschen", tint = pal.sub, modifier = Modifier.size(20.dp))
                    }
                }
                if (ui.mode == SearchMode.DEST && Settings.state.value.aiEnabled) {
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).clickable { vm.openAssistant() },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.AutoAwesome, "KI-Assistent", tint = Color(0xFF7C4DFF), modifier = Modifier.size(20.dp)) }
                }
                if (ui.mode == SearchMode.DEST && Settings.state.value.hasTomTom) {
                    Box(
                        Modifier.size(36.dp).clip(CircleShape)
                            .background(if (ui.chargerOnly) pal.green else Color.Transparent)
                            .clickable { vm.toggleChargerOnly() },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.EvStation, "Nur Ladestationen", tint = if (ui.chargerOnly) Color.White else pal.green, modifier = Modifier.size(20.dp)) }
                }
                Box(
                    Modifier.size(36.dp).clip(CircleShape).clickable {
                        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
                            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Wohin möchtest du?")
                        try {
                            speech.launch(i)
                        } catch (e: ActivityNotFoundException) {
                            android.widget.Toast.makeText(ctx, "Spracheingabe ist auf diesem Gerät nicht verfügbar", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Mic, "Spracheingabe", tint = pal.blue, modifier = Modifier.size(22.dp)) }
            }
        }
        // Inhalt beim Hochziehen
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 10.dp)) {
            val showSuggestions = ui.query.trim().length >= 3
            // „Zuletzt“ erst, wenn man ins Suchfeld tippt; sonst Favoriten, Fahrzeug und gespeicherte Routen
            val typing = ui.searchActive || ui.query.isNotEmpty() || ui.mode != SearchMode.DEST
            if (ui.mode == SearchMode.DEST && !showSuggestions) {
                FavoritesRow(vm)
                if (!typing) {
                    VehicleCard(vm)
                    SavedRoutesList(vm)
                }
            }
            if (showSuggestions && ui.chargerHits.isNotEmpty()) {
                Text("Ladestationen", color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 4.dp))
                ui.chargerHits.forEach { h ->
                    Row(
                        Modifier.fillMaxWidth().clickable { focus.clearFocus(); vm.openCharger(h) }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(Color(operatorColor(h.operator.ifBlank { h.name }))),
                            contentAlignment = Alignment.Center,
                        ) { Text("⚡", color = Color.White, fontSize = 16.sp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(chargerTitle(h), color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val me = LocationHub.fix.value?.pos
                            if (h.address.isNotBlank()) {
                                Text(h.address, color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text(
                                listOfNotNull(
                                    h.operator.ifBlank { null }?.takeIf { !chargerTitle(h).contains(it, true) },
                                    if (h.powerKw > 0) "${h.powerKw.roundToInt()} kW" else null,
                                    me?.let { fmtKm(haversine(it, h.pos)) },
                                ).joinToString(" · "),
                                color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
            val items = if (showSuggestions) ui.suggestions else if (typing) recents else emptyList()
            if (!(showSuggestions && ui.chargerOnly) && (showSuggestions || typing)) Text(
                if (showSuggestions) "Orte und Adressen" else "Zuletzt",
                color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 4.dp),
            )
            if (ui.searching && items.isEmpty()) {
                Text("Suche …", color = pal.sub, modifier = Modifier.padding(16.dp))
            } else if (items.isEmpty() && (showSuggestions || typing) && !(showSuggestions && ui.chargerHits.isNotEmpty())) {
                Text(if (showSuggestions) "Nichts gefunden" else "Noch keine Ziele", color = pal.sub, modifier = Modifier.padding(16.dp))
            }
            items.forEach { p ->
                PlaceRow(p, recent = !showSuggestions) {
                    focus.clearFocus()
                    vm.pick(p)
                }
            }
        }
    }
}

@Composable
private fun PlaceRow(p: Place, recent: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(if (recent) pal.field else pal.red),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (recent) Icons.Filled.History else Icons.Filled.Place, null,
                tint = if (recent) pal.sub else Color.White, modifier = Modifier.size(20.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.title, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (p.subtitle.isNotBlank()) {
                Text(p.subtitle, color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ---------------- Routenauswahl ----------------

/** Akkustand beim Start (bis OBD in Runde 3 kommt, manuell) */
@Composable
fun SocStartRow(settings: AppSettings) {
    val pal = LocalPal.current
    val obd = obdSocState()
    val nav = NavSession.state.collectAsState().value
    if (nav.start != null) {
        // vorausgeplante Fahrt ab eigenem Start: eigener Start-Akku
        val v = nav.startSoc ?: settings.socStart
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Akku beim Start", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            StepButton("−") { NavSession.setStartSoc(v - 5) }
            Text(fmtPct(v), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
            StepButton("+") { NavSession.setStartSoc(v + 5) }
        }
        return
    }
    if (obd != null) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Akku jetzt", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(fmtSoc(obd), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("  OBD", color = pal.green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        return
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Akku jetzt", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        StepButton("−") { changeSoc(settings, -5.0) }
        Text(fmtPct(settings.socStart), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
        StepButton("+") { changeSoc(settings, 5.0) }
    }
}

private fun changeSoc(s: AppSettings, delta: Double) {
    val v = (s.socStart + delta).coerceIn(5.0, 100.0)
    if (v == s.socStart) return
    Settings.update { it.copy(socStart = v) }
    NavSession.replan()
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(pal.cardSolid).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = pal.blue, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun RouteRow(r: Route, selected: Boolean, deltaS: Double, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (selected) pal.blue.copy(alpha = 0.12f) else pal.field.copy(alpha = 0.6f))
            .border(2.dp, if (selected) pal.blue else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fmtDuration(r.durationS), color = pal.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                if (deltaS > 60) {
                    Spacer(Modifier.width(8.dp))
                    Text("+${fmtDuration(deltaS)}", color = pal.sub, fontSize = 14.sp)
                }
            }
            Text(
                "${fmtKm(r.distanceM)} · Ankunft ${fmtEta(r.durationS)}" + if (r.summary.isNotBlank()) " · über ${r.summary}" else "",
                color = pal.sub, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            val ev = buildList {
                if (r.stops.isNotEmpty()) add("⚡ ${r.stops.size} × laden · ${fmtDuration(r.chargeS)}")
                r.arrivalSoc?.let { add("Ziel ${fmtPct(it)}") }
            }.joinToString(" · ")
            if (ev.isNotBlank()) Text(ev, color = if (r.feasible) pal.green else pal.red, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            if (r.trafficDelayS > 120) {
                Text("Verkehr: +${fmtDuration(r.trafficDelayS)}", color = Color(0xFFFF9500), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (r.tag.isNotBlank()) {
            Spacer(Modifier.width(8.dp))
            Text(
                r.tag,
                color = if (selected) Color.White else pal.text,
                fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (selected) pal.blue else pal.field)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

/** Details der gewählten Route: Wetter, Akku-Verlauf, Ladestopps */
@Composable
fun RouteDetails(r: Route, avail: Map<String, Availability>) {
    val pal = LocalPal.current
    Spacer(Modifier.height(12.dp))
    r.reason?.let { Text(it, color = pal.red, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp)) }
    r.weather?.let { w ->
        val wind = when {
            w.headwindKmh > 5 -> " · Gegenwind ${w.headwindKmh.roundToInt()} km/h"
            w.headwindKmh < -5 -> " · Rückenwind ${(-w.headwindKmh).roundToInt()} km/h"
            else -> ""
        }
        Text(
            "Wetter unterwegs: ${w.tempC.roundToInt()} °C$wind" + if (w.rain) " · Regen" else "",
            color = pal.sub, fontSize = 13.sp,
        )
    }
    if (r.socProfile.size >= 2) {
        Spacer(Modifier.height(8.dp))
        Text("Akku-Verlauf", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        SocChart(r)
    }
    if (r.stops.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        Text("Ladestopps", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        r.stops.forEachIndexed { i, st -> StopRow(i + 1, st, st.uuid?.let { avail[it] }, WishPlanner.timeAt(r, st.alongM)) }
    }
}

@Composable
private fun StopRow(no: Int, st: ChargeStop, a: Availability?, etaS: Double) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(pal.green), contentAlignment = Alignment.Center) {
            Text("$no", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(st.name, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val op = if (st.operator.isNotBlank() && st.operator != st.name) "${st.operator} · " else ""
            Text(
                "${op}km ${(st.alongM / 1000).roundToInt()} · ${st.powerKw.roundToInt()} kW · Ankunft ${fmtEta(etaS)}",
                color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                "${fmtPct(st.arriveSoc)} → ${fmtPct(st.targetSoc)} · ${fmtDuration(st.chargeS)}",
                color = pal.text, fontSize = 13.sp,
            )
            if (Settings.state.value.hasTomTom && !NavSession.state.value.navigating) {
                Text(
                    "Anderen wählen", color = pal.blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 2.dp).clickable { NavSession.openChargerSearch(st.uuid) },
                )
            }
        }
        if (a != null && a.known) {
            Text(
                "${a.available}/${a.total} frei",
                color = if (a.available > 0) pal.green else pal.red, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

/** Akkustand über die Strecke, mit Reserve-Linie */
@Composable
private fun SocChart(r: Route) {
    val pal = LocalPal.current
    val total = max(1.0, r.cumM.lastOrNull() ?: 1.0)
    val minSoc = Settings.state.value.minSocStop
    Canvas(Modifier.fillMaxWidth().height(90.dp).padding(vertical = 6.dp)) {
        val w = size.width
        val h = size.height
        fun x(m: Double) = (m / total * w).toFloat()
        fun y(p: Double) = (h - (p.coerceIn(0.0, 100.0) / 100.0) * h).toFloat()
        // Reserve
        drawLine(pal.red.copy(alpha = 0.5f), Offset(0f, y(minSoc)), Offset(w, y(minSoc)), 2f)
        val line = Path()
        val fill = Path()
        r.socProfile.forEachIndexed { i, (m, p) ->
            if (i == 0) { line.moveTo(x(m), y(p)); fill.moveTo(x(m), h); fill.lineTo(x(m), y(p)) } else { line.lineTo(x(m), y(p)); fill.lineTo(x(m), y(p)) }
        }
        val last = r.socProfile.last()
        fill.lineTo(x(last.first), h)
        fill.close()
        drawPath(fill, pal.green.copy(alpha = 0.18f))
        drawPath(line, pal.green, style = Stroke(width = 5f))
        r.stops.forEach { st -> drawCircle(pal.green, 7f, Offset(x(st.alongM), y(st.targetSoc))) }
    }
}

@Composable
private fun ActionCard(text: String, action: String, onAction: () -> Unit, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 18.dp) {
        Column(Modifier.padding(14.dp)) {
            Text(text, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                ) { Text(action, fontWeight = FontWeight.Bold) }
                TextButton(onClick = onDismiss) { Text("Ignorieren", color = pal.sub) }
            }
        }
    }
}

// ---------------- Navigation ----------------

@Composable
fun NavBanner(r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val step = r.steps.getOrNull(p.stepIdx) ?: return
    val next = r.steps.getOrNull(p.stepIdx + 1)
    val live by NavSession.liveAlong.collectAsState()
    val dist = live?.let { a -> ((r.stepAlongM.getOrNull(p.stepIdx) ?: a) - a).coerceAtLeast(0.0) } ?: p.distToStepM
    val speed = LocationHub.fix.value?.speed ?: 0.0
    val lanes = findLaneSection(r, p, live ?: p.alongM, speed)
    val showNext = next != null && step.distanceM < 300 && step.type != "arrive"
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp), 12.dp).statusBarsPadding()) {
        Row(Modifier.padding(start = 16.dp, end = 18.dp, top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            // Abbiegesymbol als blaue Plakette, damit es trotz Glas sofort ins Auge fällt
            Box(Modifier.size(62.dp).clip(RoundedCornerShape(18.dp)).background(pal.blue), contentAlignment = Alignment.Center) {
                ManeuverIcon(step.type, step.mod, Color.White, 44.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(fmtDistShort(dist), color = pal.text, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
                val txt = step.bannerText()
                val shield = Regex("^([ABEKL]\\s?\\d{1,3}[a-z]?)\\b\\s*(.*)").find(txt)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (shield != null) {
                        val ref = shield.groupValues[1].replace(" ", "")
                        Text(
                            ref, color = if (ref.startsWith("A") || ref.startsWith("E")) Color.White else Color(0xFF1B1F24),
                            fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp))
                                .background(if (ref.startsWith("A") || ref.startsWith("E")) Color(0xFF1F4FB8) else Color(0xFFFFCC00))
                                .border(1.5.dp, Color.White, RoundedCornerShape(6.dp)).padding(horizontal = 7.dp, vertical = 1.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(
                        (shield?.groupValues?.get(2)?.ifBlank { null } ?: if (shield == null) txt else ""), color = pal.sub, fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (lanes != null || showNext) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(1.dp).background(Color.White.copy(alpha = if (pal.dark) 0.18f else 0.8f)))
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 18.dp, top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (lanes != null) {
                    val cell = if (lanes.lanes.size > 5) 36.dp else 42.dp
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        lanes.lanes.forEachIndexed { i, lane ->
                            if (i > 0) LaneDivider(cell * 0.8f, pal.sub.copy(alpha = 0.5f))
                            LaneCell(lane, cell, on = pal.blue, off = pal.sub.copy(alpha = 0.45f), hi = pal.blue.copy(alpha = 0.12f))
                        }
                    }
                } else {
                    Spacer(Modifier.weight(1f))
                }
                if (showNext) {
                    Text("Dann", color = pal.sub, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(6.dp))
                    ManeuverIcon(next!!.type, next.mod, pal.text, 26.dp)
                }
            }
        }
    }
}

@Composable
fun SpeedRow(fix: Fix?, r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val live by NavSession.liveAlong.collectAsState()
    val limit = r.limitAt(live ?: p.alongM)
    // Anzeige leicht geglättet, damit sie nicht flackert
    val kmhAnim by androidx.compose.animation.core.animateFloatAsState(((fix?.speed ?: 0.0) * 3.6).toFloat(), androidx.compose.animation.core.tween(600), label = "kmh")
    val kmh = kmhAnim.roundToInt()
    val target = NavSession.state.collectAsState().value.tripMaxSpeed
    val overTarget = target != null && kmh > target + 5
    val tooFast = limit != null && kmh > limit + 3
    // Kapsel wie bei TomTom: Tempolimit oben, eigenes Tempo darunter
    Box(
        Modifier.width(74.dp).glass(RoundedCornerShape(38.dp), 8.dp, tint = if (tooFast) pal.red else null)
            .then(if (target != null) Modifier.border(3.dp, if (overTarget) Color(0xFFFF9500) else pal.blue, RoundedCornerShape(38.dp)) else Modifier),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (limit != null) {
                Box(
                    Modifier.size(60.dp).clip(CircleShape).background(Color.White).border(6.dp, Color(0xFFE5332A), CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Text("$limit", color = Color(0xFF1B1F24), fontSize = if (limit >= 100) 21.sp else 24.sp, fontWeight = FontWeight.ExtraBold) }
                Spacer(Modifier.height(4.dp))
            }
            Text("$kmh", color = if (tooFast) Color.White else pal.text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 30.sp)
            Text("km/h", color = if (tooFast) Color.White else pal.sub, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (target != null) {
                Text("Ziel $target", color = if (tooFast) Color.White else if (overTarget) Color(0xFFFF9500) else pal.blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Knöpfe während der Navigation, rechts unten übereinander: Zentrieren, Übersicht, Ton, „⋯“ */
@Composable
fun NavControls(vm: MainViewModel, ui: MainViewModel.Ui) {
    val pal = LocalPal.current
    val set by Settings.state.collectAsState()
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.End) {
        // KI-Assistent auch während der Fahrt: öffnet direkt die Spracheingabe
        if (set.aiEnabled) MapButton(Icons.Filled.AutoAwesome, "KI-Assistent", tint = Color(0xFF7C4DFF)) { vm.openAssistant(listen = true) }
        if (!ui.follow) MapButton(Icons.Filled.NearMe, "Zentrieren", tint = pal.blue) { vm.endOverview() }
        MapButton(
            Icons.Filled.ZoomOutMap,
            when (ui.overviewLevel) { 1 -> "Ganze Strecke"; 2 -> "Zurück zur Fahrt"; else -> "Übersicht" },
            tint = if (ui.overviewLevel > 0) pal.blue else pal.text,
        ) { vm.toggleOverview() }
        MapButton(
            if (set.voice) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
            "Sprachansagen", tint = if (set.voice) pal.text else pal.sub,
        ) { Settings.update { it.copy(voice = !it.voice) } }
        MapButton(Icons.Filled.MoreHoriz, "Weitere", tint = if (ui.navMore) pal.blue else pal.text) { vm.toggleNavMore() }
    }
}

/** Aufgeklapptes „⋯“: rechts über den Knöpfen, nur solange offen */
@Composable
fun NavMoreButtons(vm: MainViewModel, settings: AppSettings) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            MapButton(Icons.Filled.Refresh, "Route neu berechnen") { vm.toggleNavMore(); NavSession.rerouteNow() }
            if (settings.hasTomTom) MapButton(Icons.Filled.EvStation, "Ladestationen suchen", tint = pal.green) { vm.toggleNavMore(); NavSession.openChargerSearch() }
            MapButton(Icons.Filled.AddLocationAlt, "Stopp hinzufügen") { vm.toggleNavMore(); vm.startSearch(SearchMode.VIA) }
        }
    }
}

@Composable
fun CoachCard(t: CoachTip) {
    val pal = LocalPal.current
    val color = if (t.warning) Color(0xFFFF9500) else pal.blue
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = pal.card, shadowElevation = 10.dp, border = androidx.compose.foundation.BorderStroke(2.dp, color)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (t.warning) "⚠" else "🐢", fontSize = 24.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(t.title, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(t.detail, color = pal.sub, fontSize = 13.sp)
            }
            Text(
                "Übernehmen", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(color).clickable { NavSession.acceptCoach() }.padding(horizontal = 10.dp, vertical = 6.dp),
            )
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(30.dp).clip(CircleShape).clickable { NavSession.dismissCoach() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, "Ignorieren", tint = pal.sub, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun ReachLegend(r: Reach.State) {
    val pal = LocalPal.current
    Surface(shape = RoundedCornerShape(16.dp), color = pal.card, shadowElevation = 8.dp) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f, fill = false)) {
                when {
                    r.loading -> Text("Berechne Reichweite …", color = pal.text, fontSize = 14.sp)
                    r.error != null -> Text(r.error, color = pal.red, fontSize = 13.sp)
                    else -> {
                        Text("Reichweite mit ${r.soc?.let { fmtSoc(it) } ?: "?"}", color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Fläche: bis ${fmtPct(Settings.state.value.minSocStop)} Rest" + if (r.round.isNotEmpty()) " · gestrichelt: hin und zurück" else "",
                            color = pal.sub, fontSize = 12.sp,
                        )
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(28.dp).clip(CircleShape).clickable { Reach.toggle() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, "Schließen", tint = pal.sub, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun DestChip(text: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Text(
        text, color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(pal.blue.copy(alpha = 0.12f)).clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

/** Nächster Halt (Ladestopp oder Zwischenstopp) mit Ankunftszeit */
data class NextHalt(val charge: Boolean, val name: String, val distM: Double, val etaS: Double, val soc: Double?)

fun nextHalt(r: Route, p: NavProgress, socDiff: Double): NextHalt? {
    val along = p.alongM
    val charge = r.stops.firstOrNull { it.alongM > along + 50 }
    val viaIdx = r.steps.indices.firstOrNull { r.steps[it].type == "via" && r.stepAlongM[it] > along + 50 }
    val viaAlong = viaIdx?.let { r.stepAlongM[it] }
    val useVia = viaAlong != null && (charge == null || viaAlong < charge.alongM)
    val target = if (useVia) viaAlong!! else charge?.alongM ?: return null
    // Zeit aus der Routenplanung, auf die aktuelle Restzeit (Verkehr) skaliert
    val tNow = WishPlanner.timeAt(r, along)
    val tEnd = WishPlanner.timeAt(r, r.cumM.last())
    val scale = if (tEnd - tNow > 60) (p.remainingS / (tEnd - tNow)).coerceIn(0.5, 2.0) else 1.0
    val eta = (WishPlanner.timeAt(r, target) - tNow) * scale
    return if (useVia) {
        NextHalt(false, r.steps[viaIdx!!].road.ifBlank { "Zwischenstopp" }, target - along, eta, r.socAt(target)?.plus(socDiff))
    } else {
        NextHalt(true, charge!!.name.substringBefore(","), target - along, eta, charge.arriveSoc + socDiff)
    }
}

@Composable
fun NavFooter(r: Route, p: NavProgress, avail: Map<String, Availability>, onDestInfo: (String) -> Unit = {}, onEnd: () -> Unit) {
    val pal = LocalPal.current
    val nowSoc = r.socAt(p.alongM)
    val real = obdSocState()
    val diff = if (real != null && nowSoc != null) real - nowSoc else 0.0
    val destSoc = r.arrivalSoc?.let { it + diff }
    val delayMin = (r.jams.filter { j -> (r.cumM.getOrNull(j.endIdx) ?: 0.0) > p.alongM }.sumOf { it.delayS } / 60).roundToInt()
    val halt = nextHalt(r, p, diff)
    var showDest by remember { mutableStateOf(false) }
    val haltFirst = halt != null && !showDest
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp), 12.dp)) {
        Column(Modifier.navigationBarsPadding().padding(start = 22.dp, end = 16.dp, top = 16.dp, bottom = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable(enabled = halt != null) { showDest = !showDest }) {
                    if (haltFirst) {
                        val h = halt!!
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (h.charge) "⚡" else "📍", fontSize = 18.sp)
                            Spacer(Modifier.width(6.dp))
                            Text(fmtEta(h.etaS), color = pal.text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            h.soc?.let { soc ->
                                Spacer(Modifier.width(10.dp))
                                SocChip("${fmtPct(soc)} bei Ankunft", soc < 10)
                            }
                        }
                        Text(
                            "${h.name} · ${fmtKm(h.distM)} · ${fmtDuration(h.etaS)}",
                            color = pal.sub, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            "🏁 ${fmtEta(p.remainingS)} · ${fmtKm(p.remainingM)}" + (destSoc?.let { " · ${fmtPct(it)} am Ziel" } ?: "") +
                                if (delayMin >= 1) " · +$delayMin min Stau" else "",
                            color = if (delayMin >= 1) pal.red else pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Flag, null, tint = pal.text, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(fmtEta(p.remainingS), color = pal.text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            if (destSoc != null) {
                                Spacer(Modifier.width(10.dp))
                                SocChip("🔋 ${fmtPct(destSoc)} am Ziel", destSoc < 10)
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmtKm(p.remainingM), color = pal.sub, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("  |  ", color = pal.divider.copy(alpha = 0.6f), fontSize = 15.sp)
                            Text(fmtDuration(p.remainingS), color = pal.sub, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("  |  ", color = pal.divider.copy(alpha = 0.6f), fontSize = 15.sp)
                            Text(
                                if (delayMin >= 1) "+$delayMin min Stau" else "frei",
                                color = if (delayMin >= 1) pal.red else pal.green, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                            )
                        }
                        halt?.let { h ->
                            Text(
                                "${if (h.charge) "⚡" else "📍"} ${h.name} · ${fmtEta(h.etaS)} · ${fmtKm(h.distM)}",
                                color = pal.green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                    }
                }
                Box(Modifier.size(48.dp).glass(CircleShape, 2.dp).clickable(onClick = onEnd), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Close, "Navigation beenden", tint = pal.text)
                }
            }
            if (real != null) {
                Text(
                    "Akku jetzt ${fmtSoc(real)}" + (nowSoc?.let { " · Plan ${fmtPct(it)}" } ?: ""),
                    color = if (diff < -4) pal.red else pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp),
                )
            }
            val nav = NavSession.state.collectAsState().value
            if (p.remainingM < 5000 && (nav.destParking.isNotEmpty() || nav.destChargers.isNotEmpty())) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    if (nav.destParking.isNotEmpty()) DestChip("🅿 Parken am Ziel (${nav.destParking.size})") { onDestInfo("park") }
                    if (nav.destChargers.isNotEmpty()) DestChip("⚡ Laden am Ziel (${nav.destChargers.size})") { onDestInfo("charge") }
                }
            }
        }
    }
}

@Composable
private fun SocChip(text: String, low: Boolean) {
    val pal = LocalPal.current
    val c = if (low) pal.red else pal.green
    Text(
        text, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = c,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(c.copy(alpha = 0.12f)).padding(horizontal = 9.dp, vertical = 3.dp),
    )
}

/** Ladebildschirm am Schnelllader: „Lade von x auf y %, ca. n min“ und „Weiterfahren“ (ohne Live-Daten) */
@Composable
fun ChargingCard(cs: NavSession.ChargeSession, r: Route, p: NavProgress?) {
    val pal = LocalPal.current
    // jede halbe Minute aktualisieren (Restzeit und Ankunft am Ziel)
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(cs) { while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(30_000) } }
    val elapsed = ((now - cs.startedAt) / 1000.0).coerceAtLeast(0.0)
    val left = (cs.chargeS - elapsed).coerceAtLeast(0.0)
    val clock = java.text.SimpleDateFormat("HH:mm", java.util.Locale.GERMANY)
    // Restzeit der Route enthält die geplante Ladedauer dieses Stopps: das bereits Geladene abziehen, die neue Schätzung einsetzen
    val restS = (p?.remainingS ?: r.durationS) - cs.plannedChargeS + left
    val restM = p?.remainingM ?: r.distanceM
    val done = left <= 0
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp), 12.dp)) {
        Column(Modifier.navigationBarsPadding().padding(start = 22.dp, end = 22.dp, top = 20.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.BatteryChargingFull, null, tint = pal.green, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    "Laden bei ${cs.name.substringBefore(",")}", color = pal.sub, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Lade von ${cs.arriveSoc.roundToInt()} % auf ${cs.targetSoc.roundToInt()} %",
                color = pal.text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
            )
            Text(
                if (done) "Geplanter Ladestand sollte erreicht sein" else "ca. ${(left / 60).roundToInt().coerceAtLeast(1)} min – fertig gegen ${clock.format(java.util.Date(cs.readyAt))}",
                color = if (done) pal.green else pal.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp),
            )
            // geschätzter Fortschritt nach Zeit (keine Live-Daten)
            Box(Modifier.padding(top = 12.dp).fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(pal.divider.copy(alpha = 0.5f))) {
                Box(Modifier.fillMaxWidth((elapsed / cs.chargeS.coerceAtLeast(1.0)).toFloat().coerceIn(0f, 1f)).height(6.dp).clip(RoundedCornerShape(3.dp)).background(pal.green))
            }
            Text(
                "Danach noch ${fmtKm(restM)} · Ankunft am Ziel ${fmtEta(restS)}",
                color = pal.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp),
            )
            Spacer(Modifier.height(14.dp))
            androidx.compose.material3.Button(
                onClick = { NavSession.finishCharging() },
                shape = RoundedCornerShape(16.dp),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Weiterfahren", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

/** Hinweiskarte kurz vor einem Ladestopp (unter dem Banner) */
@Composable
fun ChargeApproachCard(r: Route, p: NavProgress, avail: Map<String, Availability>) {
    val pal = LocalPal.current
    val st = r.stops.firstOrNull { it.alongM > p.alongM + 50 } ?: return
    val d = st.alongM - p.alongM
    if (d > 5000) return
    val a = st.uuid?.let { avail[it] }
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = pal.card, shadowElevation = 10.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(pal.green), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Ladestopp in ${fmtDistShort(d)}", color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    st.name + if (a != null && a.known) " · ${a.available} von ${a.total} frei" else "",
                    color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${st.arriveSoc.roundToInt()} → ${st.targetSoc.roundToInt()} %", color = pal.green, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                Text("${(st.chargeS / 60).roundToInt()} min", color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ---------------- Einstellungen ----------------

enum class SettingsPage(val title: String) {
    MAIN("Einstellungen"), DISPLAY("Darstellung"), NAV("Navigation"), VEHICLE("Fahrzeug"),
    CHARGING("Ladeplanung"), OBD("OBD2-Adapter"), LEARN("Fahrten & Lernen"), TOMTOM("TomTom"),
    BACKUP("Sichern"), INFO("Info"), AI("KI-Assistent"),
}

@Composable
fun SettingsScreen(s: AppSettings, onClose: () -> Unit, onOpenObd: () -> Unit, onOpenTrips: () -> Unit) {
    val pal = LocalPal.current
    var page by remember { mutableStateOf(SettingsPage.MAIN) }
    BackHandler(enabled = page != SettingsPage.MAIN) { page = SettingsPage.MAIN }

    Surface(Modifier.fillMaxSize(), color = pal.screen) {
        Column(
            Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            // Kopfzeile
            if (page == SettingsPage.MAIN) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Einstellungen", color = pal.text, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onClose) { Text("Fertig", color = pal.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.clip(RoundedCornerShape(10.dp)).clickable { page = SettingsPage.MAIN }.padding(vertical = 6.dp, horizontal = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = pal.blue)
                        Text("Einstellungen", color = pal.blue, fontSize = 17.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onClose) { Text("Fertig", color = pal.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
                }
                Text(page.title, color = pal.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }

            when (page) {
                SettingsPage.MAIN -> SettingsMain(s) { page = it }
                SettingsPage.DISPLAY -> { DisplayPage(s); PoiSection(s) }
                SettingsPage.NAV -> NavPage(s, onClose)
                SettingsPage.VEHICLE -> VehiclePage(s)
                SettingsPage.CHARGING -> ChargingPage(s)
                SettingsPage.OBD -> Section("Adapter") { ObdSettingsSection(s, onOpenObd) }
                SettingsPage.LEARN -> Section("Aufzeichnung") { LearnSettingsSection(s, onOpenTrips) }
                SettingsPage.TOMTOM -> TomTomPage(s)
                SettingsPage.AI -> AiPage(s)
                SettingsPage.BACKUP -> Section("Sicherung") { BackupSection() }
                SettingsPage.INFO -> InfoPage()
            }
        }
    }
}

// ---------------- Übersicht ----------------

@Composable
private fun SettingsMain(s: AppSettings, open: (SettingsPage) -> Unit) {
    val conn by Obd.conn.collectAsState()
    val trips by TripRecorder.trips.collectAsState()
    val count by ApiCounter.today.collectAsState()

    MenuGroup("Karte und Fahrt") {
        MenuRow(Icons.Filled.Palette, Color(0xFFAF52DE), "Darstellung",
            "${listOf("Bright", "Positron", "TomTom")[s.mapStyle.coerceIn(0, 2)]} · ${listOf("Automatisch", "Hell", "Dunkel")[s.mapMode.ordinal]} · ${s.vehicle.label}") { open(SettingsPage.DISPLAY) }
        MenuDivider()
        MenuRow(Icons.Filled.Navigation, Color(0xFF0A84FF), "Navigation",
            (if (s.voice) "Ansagen an" else "Ansagen aus") + if (s.avoidToll || s.avoidMotorway || s.avoidFerry) " · Vermeiden aktiv" else "") { open(SettingsPage.NAV) }
    }
    MenuGroup("Auto und Laden") {
        MenuRow(Icons.Filled.DirectionsCar, Color(0xFF5E5CE6), "Fahrzeug",
            "${Vehicles.byId(s.vehicleId).name} · ${String.format(java.util.Locale.GERMANY, "%.1f", s.usableKwh)} kWh") { open(SettingsPage.VEHICLE) }
        MenuDivider()
        MenuRow(Icons.Filled.EvStation, Color(0xFF30D158), "Ladeplanung",
            "Reserve ${fmtPct(s.minSocStop)} / Ziel ${fmtPct(s.minSocDest)}" +
                if (s.preferOperators.isNotEmpty()) " · ${s.preferOperators.size} bevorzugt" else "") { open(SettingsPage.CHARGING) }
        MenuDivider()
        MenuRow(Icons.Filled.Bluetooth, Color(0xFF0A84FF), "OBD2-Adapter",
            if (s.obdName.isBlank()) "Kein Adapter" else s.obdName + if (conn == Obd.Conn.READY) " · verbunden" else "") { open(SettingsPage.OBD) }
        MenuDivider()
        MenuRow(Icons.Filled.Insights, Color(0xFFFF9F0A), "Fahrten & Lernen",
            "${trips.size} Fahrten · ${Learner.totalKm().roundToInt()} km gelernt") { open(SettingsPage.LEARN) }
    }
    MenuGroup("Dienste") {
        MenuRow(Icons.Filled.Traffic, Color(0xFFFF3B30), "TomTom",
            if (s.hasTomTom) "Key hinterlegt · heute $count Anfragen" else "Kein Key – ohne Verkehr und Ladestopps") { open(SettingsPage.TOMTOM) }
        MenuRow(Icons.Filled.AutoAwesome, Color(0xFF7C4DFF), "KI-Assistent",
            if (s.aiEnabled) "An · ${LlmModels.byId(s.aiModel).name} · offline auf dem Handy" else "Aus") { open(SettingsPage.AI) }
    }
    MenuGroup("Allgemein") {
        MenuRow(Icons.Filled.Backup, Color(0xFF8E8E93), "Sichern und Wiederherstellen", "Einstellungen, Favoriten, Gelerntes") { open(SettingsPage.BACKUP) }
        MenuDivider()
        MenuRow(Icons.Filled.Info, Color(0xFF8E8E93), "Info", "Version, Datenquellen, Signatur") { open(SettingsPage.INFO) }
    }
}

@Composable
private fun MenuGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column {
        Text(title.uppercase(), color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 14.dp, bottom = 6.dp))
        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid) { Column(Modifier.fillMaxWidth(), content = content) }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, color: Color, title: String, summary: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(color), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = pal.text, fontSize = 16.sp)
            Text(summary, color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = pal.sub)
    }
}

@Composable
private fun MenuDivider() {
    Box(Modifier.fillMaxWidth().padding(start = 58.dp).height(1.dp).background(LocalPal.current.divider))
}

// ---------------- Unterseiten ----------------

@Composable
private fun DisplayPage(s: AppSettings) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    Section("Fahrzeugbild") {
        // eigenes Bild oder eines der 3D-Modelle
        val pick = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null && saveVehiclePhoto(ctx, uri)) Settings.update { it.copy(carView = "photo", carPhotoVersion = System.currentTimeMillis()) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val opts = listOf("photo" to "Eigenes Bild") + CarModels.all.map { it.id to it.label }
            opts.forEach { (id, label) ->
                val sel = s.carView == id
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(pal.field)
                        .border(2.dp, if (sel) pal.blue else Color.Transparent, RoundedCornerShape(14.dp))
                        .clickable { Settings.update { it.copy(carView = id) } }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    if (id == "photo") {
                        VehiclePhoto(s.carPhotoVersion, Modifier.size(54.dp, 36.dp))
                    } else {
                        // kleine Vorschau aus den vorgerenderten Ansichten
                        val icon = when (id) {
                            "car_compact" -> VehicleIcon.COMPACT3D
                            "car_suv" -> VehicleIcon.SUV3D
                            "car_sport" -> VehicleIcon.SPORT3D
                            else -> VehicleIcon.FUTURE3D
                        }
                        val bmp = remember(id, s.modelOrigColor, s.carColor) {
                            VehicleSprites.frames(ctx, icon, if (s.modelOrigColor) null else s.carColor.toInt())?.get(9)?.asImageBitmap()
                        }
                        if (bmp != null) androidx.compose.foundation.Image(bmp, null, Modifier.size(54.dp, 36.dp))
                    }
                    Text(label, color = pal.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        if (s.carView == "photo") {
            Row(Modifier.padding(top = 8.dp)) {
                TextButton(onClick = { pick.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Eigenes Bild wählen …")
                }
                if (java.io.File(ctx.filesDir, "vehicle_photo.png").exists()) {
                    TextButton(onClick = {
                        java.io.File(ctx.filesDir, "vehicle_photo.png").delete()
                        Settings.update { it.copy(carPhotoVersion = System.currentTimeMillis()) }
                    }) { Text("Standardbild", color = pal.sub) }
                }
            }
            Text("Tipp: Ein Foto mit freigestelltem Auto (transparenter Hintergrund, PNG) sieht am besten aus.", color = pal.sub, fontSize = 12.sp)
        } else {
            Spacer(Modifier.height(8.dp))
            ToggleRow("Originalfarbe des Modells", s.modelOrigColor) { v -> Settings.update { it.copy(modelOrigColor = v) } }
            if (!s.modelOrigColor) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 6.dp)) {
                    CAR_COLORS.forEach { c ->
                        Box(
                            Modifier.size(30.dp).clip(CircleShape).background(Color(c))
                                .border(if (s.carColor == c) 3.dp else 1.dp, if (s.carColor == c) pal.blue else pal.divider, CircleShape)
                                .clickable { Settings.update { it.copy(carColor = c) } },
                        )
                    }
                }
            }
            Text("In der Fahrzeugkarte mit dem Finger seitlich wischen, um das Auto zu drehen.", color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
    Section("Karte") {
        Label("Kartenstil")
        Segmented(listOf("Bright", "Positron", "TomTom"), s.mapStyle.coerceIn(0, 2)) { i ->
            Settings.update { it.copy(mapStyle = i) }
        }
        Text(
            when (s.mapStyle) {
                1 -> "Positron: hell und zurückhaltend, ähnlich wie Apple Maps (OpenStreetMap)."
                2 -> if (s.hasTomTom) "TomTom: gleiches Kartenwerk wie die Route – die Linie liegt exakt auf der Straße. Tag und Nacht automatisch."
                else "TomTom braucht den TomTom-Key (Einstellungen → TomTom). Bis dahin wird Bright angezeigt."
                else -> "Bright: klar und farbig, gut lesbar (OpenStreetMap)."
            },
            color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp),
        )
        if (s.mapStyle != 2) {
            Label("Kartenstil bei Nacht")
            Segmented(listOf("Dunkelblau (Fiord)", "Schwarz"), s.nightStyle.coerceIn(0, 1)) { i ->
                Settings.update { it.copy(nightStyle = i) }
            }
            Text("Fiord ist heller und besser lesbar, „Schwarz“ blendet nachts am wenigsten.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp))
        }
        Label("Hell oder dunkel")
        Segmented(listOf("Automatisch", "Hell", "Dunkel"), s.mapMode.ordinal) { i ->
            Settings.update { it.copy(mapMode = MapMode.entries[i]) }
        }
        Text("„Automatisch“ folgt dem Dunkelmodus des Handys.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
    Section("Glas-Effekt") {
        ToggleRow("Echte Unschärfe hinter dem Glas (experimentell)", s.glassBlur) { v -> Settings.update { it.copy(glassBlur = v) } }
        Text(
            "An: Die Karte verschwimmt hinter Banner, Leisten und Knöpfen wie bei Apple. Braucht etwas mehr Akku und wird erst nach einem Neustart der App wirksam (ab Android 12).",
            color = pal.sub, fontSize = 13.sp,
        )
    }
    Section("Fahrsymbol") {
        listOf(VehicleIcon.entries.take(3), VehicleIcon.entries.drop(3).take(3), VehicleIcon.entries.drop(6)).forEachIndexed { row, group ->
            if (row == 1) Text("3D-Modelle", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = if (row == 2) 10.dp else 0.dp)) {
                group.forEach { v ->
                    val bmp = remember(v, s.carColor, s.modelOrigColor) {
                        when (v) {
                            VehicleIcon.ARROW -> VehicleIcons.arrow(ctx)
                            VehicleIcon.CAR -> VehicleIcons.car(ctx, s.carColor.toInt())
                            VehicleIcon.DOT -> VehicleIcons.dot(ctx)
                            else -> VehicleSprites.frames(ctx, v, if (s.modelOrigColor) null else s.carColor.toInt())?.get(9) ?: VehicleIcons.arrow(ctx)
                        }.asImageBitmap()
                    }
                    val sel = s.vehicle == v
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(pal.field)
                            .border(2.dp, if (sel) pal.blue else Color.Transparent, RoundedCornerShape(14.dp))
                            .clickable { Settings.update { it.copy(vehicle = v) } }
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Image(bmp, null, Modifier.size(if (VehicleSprites.isSprite(v)) 64.dp else 48.dp))
                        Text(v.label, color = pal.text, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
        if (VehicleSprites.isSprite(s.vehicle)) {
            Spacer(Modifier.height(12.dp))
            ToggleRow("Originalfarbe des Modells", s.modelOrigColor) { v -> Settings.update { it.copy(modelOrigColor = v) } }
        }
        if (s.vehicle == VehicleIcon.CAR || (VehicleSprites.isSprite(s.vehicle) && !s.modelOrigColor)) {
            Spacer(Modifier.height(16.dp))
            Label(if (s.vehicle == VehicleIcon.CAR) "Autofarbe" else "Lackfarbe")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CAR_COLORS.forEach { c ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                            .border(if (s.carColor == c) 3.dp else 1.dp, if (s.carColor == c) pal.blue else pal.divider, CircleShape)
                            .clickable { Settings.update { it.copy(carColor = c) } },
                    )
                }
            }
        }
        Text("3D-Modelle: Kenney „Car Kit“ (CC0) und Quaternius „Spaceship Pack“.", color = pal.sub, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
private fun PoiSection(s: AppSettings) {
    val pal = LocalPal.current
    Section("Orte auf der Karte") {
        ToggleRow("Orte anzeigen (zum Antippen)", s.poiEnabled) { v -> Settings.update { it.copy(poiEnabled = v) } }
        if (s.poiEnabled) {
            Text("Erscheinen, sobald du auf Stadtteil- bzw. Straßenebene hineinzoomst. Antippen öffnet das Ortsfenster mit Öffnungszeiten und Route.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            Pois.CATS.forEach { c ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                        Settings.update { it.copy(poiCats = if (c.id in it.poiCats) it.poiCats - c.id else it.poiCats + c.id) }
                    }.padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(28.dp).clip(CircleShape).background(Color(c.color)), contentAlignment = Alignment.Center) {
                        Text(c.emoji, color = Color.White, fontSize = 13.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(c.label, color = pal.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = c.id in s.poiCats,
                        onCheckedChange = { on ->
                            Settings.update { it.copy(poiCats = if (on) it.poiCats + c.id else it.poiCats - c.id) }
                            },
                        colors = SwitchDefaults.colors(checkedTrackColor = pal.green, checkedThumbColor = Color.White),
                    )
                }
            }
            ToggleRow("Auch während der Navigation", s.poiInNav) { v -> Settings.update { it.copy(poiInNav = v) } }
        }
    }
}

@Composable
private fun AiPage(s: AppSettings) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val dl by ModelDownloads.state.collectAsState()
    val ver by ModelDownloads.version.collectAsState()
    Section("KI-Assistent") {
        ToggleRow("Assistent in der Suche anzeigen (✨)", s.aiEnabled) { v -> Settings.update { it.copy(aiEnabled = v) } }
        Text(
            "Der Assistent übersetzt deine Wünsche („nach Varazze, nur Tesla, mittags Pause bei IKEA“) für die Planung und antwortet in normalen Sätzen. " +
                "Er läuft komplett offline auf dem Handy (llama.cpp), ohne Konto und ohne Kosten. Er plant nur Routen – Wetter oder Strände kennt er nicht.",
            color = pal.sub, fontSize = 13.sp,
        )
        if (!LlamaNative.available) Text("Auf diesem Gerät nicht verfügbar (nur 64-Bit-ARM).", color = pal.red, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
    Section("Modell") {
        LlmModels.ALL.forEach { m ->
            val have = remember(ver) { LlmModels.isDownloaded(ctx, m) }
            val unverified = remember(ver) { LlmModels.isUnverified(ctx, m) }
            val sizeMb = remember(ver) { LlmModels.fileOf(ctx, m).length() / 1_000_000 }
            val selected = s.aiModel == m.id
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { Settings.update { it.copy(aiModel = m.id) }; LlmEngine.unload() }
                    .background(if (selected) pal.blue.copy(alpha = 0.1f) else Color.Transparent).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(20.dp).clip(CircleShape).background(if (selected) pal.blue else pal.field), contentAlignment = Alignment.Center) {
                    if (selected) Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(m.name, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(m.note, color = pal.sub, fontSize = 12.sp)
                    val p = dl?.takeIf { it.modelId == m.id }
                    Text(
                        when {
                            p != null && p.error != null -> "Fehler: ${p.error}"
                            p != null && p.verifying -> "Prüfe Datei … ${p.verifyPct} %"
                            p != null && !p.finished -> "Lädt … ${p.doneMb.roundToInt()}" + if (p.totalMb > 0) " / ${p.totalMb.roundToInt()} MB" else " MB"
                            have -> "Geprüft und bereit · $sizeMb MB"
                            unverified -> "Noch nicht geprüft · $sizeMb MB"
                            else -> "Nicht geladen · ${m.sizeLabel}"
                        },
                        color = if (p?.error != null) pal.red else if (have) pal.green else pal.sub, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
                val loading = dl?.let { it.modelId == m.id && !it.finished && it.error == null } == true
                when {
                    loading -> TextButton(onClick = { ModelDownloads.cancel() }) { Text("Stopp", color = pal.red) }
                    have -> TextButton(onClick = { ModelDownloads.delete(ctx, m) }) { Text("Löschen", color = pal.red) }
                    unverified -> TextButton(onClick = { ModelDownloads.verify(ctx, m) }) { Text("Prüfen") }
                    else -> TextButton(onClick = {
                        if (s.aiWifiOnly && !OfflineMaps.isWifi(ctx)) {
                            android.widget.Toast.makeText(ctx, "Bitte mit WLAN verbinden (oder „Nur im WLAN“ ausschalten)", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            ModelDownloads.start(ctx, m)
                        }
                    }) { Text("Laden") }
                }
            }
        }
        ToggleRow("Nur im WLAN herunterladen", s.aiWifiOnly) { v -> Settings.update { it.copy(aiWifiOnly = v) } }
        Label("Rechenkerne: ${s.aiThreads}")
        Segmented(listOf("2", "4", "6"), listOf(2, 4, 6).indexOf(s.aiThreads).coerceAtLeast(1)) { i -> Settings.update { it.copy(aiThreads = listOf(2, 4, 6)[i]) }; LlmEngine.unload() }
        Text("Mehr Kerne = schneller, aber mehr Akku. Auf dem Pixel 8 Pro sind 4 ein guter Wert.", color = pal.sub, fontSize = 12.sp)
    }
    Section("Schnellstart") {
        val preparing by LlmEngine.preparing.collectAsState()
        val ver2 by ModelDownloads.version.collectAsState()
        val m = LlmModels.byId(s.aiModel)
        val ready = remember(ver2, preparing) { LlmEngine.cacheFile(ctx, m.id, 0).exists() }
        Text(
            when {
                preparing -> "Anleitung wird eingelesen … (einmalig)"
                ready -> "✓ Vorbereitet – Anfragen starten sofort"
                else -> "Noch nicht vorbereitet – die erste Anfrage dauert einmalig länger"
            },
            color = if (ready && !preparing) pal.green else pal.text, fontSize = 14.sp,
        )
        if (!preparing && LlmModels.isDownloaded(ctx, m)) {
            TextButton(onClick = { Assistant.prewarm(ctx) }) { Text(if (ready) "Erneut prüfen" else "Jetzt vorbereiten") }
        }
        ToggleRow("Antworten von der KI formulieren (langsamer)", s.aiReplyLlm) { v -> Settings.update { it.copy(aiReplyLlm = v) } }
        Text("Aus: Die App antwortet sofort mit festen Sätzen und den echten Zahlen.", color = pal.sub, fontSize = 12.sp)
    }
    Section("Leistung") {
        val stats by LlmEngine.stats.collectAsState()
        val cpu by LlmEngine.cpu.collectAsState()
        Text("Prozessor-Variante: " + cpu.ifBlank { "wird beim ersten Laden ermittelt" }, color = pal.text, fontSize = 14.sp)
        if (LlmEngine.loadMs > 0) Text("Modell laden: ${"%.1f".format(LlmEngine.loadMs / 1000.0)} s", color = pal.text, fontSize = 14.sp)
        if (stats.isEmpty()) Text("Noch keine Anfrage gemessen.", color = pal.sub, fontSize = 13.sp)
        stats.forEach { st ->
            val pTps = if (st.promptMs > 0) st.promptN / (st.promptMs / 1000) else 0.0
            val gTps = if (st.genMs > 0) st.genN / (st.genMs / 1000) else 0.0
            Text(
                "${st.label}: ${"%.1f".format((st.promptMs + st.genMs) / 1000)} s · Eingabe ${st.promptN} Tokens (${pTps.roundToInt()} T/s)" +
                    (if (st.fromFile) " · Anleitung aus Datei" else "") + " · Ausgabe ${st.genN} Tokens (${"%.1f".format(gTps)} T/s)",
                color = pal.text, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

@Composable
private fun NavPage(s: AppSettings, onClose: () -> Unit = {}) {
    val pal = LocalPal.current
    Section("Ansagen") {
        ToggleRow("Sprachansagen", s.voice) { v -> Settings.update { it.copy(voice = v) } }
    }
    Section("Routen") {
        ToggleRow("Mautstraßen vermeiden", s.avoidToll) { v -> Settings.update { it.copy(avoidToll = v) } }
        ToggleRow("Autobahnen vermeiden", s.avoidMotorway) { v -> Settings.update { it.copy(avoidMotorway = v) } }
        ToggleRow("Fähren vermeiden", s.avoidFerry) { v -> Settings.update { it.copy(avoidFerry = v) } }
        Spacer(Modifier.height(10.dp))
        Label(if (s.maxSpeedKmh == 0) "Höchstgeschwindigkeit: keine Begrenzung" else "Höchstgeschwindigkeit: ${s.maxSpeedKmh} km/h")
        Slider(
            value = (if (s.maxSpeedKmh == 0) 170 else s.maxSpeedKmh).toFloat(),
            onValueChange = { v -> val k = (v / 10).roundToInt() * 10; Settings.update { it.copy(maxSpeedKmh = if (k >= 170) 0 else k) } },
            valueRange = 90f..170f,
        )
        Text("Gilt für neue Routen. Die Höchstgeschwindigkeit beeinflusst Fahrzeit und Verbrauch (nur mit TomTom).", color = pal.sub, fontSize = 13.sp)
    }
    Section("Verkehr") {
        ToggleRow("Verkehrslage auf der Karte", s.showTraffic) { v -> Settings.update { it.copy(showTraffic = v) } }
        if (!s.hasTomTom) Text("Braucht einen TomTom-Key.", color = pal.sub, fontSize = 13.sp)
    }
    EcoAndSimulationSections(s) { onClose() }
    Section("Tempo-Coach") {
        ToggleRow("Tempo-Coach", s.coachEnabled) { v -> Settings.update { it.copy(coachEnabled = v) } }
        ToggleRow("Tipps ansagen", s.coachVoice) { v -> Settings.update { it.copy(coachVoice = v) } }
        Text(
            "Schlägt während der Fahrt (ab 80 km/h) ein niedrigeres Tempo vor, wenn dadurch ein Ladestopp entfällt oder der Akku sonst zu knapp wird.",
            color = pal.sub, fontSize = 13.sp,
        )
    }
    Section("Reichweiten-Blase") {
        ToggleRow("Knopf auf der Karte anzeigen", s.reachEnabled) { v -> Settings.update { it.copy(reachEnabled = v) }; if (!v && Reach.state.value.active) Reach.toggle() }
        ToggleRow("Ring „hin und zurück“", s.reachRoundTrip) { v -> Settings.update { it.copy(reachRoundTrip = v) } }
        Text(
            "Zeigt, wie weit du mit dem aktuellen Akku kommst (bis zur Reserve am Ladestopp), über echte Straßen mit deinem gelernten Verbrauch.",
            color = pal.sub, fontSize = 13.sp,
        )
    }
    Section("Offline-Karte") {
        val off by OfflineMaps.state.collectAsState()
        val ctx = LocalContext.current
        ToggleRow("Karte der Route automatisch speichern", s.offlineAuto) { v -> Settings.update { it.copy(offlineAuto = v) } }
        ToggleRow("Nur im WLAN", s.offlineWifiOnly) { v -> Settings.update { it.copy(offlineWifiOnly = v) } }
        Spacer(Modifier.height(6.dp))
        Label("Detailgrad")
        Segmented(listOf("Detailliert", "Sparsam"), if (s.offlineDetail) 0 else 1) { i -> Settings.update { it.copy(offlineDetail = i == 0) } }
        Text(
            "Gespeichert wird die Karte entlang der Route (etwa 1 km links und rechts). Detailliert braucht für 300 km grob 20–40 MB.",
            color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            when {
                off.error != null -> "Fehler: ${off.error}"
                off.running -> "Lädt „${off.label}“ … ${off.percent} % · ${String.format(java.util.Locale.GERMANY, "%.1f", off.sizeMb)} MB"
                off.done -> "Gespeichert: „${off.label}“ · ${String.format(java.util.Locale.GERMANY, "%.1f", off.sizeMb)} MB"
                else -> "Noch keine Route gespeichert."
            },
            color = if (off.error != null) pal.red else pal.text, fontSize = 14.sp,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
            if (NavSession.state.value.route != null) {
                TextButton(onClick = { NavSession.saveOffline() }) { Text("Aktuelle Route speichern") }
            }
            TextButton(onClick = { OfflineMaps.clear(ctx) }) { Text("Löschen", color = pal.red) }
        }
    }
}

@Composable
private fun VehiclePage(s: AppSettings) {
    val pal = LocalPal.current
    val cur = Vehicles.byId(s.vehicleId)
    var picking by remember { mutableStateOf(false) }
    Section("Fahrzeug") {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { picking = !picking }.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(cur.name, color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    listOf(cur.years, if (cur.grossKwh > 0) "${cur.grossKwh.roundToInt()} kWh brutto" else "", "bis ${Vehicles.maxDc(s).roundToInt()} kW DC", cur.obd.label)
                        .filter { it.isNotBlank() }.joinToString(" · "),
                    color = pal.sub, fontSize = 13.sp,
                )
            }
            Text(if (picking) "Fertig" else "Ändern", color = pal.blue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        if (cur.note.isNotBlank()) Text(cur.note, color = Color(0xFFFF9500), fontSize = 13.sp)
        if (picking) {
            Vehicles.ALL.groupBy { it.group }.forEach { (group, list) ->
                Text(group, color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 2.dp))
                list.forEach { v ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                            Settings.update { it.copy(vehicleId = v.id, usableKwh = v.usableKwh) }
                            picking = false
                        }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(20.dp).clip(CircleShape)
                                .background(if (v.id == cur.id) pal.blue else pal.field),
                            contentAlignment = Alignment.Center,
                        ) { if (v.id == cur.id) Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White)) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(v.name, color = pal.text, fontSize = 15.sp)
                            Text(
                                listOf(v.years, if (v.id != "custom") "${v.usableKwh.roundToInt()} kWh netto · ${v.maxDcKw.roundToInt()} kW" else "Kapazität und Ladeleistung selbst einstellen")
                                    .filter { it.isNotBlank() }.joinToString(" · "),
                                color = pal.sub, fontSize = 12.sp,
                            )
                        }
                        Text(
                            v.obd.label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                            color = when (v.obd) { ObdSupport.TESTED -> pal.green; ObdSupport.LIKELY -> Color(0xFFFF9500); ObdSupport.NONE -> pal.sub },
                        )
                    }
                }
            }
            Text(
                "„OBD ✓“: Abfragen wie beim ë-C4 bestätigt. „ungetestet“: gleiche Plattform, Abfragen sehr wahrscheinlich gleich. " +
                    "„kein OBD“: eigenes System, Akku am Ring einstellen. Gelerntes (Verbrauch, Ladekurve) stammt vom bisherigen Fahrzeug – nach einem Wechsel ggf. unter „Fahrten & Lernen“ zurücksetzen.",
                color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
    Section("Akku (${cur.name})") {
        Label("Nutzbare Kapazität: ${String.format(java.util.Locale.GERMANY, "%.1f", s.usableKwh)} kWh")
        Slider(
            value = s.usableKwh.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(usableKwh = (v * 2).roundToInt() / 2.0) } },
            valueRange = 20f..100f,
        )
        if (cur.id == "custom") {
            Label("Höchste Ladeleistung (DC): ${s.customDcKw} kW")
            Slider(
                value = s.customDcKw.toFloat(),
                onValueChange = { v -> Settings.update { it.copy(customDcKw = (v / 5).roundToInt() * 5) } },
                valueRange = 20f..250f,
            )
        }
        Text("Mit OBD kannst du den gemessenen Wert unter „OBD2-Adapter → Live & Rohdaten“ übernehmen.", color = pal.sub, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        ToggleRow("Akkustand abrunden wie im Auto", s.socFloor) { b -> Settings.update { it.copy(socFloor = b) } }
    }
    Section("Verbrauch") {
        Label("Fahrweise")
        Segmented(listOf("Sparsam", "Normal", "Zügig"), s.style) { i -> Settings.update { it.copy(style = i) } }
        Text("Wird nach und nach durch dein gelerntes Fahrverhalten ersetzt.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 12.dp))
        Label("Referenzverbrauch: ${s.refConsumptionPct} %")
        Slider(
            value = s.refConsumptionPct.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(refConsumptionPct = (v / 5).roundToInt() * 5) } },
            valueRange = 80f..130f,
        )
        Label("Zusatzgewicht (Personen, Gepäck): ${s.extraWeightKg} kg")
        Slider(
            value = s.extraWeightKg.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(extraWeightKg = (v / 25).roundToInt() * 25) } },
            valueRange = 0f..400f,
        )
    }
}

@Composable
private fun ChargingPage(s: AppSettings) {
    Section("Reserve") {
        Label("Mindest-Akku am Ladestopp: ${fmtPct(s.minSocStop)}")
        Slider(
            value = s.minSocStop.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(minSocStop = v.roundToInt().toDouble()) } },
            valueRange = 5f..30f,
        )
        Label("Mindest-Akku am Ziel: ${fmtPct(s.minSocDest)}")
        Slider(
            value = s.minSocDest.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(minSocDest = v.roundToInt().toDouble()) } },
            valueRange = 5f..50f,
        )
    }
    Section("Ladeanbieter und Ladekarten") { OperatorSettings(s) }
}

@Composable
private fun TomTomPage(s: AppSettings) {
    val pal = LocalPal.current
    Section("Zugang") {
        OutlinedTextField(
            value = s.tomtomKey,
            onValueChange = { v -> Settings.update { it.copy(tomtomKey = v.trim()) } },
            label = { Text("TomTom API-Key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Für Verkehr, Ladestopps, Spuren, Tempolimits und Ladesäulen-Belegung.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
    Section("Verbrauch heute") {
        val count by ApiCounter.today.collectAsState()
        Text("$count von 2.500 freien Anfragen", color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text("Karten-Kacheln für die Verkehrslage zählen extra (50.000 pro Tag).", color = pal.sub, fontSize = 13.sp)
    }
}

@Composable
private fun InfoPage() {
    val pal = LocalPal.current
    Section("Version") {
        Text("ELdoroado ${BuildConfigLite.version}", color = pal.text, fontSize = 16.sp)
        SigningInfo()
    }
    Section("Fehlerprotokoll") {
        val ver by CrashLog.version.collectAsState()
        val ctx = LocalContext.current
        val text = remember(ver) { CrashLog.text() }
        if (text.isBlank()) {
            Text("Keine Fehler aufgezeichnet.", color = pal.sub, fontSize = 14.sp)
        } else {
            val count = Regex("=== ").findAll(text).count()
            Text("$count Einträge, letzter:", color = pal.text, fontSize = 14.sp)
            Text(
                text.trim().substringAfterLast("=== ").take(600), color = pal.sub, fontSize = 12.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, maxLines = 12, overflow = TextOverflow.Ellipsis,
            )
            Row {
                TextButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "ELdoroado Fehlerprotokoll")
                        putExtra(Intent.EXTRA_TEXT, scrubSecrets(CrashLog.text()))
                    }
                    ctx.startActivity(Intent.createChooser(send, "Protokoll teilen"))
                }) { Text("Teilen") }
                TextButton(onClick = { CrashLog.clear() }) { Text("Löschen", color = pal.red) }
            }
        }
    }
    Section("Datenquellen") {
        Text(
            "Kartendaten © OpenStreetMap-Mitwirkende\nKartenstil: OpenFreeMap\nRouting ohne Key: OSRM\nSuche: Photon (Komoot)\n" +
                "Verkehr und Ladeplanung: TomTom\nWetter und Höhe: Open-Meteo",
            color = pal.sub, fontSize = 14.sp,
        )
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column {
        Text(title.uppercase(), color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 14.dp, bottom = 6.dp))
        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid) {
            Column(Modifier.fillMaxWidth().padding(14.dp), content = content)
        }
    }
}

@Composable
fun Label(t: String) {
    Text(t, color = LocalPal.current.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.field).padding(3.dp)) {
        options.forEachIndexed { i, o ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                    .background(if (i == selected) pal.selectedSeg else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    o, color = pal.text, fontSize = 14.sp,
                    fontWeight = if (i == selected) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

@Composable
fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = pal.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = value,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = pal.green, checkedThumbColor = Color.White),
        )
    }
}
