package de.evroute

/** Hilfen für die Übersicht während der Navigation */
object RouteBarData {
    fun nearestIdx(r: Route, m: Double): Int {
        var i = r.cumM.binarySearch(m)
        if (i < 0) i = -i - 1
        return i.coerceIn(0, r.points.lastIndex)
    }

    /** Punkte eines Streckenabschnitts (zum Einpassen der Karte) */
    fun slice(r: Route, from: Double, to: Double): List<LatLon> {
        val a = nearestIdx(r, from)
        val b = nearestIdx(r, to).coerceAtLeast(a + 1).coerceAtMost(r.points.lastIndex)
        val step = ((b - a) / 300).coerceAtLeast(1)
        return (a..b step step).map { r.points[it] } + r.points[b]
    }
}
