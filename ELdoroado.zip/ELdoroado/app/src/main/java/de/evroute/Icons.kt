package de.evroute

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import android.graphics.Color as AColor
import androidx.compose.ui.graphics.Path as CPath

/** Fahrzeugsymbole für die Karte (als Bitmap, Spitze zeigt nach Norden) */
object VehicleIcons {
    private fun shadowPaint(d: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x66000000
        maskFilter = BlurMaskFilter(3.5f * d, BlurMaskFilter.Blur.NORMAL)
    }

    /** Navigationspfeil im TomTom-Stil: zweifarbiger 3D-Pfeil mit weißem Rand und Schatten */
    fun arrow(ctx: Context): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val s = (54 * d).toInt()
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val tipX = 0.5f * s; val tipY = 0.08f * s
        val rX = 0.86f * s; val rY = 0.88f * s
        val nX = 0.5f * s; val nY = 0.68f * s
        val lX = 0.14f * s; val lY = 0.88f * s
        val outline = Path().apply { moveTo(tipX, tipY); lineTo(rX, rY); lineTo(nX, nY); lineTo(lX, lY); close() }
        // Schatten
        c.save(); c.translate(0f, 3f * d); c.drawPath(outline, shadowPaint(d)); c.restore()
        // weißer Rand
        c.drawPath(
            outline,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL_AND_STROKE
                strokeWidth = 5f * d
                strokeJoin = Paint.Join.ROUND
                color = AColor.WHITE
            },
        )
        // linke Hälfte hell, rechte Hälfte dunkel (3D-Wirkung)
        val left = Path().apply { moveTo(tipX, tipY); lineTo(nX, nY); lineTo(lX, lY); close() }
        val right = Path().apply { moveTo(tipX, tipY); lineTo(rX, rY); lineTo(nX, nY); close() }
        c.drawPath(left, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF4DA6FF.toInt() })
        c.drawPath(right, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A5BD6.toInt() })
        return bmp
    }

    fun dot(ctx: Context): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val s = (34 * d).toInt()
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = s / 2f
        c.drawCircle(cx, cx, s * 0.48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x330A84FF })
        c.drawCircle(cx, cx + d, s * 0.30f, shadowPaint(d))
        c.drawCircle(cx, cx, s * 0.30f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.WHITE })
        c.drawCircle(cx, cx, s * 0.22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A84FF.toInt() })
        return bmp
    }

    /** Kleines Auto von oben, Farbe frei wählbar */
    fun car(ctx: Context, color: Int): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val w = (28 * d).toInt()
        val h = (52 * d).toInt()
        val bmp = Bitmap.createBitmap(h, h, Bitmap.Config.ARGB_8888) // quadratisch, damit die Drehung mittig bleibt
        val c = Canvas(bmp)
        c.translate((h - w) / 2f, 0f)
        val body = RectF(0.10f * w, 0.04f * h, 0.90f * w, 0.96f * h)
        val r = 0.34f * w
        c.save(); c.translate(0f, 2f * d); c.drawRoundRect(body, r, r, shadowPaint(d)); c.restore()
        c.drawRoundRect(body, r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
        c.drawRoundRect(
            body, r, r,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 1.4f * d
                this.color = shade(color, 0.7f)
            },
        )
        val glass = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xE61B2430.toInt() }
        val front = Path().apply {
            moveTo(0.24f * w, 0.25f * h); lineTo(0.76f * w, 0.25f * h)
            lineTo(0.84f * w, 0.40f * h); lineTo(0.16f * w, 0.40f * h); close()
        }
        c.drawPath(front, glass)
        c.drawRoundRect(
            RectF(0.20f * w, 0.42f * h, 0.80f * w, 0.72f * h), 0.12f * w, 0.12f * w,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = shade(color, 1.12f) },
        )
        val rear = Path().apply {
            moveTo(0.18f * w, 0.74f * h); lineTo(0.82f * w, 0.74f * h)
            lineTo(0.74f * w, 0.85f * h); lineTo(0.26f * w, 0.85f * h); close()
        }
        c.drawPath(rear, glass)
        val light = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFFFFF4C2.toInt() }
        c.drawOval(RectF(0.18f * w, 0.05f * h, 0.38f * w, 0.09f * h), light)
        c.drawOval(RectF(0.62f * w, 0.05f * h, 0.82f * w, 0.09f * h), light)
        return bmp
    }

    /** Roter Stecknadel-Pin für einen gewählten Ort */
    fun pin(ctx: Context): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val w = (34 * d).toInt()
        val h = (46 * d).toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = w / 2f
        val r = w * 0.42f
        val body = Path().apply {
            addCircle(cx, r + 2 * d, r, Path.Direction.CW)
            moveTo(cx - r * 0.62f, r + 2 * d + r * 0.72f)
            lineTo(cx, h - 2 * d)
            lineTo(cx + r * 0.62f, r + 2 * d + r * 0.72f)
            close()
        }
        c.save(); c.translate(0f, 1.5f * d); c.drawPath(body, shadowPaint(d)); c.restore()
        c.drawPath(body, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF3B30.toInt() })
        c.drawCircle(cx, r + 2 * d, r * 0.38f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.WHITE })
        return bmp
    }

    /** Pfeilspitze für den Abbiegepfeil auf der Route (weiß mit dunklem Rand, zeigt nach oben) */
    fun arrowHead(ctx: Context): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val s = (30 * d).toInt()
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val path = Path().apply {
            moveTo(0.5f * s, 0.06f * s)
            lineTo(0.94f * s, 0.94f * s)
            lineTo(0.06f * s, 0.94f * s)
            close()
        }
        c.drawPath(
            path,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 4f * d
                strokeJoin = Paint.Join.ROUND
                color = 0xFF0B1E3F.toInt()
            },
        )
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.WHITE })
        return bmp
    }

    /** Ladesymbol in beliebiger Farbe (für Ladestationen auf der Karte) */
    fun chargerColored(ctx: Context, fillColor: Int, sizeDp: Int = 28): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val s = (sizeDp * d).toInt()
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = s / 2f
        c.drawCircle(cx, cx + d, s * 0.42f, shadowPaint(d))
        c.drawCircle(cx, cx, s * 0.42f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.WHITE })
        c.drawCircle(cx, cx, s * 0.35f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fillColor })
        val bolt = Path().apply {
            moveTo(0.56f * s, 0.22f * s); lineTo(0.34f * s, 0.55f * s); lineTo(0.48f * s, 0.55f * s)
            lineTo(0.43f * s, 0.78f * s); lineTo(0.66f * s, 0.44f * s); lineTo(0.52f * s, 0.44f * s); close()
        }
        c.drawPath(bolt, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.WHITE })
        return bmp
    }

    /** Grünes Ladesymbol für Ladestopps auf der Karte */
    fun charger(ctx: Context): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val s = (34 * d).toInt()
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = s / 2f
        c.drawCircle(cx, cx + d, s * 0.42f, shadowPaint(d))
        c.drawCircle(cx, cx, s * 0.42f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.WHITE })
        c.drawCircle(cx, cx, s * 0.36f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF30D158.toInt() })
        val bolt = Path().apply {
            moveTo(0.56f * s, 0.20f * s); lineTo(0.32f * s, 0.55f * s); lineTo(0.48f * s, 0.55f * s)
            lineTo(0.42f * s, 0.80f * s); lineTo(0.68f * s, 0.43f * s); lineTo(0.52f * s, 0.43f * s); close()
        }
        c.drawPath(bolt, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.WHITE })
        return bmp
    }

    private fun shade(c: Int, f: Float): Int {
        fun ch(v: Int) = (v * f).toInt().coerceIn(0, 255)
        return AColor.argb(AColor.alpha(c), ch(AColor.red(c)), ch(AColor.green(c)), ch(AColor.blue(c)))
    }
}

/** Abbiegepfeile im Banner (selbst gezeichnet, wie bei Apple Maps) */
@Composable
fun ManeuverIcon(type: String, mod: String?, color: Color, dp: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(dp)) { drawManeuver(type, mod, color) }
}

private fun angleOf(mod: String?): Double = when (mod) {
    "slight right" -> 40.0
    "right" -> 90.0
    "sharp right" -> 135.0
    "slight left" -> -40.0
    "left" -> -90.0
    "sharp left" -> -135.0
    "uturn" -> 180.0
    else -> 0.0
}

private fun dirOf(deg: Double): Offset {
    val a = deg * PI / 180
    return Offset(sin(a).toFloat(), -cos(a).toFloat())
}

private fun DrawScope.drawManeuver(type: String, mod: String?, color: Color) {
    val w = size.width
    val sw = w * 0.11f
    val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)

    fun head(e: Offset, deg: Double) {
        val dv = dirOf(deg)
        val n = Offset(-dv.y, dv.x)
        val h = w * 0.17f
        val p = CPath().apply {
            moveTo((e + dv * h).x, (e + dv * h).y)
            lineTo((e + n * (h * 0.85f)).x, (e + n * (h * 0.85f)).y)
            lineTo((e - n * (h * 0.85f)).x, (e - n * (h * 0.85f)).y)
            close()
        }
        drawPath(p, color)
    }

    when {
        type == "charge" -> {
            val p = CPath().apply {
                moveTo(w * 0.58f, w * 0.06f)
                lineTo(w * 0.24f, w * 0.56f)
                lineTo(w * 0.47f, w * 0.56f)
                lineTo(w * 0.40f, w * 0.94f)
                lineTo(w * 0.77f, w * 0.40f)
                lineTo(w * 0.53f, w * 0.40f)
                close()
            }
            drawPath(p, color)
        }
        type == "arrive" -> {
            val c = Offset(w * 0.5f, w * 0.36f)
            drawCircle(color, w * 0.2f, c, style = Stroke(sw * 0.9f))
            drawCircle(color, w * 0.07f, c)
            drawLine(color, Offset(w * 0.5f, w * 0.58f), Offset(w * 0.5f, w * 0.92f), sw, StrokeCap.Round)
        }
        type == "roundabout" || type == "rotary" || type == "roundabout turn" -> {
            // Kreis gegen den Uhrzeigersinn: Einfahrt unten, befahrener Bogen kräftig bis zur Ausfahrt
            val c = Offset(w * 0.5f, w * 0.47f)
            val r = w * 0.19f
            drawCircle(color.copy(alpha = 0.35f), r, c, style = Stroke(sw * 0.75f))
            drawLine(color, Offset(w * 0.5f, w * 0.96f), Offset(w * 0.5f, c.y + r), sw, StrokeCap.Round)
            val deg = if (mod == "uturn") 200.0 else angleOf(mod).let { if (it == 0.0 && mod != "straight" && mod != null) 0.0 else it }
            val exitCanvas = (deg - 90.0).toFloat()
            var sweep = 90f - exitCanvas
            while (sweep <= 0f) sweep += 360f
            while (sweep > 360f) sweep -= 360f
            drawArc(
                color, 90f, -sweep, false, Offset(c.x - r, c.y - r), androidx.compose.ui.geometry.Size(r * 2, r * 2),
                style = Stroke(sw, cap = StrokeCap.Round),
            )
            val dv = dirOf(deg)
            val e = c + dv * (r + w * 0.2f)
            drawLine(color, c + dv * r, e, sw, StrokeCap.Round)
            head(e, deg)
        }
        mod == "uturn" -> {
            val p = CPath().apply {
                moveTo(w * 0.66f, w * 0.92f)
                lineTo(w * 0.66f, w * 0.42f)
                cubicTo(w * 0.66f, w * 0.12f, w * 0.30f, w * 0.12f, w * 0.30f, w * 0.42f)
                lineTo(w * 0.30f, w * 0.56f)
            }
            drawPath(p, color, style = stroke)
            head(Offset(w * 0.30f, w * 0.56f), 180.0)
        }
        else -> {
            val deg = angleOf(mod)
            val mid = Offset(w * 0.5f, w * 0.56f)
            val e = mid + dirOf(deg) * (w * 0.27f)
            val p = CPath().apply {
                moveTo(w * 0.5f, w * 0.94f)
                lineTo(mid.x, mid.y)
                lineTo(e.x, e.y)
            }
            drawPath(p, color, style = stroke)
            head(e, deg)
        }
    }
}
