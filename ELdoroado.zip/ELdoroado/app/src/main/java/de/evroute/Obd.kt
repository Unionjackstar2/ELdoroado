package de.evroute

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Eine Abfrage an ein Steuergerät (UDS „22 xx xx“) */
data class PidDef(
    val key: String,
    val label: String,
    val ecu: String,
    val did: String,
    val unit: String,
    val every: Int, // jede n-te Runde abfragen
    val decode: (ByteArray, AppSettings) -> Double?,
)

data class PidValue(val label: String, val raw: String, val value: Double?, val unit: String, val time: Long)

/**
 * OBD2 für Citroën ë-C4 / Stellantis e-CMP über einen BLE-ELM327 (z. B. Vgate iCar Pro 2S).
 * Abfragen nach OVMS-/Car-Scanner-Liste: BMS 6B4 (Antwort 694), Fahrzeug 6A2 (Antwort 682).
 */
@SuppressLint("MissingPermission")
object Obd {
    enum class Conn { OFF, CONNECTING, INIT, READY, ERROR }

    data class Dev(val name: String, val address: String, val rssi: Int)

    private val RESP = mapOf("6B4" to "694", "6A2" to "682")

    private fun u16(b: ByteArray, i: Int = 0): Int? =
        if (b.size >= i + 2) ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF) else null

    private fun u8(b: ByteArray, i: Int = 0): Int? = if (b.size > i) b[i].toInt() and 0xFF else null

    val PIDS = listOf(
        PidDef("soc", "Akkustand (SoC)", "6B4", "D810", "%", 1) { b, _ -> u16(b)?.div(512.0) },
        PidDef("socCal", "Akkustand kalibriert", "6B4", "D410", "%", 1) { b, _ -> u16(b)?.div(512.0) },
        PidDef("kwh", "Energie im Akku", "6B4", "D865", "kWh", 1) { b, _ -> u16(b)?.div(100.0) },
        PidDef("volt", "Spannung (D815)", "6B4", "D815", "V", 1) { b, s -> u16(b)?.times(s.obdVoltFactor) },
        PidDef("curr", "Strom (D816)", "6B4", "D816", "A", 1) { b, s ->
            u16(b)?.let { raw -> val v = if (s.obdCurrSigned && raw >= 0x8000) raw - 0x10000 else raw; v * s.obdCurrFactor + s.obdCurrOffset }
        },
        PidDef("soh", "Gesundheit (SOH)", "6B4", "D860", "%", 10) { b, _ -> u16(b)?.div(655.36) },
        PidDef("cellMin", "Zelle min.", "6B4", "D86F", "V", 5) { b, _ -> u16(b)?.div(1000.0) },
        PidDef("cellMax", "Zelle max.", "6B4", "D870", "V", 5) { b, _ -> u16(b)?.div(1000.0) },
        PidDef("ambient", "Außentemperatur (≈)", "6A2", "D434", "°C", 5) { b, _ -> u8(b)?.minus(40.0) },
        PidDef("battTemp", "Akkutemperatur (≈)", "6A2", "D8EF", "°C", 5) { b, _ -> u8(b)?.minus(40.0) },
        PidDef("speed", "Tempo (≈)", "6A2", "D402", "km/h", 2) { b, _ -> u16(b)?.div(100.0) },
    )

    // Bekannte BLE-UART-Kanäle von ELM327-Adaptern (Service, Notify, Write)
    private val KNOWN = listOf(
        Triple("0000fff0-0000-1000-8000-00805f9b34fb", "0000fff1-0000-1000-8000-00805f9b34fb", "0000fff2-0000-1000-8000-00805f9b34fb"),
        Triple("e7810a71-73ae-499d-8c15-faa9aef0c3f2", "bef8d6c9-9c21-4c9e-b632-bd58c1009f9f", "bef8d6c9-9c21-4c9e-b632-bd58c1009f9f"),
        Triple("000018f0-0000-1000-8000-00805f9b34fb", "00002af0-0000-1000-8000-00805f9b34fb", "00002af1-0000-1000-8000-00805f9b34fb"),
        Triple("0000ffe0-0000-1000-8000-00805f9b34fb", "0000ffe1-0000-1000-8000-00805f9b34fb", "0000ffe1-0000-1000-8000-00805f9b34fb"),
    )
    private val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val holders = mutableSetOf<String>()
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var pollJob: Job? = null
    private var reconnectJob: Job? = null
    private var scanCb: ScanCallback? = null
    private val buffer = StringBuilder()
    @Volatile private var pending: CompletableDeferred<String>? = null
    private val mutex = Mutex()
    private var currentEcu: String? = null
    private var failures = 0

    private val _conn = MutableStateFlow(Conn.OFF)
    val conn: StateFlow<Conn> = _conn.asStateFlow()
    private val _status = MutableStateFlow("Nicht verbunden")
    val status: StateFlow<String> = _status.asStateFlow()
    private val _values = MutableStateFlow<Map<String, PidValue>>(emptyMap())
    val values: StateFlow<Map<String, PidValue>> = _values.asStateFlow()
    private val _log = MutableStateFlow<List<String>>(emptyList())
    val log: StateFlow<List<String>> = _log.asStateFlow()
    private val _devices = MutableStateFlow<List<Dev>>(emptyList())
    val devices: StateFlow<List<Dev>> = _devices.asStateFlow()
    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()

    fun init(ctx: Context) { app = ctx.applicationContext }

    private val bt get() = (app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    fun hasPermission(): Boolean = if (Build.VERSION.SDK_INT >= 31) {
        ContextCompat.checkSelfPermission(app, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(app, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
    } else {
        ContextCompat.checkSelfPermission(app, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    /** Frischer Akkustand (höchstens 2 Minuten alt) */
    fun freshSoc(): Double? {
        val key = if (Settings.state.value.obdSocSource == 1) "socCal" else "soc"
        val v = _values.value[key] ?: return null
        val soc = v.value ?: return null
        return if (System.currentTimeMillis() - v.time < 120_000 && soc in 0.5..100.5) soc.coerceIn(0.0, 100.0) else null
    }

    fun value(key: String): Double? = _values.value[key]?.takeIf { System.currentTimeMillis() - it.time < 120_000 }?.value

    private fun logLine(s: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(Date())
        _log.update { (it + "$t  $s").takeLast(300) }
    }

    fun clearLog() { _log.value = emptyList() }

    // ---------------- Suchen ----------------

    fun startScan() {
        if (!hasPermission() || bt?.isEnabled != true) {
            _status.value = if (bt?.isEnabled == true) "Bluetooth-Berechtigung fehlt" else "Bluetooth ist ausgeschaltet"
            return
        }
        stopScan()
        _devices.value = emptyList()
        val cb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                val name = r.device.name ?: r.scanRecord?.deviceName ?: return
                val d = Dev(name, r.device.address, r.rssi)
                _devices.update { list -> (list.filter { it.address != d.address } + d).sortedByDescending { it.rssi } }
            }
        }
        scanCb = cb
        bt.bluetoothLeScanner?.startScan(cb)
        _scanning.value = true
        scope.launch { delay(15_000); stopScan() }
    }

    fun stopScan() {
        scanCb?.let { runCatching { bt?.bluetoothLeScanner?.stopScan(it) } }
        scanCb = null
        _scanning.value = false
    }

    fun select(d: Dev) {
        stopScan()
        Settings.update { it.copy(obdAddress = d.address, obdName = d.name) }
        disconnect()
        if (holders.isNotEmpty()) connect()
    }

    fun forget() {
        disconnect()
        Settings.update { it.copy(obdAddress = "", obdName = "") }
    }

    // ---------------- Wer braucht die Verbindung? ----------------

    fun acquire(tag: String) {
        // Fahrzeuge ohne hinterlegte OBD-Abfragen (z. B. Leapmotor): gar nicht erst verbinden
        if (Vehicles.current().obd == ObdSupport.NONE) return
        holders += tag
        if (_conn.value == Conn.OFF || _conn.value == Conn.ERROR) connect()
    }

    fun release(tag: String) {
        holders -= tag
        if (holders.isEmpty()) disconnect()
    }

    fun reconnectNow() { disconnect(); if (holders.isNotEmpty()) connect() }

    private fun connect() {
        val addr = Settings.state.value.obdAddress
        if (addr.isBlank() || !hasPermission() || bt?.isEnabled != true) return
        reconnectJob?.cancel()
        _conn.value = Conn.CONNECTING
        _status.value = "Verbinde mit ${Settings.state.value.obdName} …"
        logLine("Verbinde mit $addr")
        gatt = runCatching { bt.getRemoteDevice(addr).connectGatt(app, false, callback, BluetoothDevice.TRANSPORT_LE) }.getOrNull()
        if (gatt == null) fail("Verbindung nicht möglich")
    }

    fun disconnect() {
        reconnectJob?.cancel()
        pollJob?.cancel()
        runCatching { gatt?.disconnect(); gatt?.close() }
        gatt = null
        writeChar = null
        currentEcu = null
        _conn.value = Conn.OFF
        _status.value = "Nicht verbunden"
    }

    private fun fail(msg: String) {
        logLine("Fehler: $msg")
        pollJob?.cancel()
        runCatching { gatt?.close() }
        gatt = null
        _conn.value = Conn.ERROR
        _status.value = msg
        if (holders.isNotEmpty()) {
            failures++
            val wait = (5_000L * failures).coerceAtMost(30_000L)
            reconnectJob?.cancel()
            reconnectJob = scope.launch { delay(wait); if (holders.isNotEmpty()) connect() }
        }
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                logLine("Verbunden, suche Kanäle")
                g.requestMtu(185)
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                if (_conn.value != Conn.OFF) fail("Verbindung getrennt (Auto aus oder außer Reichweite?)")
            }
        }

        @Suppress("DEPRECATION")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            var notify: BluetoothGattCharacteristic? = null
            var write: BluetoothGattCharacteristic? = null
            for ((s, n, w) in KNOWN) {
                val svc = g.getService(UUID.fromString(s)) ?: continue
                notify = svc.getCharacteristic(UUID.fromString(n))
                write = svc.getCharacteristic(UUID.fromString(w))
                if (notify != null && write != null) break
            }
            if (notify == null || write == null) {
                // Automatisch: erster Dienst mit Benachrichtigung und Schreiben
                for (svc in g.services) {
                    val n = svc.characteristics.firstOrNull {
                        it.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
                    }
                    val w = svc.characteristics.firstOrNull {
                        it.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                    }
                    if (n != null && w != null && !svc.uuid.toString().startsWith("00001800") && !svc.uuid.toString().startsWith("00001801")) {
                        notify = n; write = w; break
                    }
                }
            }
            if (notify == null || write == null) { fail("Kein passender Kanal am Adapter gefunden"); return }
            logLine("Kanal: ${notify.service.uuid.toString().take(8)} / ${notify.uuid.toString().take(8)} / ${write.uuid.toString().take(8)}")
            writeChar = write
            write.writeType = if (write.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) {
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            } else {
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            }
            g.setCharacteristicNotification(notify, true)
            val d = notify.getDescriptor(CCCD)
            if (d == null) { startInit(); return }
            d.value = if (notify.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) {
                BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            } else {
                BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            }
            g.writeDescriptor(d)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) { startInit() }

        @Suppress("DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) = onBytes(c.value ?: ByteArray(0))

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) = onBytes(value)
    }

    private fun onBytes(b: ByteArray) {
        synchronized(buffer) {
            buffer.append(String(b, Charsets.US_ASCII))
            if (buffer.contains('>')) pending?.complete(buffer.toString())
        }
    }

    /** Befehl senden und Antwort bis zum Prompt „>“ abwarten */
    @Suppress("DEPRECATION")
    suspend fun send(cmd: String, timeoutMs: Long = 3000, log: Boolean = false): String = mutex.withLock {
        val c = writeChar ?: throw IllegalStateException("nicht verbunden")
        val g = gatt ?: throw IllegalStateException("nicht verbunden")
        val d = CompletableDeferred<String>()
        synchronized(buffer) { buffer.clear() }
        pending = d
        c.value = "$cmd\r".toByteArray(Charsets.US_ASCII)
        g.writeCharacteristic(c)
        val resp = withTimeout(timeoutMs) { d.await() }
        val clean = resp.replace(">", "").trim()
        if (log) logLine("→ $cmd   ← ${clean.replace("\r", " | ").replace("\n", "")}")
        clean
    }

    private fun startInit() {
        scope.launch {
            _conn.value = Conn.INIT
            _status.value = "Adapter wird eingerichtet …"
            try {
                // Einrichtung wie Car Scanner / OVMS für Stellantis-E-Autos
                send("ATWS", 5000, log = true)
                delay(300)
                for (c in listOf("ATE0", "ATL0", "ATS0", "ATH1", "ATSP6", "ATAT1", "ATCAF1", "ATFCSD300000", "ATFCSM1")) {
                    send(c, 3000, log = true)
                }
                currentEcu = null
                failures = 0
                _conn.value = Conn.READY
                _status.value = "Verbunden mit ${Settings.state.value.obdName}"
                startPolling()
            } catch (e: CancellationException) {
                if (e is TimeoutCancellationException) fail("Adapter antwortet nicht") else throw e
            } catch (e: Exception) {
                fail("Einrichtung fehlgeschlagen: ${e.message}")
            }
        }
    }

    private suspend fun selectEcu(ecu: String) {
        if (currentEcu == ecu) return
        send("ATSH$ecu")
        send("ATFCSH$ecu")
        RESP[ecu]?.let { send("ATCRA$it") }
        currentEcu = ecu
    }

    /** Ab einem eigenen Konsolenbefehl ist der Steuergeräte-Zustand unbekannt */
    suspend fun console(cmd: String): String {
        val r = try {
            send(cmd.trim().uppercase(Locale.ROOT), 5000, log = true)
        } catch (e: CancellationException) {
            if (e is TimeoutCancellationException) "Zeitüberschreitung" else throw e
        } catch (e: Exception) {
            "Fehler: ${e.message}"
        }
        currentEcu = null
        return r
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = scope.launch {
            var round = 0
            var timeouts = 0
            while (isActive) {
                val set = Settings.state.value
                val logRaw = set.obdLogPolling
                for (ecu in listOf("6B4", "6A2")) {
                    val due = PIDS.filter { it.ecu == ecu && round % it.every == 0 }
                    if (due.isEmpty()) continue
                    try {
                        selectEcu(ecu)
                        for (p in due) {
                            val resp = send("22${p.did}", 2500, log = logRaw)
                            val data = parseUds(resp, p.did)
                            if (data != null) {
                                val v = p.decode(data, set)
                                _values.update { it + (p.key to PidValue(p.label, data.toHex(), v, p.unit, System.currentTimeMillis())) }
                            }
                        }
                        timeouts = 0
                    } catch (e: CancellationException) {
                        if (e !is TimeoutCancellationException) throw e
                        timeouts++
                        logLine("Keine Antwort von $ecu")
                        currentEcu = null
                        if (timeouts >= 6) { fail("Auto antwortet nicht (Zündung aus?)"); return@launch }
                    } catch (e: Exception) {
                        logLine("Fehler: ${e.message}")
                        currentEcu = null
                    }
                }
                deriveValues()
                round++
                delay(2000)
            }
        }
    }

    /** Leistung und Kapazität aus den Messwerten ableiten */
    private fun deriveValues() {
        val s = Settings.state.value
        val now = System.currentTimeMillis()
        val v = value("volt")
        val i = value("curr")
        if (s.obdPowerEnabled && v != null && i != null) {
            _values.update { it + ("power" to PidValue("Leistung (berechnet)", "", v * i / 1000.0, "kW", now)) }
        }
        val kwh = value("kwh")
        val soc = freshSoc()
        if (kwh != null && soc != null && soc > 20) {
            _values.update { it + ("capacity" to PidValue("Kapazität (berechnet)", "", kwh / (soc / 100.0), "kWh", now)) }
        }
    }

    /**
     * ELM-Antwort mit Kopfzeilen (ATH1) in die UDS-Nutzdaten nach „62 DID“ wandeln.
     * Einzelrahmen: 694 05 62 D8 10 xx xx; Mehrfachrahmen: 694 10 LL … / 694 21 … (ISO-TP)
     */
    fun parseUds(resp: String, did: String): ByteArray? {
        val up = resp.uppercase(Locale.ROOT)
        if (listOf("NO DATA", "NODATA", "ERROR", "?", "UNABLE", "STOPPED", "BUS").any { up.contains(it) }) return null
        val frames = up.split('\r', '\n').map { it.replace(" ", "").trim() }
            .filter { it.length >= 5 && it.all { c -> c in '0'..'9' || c in 'A'..'F' } && (it.length - 3) % 2 == 0 }
        val out = ArrayList<Byte>()
        var total = -1
        for (f in frames) {
            val bytes = f.substring(3).chunked(2).map { it.toInt(16).toByte() }
            if (bytes.isEmpty()) continue
            val pci = (bytes[0].toInt() and 0xF0) shr 4
            when (pci) {
                0 -> {
                    val len = bytes[0].toInt() and 0x0F
                    out.clear(); out.addAll(bytes.drop(1).take(len)); total = len
                }
                1 -> {
                    total = ((bytes[0].toInt() and 0x0F) shl 8) or (bytes[1].toInt() and 0xFF)
                    out.clear(); out.addAll(bytes.drop(2))
                }
                2 -> out.addAll(bytes.drop(1))
            }
        }
        val payload = if (total > 0) out.take(total) else out
        val didHi = did.substring(0, 2).toInt(16).toByte()
        val didLo = did.substring(2, 4).toInt(16).toByte()
        if (payload.size < 3 || payload[0] != 0x62.toByte() || payload[1] != didHi || payload[2] != didLo) return null
        return payload.drop(3).toByteArray()
    }

    private fun ByteArray.toHex(): String = joinToString(" ") { String.format("%02X", it) }
}
