@file:OptIn(ExperimentalMaterial3Api::class)

package de.evroute

import androidx.compose.material3.AlertDialog
import androidx.compose.material.icons.filled.Build
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.material.icons.filled.Warning
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.animation.animateContentSize
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.ZoomOutMap
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Adjust
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.animation.core.animate
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.speech.RecognizerIntent
import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.material.icons.filled.Mic
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import java.util.Locale
import kotlin.math.roundToInt

// ---------------- Farben im Apple-Stil ----------------

/** Farbschema: TomTom-Klarheit, Apple-Ruhe, Material-3-Expressive-Formen */
class Pal(val dark: Boolean) {
    val card = if (dark) Color(0xFF1E2126) else Color(0xFFFFFFFF)
    val cardSolid = if (dark) Color(0xFF1E2126) else Color.White
    val screen = if (dark) Color(0xFF0F1114) else Color(0xFFF4F6F9)
    val field = if (dark) Color(0xFF2A2E35) else Color(0xFFEEF1F5)
    val text = if (dark) Color(0xFFF2F4F7) else Color(0xFF1B1F24)
    val sub = if (dark) Color(0xFF9AA3AE) else Color(0xFF5B636E)
    val blue = if (dark) Color(0xFF5B9BFF) else Color(0xFF2F6FE0)
    val green = if (dark) Color(0xFF34C76F) else Color(0xFF1F9D55)
    val red = Color(0xFFE5332A)
    val banner = if (dark) Color(0xFF2558BE) else Color(0xFF2F6FE0)
    val bannerDeep = if (dark) Color(0xFF1C469C) else Color(0xFF1F56C2)
    val divider = if (dark) Color(0x26FFFFFF) else Color(0x1A000000)
    val selectedSeg = if (dark) Color(0xFF636366) else Color.White
    // Gold aus dem ELdoroado-Logo (Akku, Vorschläge)
    val gold = if (dark) Color(0xFFFFD65C) else Color(0xFF9A6200)
    val goldFill = Color(0xFFF0A01E)
}

val LocalPal = staticCompositionLocalOf { Pal(false) }

/** Noto Sans in fünf Stärken (freie OFL-Lizenz) */
val NotoSans = androidx.compose.ui.text.font.FontFamily(
    androidx.compose.ui.text.font.Font(R.font.noto_sans_400, FontWeight.Normal),
    androidx.compose.ui.text.font.Font(R.font.noto_sans_500, FontWeight.Medium),
    androidx.compose.ui.text.font.Font(R.font.noto_sans_600, FontWeight.SemiBold),
    androidx.compose.ui.text.font.Font(R.font.noto_sans_700, FontWeight.Bold),
    androidx.compose.ui.text.font.Font(R.font.noto_sans_800, FontWeight.ExtraBold),
)

val NotoTypography: androidx.compose.material3.Typography = androidx.compose.material3.Typography().let { t ->
    fun TextStyle.n() = copy(fontFamily = NotoSans)
    t.copy(
        displayLarge = t.displayLarge.n(), displayMedium = t.displayMedium.n(), displaySmall = t.displaySmall.n(),
        headlineLarge = t.headlineLarge.n(), headlineMedium = t.headlineMedium.n(), headlineSmall = t.headlineSmall.n(),
        titleLarge = t.titleLarge.n(), titleMedium = t.titleMedium.n(), titleSmall = t.titleSmall.n(),
        bodyLarge = t.bodyLarge.n(), bodyMedium = t.bodyMedium.n(), bodySmall = t.bodySmall.n(),
        labelLarge = t.labelLarge.n(), labelMedium = t.labelMedium.n(), labelSmall = t.labelSmall.n(),
    )
}

private val CAR_COLORS = listOf(
    0xFF0A84FF, 0xFFF2F2F7, 0xFFFF3B30, 0xFF8E8E93, 0xFF1C1C1E, 0xFF30D158, 0xFFFF9F0A,
)

// ---------------- Hauptbildschirm ----------------

@Composable
fun EvRouteApp(vm: MainViewModel) {
    val settings by Settings.state.collectAsState()
    val nav by NavSession.state.collectAsState()
    val trafficBlocked by TrafficGuard.blocked.collectAsState()
    val fix by LocationHub.fix.collectAsState()
    val ui by vm.ui.collectAsState()
    val recents by Recents.items.collectAsState()
    val mc by MapChargers.state.collectAsState()
    val view = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.DisposableEffect(nav.navigating) {
        view.keepScreenOn = nav.navigating
        onDispose { view.keepScreenOn = false }
    }
    val mcMoved by MapChargers.moved.collectAsState()
    val reach by Reach.state.collectAsState()
    val ctx = LocalContext.current
    val dark = when (settings.mapMode) {
        MapMode.AUTO -> isSystemInDarkTheme()
        MapMode.DAY -> false
        MapMode.NIGHT -> true
    }
    val pal = remember(dark) { Pal(dark) }

    BackHandler(enabled = ui.showSettings && !ui.showObd && !ui.showTrips) { vm.closeSettings() }
    BackHandler(enabled = ui.showTrips) { vm.closeTrips() }
    BackHandler(enabled = ui.showObd) { vm.closeObd() }
    if (ui.saveDialog) {
        val d = nav.dest
        var name by remember { mutableStateOf(listOfNotNull(nav.start?.title?.substringBefore(","), d?.title?.substringBefore(",")).joinToString(" → ")) }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = vm::closeSaveDialog,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Route speichern", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Gespeichert werden Start, Ziel, Zwischenstopps und deine festen Ladestopps. Beim Aufrufen wird mit aktuellem Verkehr, Wetter und Akku neu gerechnet.", fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }, shape = RoundedCornerShape(16.dp))
                }
            },
            confirmButton = { TextButton(onClick = { vm.saveRoute(name) }) { Text("Speichern", fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = vm::closeSaveDialog) { Text("Abbrechen") } },
        )
    }
    ui.deleteSaved?.let { r ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { vm.askDeleteSaved(null) },
            shape = RoundedCornerShape(28.dp),
            title = { Text("Route löschen?", fontWeight = FontWeight.Bold) },
            text = { Text("„${r.name}“ wird aus den gespeicherten Routen entfernt.") },
            confirmButton = { TextButton(onClick = { SavedRoutes.remove(r.id); vm.askDeleteSaved(null) }) { Text("Löschen", color = pal.red, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { vm.askDeleteSaved(null) }) { Text("Abbrechen") } },
        )
    }

    if (ui.askPrecise) {
        val req = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()) {
            LocationHub.refreshPermission(ctx)
            LocationHub.acquire(ctx, "ui")
            vm.setAskPrecise(false)
        }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { vm.setAskPrecise(false) },
            shape = RoundedCornerShape(28.dp),
            title = { Text("Genauer Standort nötig", fontWeight = FontWeight.Bold) },
            text = { Text("Du hast nur den ungefähren Standort freigegeben (auf etwa 2 km genau). Für Abbiegehinweise braucht die Navigation deinen genauen Standort.") },
            confirmButton = {
                TextButton(onClick = { req.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)) }) {
                    Text("Genauen Standort erlauben", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { vm.setAskPrecise(false) }) { Text("Abbrechen") } },
        )
    }

    // Rückfrage: Zwischenstopp überspringen oder Navigation beenden
    if (ui.askEnd && nav.navigating) {
        val next = NavSession.nextVia()
        androidx.compose.material3.AlertDialog(
            onDismissRequest = vm::closeAskEnd,
            shape = RoundedCornerShape(28.dp),
            title = { Text(if (next != null) "Was möchtest du beenden?" else "Navigation beenden?", fontWeight = FontWeight.Bold) },
            text = {
                if (next != null) {
                    Column {
                        Text("Nächster Zwischenstopp: ${next.place.title}")
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = { vm.closeAskEnd(); NavSession.skipNextVia() },
                            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
                        ) { Text("Zwischenstopp überspringen", fontWeight = FontWeight.Bold) }
                    }
                } else {
                    Text("Die laufende Navigation wird beendet.")
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.closeAskEnd(); NavSession.stop(ctx) }) {
                    Text("Navigation beenden", color = pal.red, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = vm::closeAskEnd) { Text(if (next != null) "Abbrechen" else "Weiterfahren") } },
        )
    }

    // Zurück-Geste: immer nur EINEN Schritt zurück, vom obersten Fenster aus (feste Reihenfolge)
    val overlay = ui.showSettings || ui.showObd || ui.showTrips
    val canBack = !overlay && (
        mc.selected != null || nav.chargerSearch != null || ui.mode != SearchMode.DEST || ui.card != null ||
            ui.longPress != null || ui.searchActive || ui.query.isNotEmpty() || (!nav.navigating && nav.dest != null)
        )
    BackHandler(enabled = canBack) {
        when {
            ui.assistant -> vm.closeAssistant()
            mc.selected != null -> vm.closeChargerCard()          // Ladestations-Fenster -> zurück zur Liste/Suche
            ui.destInfo != null -> vm.closeDestInfo()
            nav.chargerSearch != null -> NavSession.closeChargerSearch() // Alternativen -> zurück zur Route
            ui.mode != SearchMode.DEST -> vm.cancelSearch()
            ui.card != null -> vm.closeCard()                      // Ortsfenster -> zurück zu den Suchergebnissen
            ui.longPress != null -> vm.closeLongPress()
            ui.searchActive || ui.query.isNotEmpty() -> vm.collapseSearch()
            !nav.navigating && nav.dest != null -> vm.backFromRoute() // Routen -> zurück zum Ortsfenster
        }
    }

    // Symbole der Statusleiste passend zur Karte: dunkel auf heller Karte, hell im Dunkeln
    androidx.compose.runtime.SideEffect {
        (view.context as? android.app.Activity)?.window?.let { w ->
            androidx.core.view.WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    // Tempolimits aus OpenStreetMap für die gewählte Route vorab laden
    val routeForLimits = NavSession.state.collectAsState().value.route
    LaunchedEffect(routeForLimits) { routeForLimits?.let { SpeedLimits.prefetch(it) } }
    val baseDensity = LocalDensity.current
    CompositionLocalProvider(
        LocalPal provides pal,
        LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density, baseDensity.fontScale * 0.88f),
    ) {
        MaterialTheme(
            colorScheme = if (dark) darkColorScheme(primary = pal.blue) else lightColorScheme(primary = pal.blue),
            typography = NotoTypography,
            shapes = androidx.compose.material3.Shapes(
                extraSmall = RoundedCornerShape(10.dp), small = RoundedCornerShape(14.dp), medium = RoundedCornerShape(20.dp),
                large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(32.dp),
            ),
        ) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val pip by Pip.active.collectAsState()
                val hPx = with(LocalDensity.current) { maxHeight.toPx() }.toDouble()
                // Querformat: Hinweise und Fenster in einer Seitenleiste links, die Karte bekommt die volle Höhe rechts daneben
                val land = maxWidth > maxHeight && !pip
                val sideW = if (land) (maxWidth * 0.40f).coerceIn(300.dp, 440.dp) else maxWidth
                val sidePx = if (land) with(LocalDensity.current) { sideW.toPx() }.toDouble() else 0.0
                val sheetMax = maxHeight
                val route = nav.route
                val progress = nav.progress

                EvMap(
                    routes = nav.routes,
                    selected = nav.selected,
                    navigating = nav.navigating,
                    progress = progress,
                    fix = fix,
                    vehicle = settings.vehicle,
                    carColor = settings.carColor,
                    dark = dark,
                    follow = ui.follow || pip,
                    recenterTick = ui.recenter,
                    pip = pip,
                    topPadPx = hPx * if (pip) 0.30 else if (land) 0.30 else 0.40,
                    bottomPadPx = hPx * if (pip) 0.10 else if (land) 0.06 else 0.12,
                    leftPadPx = sidePx,
                    sheetPadPx = if (land) with(LocalDensity.current) { 40.dp.roundToPx() } else if (ui.card != null || mc.selected != null || nav.chargerSearch != null) (hPx * 0.55).toInt() else if (ui.sheetPx > 0 && nav.dest != null) ui.sheetPx + with(LocalDensity.current) { 40.dp.roundToPx() } else (hPx * 0.50).toInt(),
                    onGesture = vm::onGesture,
                    onTap = vm::onMapTap,
                    mapStyleChoice = settings.mapStyle,
                    nightStyleChoice = settings.nightStyle,
                    onLongPress = vm::onLongPress,
                    mapChargers = nav.chargerSearch?.hits?.take(60) ?: if (mc.active) mc.hits else emptyList(),
                    pin = ui.card?.pos ?: mc.selected?.pos,
                    reach = reach,
                    overviewPts = ui.overviewPts,
                    overviewKey = ui.overviewKey,
                    poiEnabled = settings.poiEnabled && (!nav.navigating || settings.poiInNav),
                    poiCats = settings.poiCats,
                    onPoiTap = { p -> vm.openCard(Place(p.name, p.pos, null, p.kind)) },
                    fitPoints = nav.chargerSearch?.takeIf { !it.loading && it.hits.isNotEmpty() && mc.selected == null }
                        ?.let { cs -> cs.hits.take(25).map { it.pos } + listOfNotNull(cs.focus) },
                    onChargerTap = { id -> MapChargers.select(id) },
                    trafficUrl = if (settings.hasTomTom && settings.showTraffic && nav.navigating && !trafficBlocked) TomTom.trafficTileUrl(settings.tomtomKey.trim(), dark) else null,
                    modifier = Modifier.fillMaxSize(),
                )

                // ----- Fahrzeug als festes Bild über der Karte (Kamera folgt, daher immer gleiche Stelle) -----
                if (pip && nav.navigating && progress != null && !nav.arrived) {
                    // Bild-im-Bild: Draufsicht, kleiner Tropfen in der Mitte des Kartenbereichs
                    val vctx = LocalContext.current
                    val dropBmp = remember { VehicleIcons.arrow(vctx).asImageBitmap() }
                    val cyPip = maxHeight * 0.60f
                    if (dark) {
                        val coneBmp = remember { VehicleIcons.cone(vctx).asImageBitmap() }
                        Image(coneBmp, null, Modifier.offset(x = maxWidth / 2 - 45.dp, y = cyPip - 90.dp).size(90.dp))
                    }
                    Image(dropBmp, null, Modifier.offset(x = maxWidth / 2 - 13.dp, y = cyPip - 13.dp).size(26.dp))
                    if (route != null) {
                        Box(Modifier.align(Alignment.TopCenter)) { PipBanner(route, progress) }
                        Box(Modifier.align(Alignment.BottomCenter)) { PipFooter(route, progress) }
                    }
                    return@BoxWithConstraints
                }
                if (nav.navigating && ui.follow && progress != null && !nav.arrived) {
                    val vctx = LocalContext.current
                    val sprite = VehicleSprites.isSprite(settings.vehicle)
                    val bmp = remember(settings.vehicle, settings.carColor, settings.modelOrigColor) {
                        when (settings.vehicle) {
                            VehicleIcon.ARROW -> VehicleIcons.arrow(vctx)
                            VehicleIcon.CAR -> VehicleIcons.car(vctx, settings.carColor.toInt())
                            VehicleIcon.DOT -> VehicleIcons.dot(vctx)
                            else -> VehicleSprites.frames(vctx, settings.vehicle, if (settings.modelOrigColor) null else settings.carColor.toInt())?.get(0)
                                ?: VehicleIcons.arrow(vctx)
                        }.asImageBitmap()
                    }
                    val size = when (settings.vehicle) {
                        VehicleIcon.ARROW -> 50.dp
                        VehicleIcon.CAR -> 54.dp
                        VehicleIcon.DOT -> 34.dp
                        else -> 74.dp
                    }
                    // Mitte des freien Kartenbereichs (wie bei der Kamera: hoch oben 40 %/unten 12 %, quer oben 30 %/unten 6 %, links Seitenleiste)
                    val cy = maxHeight * if (land) 0.62f else 0.64f
                    val cx = if (land) sideW + (maxWidth - sideW) / 2 else maxWidth / 2
                    // nachts: Lichtkegel nach vorn, wie Scheinwerfer auf der Straße (liegt perspektivisch auf der Fahrbahn)
                    if (dark) {
                        val coneBmp = remember { VehicleIcons.cone(vctx).asImageBitmap() }
                        val coneW = 230.dp
                        val coneH = 230.dp
                        Image(
                            coneBmp, null,
                            Modifier.offset(x = cx - coneW / 2, y = cy - coneH).size(coneW, coneH)
                                .graphicsLayer {
                                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 1f)
                                    rotationX = 52f
                                    cameraDistance = 10f * density
                                },
                        )
                    }
                    Image(
                        bmp, null,
                        Modifier.offset(x = cx - size / 2, y = cy - size / 2).size(size)
                            .graphicsLayer {
                                if (settings.vehicle != VehicleIcon.DOT && !sprite) {
                                    rotationX = 45f
                                    cameraDistance = 14f * density
                                }
                            },
                    )
                }

                // ----- oben -----
                val bannerOn = ui.mode == SearchMode.DEST && nav.navigating && route != null && progress != null && !nav.arrived && nav.charging == null
                var bannerH by remember { mutableStateOf(0) }
                // eigener Knoten je Ausrichtung (Abstands-Modifier nicht am selben Knoten wechseln, siehe unten)
                androidx.compose.runtime.key(land) {
                if (bannerOn) {
                    Box(
                        (if (land) Modifier.align(Alignment.TopStart).width(sideW).displayCutoutPadding() else Modifier.align(Alignment.TopCenter))
                            .onSizeChanged { bannerH = it.height },
                    ) { NavBanner(route!!, progress!!) }
                }
                Column(
                    (if (land) Modifier.align(Alignment.TopStart).width(sideW) else Modifier.align(Alignment.TopCenter))
                        .then(if (bannerOn) Modifier.padding(top = with(LocalDensity.current) { bannerH.toDp() }) else Modifier.statusBarsPadding())
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    nav.chargeNotice?.let { msg ->
                        GlassCard(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.BatteryChargingFull, null, tint = pal.green, modifier = Modifier.size(22.dp))
                                Spacer(Modifier.width(10.dp))
                                Text(msg, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    if (bannerOn && route != null && progress != null && nav.charging == null) {
                        // federnd ein- und ausblenden (Material 3 Expressive)
                        val springIn = androidx.compose.animation.slideInVertically(
                            androidx.compose.animation.core.spring(dampingRatio = 0.62f, stiffness = 380f),
                        ) { -it / 2 } + androidx.compose.animation.fadeIn()
                        val springOut = androidx.compose.animation.slideOutVertically { -it / 2 } + androidx.compose.animation.fadeOut()
                        val lastWarn = remember { mutableStateOf<NavSession.Warning?>(null) }
                        if (nav.warning != null) lastWarn.value = nav.warning
                        androidx.compose.animation.AnimatedVisibility(nav.warning != null, enter = springIn, exit = springOut) {
                            lastWarn.value?.let { WarningCard(it) }
                        }
                        val chargeSoon = nav.warning == null && route.stops.any { it.alongM > progress.alongM + 50 && it.alongM - progress.alongM <= 5000 }
                        androidx.compose.animation.AnimatedVisibility(chargeSoon, enter = springIn, exit = springOut) {
                            ChargeApproachCard(route, progress, nav.availability)
                        }
                        val lastCoach = remember { mutableStateOf<CoachTip?>(null) }
                        if (nav.coach != null) lastCoach.value = nav.coach
                        androidx.compose.animation.AnimatedVisibility(nav.coach != null, enter = springIn, exit = springOut) {
                            lastCoach.value?.let { CoachCard(it) }
                        }
                        if (nav.gpsLost) InfoPill("Kein GPS (Tunnel?) – Position wird geschätzt", spinner = false)
                    }
                    if (!nav.navigating && ui.mode == SearchMode.DEST) LocationBanner()
                    if (reach.active && !nav.navigating && ui.mode == SearchMode.DEST) {
                        Box(Modifier.fillMaxWidth().padding(end = 64.dp), contentAlignment = Alignment.CenterStart) { ReachLegend(reach) }
                    }
                    if (mc.active && !nav.navigating && ui.mode == SearchMode.DEST) {
                        Box(Modifier.fillMaxWidth().padding(end = 64.dp), contentAlignment = Alignment.CenterStart) { MapChargerPill(mc, mcMoved, settings.mapFastOnly) }
                    }
                    if (nav.rerouting) InfoPill("Route wird neu berechnet …", spinner = true)
                    nav.offer?.let { o ->
                        ActionCard(
                            "Schnellere Route: ${fmtDuration(o.savedS)} gespart",
                            "Übernehmen", NavSession::acceptOffer, NavSession::dismissOffer,
                        )
                    }
                    nav.fullPark?.let { p ->
                        ActionCard(
                            "Ladepark „${p.name}“ ist gerade voll belegt",
                            "Anderen suchen", NavSession::avoidFullPark, NavSession::dismissFullPark,
                        )
                    }
                    if (nav.navigating && progress != null && progress.offRouteM > 60 && !nav.rerouting) {
                        InfoPill("Abseits der Route", spinner = false)
                    }
                }
                }

                // ----- rechts: Kartenknöpfe -----
                Column(
                    if (nav.navigating) Modifier.align(Alignment.CenterEnd).padding(end = 12.dp)
                    else Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 8.dp, end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (!nav.navigating) MapButton(Icons.Filled.Settings, "Einstellungen") { vm.openSettings() }
                    if (!nav.navigating) {
                        MapButton(Icons.Filled.EvStation, "Ladestationen auf der Karte", tint = if (mc.active) pal.green else pal.blue) { MapChargers.toggle() }
                    }
                    if (!nav.navigating) MapButton(Icons.Filled.NearMe, "Zentrieren") { vm.recenter() }
                }

                // ----- unten -----
                val footerMode = nav.navigating && route != null && progress != null && !nav.arrived && !ui.assistant && mc.selected == null &&
                    ui.destInfo == null && nav.chargerSearch == null && ui.mode == SearchMode.DEST && ui.card == null && ui.longPress == null
                val searchSheetMode = !footerMode && !ui.assistant && mc.selected == null && nav.chargerSearch == null &&
                    !(ui.destInfo != null && nav.navigating) &&
                    (ui.mode != SearchMode.DEST || (ui.card == null && ui.longPress == null && !nav.arrived && !nav.navigating && nav.dest == null))
                // Je Darstellung ein eigener Knoten (key): Wechselt man zwischen Modifier-Ketten mit unterschiedlichen
                // Rand-Abständen (Gestenleiste/Tastatur) am selben Knoten, schaukeln sich die verbrauchten Abstände
                // in Compose endlos hoch – die App friert ein.
                val bottomMode = when { footerMode -> 0; searchSheetMode -> 1; else -> 2 }
                androidx.compose.runtime.key(bottomMode * 2 + if (land) 1 else 0) {
                Column(
                    (if (land) Modifier.align(Alignment.BottomStart).width(sideW).displayCutoutPadding() else Modifier.align(Alignment.BottomCenter))
                        .then(if (bottomMode == 0) Modifier else Modifier.imePadding()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    val lp = ui.longPress
                    val sel = mc.selected
                    CompositionLocalProvider(LocalFlushSheet provides (bottomMode == 2)) {
                    when {
                        sel != null -> ChargerCard(sel, mc, fix?.pos, nav, sheetMax, onClose = vm::closeChargerCard)
                        ui.destInfo != null && nav.navigating -> DestInfoSheet(vm, ui, nav, fix?.pos, sheetMax)
                        nav.chargerSearch != null -> ChargerSheet(nav, settings, sheetMax)
                        ui.mode != SearchMode.DEST -> SearchSheet(ui, recents, vm, sheetMax)
                        ui.card != null -> PlaceCard(vm, ui, nav, fix?.pos, sheetMax)
                        lp != null && ui.mode == SearchMode.DEST -> LongPressCard(lp, nav.dest != null || nav.navigating, vm)
                        nav.arrived -> ArrivedWithSummary(nav.dest, sheetMax) { NavSession.stop(ctx) }
                        nav.navigating && route != null && nav.charging != null -> ChargingCard(nav.charging!!, route, progress)
                        nav.navigating && route != null && progress != null -> {
                            if (ui.navMore && !land) Box(Modifier.padding(horizontal = 12.dp)) { NavMoreButtons(vm, settings) }
                            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.Bottom) {
                                SpeedRow(fix, route, progress)
                                Spacer(Modifier.weight(1f))
                                // im Querformat sitzen die Knöpfe am rechten Rand (sonst überdecken sie Banner und Fahrtleiste)
                                if (!land) NavControls(vm, ui)
                            }
                            NavFooter(route, progress, nav.availability, onDestInfo = vm::openDestInfo) { vm.askEnd() }
                        }
                        nav.navigating -> GlassCard { Text("Warte auf GPS …", Modifier.padding(18.dp), color = pal.text) }
                        nav.dest != null -> RouteSheet(nav, settings, sheetMax, vm, onGo = {
                            if (!LocationHub.precise(ctx)) {
                                vm.setAskPrecise(true)
                            } else {
                                vm.recenter()
                                NavSession.start(ctx)
                            }
                        })
                        else -> SearchSheet(ui, recents, vm, sheetMax)
                    }
                    }
                }
                }
                // Querformat: Fahrtknöpfe als Spalte am rechten Rand
                if (land && bottomMode == 0 && route != null && progress != null && nav.charging == null) {
                    androidx.compose.runtime.key("navControlsRight") {
                        // aufgeklapptes „⋯“ als zweite Spalte links neben den Knöpfen, unten bündig mit dem „⋯“-Knopf
                        CompositionLocalProvider(LocalCompactButtons provides true) {
                            Row(Modifier.align(Alignment.CenterEnd).padding(end = 14.dp), verticalAlignment = Alignment.Bottom) {
                                if (ui.navMore) {
                                    NavMoreButtons(vm, settings, inline = true)
                                    Spacer(Modifier.width(8.dp))
                                }
                                NavControls(vm, ui)
                            }
                        }
                    }
                }
            }
            ui.viaAsk?.let { p -> ViaAskDialog(p, vm) }
            if (ui.showSettings) SettingsScreen(settings, vm::closeSettings, vm::openObd, vm::openTrips, ui.settingsPage)
            val setupOpen by SetupFlow.open.collectAsState()
            if (!settings.setupDone || setupOpen) SetupWizard(settings, vm)
            if (ui.showObd) ObdScreen(vm)
            if (ui.showTrips) TripsScreen(vm)
            ui.editFav?.let { f -> FavEditDialog(f) { vm.editFavorite(null) } }
        }
    }
}

// ---------------- Bausteine ----------------

@Composable
fun GlassCard(modifier: Modifier = Modifier, corner: Dp = 28.dp, content: @Composable ColumnScope.() -> Unit) {
    if (LocalFlushSheet.current) {
        // unterstes Fenster: bündig am unteren Rand, nur oben abgerundet; die Gestenleiste liegt mit auf dem Glas
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp), 12.dp)) {
            CompositionLocalProvider(LocalFlushSheet provides false) {
                Column(modifier, content = content)
            }
            Spacer(Modifier.fillMaxWidth().windowInsetsBottomHeight(WindowInsets.navigationBars))
        }
    } else {
        Column(modifier.glass(RoundedCornerShape(corner.coerceAtLeast(26.dp))), content = content)
    }
}

/** Gesetzt für das unterste Fenster: dann schließt GlassCard bündig mit dem unteren Bildschirmrand ab */
val LocalFlushSheet = androidx.compose.runtime.staticCompositionLocalOf { false }

@Composable
fun MapButton(icon: ImageVector, desc: String, tint: Color = LocalPal.current.text, onClick: () -> Unit) {
    val compact = LocalCompactButtons.current
    Box(
        Modifier.size(if (compact) 46.dp else 54.dp).glass(CircleShape, 6.dp).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = tint, modifier = Modifier.size(if (compact) 22.dp else 24.dp)) }
}

/** Querformat: kleinere Kartenknöpfe mit weniger Abstand, damit alle in die Höhe passen */
val LocalCompactButtons = androidx.compose.runtime.staticCompositionLocalOf { false }

@Composable
fun InfoPill(text: String, spinner: Boolean) {
    val pal = LocalPal.current
    Surface(shape = RoundedCornerShape(16.dp), color = pal.card, shadowElevation = 6.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (spinner) {
                CircularProgressIndicator(Modifier.size(16.dp), color = pal.blue, strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
            }
            Text(text, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ---------------- Suche ----------------

/** Hinweis, wenn der Standort nur ungefähr oder gar nicht freigegeben ist */
@Composable
fun LocationBanner() {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val perm by LocationHub.perm.collectAsState()
    if (perm == LocationHub.Perm.PRECISE) return
    val activity = ctx as? android.app.Activity
    val req = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()) {
        LocationHub.refreshPermission(ctx)
        LocationHub.acquire(ctx, "ui")
    }
    // Hat der Nutzer dauerhaft abgelehnt, hilft nur noch der Weg über die Einstellungen
    val blocked = perm == LocationHub.Perm.NONE && activity != null &&
        !androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.ACCESS_FINE_LOCATION)
    Surface(Modifier.fillMaxWidth().padding(end = 64.dp), shape = RoundedCornerShape(20.dp), color = pal.card, shadowElevation = 8.dp) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (perm == LocationHub.Perm.APPROX) Icons.Filled.Place else Icons.Filled.Warning, null, tint = Color(0xFFFF9500), modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (perm == LocationHub.Perm.APPROX) "Nur ungefährer Standort" else "Kein Standort freigegeben",
                    color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    if (perm == LocationHub.Perm.APPROX) "Karte und Planung gehen – für die Navigation den genauen Standort erlauben."
                    else "Ohne Standort kann die App weder planen noch navigieren.",
                    color = pal.sub, fontSize = 12.sp,
                )
            }
            Text(
                if (blocked) "Einstellungen" else "Erlauben", color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                    if (blocked) {
                        ctx.startActivity(
                            Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.fromParts("package", ctx.packageName, null))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    } else {
                        req.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION))
                    }
                }.padding(8.dp),
            )
        }
    }
}

/** Gespeicherte Routen in der Suche */
@Composable
fun SavedRoutesList(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by SavedRoutes.items.collectAsState()
    if (list.isEmpty()) return
    Text("Gespeicherte Routen", color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 4.dp))
    list.forEach { r ->
        Row(
            Modifier.fillMaxWidth().clickable { vm.openSaved(r) }.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(pal.blue.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Route, null, tint = pal.blue, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val stops = r.vias.size
                val chargers = r.vias.count { it.isCharger }
                Text(
                    listOfNotNull(
                        "${r.start?.title?.substringBefore(",") ?: "Mein Standort"} → ${r.dest.title.substringBefore(",")}",
                        if (stops > 0) "$stops Stopp${if (stops > 1) "s" else ""}" + if (chargers > 0) " (davon $chargers Laden)" else "" else null,
                        r.startSoc?.let { "Start ${it.roundToInt()} %" },
                    ).joinToString(" · "),
                    color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Box(Modifier.size(40.dp).clip(CircleShape).clickable { vm.askDeleteSaved(r) }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, "Löschen", tint = pal.sub, modifier = Modifier.size(18.dp))
            }
        }
    }
}

internal fun agoText(at: Long): String {
    val min = ((System.currentTimeMillis() - at) / 60_000).toInt()
    return when {
        min < 1 -> "gerade eben"
        min < 60 -> "vor $min min"
        min < 60 * 24 -> "vor ${min / 60} h"
        else -> "vor ${min / (60 * 24)} Tagen"
    }
}

/** Suche als Fenster am unteren Rand: zu sieht man nur die Suchleiste, hochgezogen Favoriten und Zuletzt */
@Composable
fun SearchSheet(ui: MainViewModel.Ui, recents: List<Place>, vm: MainViewModel, screenH: Dp) {
    val pal = LocalPal.current
    val focus = LocalFocusManager.current
    val ctx = LocalContext.current
    val density = LocalDensity.current
    // bündig am unteren Rand: die Gestenleiste gehört mit zum Fenster
    val navInset = WindowInsets.navigationBars.getBottom(density).toFloat()
    // geschlossen: genau bis unter die Suchleiste (Kopf wird eigenständig gemessen) plus Gestenleiste
    var headerPx by remember { mutableFloatStateOf(0f) }
    val peek = if (headerPx > 0f) headerPx + navInset + with(density) { 10.dp.toPx() }
    else with(density) { (if (ui.mode == SearchMode.DEST) 92.dp else 132.dp).toPx() } + navInset
    val maxFull = with(density) { (screenH * 0.62f).toPx() } + navInset
    // Drei Zustände: zu (nur Suchleiste) · offen beim Suchen (feste Höhe) · offen ohne Suche (so hoch wie der Inhalt).
    // Die Höhe des Inhalts wird unabhängig von der Fensterhöhe gemessen (keine Rückkopplung),
    // die Fensterhöhe federt weich dorthin und folgt beim Ziehen dem Finger.
    val open = ui.searchActive || ui.query.isNotEmpty() || ui.mode != SearchMode.DEST
    var expanded by remember { mutableStateOf(open) }
    LaunchedEffect(open) { if (open) expanded = true else if (expanded) expanded = false }
    var naturalPx by remember { mutableFloatStateOf(0f) }
    fun targetPx(exp: Boolean): Float = when {
        !exp -> peek
        open -> maxFull
        naturalPx > 0f -> naturalPx.coerceIn(peek, maxFull)
        else -> maxFull
    }
    val heightAnim = remember { androidx.compose.animation.core.Animatable(peek) }
    val sheetScope = rememberCoroutineScope()
    var dragging by remember { mutableStateOf(false) }
    val springSpec = androidx.compose.animation.core.spring<Float>(dampingRatio = 0.86f, stiffness = 420f)
    LaunchedEffect(expanded, open, naturalPx, peek, maxFull) {
        if (!dragging) heightAnim.animateTo(targetPx(expanded), springSpec)
    }
    val drag = rememberDraggableState { d ->
        sheetScope.launch { heightAnim.snapTo((heightAnim.value - d).coerceIn(peek, maxFull)) }
    }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) { vm.setSearchActive(true); vm.onQuery(text) }
    }

    Box(
        Modifier.fillMaxWidth().height(with(density) { heightAnim.value.toDp() })
            .glass(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp), 12.dp),
    ) {
        // Kopf (Suchleiste) und Inhalt gemeinsam in eigener Höhe messen – unabhängig davon, wie weit das Fenster gerade offen ist
        Column(
            Modifier.fillMaxWidth().align(Alignment.TopCenter)
                .wrapContentHeight(Alignment.Top, unbounded = true)
                .then(if (open) Modifier.height(with(density) { maxFull.toDp() }) else Modifier.heightIn(max = with(density) { maxFull.toDp() }))
                .onSizeChanged { if (!open) naturalPx = it.height.toFloat() },
        ) {
        Column(
            Modifier.fillMaxWidth()
                .onSizeChanged { headerPx = it.height.toFloat() }
                .draggable(
                    state = drag,
                    orientation = Orientation.Vertical,
                    onDragStarted = { dragging = true },
                    onDragStopped = { v ->
                        dragging = false
                        val mid = (peek + targetPx(true)) / 2
                        val openNow = when {
                            v < -700f -> true
                            v > 700f -> false
                            else -> heightAnim.value > mid
                        }
                        if (!openNow) {
                            focus.clearFocus()
                            vm.setSearchActive(false)
                        }
                        expanded = openNow
                        heightAnim.animateTo(targetPx(openNow), springSpec, initialVelocity = -v)
                    },
                ).padding(top = 8.dp),
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(pal.sub.copy(alpha = 0.5f)))
            }
            if (ui.mode != SearchMode.DEST) {
                Row(Modifier.padding(start = 16.dp, end = 10.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when (ui.mode) {
                            SearchMode.HOME -> "Zuhause festlegen"
                            SearchMode.WORK -> "Arbeit festlegen"
                            SearchMode.FAV -> "Favorit hinzufügen"
                            SearchMode.START -> "Start festlegen"
                            else -> "Stopp hinzufügen"
                        },
                        color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                    )
                    CloseDot(vm::cancelSearch)
                }
                if (ui.mode == SearchMode.VIA) {
                    Text(
                        "Suchen, Favorit antippen oder lange auf die Karte drücken.",
                        color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 2.dp),
                    )
                }
            }
            Row(
                Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 0.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.field)
                    .padding(start = 14.dp, end = 6.dp, top = 9.dp, bottom = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Search, null, tint = pal.sub, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f).padding(vertical = 6.dp)) {
                    if (ui.query.isEmpty()) Text(if (ui.chargerOnly) "Ladestation suchen" else "Suche nach Ort oder Adresse", color = pal.sub, fontSize = 17.sp)
                    BasicTextField(
                        value = ui.query,
                        onValueChange = vm::onQuery,
                        singleLine = true,
                        textStyle = TextStyle(color = pal.text, fontSize = 17.sp, fontFamily = NotoSans),
                        cursorBrush = SolidColor(pal.blue),
                        modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) vm.setSearchActive(true) },
                    )
                }
                if (ui.query.isNotEmpty()) {
                    Box(Modifier.size(36.dp).clip(CircleShape).clickable { vm.onQuery("") }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Close, "Löschen", tint = pal.sub, modifier = Modifier.size(20.dp))
                    }
                }
                if (ui.mode == SearchMode.DEST && Settings.state.value.hasChargerSource) {
                    Box(
                        Modifier.size(36.dp).clip(CircleShape)
                            .background(if (ui.chargerOnly) pal.green else Color.Transparent)
                            .clickable { vm.toggleChargerOnly() },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.EvStation, "Nur Ladestationen", tint = if (ui.chargerOnly) Color.White else pal.green, modifier = Modifier.size(20.dp)) }
                }
                Box(
                    Modifier.size(36.dp).clip(CircleShape).clickable {
                        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
                            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Wohin möchtest du?")
                        try {
                            speech.launch(i)
                        } catch (e: ActivityNotFoundException) {
                            android.widget.Toast.makeText(ctx, "Spracheingabe ist auf diesem Gerät nicht verfügbar", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Mic, "Spracheingabe", tint = pal.blue, modifier = Modifier.size(22.dp)) }
            }
        }
        // Inhalt beim Hochziehen – geschlossen unsichtbar, blendet beim Aufziehen weich ein
        val fadePx = with(density) { 70.dp.toPx() }
        Column(
            Modifier.weight(1f, fill = false)
                .graphicsLayer { alpha = ((heightAnim.value - peek) / fadePx).coerceIn(0f, 1f) }
                .padding(top = 10.dp)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding().padding(bottom = 10.dp),
        ) {
            val showSuggestions = ui.query.trim().length >= 3
            // „Zuletzt“ erst, wenn man ins Suchfeld tippt; sonst Favoriten, Fahrzeug und gespeicherte Routen
            val typing = ui.searchActive || ui.query.isNotEmpty() || ui.mode != SearchMode.DEST
            if (ui.mode == SearchMode.DEST && !showSuggestions) {
                FavoritesRow(vm)
                if (!typing) {
                    HomeOverview(vm)
                    SavedRoutesList(vm)
                }
            }
            if (showSuggestions && ui.chargerHits.isNotEmpty()) {
                Text("Ladestationen", color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 4.dp))
                ui.chargerHits.forEach { h ->
                    Row(
                        Modifier.fillMaxWidth().clickable { focus.clearFocus(); vm.openCharger(h) }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(Color(operatorColor(h.operator.ifBlank { h.name }))),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(chargerTitle(h), color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val me = LocationHub.fix.value?.pos
                            if (h.address.isNotBlank()) {
                                Text(h.address, color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text(
                                listOfNotNull(
                                    h.operator.ifBlank { null }?.takeIf { !chargerTitle(h).contains(it, true) },
                                    if (h.powerKw > 0) "${h.powerKw.roundToInt()} kW" else null,
                                    me?.let { fmtKm(haversine(it, h.pos)) },
                                ).joinToString(" · "),
                                color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
            val items = if (showSuggestions) ui.suggestions else if (typing) recents else emptyList()
            if (!(showSuggestions && ui.chargerOnly) && (showSuggestions || typing)) Text(
                if (showSuggestions) "Orte und Adressen" else "Zuletzt",
                color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 4.dp),
            )
            if (ui.searching && items.isEmpty()) {
                Text("Suche …", color = pal.sub, modifier = Modifier.padding(16.dp))
            } else if (items.isEmpty() && (showSuggestions || typing) && !(showSuggestions && ui.chargerHits.isNotEmpty())) {
                Text(if (showSuggestions) "Nichts gefunden" else "Noch keine Ziele", color = pal.sub, modifier = Modifier.padding(16.dp))
            }
            items.forEach { p ->
                PlaceRow(p, recent = !showSuggestions) {
                    focus.clearFocus()
                    vm.pick(p)
                }
            }
        }
        }
    }
}

@Composable
private fun PlaceRow(p: Place, recent: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(if (recent) pal.field else pal.red),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (recent) Icons.Filled.History else Icons.Filled.Place, null,
                tint = if (recent) pal.sub else Color.White, modifier = Modifier.size(20.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.title, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (p.subtitle.isNotBlank()) {
                Text(p.subtitle, color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ---------------- Routenauswahl ----------------

/** Akkustand beim Start (bis OBD in Runde 3 kommt, manuell) */
@Composable
fun SocStartRow(settings: AppSettings) {
    val pal = LocalPal.current
    val obd = obdSocState()
    val nav = NavSession.state.collectAsState().value
    if (nav.start != null) {
        // vorausgeplante Fahrt ab eigenem Start: eigener Start-Akku
        val v = nav.startSoc ?: settings.socStart
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Akku beim Start", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            StepButton("−") { NavSession.setStartSoc(v - 5) }
            Text(fmtPct(v), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
            StepButton("+") { NavSession.setStartSoc(v + 5) }
        }
        return
    }
    if (obd != null) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Akku jetzt", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(fmtSoc(obd), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("  OBD", color = pal.green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        return
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.field).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Akku jetzt", color = pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        StepButton("−") { changeSoc(settings, -5.0) }
        Text(fmtPct(settings.socStart), color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
        StepButton("+") { changeSoc(settings, 5.0) }
    }
}

private fun changeSoc(s: AppSettings, delta: Double) {
    val v = (s.socStart + delta).coerceIn(5.0, 100.0)
    if (v == s.socStart) return
    Settings.update { it.copy(socStart = v) }
    NavSession.replan()
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(pal.cardSolid).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = pal.blue, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun RouteRow(r: Route, selected: Boolean, deltaS: Double, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (selected) pal.blue.copy(alpha = 0.12f) else pal.field.copy(alpha = 0.6f))
            .border(2.dp, if (selected) pal.blue else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fmtDuration(r.durationS), color = pal.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                if (deltaS > 60) {
                    Spacer(Modifier.width(8.dp))
                    Text("+${fmtDuration(deltaS)}", color = pal.sub, fontSize = 14.sp)
                }
            }
            Text(
                "${fmtKm(r.distanceM)} · Ankunft ${fmtEta(r.durationS)}" + if (r.summary.isNotBlank()) " · über ${r.summary}" else "",
                color = pal.sub, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            val ev = buildList {
                if (r.stops.isNotEmpty()) add("${r.stops.size} × laden · ${fmtDuration(r.chargeS)}")
                r.arrivalSoc?.let { add("Ziel ${fmtPct(it)}") }
            }.joinToString(" · ")
            if (ev.isNotBlank()) Text(ev, color = if (r.feasible) pal.green else pal.red, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            if (r.trafficDelayS > 120) {
                Text("Verkehr: +${fmtDuration(r.trafficDelayS)}", color = Color(0xFFFF9500), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (r.tag.isNotBlank()) {
            Spacer(Modifier.width(8.dp))
            Text(
                r.tag,
                color = if (selected) Color.White else pal.text,
                fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (selected) pal.blue else pal.field)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

/** Details der gewählten Route: Wetter, Ladestopps */
@Composable
fun RouteDetails(r: Route, avail: Map<String, Availability>) {
    val pal = LocalPal.current
    Spacer(Modifier.height(12.dp))
    r.reason?.let { Text(it, color = pal.red, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp)) }
    r.weather?.let { w ->
        val wind = when {
            w.headwindKmh > 5 -> " · Gegenwind ${w.headwindKmh.roundToInt()} km/h"
            w.headwindKmh < -5 -> " · Rückenwind ${(-w.headwindKmh).roundToInt()} km/h"
            else -> ""
        }
        Text(
            "Wetter unterwegs: ${w.tempC.roundToInt()} °C$wind" + if (w.rain) " · Regen" else "",
            color = pal.sub, fontSize = 13.sp,
        )
    }
    if (r.stops.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        Text("Ladestopps", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        r.note?.takeIf { it.startsWith("Offline geplant") }?.let { Text(it, color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)) }
        r.stops.forEachIndexed { i, st -> StopRow(i + 1, st, st.uuid?.let { avail[it] }, WishPlanner.timeAt(r, st.alongM)) }
    }
}

@Composable
private fun StopRow(no: Int, st: ChargeStop, a: Availability?, etaS: Double) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(pal.green), contentAlignment = Alignment.Center) {
            Text("$no", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(st.name, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val op = if (st.operator.isNotBlank() && st.operator != st.name) "${st.operator} · " else ""
            Text(
                "${op}km ${(st.alongM / 1000).roundToInt()} · ${st.powerKw.roundToInt()} kW · Ankunft ${fmtEta(etaS)}",
                color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                "${fmtPct(st.arriveSoc)} → ${fmtPct(st.targetSoc)} · ${fmtDuration(st.chargeS)}",
                color = pal.text, fontSize = 13.sp,
            )
            if (st.why.isNotBlank()) Text("Warum: ${st.why}", color = pal.sub, fontSize = 12.sp, maxLines = 3)
            if (Settings.state.value.hasChargerSource && !NavSession.state.value.navigating) {
                Text(
                    "Anderen wählen", color = pal.blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 2.dp).clickable { NavSession.openChargerSearch(st.uuid) },
                )
            }
        }
        if (a != null && a.known) {
            Text(
                "${a.available}/${a.total} frei",
                color = if (a.available > 0) pal.green else pal.red, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

/** Akkustand über die Strecke, mit Reserve-Linie */
@Composable
private fun SocChart(r: Route) {
    val pal = LocalPal.current
    val total = max(1.0, r.cumM.lastOrNull() ?: 1.0)
    val minSoc = Settings.state.value.minSocStop
    Canvas(Modifier.fillMaxWidth().height(90.dp).padding(vertical = 6.dp)) {
        val w = size.width
        val h = size.height
        fun x(m: Double) = (m / total * w).toFloat()
        fun y(p: Double) = (h - (p.coerceIn(0.0, 100.0) / 100.0) * h).toFloat()
        // Reserve
        drawLine(pal.red.copy(alpha = 0.5f), Offset(0f, y(minSoc)), Offset(w, y(minSoc)), 2f)
        val line = Path()
        val fill = Path()
        r.socProfile.forEachIndexed { i, (m, p) ->
            if (i == 0) { line.moveTo(x(m), y(p)); fill.moveTo(x(m), h); fill.lineTo(x(m), y(p)) } else { line.lineTo(x(m), y(p)); fill.lineTo(x(m), y(p)) }
        }
        val last = r.socProfile.last()
        fill.lineTo(x(last.first), h)
        fill.close()
        drawPath(fill, pal.green.copy(alpha = 0.18f))
        drawPath(line, pal.green, style = Stroke(width = 5f))
        r.stops.forEach { st -> drawCircle(pal.green, 7f, Offset(x(st.alongM), y(st.targetSoc))) }
    }
}

@Composable
private fun ActionCard(text: String, action: String, onAction: () -> Unit, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    GlassCard(Modifier.fillMaxWidth(), corner = 18.dp) {
        Column(Modifier.padding(14.dp)) {
            Text(text, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                ) { Text(action, fontWeight = FontWeight.Bold) }
                TextButton(onClick = onDismiss) { Text("Ignorieren", color = pal.sub) }
            }
        }
    }
}

// ---------------- Navigation ----------------

@Composable
fun PipBanner(r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val step = r.steps.getOrNull(p.stepIdx) ?: return
    val live by NavSession.liveAlong.collectAsState()
    val rbStep = r.steps.getOrNull(p.stepIdx - 1)?.takeIf { it.isRoundabout }
    val rbExit = rbStep?.let { roundaboutExitAlong(r, p.stepIdx - 1) }
    val nowAlong = live ?: p.alongM
    val inRb = rbStep != null && rbExit != null && nowAlong < rbExit
    val dist = if (inRb) (rbExit!! - nowAlong).coerceAtLeast(0.0)
    else live?.let { a -> ((r.stepAlongM.getOrNull(p.stepIdx) ?: a) - a).coerceAtLeast(0.0) } ?: p.distToStepM
    val icon = if (inRb) rbStep!! else step
    Row(
        Modifier.fillMaxWidth().background(pal.blue).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ManeuverIcon(icon.type, icon.mod, Color.White, 30.dp)
        Spacer(Modifier.width(6.dp))
        Text(fmtDistShort(dist), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** Bild-im-Bild unten: Ankunftszeit und Akku am Ziel, klein */
@Composable
fun PipFooter(r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val nowSoc = r.socAt(p.alongM)
    val real = obdSocState()
    val diff = if (real != null && nowSoc != null) real - nowSoc else 0.0
    val destSoc = r.arrivalSoc?.let { it + diff }
    Row(
        Modifier.fillMaxWidth().background(pal.cardSolid).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Flag, null, tint = pal.text, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(4.dp))
        Text(fmtEta(p.remainingS), color = pal.text, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        Spacer(Modifier.weight(1f))
        destSoc?.let {
            IconLine(Icons.Filled.BatteryChargingFull, fmtPct(it), if (it < 10) pal.red else pal.green, 13.sp, FontWeight.SemiBold)
        }
    }
}

/** Abbiegehinweis oben in der Fahransicht */
@Composable
fun NavBanner(r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val step = r.steps.getOrNull(p.stepIdx) ?: return
    val next = r.steps.getOrNull(p.stepIdx + 1)
    val live by NavSession.liveAlong.collectAsState()
    // im Kreisverkehr: bis zur eigenen Ausfahrt herunterzählen
    val rbStep = r.steps.getOrNull(p.stepIdx - 1)?.takeIf { it.isRoundabout }
    val rbExit = rbStep?.let { roundaboutExitAlong(r, p.stepIdx - 1) }
    val nowAlong = live ?: p.alongM
    val inRb = rbStep != null && rbExit != null && nowAlong < rbExit
    val dist = if (inRb) (rbExit!! - nowAlong).coerceAtLeast(0.0)
    else live?.let { a -> ((r.stepAlongM.getOrNull(p.stepIdx) ?: a) - a).coerceAtLeast(0.0) } ?: p.distToStepM
    val speed = LocationHub.fix.value?.speed ?: 0.0
    val lanes = findLaneSection(r, p, live ?: p.alongM, speed)
    val showNext = next != null && step.distanceM < 300 && step.type != "arrive"
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp), 12.dp).statusBarsPadding()) {
        Row(Modifier.padding(start = 16.dp, end = 18.dp, top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            // Abbiegesymbol als blaue Plakette, damit es trotz Glas sofort ins Auge fällt
            Box(Modifier.size(62.dp).clip(RoundedCornerShape(18.dp)).background(pal.blue), contentAlignment = Alignment.Center) {
                val icon = if (inRb) rbStep!! else step
                ManeuverIcon(icon.type, icon.mod, Color.White, 44.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(fmtDistShort(dist), color = pal.text, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
                val txt = if (inRb) "Ausfahrt nehmen" + (rbStep!!.road.takeIf { it.isNotBlank() }?.let { " · $it" } ?: "") else step.bannerText()
                val shield = Regex("^([ABEKL]\\s?\\d{1,3}[a-z]?)\\b\\s*(.*)").find(txt)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (shield != null) {
                        val ref = shield.groupValues[1].replace(" ", "")
                        Text(
                            ref, color = if (ref.startsWith("A") || ref.startsWith("E")) Color.White else Color(0xFF1B1F24),
                            fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp))
                                .background(if (ref.startsWith("A") || ref.startsWith("E")) Color(0xFF1F4FB8) else Color(0xFFFFCC00))
                                .border(1.5.dp, Color.White, RoundedCornerShape(6.dp)).padding(horizontal = 7.dp, vertical = 1.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(
                        (shield?.groupValues?.get(2)?.ifBlank { null } ?: if (shield == null) txt else ""), color = pal.sub, fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (lanes != null || showNext) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(1.dp).background(Color.White.copy(alpha = if (pal.dark) 0.18f else 0.8f)))
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 18.dp, top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (lanes != null) {
                    val cell = if (lanes.lanes.size > 5) 36.dp else 42.dp
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        lanes.lanes.forEachIndexed { i, lane ->
                            if (i > 0) LaneDivider(cell * 0.8f, pal.sub.copy(alpha = 0.5f))
                            LaneCell(lane, cell, on = pal.blue, off = pal.sub.copy(alpha = 0.45f), hi = pal.blue.copy(alpha = 0.12f))
                        }
                    }
                } else {
                    Spacer(Modifier.weight(1f))
                }
                if (showNext) {
                    Text("Dann", color = pal.sub, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(6.dp))
                    ManeuverIcon(next!!.type, next.mod, pal.text, 26.dp)
                }
            }
        }
    }
}

@Composable
fun SpeedRow(fix: Fix?, r: Route, p: NavProgress) {
    val pal = LocalPal.current
    val live by NavSession.liveAlong.collectAsState()
    val (limit, limitSrc) = SpeedLimits.at(r, live ?: p.alongM)
    val showSrc = Settings.state.collectAsState().value.speedSourceLabel
    // Anzeige leicht geglättet, damit sie nicht flackert
    val kmhAnim by androidx.compose.animation.core.animateFloatAsState(((fix?.speed ?: 0.0) * 3.6).toFloat(), androidx.compose.animation.core.tween(600), label = "kmh")
    val kmh = kmhAnim.roundToInt()
    val target = NavSession.state.collectAsState().value.tripMaxSpeed
    val overTarget = target != null && kmh > target + 5
    val tooFast = limit != null && kmh > limit + 3
    // Kapsel wie bei TomTom: Tempolimit oben, eigenes Tempo darunter
    Box(
        Modifier.width(74.dp).glass(RoundedCornerShape(38.dp), 8.dp, tint = if (tooFast) pal.red else null)
            .then(if (target != null) Modifier.border(3.dp, if (overTarget) Color(0xFFFF9500) else pal.blue, RoundedCornerShape(38.dp)) else Modifier),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (limit != null) {
                Box(
                    Modifier.size(60.dp).clip(CircleShape).background(Color.White).border(6.dp, Color(0xFFE5332A), CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Text("$limit", color = Color(0xFF1B1F24), fontSize = if (limit >= 100) 21.sp else 24.sp, fontWeight = FontWeight.ExtraBold) }
                if (showSrc && limitSrc != null) Text(limitSrc, color = pal.sub, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
            }
            Text("$kmh", color = if (tooFast) Color.White else pal.text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 30.sp)
            Text("km/h", color = if (tooFast) Color.White else pal.sub, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (target != null) {
                Text("Ziel $target", color = if (tooFast) Color.White else if (overTarget) Color(0xFFFF9500) else pal.blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Knöpfe während der Navigation, rechts unten übereinander: Zentrieren, Übersicht, Ton, „⋯“ */
@Composable
fun NavControls(vm: MainViewModel, ui: MainViewModel.Ui) {
    val pal = LocalPal.current
    val set by Settings.state.collectAsState()
    Column(verticalArrangement = Arrangement.spacedBy(if (LocalCompactButtons.current) 8.dp else 12.dp), horizontalAlignment = Alignment.End) {
        if (!ui.follow) MapButton(Icons.Filled.NearMe, "Zentrieren", tint = pal.blue) { vm.endOverview() }
        MapButton(
            Icons.Filled.ZoomOutMap,
            when (ui.overviewLevel) { 1 -> "Ganze Strecke"; 2 -> "Zurück zur Fahrt"; else -> "Übersicht" },
            tint = if (ui.overviewLevel > 0) pal.blue else pal.text,
        ) { vm.toggleOverview() }
        MapButton(
            if (set.voice) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
            "Sprachansagen", tint = if (set.voice) pal.text else pal.sub,
        ) { Settings.update { it.copy(voice = !it.voice) } }
        MapButton(Icons.Filled.MoreHoriz, "Weitere", tint = if (ui.navMore) pal.blue else pal.text) { vm.toggleNavMore() }
    }
}

/** Aufgeklapptes „⋯“: rechts über den Knöpfen, nur solange offen */
@Composable
fun NavMoreButtons(vm: MainViewModel, settings: AppSettings, inline: Boolean = false) {
    val pal = LocalPal.current
    val buttons: @Composable () -> Unit = {
        Column(verticalArrangement = Arrangement.spacedBy(if (LocalCompactButtons.current) 8.dp else 10.dp)) {
            MapButton(Icons.Filled.Refresh, "Route neu berechnen") { vm.toggleNavMore(); NavSession.rerouteNow() }
            MapButton(Icons.Filled.AddLocationAlt, "Stopp hinzufügen") { vm.toggleNavMore(); vm.startSearch(SearchMode.VIA) }
        }
    }
    if (inline) buttons() else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { buttons() }
}

@Composable
fun CoachCard(t: CoachTip) {
    val pal = LocalPal.current
    val color = if (t.warning) Color(0xFFFF9500) else pal.blue
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = pal.card, shadowElevation = 10.dp, border = androidx.compose.foundation.BorderStroke(2.dp, color)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (t.warning) Icons.Filled.Warning else Icons.Filled.Speed, null, tint = color, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(t.title, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(t.detail, color = pal.sub, fontSize = 13.sp)
            }
            Text(
                "Übernehmen", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(color).clickable { NavSession.acceptCoach() }.padding(horizontal = 10.dp, vertical = 6.dp),
            )
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(30.dp).clip(CircleShape).clickable { NavSession.dismissCoach() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, "Ignorieren", tint = pal.sub, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun ReachLegend(r: Reach.State) {
    val pal = LocalPal.current
    Surface(shape = RoundedCornerShape(16.dp), color = pal.card, shadowElevation = 8.dp) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f, fill = false)) {
                when {
                    r.loading -> Text("Berechne Reichweite …", color = pal.text, fontSize = 14.sp)
                    r.error != null -> Text(r.error, color = pal.red, fontSize = 13.sp)
                    else -> {
                        Text("Reichweite mit ${r.soc?.let { fmtSoc(it) } ?: "?"}", color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Fläche: bis ${fmtPct(Settings.state.value.minSocStop)} Rest" + if (r.round.isNotEmpty()) " · gestrichelt: hin und zurück" else "",
                            color = pal.sub, fontSize = 12.sp,
                        )
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(28.dp).clip(CircleShape).clickable { Reach.toggle() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, "Schließen", tint = pal.sub, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun DestChip(text: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Text(
        text, color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(pal.blue.copy(alpha = 0.12f)).clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

/** Nächster Halt (Ladestopp oder Zwischenstopp) mit Ankunftszeit */
data class NextHalt(val charge: Boolean, val name: String, val distM: Double, val etaS: Double, val soc: Double?)

fun nextHalt(r: Route, p: NavProgress, socDiff: Double): NextHalt? {
    val along = p.alongM
    val charge = r.stops.firstOrNull { it.alongM > along + 50 }
    val viaIdx = r.steps.indices.firstOrNull { r.steps[it].type == "via" && r.stepAlongM[it] > along + 50 }
    val viaAlong = viaIdx?.let { r.stepAlongM[it] }
    val useVia = viaAlong != null && (charge == null || viaAlong < charge.alongM)
    val target = if (useVia) viaAlong!! else charge?.alongM ?: return null
    // Zeit aus der Routenplanung, auf die aktuelle Restzeit (Verkehr) skaliert
    val tNow = WishPlanner.timeAt(r, along)
    val tEnd = WishPlanner.timeAt(r, r.cumM.last())
    val scale = if (tEnd - tNow > 60) (p.remainingS / (tEnd - tNow)).coerceIn(0.5, 2.0) else 1.0
    val eta = (WishPlanner.timeAt(r, target) - tNow) * scale
    return if (useVia) {
        NextHalt(false, r.steps[viaIdx!!].road.ifBlank { "Zwischenstopp" }, target - along, eta, r.socAt(target)?.plus(socDiff))
    } else {
        NextHalt(true, charge!!.name.substringBefore(","), target - along, eta, charge.arriveSoc + socDiff)
    }
}

@Composable
fun NavFooter(r: Route, p: NavProgress, avail: Map<String, Availability>, onDestInfo: (String) -> Unit = {}, onEnd: () -> Unit) {
    val compact = LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val pal = LocalPal.current
    val nowSoc = r.socAt(p.alongM)
    val real = obdSocState()
    val diff = if (real != null && nowSoc != null) real - nowSoc else 0.0
    val destSoc = r.arrivalSoc?.let { it + diff }
    val delayMin = (r.jams.filter { j -> (r.cumM.getOrNull(j.endIdx) ?: 0.0) > p.alongM }.sumOf { it.delayS } / 60).roundToInt()
    val halt = nextHalt(r, p, diff)
    var showDest by remember { mutableStateOf(false) }
    val haltFirst = halt != null && !showDest
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp), 12.dp)) {
        Column(Modifier.navigationBarsPadding().padding(start = 22.dp, end = 16.dp, top = 20.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable(enabled = halt != null) { showDest = !showDest }) {
                    if (haltFirst) {
                        val h = halt!!
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (h.charge) Icons.Filled.Bolt else Icons.Filled.Place, null, tint = if (h.charge) pal.green else pal.blue, modifier = Modifier.size(26.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(fmtEta(h.etaS), color = pal.text, fontSize = 32.sp, fontWeight = FontWeight.Medium)
                            h.soc?.let { soc ->
                                Spacer(Modifier.width(12.dp))
                                SocChip("${fmtPct(soc)} bei Ankunft", soc < 10)
                            }
                        }
                        Text(
                            "${h.name} · ${fmtKm(h.distM)} · ${fmtDuration(h.etaS)}",
                            color = pal.sub, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        IconLine(
                            Icons.Filled.Flag,
                            "${fmtEta(p.remainingS)} · ${fmtKm(p.remainingM)}" + (destSoc?.let { " · ${fmtPct(it)} am Ziel" } ?: "") +
                                if (delayMin >= 1) " · +$delayMin min Stau" else "",
                            if (delayMin >= 1) pal.red else pal.sub, 16.sp, modifier = Modifier.padding(top = 4.dp),
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Flag, null, tint = pal.text, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(fmtEta(p.remainingS), color = pal.text, fontSize = 32.sp, fontWeight = FontWeight.Medium)
                            if (destSoc != null) {
                                Spacer(Modifier.width(12.dp))
                                SocChip(if (compact) fmtPct(destSoc) else "${fmtPct(destSoc)} am Ziel", destSoc < 10, Icons.Filled.BatteryChargingFull)
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmtKm(p.remainingM), color = pal.sub, fontSize = 19.sp, fontWeight = FontWeight.Medium)
                            Text("  |  ", color = pal.divider.copy(alpha = 0.6f), fontSize = 19.sp)
                            Text(fmtDuration(p.remainingS), color = pal.sub, fontSize = 19.sp, fontWeight = FontWeight.Medium)
                            Text("  |  ", color = pal.divider.copy(alpha = 0.6f), fontSize = 19.sp)
                            Text(
                                if (delayMin >= 1) (if (compact) "+$delayMin min" else "+$delayMin min Stau") else "frei",
                                color = if (delayMin >= 1) pal.red else pal.green, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                                maxLines = 1, softWrap = false,
                            )
                        }
                        halt?.let { h ->
                            IconLine(
                                if (h.charge) Icons.Filled.Bolt else Icons.Filled.Place,
                                "${h.name} · ${fmtEta(h.etaS)} · ${fmtKm(h.distM)}",
                                pal.green, 16.sp, FontWeight.SemiBold, Modifier.padding(top = 4.dp),
                            )
                        }
                    }
                }
                Box(Modifier.size(56.dp).glass(CircleShape, 2.dp).clickable(onClick = onEnd), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Close, "Navigation beenden", tint = pal.text, modifier = Modifier.size(28.dp))
                }
            }
            if (real != null) {
                Text(
                    "Akku ${fmtSoc(real)}" + (nowSoc?.let { " · Plan ${fmtPct(it)}" } ?: ""),
                    color = if (diff < -4) pal.red else pal.sub, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp),
                )
            }
            val nav = NavSession.state.collectAsState().value
            if (p.remainingM < 5000 && (nav.destParking.isNotEmpty() || nav.destChargers.isNotEmpty())) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    if (nav.destParking.isNotEmpty()) DestChip("Parken am Ziel (${nav.destParking.size})") { onDestInfo("park") }
                    if (nav.destChargers.isNotEmpty()) DestChip("Laden am Ziel (${nav.destChargers.size})") { onDestInfo("charge") }
                }
            }
        }
    }
}

@Composable
private fun SocChip(text: String, low: Boolean, icon: ImageVector? = null) {
    val pal = LocalPal.current
    val c = if (low) pal.red else pal.green
    Row(
        Modifier.clip(RoundedCornerShape(14.dp)).background(c.copy(alpha = 0.12f)).padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = c, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = c, maxLines = 1, softWrap = false)
    }
}

/** Symbol + Text in einer Zeile (statt Emojis, die je nach Handy anders aussehen) */
@Composable
fun IconLine(icon: ImageVector, text: String, color: Color, size: TextUnit, weight: FontWeight = FontWeight.Normal, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = color, modifier = Modifier.size((size.value + 2).dp))
        Spacer(Modifier.width(5.dp))
        Text(text, color = color, fontSize = size, fontWeight = weight, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Ladebildschirm am Schnelllader: „Lade von x auf y %, ca. n min“ und „Weiterfahren“ (ohne Live-Daten) */
@Composable
fun ChargingCard(cs: NavSession.ChargeSession, r: Route, p: NavProgress?) {
    val pal = LocalPal.current
    // jede halbe Minute aktualisieren (Restzeit und Ankunft am Ziel)
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(cs) { while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(30_000) } }
    val elapsed = ((now - cs.startedAt) / 1000.0).coerceAtLeast(0.0)
    val left = (cs.chargeS - elapsed).coerceAtLeast(0.0)
    val clock = java.text.SimpleDateFormat("HH:mm", java.util.Locale.GERMANY)
    // Restzeit der Route enthält die geplante Ladedauer dieses Stopps: das bereits Geladene abziehen, die neue Schätzung einsetzen
    val restS = (p?.remainingS ?: r.durationS) - cs.plannedChargeS + left
    val restM = p?.remainingM ?: r.distanceM
    val done = left <= 0
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp), 12.dp)) {
        Column(Modifier.navigationBarsPadding().padding(start = 22.dp, end = 22.dp, top = 20.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.BatteryChargingFull, null, tint = pal.green, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    "Laden bei ${cs.name.substringBefore(",")}", color = pal.sub, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Lade von ${cs.arriveSoc.roundToInt()} % auf ${cs.targetSoc.roundToInt()} %",
                color = pal.text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
            )
            Text(
                if (done) "Geplanter Ladestand sollte erreicht sein" else "ca. ${(left / 60).roundToInt().coerceAtLeast(1)} min – fertig gegen ${clock.format(java.util.Date(cs.readyAt))}",
                color = if (done) pal.green else pal.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp),
            )
            // geschätzter Fortschritt nach Zeit (keine Live-Daten)
            Box(Modifier.padding(top = 12.dp).fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(pal.divider.copy(alpha = 0.5f))) {
                Box(Modifier.fillMaxWidth((elapsed / cs.chargeS.coerceAtLeast(1.0)).toFloat().coerceIn(0f, 1f)).height(6.dp).clip(RoundedCornerShape(3.dp)).background(pal.green))
            }
            Text(
                "Danach noch ${fmtKm(restM)} · Ankunft am Ziel ${fmtEta(restS)}",
                color = pal.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp),
            )
            Spacer(Modifier.height(14.dp))
            androidx.compose.material3.Button(
                onClick = { NavSession.finishCharging() },
                shape = RoundedCornerShape(16.dp),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = pal.blue, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Weiterfahren", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

/** Hinweiskarte kurz vor einem Ladestopp (unter dem Banner) */
@Composable
fun ChargeApproachCard(r: Route, p: NavProgress, avail: Map<String, Availability>) {
    val pal = LocalPal.current
    val st = r.stops.firstOrNull { it.alongM > p.alongM + 50 } ?: return
    val d = st.alongM - p.alongM
    if (d > 5000) return
    val a = st.uuid?.let { avail[it] }
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = pal.card, shadowElevation = 10.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(pal.green), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Ladestopp in ${fmtDistShort(d)}", color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    st.name + if (a != null && a.known) " · ${a.available} von ${a.total} frei" else "",
                    color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${st.arriveSoc.roundToInt()} → ${st.targetSoc.roundToInt()} %", color = pal.green, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                Text("${(st.chargeS / 60).roundToInt()} min", color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ---------------- Einstellungen ----------------

enum class SettingsPage(val title: String) {
    MAIN("Einstellungen"), DISPLAY("Darstellung"), NAV("Navigation"), VEHICLE("Fahrzeug"),
    CHARGING("Ladeplanung"), OBD("OBD2-Adapter"), LEARN("Fahrten & Lernen"), TOMTOM("Verkehr (TomTom)"), DEV("Entwickleroptionen"), CHARGERS("Ladesäulen"), ROUTING("Kartendaten"),
    BACKUP("Sichern"), INFO("Info"), ECO("Eco-Score"), ECO_TRIPS("Alle Fahrten"), SPEED("Tempolimits"),
}

@Composable
fun SettingsScreen(s: AppSettings, onClose: () -> Unit, onOpenObd: () -> Unit, onOpenTrips: () -> Unit, startPage: String? = null) {
    val pal = LocalPal.current
    var page by remember { mutableStateOf(startPage?.let { p -> SettingsPage.entries.firstOrNull { it.name == p } } ?: SettingsPage.MAIN) }
    // Unterseiten mit eigener Elternseite (zurück führt dorthin statt zur Übersicht)
    val parent = if (page == SettingsPage.ECO_TRIPS) SettingsPage.ECO else SettingsPage.MAIN
    BackHandler(enabled = page != SettingsPage.MAIN) { page = parent }

    Surface(Modifier.fillMaxSize(), color = pal.screen) {
        Column(
            Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            // Kopfzeile
            if (page == SettingsPage.MAIN) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Einstellungen", color = pal.text, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onClose) { Text("Fertig", color = pal.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.clip(RoundedCornerShape(10.dp)).clickable { page = parent }.padding(vertical = 6.dp, horizontal = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = pal.blue)
                        Text(if (parent == SettingsPage.MAIN) "Einstellungen" else parent.title, color = pal.blue, fontSize = 17.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onClose) { Text("Fertig", color = pal.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
                }
                Text(page.title, color = pal.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }

            when (page) {
                SettingsPage.MAIN -> SettingsMain(s) { page = it }
                SettingsPage.DISPLAY -> { DisplayPage(s); PoiSection(s) }
                SettingsPage.NAV -> NavPage(s, onClose)
                SettingsPage.VEHICLE -> VehiclePage(s)
                SettingsPage.CHARGING -> ChargingPage(s)
                SettingsPage.OBD -> Section("Adapter") { ObdSettingsSection(s, onOpenObd) }
                SettingsPage.LEARN -> {
                    Section("Aufzeichnung") { LearnSettingsSection(s, onOpenTrips) }
                    Section("Gelernt ohne OBD") {
                        val b by ManualLearn.buckets.collectAsState()
                        val text = remember(b) { ManualLearn.describe() }
                        Text(
                            if (text.isBlank()) "Noch nichts gelernt. Nach der Ankunft fragt die App nach dem Akkustand im Auto, wenn kein OBD-Adapter verbunden ist."
                            else "Verbrauchskorrektur nach Temperatur: $text",
                            color = LocalPal.current.sub, fontSize = 13.sp,
                        )
                        if (text.isNotBlank()) TextButton(onClick = { ManualLearn.reset() }) { Text("Zurücksetzen", color = LocalPal.current.red) }
                    }
                }
                SettingsPage.TOMTOM -> TomTomPage(s)
                SettingsPage.DEV -> DevPage(s, onClose)
                SettingsPage.CHARGERS -> ChargersPage(s)
                SettingsPage.ROUTING -> RoutingPage(s)
                SettingsPage.ECO -> EcoPage(s) { page = SettingsPage.ECO_TRIPS }
                SettingsPage.ECO_TRIPS -> EcoTripsPage()
                SettingsPage.SPEED -> SpeedLimitPage(s)
                SettingsPage.BACKUP -> Section("Sicherung") { BackupSection() }
                SettingsPage.INFO -> InfoPage()
            }
        }
    }
}

// ---------------- Übersicht ----------------

@Composable
private fun SettingsMain(s: AppSettings, open: (SettingsPage) -> Unit) {
    val conn by Obd.conn.collectAsState()
    val trips by TripRecorder.trips.collectAsState()
    val count by ApiCounter.today.collectAsState()
    val tiles by ValhallaTiles.state.collectAsState()
    val chargers by ChargerRegistry.count.collectAsState()
    val eco by EcoStore.items.collectAsState()
    val weekScore = remember(eco) { EcoStats.buckets(eco, EcoStats.Period.WEEK, 1).first().score?.roundToInt() }

    MenuGroup("Fahrzeug") {
        MenuRow(Icons.Filled.DirectionsCar, Color(0xFF5E5CE6), "Fahrzeug",
            "${Vehicles.byId(s.vehicleId).name} · ${String.format(java.util.Locale.GERMANY, "%.1f", s.usableKwh)} kWh") { open(SettingsPage.VEHICLE) }
        MenuDivider()
        MenuRow(Icons.Filled.Bluetooth, Color(0xFF0A84FF), "OBD2-Adapter",
            if (s.obdName.isBlank()) "Kein Adapter" else s.obdName + if (conn == Obd.Conn.READY) " · verbunden" else "") { open(SettingsPage.OBD) }
        MenuDivider()
        MenuRow(Icons.Filled.EvStation, Color(0xFF30D158), "Ladeplanung",
            "Reserve ${fmtPct(s.minSocStop)} · Ziel ${fmtPct(s.minSocDest)}") { open(SettingsPage.CHARGING) }
    }
    MenuGroup("Navigation") {
        MenuRow(Icons.Filled.Navigation, Color(0xFF0A84FF), "Navigation",
            (if (s.voice) "Ansagen an" else "Ansagen aus") + if (s.avoidToll || s.avoidMotorway || s.avoidFerry) " · Vermeiden aktiv" else "") { open(SettingsPage.NAV) }
        MenuDivider()
        MenuRow(Icons.Filled.Traffic, Color(0xFFFF3B30), "Verkehr (TomTom)",
            if (s.hasTomTom) "Key hinterlegt · heute $count Anfragen" else "Optional: Staus auch in der Stadt") { open(SettingsPage.TOMTOM) }
        MenuDivider()
        MenuRow(Icons.Filled.Palette, Color(0xFFAF52DE), "Darstellung",
            "${listOf("Bright", "Positron")[s.mapStyle.coerceIn(0, 1)]} · ${listOf("Automatisch", "Hell", "Dunkel")[s.mapMode.ordinal]}") { open(SettingsPage.DISPLAY) }
    }
    MenuGroup("Offline-Daten") {
        MenuRow(Icons.Filled.Route, Color(0xFF5856D6), "Kartendaten",
            if (tiles.ready) "Stand ${tiles.installedVersion}" + if (tiles.updateAvailable) " · Update verfügbar" else "" else "Noch nicht geladen") { open(SettingsPage.ROUTING) }
        MenuDivider()
        MenuRow(Icons.Filled.EvStation, Color(0xFF34C759), "Ladesäulen",
            if (chargers > 0) "${"%,d".format(Locale.GERMANY, chargers)} Standorte" else "Noch nicht geladen") { open(SettingsPage.CHARGERS) }
    }
    MenuGroup("Auswertung") {
        MenuRow(Icons.Filled.Eco, Color(0xFF1F9D55), "Eco-Score",
            weekScore?.let { "Ø $it diese Woche" } ?: "${eco.size} Fahrten") { open(SettingsPage.ECO) }
        MenuDivider()
        MenuRow(Icons.Filled.Insights, Color(0xFFFF9F0A), "Fahrten & Lernen",
            "${trips.size} Fahrten · ${Learner.totalKm().roundToInt()} km gelernt") { open(SettingsPage.LEARN) }
    }
    MenuGroup("Allgemein") {
        MenuRow(Icons.Filled.Backup, Color(0xFF8E8E93), "Sichern und Wiederherstellen", "Einstellungen, Favoriten, Gelerntes") { open(SettingsPage.BACKUP) }
        MenuDivider()
        MenuRow(Icons.Filled.Info, Color(0xFF8E8E93), "Info", "Version und Datenquellen") { open(SettingsPage.INFO) }
        MenuDivider()
        MenuRow(Icons.Filled.AutoAwesome, Color(0xFF0A84FF), "Ersteinrichtung", "Schritt für Schritt neu einrichten") { SetupFlow.open.value = true }
        if (s.devMode) {
            MenuDivider()
            MenuRow(Icons.Filled.Build, Color(0xFFFF9500), "Entwickleroptionen", "Simulation, eigene Schlüssel, Prüfwerte") { open(SettingsPage.DEV) }
        }
    }
}

@Composable
private fun MenuGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column {
        Text(title.uppercase(), color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 14.dp, bottom = 6.dp))
        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid) { Column(Modifier.fillMaxWidth(), content = content) }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, color: Color, title: String, summary: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(color), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = pal.text, fontSize = 16.sp)
            Text(summary, color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = pal.sub)
    }
}

@Composable
private fun MenuDivider() {
    Box(Modifier.fillMaxWidth().padding(start = 58.dp).height(1.dp).background(LocalPal.current.divider))
}

// ---------------- Unterseiten ----------------

@Composable
private fun DisplayPage(s: AppSettings) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    Section("Karte") {
        Label("Kartenstil")
        Segmented(listOf("Bright", "Positron"), s.mapStyle.coerceIn(0, 1)) { i -> Settings.update { it.copy(mapStyle = i) } }
        Spacer(Modifier.height(14.dp))
        Label("Bei Nacht")
        Segmented(listOf("Dunkelblau", "Schwarz"), s.nightStyle.coerceIn(0, 1)) { i -> Settings.update { it.copy(nightStyle = i) } }
        Spacer(Modifier.height(14.dp))
        Label("Hell oder dunkel")
        Segmented(listOf("Automatisch", "Hell", "Dunkel"), s.mapMode.ordinal) { i -> Settings.update { it.copy(mapMode = MapMode.entries[i]) } }
    }
    Section("Fahrsymbol") {
        listOf(VehicleIcon.entries.take(3), VehicleIcon.entries.drop(3).take(3), VehicleIcon.entries.drop(6)).forEachIndexed { row, group ->
            if (group.isEmpty()) return@forEachIndexed
            if (row == 1) Text("3D-Modelle", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = if (row == 2) 10.dp else 0.dp)) {
                group.forEach { v ->
                    val bmp = remember(v, s.carColor, s.modelOrigColor) {
                        when (v) {
                            VehicleIcon.ARROW -> VehicleIcons.arrow(ctx)
                            VehicleIcon.CAR -> VehicleIcons.car(ctx, s.carColor.toInt())
                            VehicleIcon.DOT -> VehicleIcons.dot(ctx)
                            else -> VehicleSprites.frames(ctx, v, if (s.modelOrigColor) null else s.carColor.toInt())?.get(9) ?: VehicleIcons.arrow(ctx)
                        }.asImageBitmap()
                    }
                    val sel = s.vehicle == v
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(pal.field)
                            .border(2.dp, if (sel) pal.blue else Color.Transparent, RoundedCornerShape(14.dp))
                            .clickable { Settings.update { it.copy(vehicle = v) } }
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Image(bmp, null, Modifier.size(if (VehicleSprites.isSprite(v)) 64.dp else 48.dp))
                        Text(if (v == VehicleIcon.ARROW) "Tropfen" else v.label, color = pal.text, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
        if (VehicleSprites.isSprite(s.vehicle)) {
            Spacer(Modifier.height(12.dp))
            ToggleRow("Originalfarbe des Modells", s.modelOrigColor) { v -> Settings.update { it.copy(modelOrigColor = v) } }
        }
        if (s.vehicle == VehicleIcon.CAR || (VehicleSprites.isSprite(s.vehicle) && !s.modelOrigColor)) {
            Spacer(Modifier.height(12.dp))
            Label("Farbe")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CAR_COLORS.forEach { c ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                            .border(if (s.carColor == c) 3.dp else 1.dp, if (s.carColor == c) pal.blue else pal.divider, CircleShape)
                            .clickable { Settings.update { it.copy(carColor = c) } },
                    )
                }
            }
        }
        Text("Ohne Navigation zeigt die Karte immer den Punkt.", color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
private fun PoiSection(s: AppSettings) {
    val pal = LocalPal.current
    Section("Orte auf der Karte") {
        ToggleRow("Orte anzeigen (zum Antippen)", s.poiEnabled) { v -> Settings.update { it.copy(poiEnabled = v) } }
        if (s.poiEnabled) {
            Text("Erscheinen, sobald du auf Stadtteil- bzw. Straßenebene hineinzoomst. Antippen öffnet das Ortsfenster mit Öffnungszeiten und Route.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            Pois.CATS.forEach { c ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                        Settings.update { it.copy(poiCats = if (c.id in it.poiCats) it.poiCats - c.id else it.poiCats + c.id) }
                    }.padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(28.dp).clip(CircleShape).background(Color(c.color)), contentAlignment = Alignment.Center) {
                        Text(c.emoji, color = Color.White, fontSize = 13.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(c.label, color = pal.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = c.id in s.poiCats,
                        onCheckedChange = { on ->
                            Settings.update { it.copy(poiCats = if (on) it.poiCats + c.id else it.poiCats - c.id) }
                            },
                        colors = SwitchDefaults.colors(checkedTrackColor = pal.green, checkedThumbColor = Color.White),
                    )
                }
            }
            ToggleRow("Auch während der Navigation", s.poiInNav) { v -> Settings.update { it.copy(poiInNav = v) } }
        }
    }
}

@Composable
private fun SpeedLimitPage(s: AppSettings) {
    val pal = LocalPal.current
    Section("Quelle") {
        Text("OpenStreetMap", color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Eingetragene Tempolimits aus OpenStreetMap, beim Planen und unterwegs abschnittsweise geladen (Overpass). " +
                "Wo nichts eingetragen ist, bleibt das Schild leer. TomTom wird nur noch für Verkehrsdaten genutzt.",
            color = pal.sub, fontSize = 13.sp,
        )
    }
    Section("Anzeige") {
        ToggleRow("Quelle unter dem Schild anzeigen (OSM)", s.speedSourceLabel) { v -> Settings.update { it.copy(speedSourceLabel = v) } }
    }
}

/** Sprachausgabe und Stimme wählen, Tempo und Tonhöhe, Probehören */
@Composable
private fun VoiceSection(s: AppSettings) {
    val pal = LocalPal.current
    var refresh by remember { mutableStateOf(0) }
    val voice = remember { runCatching { NavSession.voice }.getOrNull() }
    // Liste etwas verzögert laden: die Sprachausgabe braucht nach einem Wechsel einen Moment
    var engines by remember { mutableStateOf(emptyList<android.speech.tts.TextToSpeech.EngineInfo>()) }
    var voices by remember { mutableStateOf(emptyList<android.speech.tts.Voice>()) }
    LaunchedEffect(s.voiceEngine, refresh) {
        kotlinx.coroutines.delay(400)
        engines = voice?.engines().orEmpty()
        voices = voice?.germanVoices().orEmpty()
        if (voices.isEmpty()) { kotlinx.coroutines.delay(1200); voices = voice?.germanVoices().orEmpty() }
    }
    fun preview() {
        voice?.applyVoice()
        voice?.say(if (s.voiceDu) "In 300 Metern rechts abbiegen auf die B 54. Nimm eine der beiden rechten Spuren." else "In 300 Metern rechts abbiegen auf die B 54. Benutzen Sie eine der beiden rechten Spuren.")
    }
    Section("Stimme") {
        if (engines.isNotEmpty()) {
            Label("Sprachausgabe")
            val active = s.voiceEngine.ifBlank { voice?.defaultEngine().orEmpty() }
            engines.forEach { e ->
                val sel = active == e.name
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                        Settings.update { it.copy(voiceEngine = e.name, voiceName = "") }
                        voice?.reload()
                        refresh++
                    }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(if (sel) "●" else "○", color = if (sel) pal.blue else pal.sub, fontSize = 16.sp)
                    Spacer(Modifier.width(10.dp))
                    Text(e.label, color = pal.text, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        Label("Deutsche Stimmen")
        val googleActive = s.voiceEngine.ifBlank { voice?.defaultEngine().orEmpty() }.contains("google")
        if (voices.isEmpty()) {
            Text(
                if (googleActive) "Keine deutschen Stimmen gefunden – ggf. in den Android-Einstellungen unter „Sprachausgabe“ herunterladen."
                else "Diese Sprachausgabe verwaltet ihre Stimme selbst (bei SherpaTTS z. B. Coqui oder Piper „Thorsten“ in der SherpaTTS-App wählen). „Probe hören“ nutzt die dort aktive Stimme.",
                color = pal.sub, fontSize = 13.sp,
            )
        }
        voices.forEachIndexed { i, v ->
            val sel = s.voiceName == v.name
            val code = v.name.substringAfter("-x-", "").substringBefore("-").uppercase().ifBlank { v.name }
            val label = "Stimme $code" + if (v.isNetworkConnectionRequired) " · online" else " · offline"
            val quality = when {
                v.quality >= 500 -> "sehr hohe Qualität"
                v.quality >= 400 -> "hohe Qualität"
                else -> "normale Qualität"
            }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                    Settings.update { it.copy(voiceName = v.name) }
                    voice?.applyVoice()
                }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(if (sel) "●" else "○", color = if (sel) pal.blue else pal.sub, fontSize = 16.sp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(label, color = pal.text, fontSize = 15.sp)
                    Text(quality, color = pal.sub, fontSize = 12.sp)
                }
                TextButton(onClick = {
                    Settings.update { it.copy(voiceName = v.name) }
                    preview()
                }) { Text("▶ Probe") }
            }
        }
        Spacer(Modifier.height(10.dp))
        Label("Sprechtempo: ${"%.2f".format(s.voiceRate)}×")
        Slider(value = s.voiceRate, onValueChange = { v -> Settings.update { it.copy(voiceRate = (v * 20).roundToInt() / 20f) } }, valueRange = 0.7f..1.4f)
        Label("Tonhöhe: ${"%.2f".format(s.voicePitch)}")
        Slider(value = s.voicePitch, onValueChange = { v -> Settings.update { it.copy(voicePitch = (v * 20).roundToInt() / 20f) } }, valueRange = 0.8f..1.25f)
        TextButton(onClick = { preview() }) { Text("Probe hören") }
    }
}

@Composable
private fun NavPage(s: AppSettings, onClose: () -> Unit = {}) {
    val pal = LocalPal.current
    Section("Ansagen") {
        ToggleRow("Sprachansagen", s.voice) { v -> Settings.update { it.copy(voice = v) } }
        ToggleRow("Du statt Sie", s.voiceDu) { v -> Settings.update { it.copy(voiceDu = v) } }
        ToggleRow("Hinweiston bei zu hohem Tempo", s.speedChime) { v -> Settings.update { it.copy(speedChime = v) } }
        ToggleRow("Kurze Pause vor Ansagen (Bluetooth)", s.voiceLeadIn) { v -> Settings.update { it.copy(voiceLeadIn = v) } }
        Spacer(Modifier.height(10.dp))
        Label("Ausgabe")
        Segmented(listOf("Automatisch", "Handy", "Bluetooth"), s.voiceOutput.coerceIn(0, 2)) { i -> Settings.update { it.copy(voiceOutput = i) } }
    }
    VoiceSection(s)
    Section("Route") {
        ToggleRow("Mautstraßen vermeiden", s.avoidToll) { v -> Settings.update { it.copy(avoidToll = v) } }
        ToggleRow("Autobahnen vermeiden", s.avoidMotorway) { v -> Settings.update { it.copy(avoidMotorway = v) } }
        ToggleRow("Fähren vermeiden", s.avoidFerry) { v -> Settings.update { it.copy(avoidFerry = v) } }
    }
    Section("Verkehr") {
        ToggleRow("Autobahn-Meldungen (Stau, Sperrung, Baustelle)", s.autobahnApi) { v -> Settings.update { it.copy(autobahnApi = v) } }
        if (s.hasTomTom) ToggleRow("Verkehrslage auf der Karte (TomTom)", s.showTraffic) { v -> Settings.update { it.copy(showTraffic = v) } }
        ToggleRow("Quelle unter dem Tempolimit-Schild", s.speedSourceLabel) { v -> Settings.update { it.copy(speedSourceLabel = v) } }
    }
    EcoAndSimulationSections(s, showSim = false) { onClose() }
    Section("Karte entlang der Route speichern") {
        val off by OfflineMaps.state.collectAsState()
        val ctx = LocalContext.current
        ToggleRow("Automatisch speichern", s.offlineAuto) { v -> Settings.update { it.copy(offlineAuto = v) } }
        ToggleRow("Nur im WLAN", s.offlineWifiOnly) { v -> Settings.update { it.copy(offlineWifiOnly = v) } }
        Spacer(Modifier.height(6.dp))
        Segmented(listOf("Detailliert", "Sparsam"), if (s.offlineDetail) 0 else 1) { i -> Settings.update { it.copy(offlineDetail = i == 0) } }
        Text(
            when {
                off.error != null -> "Fehler: ${off.error}"
                off.running -> "Lädt … ${off.percent} % · ${String.format(java.util.Locale.GERMANY, "%.1f", off.sizeMb)} MB"
                off.done -> "Gespeichert: ${off.label} · ${String.format(java.util.Locale.GERMANY, "%.1f", off.sizeMb)} MB"
                else -> "Noch nichts gespeichert"
            },
            color = if (off.error != null) pal.red else pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (NavSession.state.value.route != null) TextButton(onClick = { NavSession.saveOffline() }) { Text("Jetzt speichern") }
            TextButton(onClick = { OfflineMaps.clear(ctx) }) { Text("Löschen", color = pal.red) }
        }
    }
}

/** Ein Eintrag in der Fahrzeugauswahl: geprüftes Profil (mit OBD) oder Open-EV-Data-Variante */
private class CarOption(
    val brand: String,
    val model: String,
    val title: String,
    val sub: String,
    val obd: ObdSupport?,
    val id: String,
    val usableKwh: Double,
)

private fun normKey(t: String) = java.text.Normalizer.normalize(t.lowercase().trim(), java.text.Normalizer.Form.NFD)
    .replace(Regex("\\p{M}"), "").replace(Regex("[^a-z0-9]+"), " ").trim()

/** Fahrzeugauswahl: Hersteller → Modell → Variante, geprüfte Profile mit OBD und Open EV Data zusammen */
@Composable
private fun VehiclePicker(s: AppSettings, onDone: () -> Unit) {
    val pal = LocalPal.current
    val ev by EvDatabase.all.collectAsState()
    var brand by remember { mutableStateOf<String?>(null) }
    var model by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    val options = remember(ev) {
        Vehicles.ALL.filter { it.id != "custom" }.map { v ->
            CarOption(v.brand, v.model, v.model, listOf(v.years, "${v.usableKwh.roundToInt()} kWh netto", "DC ${v.maxDcKw.roundToInt()} kW").filter { it.isNotBlank() }.joinToString(" · "), v.obd, v.id, v.usableKwh)
        } + ev.map { sp ->
            CarOption(sp.brand, sp.title, sp.year?.toString() ?: sp.title, sp.details, null, "ev:${sp.id}", sp.usableKwh)
        }
    }
    fun choose(o: CarOption) {
        Settings.update { it.copy(vehicleId = o.id, usableKwh = o.usableKwh) }
        onDone()
    }
    if (brand != null) {
        Text(
            "‹ " + listOfNotNull(brand, model).joinToString(" · "),
            color = pal.blue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).clickable { if (model != null) model = null else brand = null }.padding(vertical = 6.dp),
        )
    }
    when {
        brand == null -> {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                label = { Text("Hersteller oder Modell suchen") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            val q = normKey(query)
            options.groupBy { normKey(it.brand) }
                .filter { (k, list) -> q.isBlank() || k.contains(q) || list.any { normKey(it.model).contains(q) } }
                .toSortedMap()
                .forEach { (_, list) ->
                    // Schreibweise der geprüften Profile bevorzugen (z. B. „Citroën“)
                    val name = list.firstOrNull { it.obd != null }?.brand ?: list.first().brand
                    val hasObd = list.any { it.obd == ObdSupport.TESTED || it.obd == ObdSupport.LIKELY }
                    PickRow(name, "${list.map { normKey(it.model) }.distinct().size} Modelle" + if (hasObd) " · mit OBD" else "") { brand = name; query = "" }
                }
            PickRow("Anderes Fahrzeug", "Kapazität und Ladeleistung selbst einstellen") {
                Settings.update { it.copy(vehicleId = "custom") }
                onDone()
            }
        }
        model == null -> {
            val bk = normKey(brand!!)
            options.filter { normKey(it.brand) == bk }.groupBy { normKey(it.model) }.entries
                .sortedWith(compareBy({ e -> if (e.value.any { it.obd != null }) 0 else 1 }, { it.key }))
                .forEach { (_, list) ->
                    val name = list.firstOrNull { it.obd != null }?.model ?: list.first().model
                    val obd = list.firstNotNullOfOrNull { it.obd }
                    PickRow(name, "${list.size} Variante" + (if (list.size > 1) "n" else "") + (obd?.let { " · ${it.label}" } ?: "")) {
                        if (list.size == 1) choose(list.first()) else model = name
                    }
                }
        }
        else -> {
            val bk = normKey(brand!!)
            val mk = normKey(model!!)
            options.filter { normKey(it.brand) == bk && normKey(it.model) == mk }
                .sortedWith(compareBy({ if (it.obd != null) 0 else 1 }, { it.title }))
                .forEach { o ->
                    PickRow((if (s.vehicleId == o.id) "✓ " else "") + o.title, o.sub + (o.obd?.let { " · ${it.label}" } ?: "")) { choose(o) }
                }
        }
    }
}

@Composable
private fun PickRow(title: String, sub: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(vertical = 9.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = pal.text, fontSize = 15.sp)
            if (sub.isNotBlank()) Text(sub, color = pal.sub, fontSize = 12.sp)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = pal.sub, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun VehiclePage(s: AppSettings) {
    val pal = LocalPal.current
    val cur = Vehicles.byId(s.vehicleId)
    var picking by remember { mutableStateOf(false) }
    Section("Fahrzeug") {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { picking = !picking }.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(cur.name, color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    listOf(cur.years, "bis ${Vehicles.maxDc(s).roundToInt()} kW DC", cur.obd.label).filter { it.isNotBlank() }.joinToString(" · "),
                    color = pal.sub, fontSize = 13.sp,
                )
            }
            Text(if (picking) "Schließen" else "Ändern", color = pal.blue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        if (cur.note.isNotBlank()) Text(cur.note, color = Color(0xFFFF9500), fontSize = 12.sp)
        if (picking) {
            VehiclePicker(s) { picking = false }
            Text(
                "Fahrzeugdaten: Open EV Data (MIT). Nach einem Fahrzeugwechsel ggf. unter „Fahrten & Lernen“ das Gelernte zurücksetzen.",
                color = pal.sub, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
    Section("Akku") {
        Label("Nutzbare Kapazität: ${String.format(java.util.Locale.GERMANY, "%.1f", s.usableKwh)} kWh")
        Slider(
            value = s.usableKwh.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(usableKwh = (v * 2).roundToInt() / 2.0) } },
            valueRange = 20f..120f,
        )
        if (cur.id == "custom") {
            Label("Höchste Ladeleistung (DC): ${s.customDcKw} kW")
            Slider(
                value = s.customDcKw.toFloat(),
                onValueChange = { v -> Settings.update { it.copy(customDcKw = (v / 5).roundToInt() * 5) } },
                valueRange = 20f..350f,
            )
        }
        ToggleRow("Akkustand abrunden wie im Auto", s.socFloor) { b -> Settings.update { it.copy(socFloor = b) } }
    }
    Section("Verbrauch") {
        Label("Fahrweise")
        Segmented(listOf("Sparsam", "Normal", "Zügig"), s.style) { i -> Settings.update { it.copy(style = i) } }
        Spacer(Modifier.height(12.dp))
        MaxSpeedSlider(s)
        Spacer(Modifier.height(12.dp))
        Label("Referenzverbrauch: ${s.refConsumptionPct} %")
        Slider(
            value = s.refConsumptionPct.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(refConsumptionPct = (v / 5).roundToInt() * 5) } },
            valueRange = 80f..130f,
        )
        Label("Zusatzgewicht: ${s.extraWeightKg} kg")
        Slider(
            value = s.extraWeightKg.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(extraWeightKg = (v / 25).roundToInt() * 25) } },
            valueRange = 0f..400f,
        )
        Text("Wird mit jeder Fahrt durch dein gelerntes Fahrverhalten verfeinert.", color = pal.sub, fontSize = 12.sp)
    }
}

@Composable
private fun ChargingPage(s: AppSettings) {
    Section("Reserve") {
        Label("Mindest-Akku am Ladestopp: ${fmtPct(s.minSocStop)}")
        Slider(
            value = s.minSocStop.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(minSocStop = v.roundToInt().toDouble()) } },
            valueRange = 5f..30f,
        )
        Label("Mindest-Akku am Ziel: ${fmtPct(s.minSocDest)}")
        Slider(
            value = s.minSocDest.toFloat(),
            onValueChange = { v -> Settings.update { it.copy(minSocDest = v.roundToInt().toDouble()) } },
            valueRange = 5f..50f,
        )
    }
    Section("Ladeanbieter und Ladekarten") { OperatorSettings(s) }
}

@Composable
private fun RoutingPage(s: AppSettings) {
    val pal = LocalPal.current
    Section("Offline-Routing (Valhalla)") {
        val vs by ValhallaTiles.state.collectAsState()
        val scope = rememberCoroutineScope()
        val lib = remember { ValhallaEngine.libraryPresent() }
        val srv = remember { ValhallaEngine.serverConfigured() }
        LaunchedEffect(Unit) { if (srv && vs.remote == null) ValhallaTiles.check() }
        if (!lib || !srv) {
            Text(
                (if (!lib) "Routing-Bibliothek fehlt. " else "") + (if (!srv) "Kein Zugang zum Kartenserver hinterlegt." else ""),
                color = pal.red, fontSize = 14.sp,
            )
        }
        Text(
            if (vs.ready) "Kartendaten: ${vs.installedVersion} · ${ValhallaTiles.gb(vs.installedBytes)}" else "Noch keine Kartendaten auf dem Handy",
            color = if (vs.ready) pal.green else pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
        )
        vs.installedDate?.takeIf { it.isNotBlank() }?.let { Text("Gebaut am $it", color = pal.sub, fontSize = 13.sp) }
        vs.remote?.let { r ->
            Text(
                "Auf dem Server: ${r.version} (${r.buildDate}) · Valhalla ${r.valhallaVersion}" + (r.sizeBytes?.let { " · ${ValhallaTiles.gb(it)}" } ?: ""),
                color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp),
            )
            if (!ValhallaTiles.compatible(r)) Text("Diese Kartendaten passen nicht zur App-Version.", color = pal.red, fontSize = 13.sp)
        }
        if (vs.downloading) {
            val frac = if (vs.total > 0) (vs.bytes.toFloat() / vs.total).coerceIn(0f, 1f) else 0f
            Box(Modifier.fillMaxWidth().padding(top = 10.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.sub.copy(alpha = 0.2f))) {
                Box(Modifier.fillMaxWidth(frac.coerceAtLeast(0.01f)).height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.blue))
            }
            Text(
                if (vs.waitingForWifi) "Wartet auf WLAN …"
                else "${ValhallaTiles.gb(vs.bytes)}" + (if (vs.total > 0) " von ${ValhallaTiles.gb(vs.total)} · ${(frac * 100).roundToInt()} %" else "") +
                    " · läuft auch bei geschlossener App weiter",
                color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
            )
            Text(
                "Abbrechen", color = pal.red, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(8.dp)).clickable { ValhallaTiles.cancel() }.padding(vertical = 6.dp),
            )
        } else if (srv && lib) {
            val label = when {
                !vs.ready -> "Kartendaten herunterladen (nur WLAN)"
                vs.updateAvailable -> "Update auf ${vs.remote?.version} laden (nur WLAN)"
                else -> null
            }
            if (label != null) {
                Text(
                    label, color = pal.blue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp))
                        .clickable { scope.launch { ValhallaTiles.startDownload(wifiOnly = true) } }.padding(vertical = 6.dp),
                )
            } else {
                Text(
                    if (vs.checking) "Prüfe auf neue Kartendaten …" else "Kartendaten sind aktuell · erneut prüfen",
                    color = pal.blue, fontSize = 14.sp,
                    modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp))
                        .clickable(enabled = !vs.checking) { scope.launch { ValhallaTiles.check() } }.padding(vertical = 6.dp),
                )
            }
        }
        vs.error?.let { Text(it, color = pal.red, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
        // Was liefern die Kacheln? (Werte der zuletzt berechneten Route)
        ValhallaRouter.lastStats.collectAsState().value?.let { st ->
            Text(
                if (st.error != null) "Letzte Abfrage der Straßendaten: Fehler – ${st.error}"
                else "Letzte Route: ${st.edges} Straßenabschnitte · Tempolimit bei ${pct(st.withLimit, st.edges)} · Höhe bei ${pct(st.withElevation, st.edges)}",
                color = if (st.error != null || (st.edges > 0 && st.withElevation == 0)) Color(0xFFFF9500) else pal.sub,
                fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
            )
            if (s.devMode) st.sample?.let { Text(it, color = pal.sub, fontSize = 10.sp) }
        }
        if (vs.ready) {
            Text(
                "Routen werden offline auf dem Handy berechnet, ohne Kontingent. Ladestopps plant die App selbst.",
                color = pal.sub, fontSize = 13.sp,
            )
            Text(
                "Kartendaten löschen", color = pal.red, fontSize = 14.sp,
                modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).clickable { ValhallaTiles.delete() }.padding(vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun ChargersPage(s: AppSettings) {
    val pal = LocalPal.current
    val n by ChargerRegistry.count.collectAsState()
    val loading by ChargerRegistry.loading.collectAsState()
    val stand by ChargerRegistry.stand.collectAsState()
    val err by ChargerRegistry.error.collectAsState()
    Section("Deutschland: Ladesäulenregister") {
        Text(
            when {
                n > 0 -> "${"%,d".format(Locale.GERMANY, n)} Standorte offline auf dem Handy"
                loading -> "Wird geladen …"
                else -> "Noch nicht geladen"
            },
            color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
        )
        if (stand.isNotBlank()) Text("Stand der Bundesnetzagentur: $stand", color = pal.sub, fontSize = 13.sp)
        err?.let { Text(it, color = pal.red, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
        Text(
            if (loading) "Lädt gerade (etwa 10 MB) …" else "Jetzt aktualisieren",
            color = if (loading) pal.sub else pal.blue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).clickable(enabled = !loading) { ChargerRegistry.updateNow() }
                .padding(vertical = 6.dp),
        )
        Text(
            "Alle öffentlichen Ladepunkte, die Betreiber der Bundesnetzagentur melden müssen. Die App lädt das Verzeichnis " +
                "höchstens einmal pro Woche (über Mobilfunk nur beim ersten Mal) und sucht dann ohne Internet und ohne Kontingent. " +
                "Keine Live-Belegung. Daten: Bundesnetzagentur.de (CC BY 4.0), aufbereitet von github.com/ratopi/ladesaeule.",
            color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp),
        )
    }
    Section("Ausland (optional)") { OcmKeyBlock(s) }
    Section("Hinweis") {
        Text(
            "Ladestopps plant die App selbst, offline mit diesem Verzeichnis und der Ladekurve deines Fahrzeugs. " +
                "Live-Belegung folgt, sobald ein Anbieter angebunden ist.",
            color = pal.sub, fontSize = 13.sp,
        )
    }
}

@Composable
private fun TomTomPage(s: AppSettings) {
    val pal = LocalPal.current
    Section("Zugang") {
        TomTomKeyBlock(s)
        if (s.hasTomTom) ToggleRow("Verkehrslage auf der Karte (Kacheln)", s.showTraffic) { v -> Settings.update { it.copy(showTraffic = v) } }
    }
    if (s.hasTomTom) Section("Anfragen") {
        val month by ApiCounter.month.collectAsState()
        val days by ApiCounter.days.collectAsState()
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column {
                Text("${"%,d".format(Locale.GERMANY, month[ApiCounter.Svc.TRAFFIC] ?: 0)}", color = pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Meldungen diesen Monat", color = pal.sub, fontSize = 12.sp)
            }
            Column {
                Text("${"%,d".format(Locale.GERMANY, month[ApiCounter.Svc.TRAFFIC_TILES] ?: 0)}", color = pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Kacheln diesen Monat", color = pal.sub, fontSize = 12.sp)
            }
        }
        // Verlauf der letzten 14 Tage: Meldungen (blau) und Kacheln (orange, eigene Skala)
        val today = java.time.LocalDate.now()
        val list = (13 downTo 0).map { today.minusDays(it.toLong()).toString() }.map { d -> days[d] ?: (0 to 0) }
        val maxA = (list.maxOfOrNull { it.first } ?: 0).coerceAtLeast(1)
        val maxB = (list.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
        val blue = pal.blue
        val orange = Color(0xFFFF9500)
        val grid = pal.divider
        androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(110.dp).padding(top = 12.dp)) {
            val w = size.width / list.size
            drawLine(grid, androidx.compose.ui.geometry.Offset(0f, size.height), androidx.compose.ui.geometry.Offset(size.width, size.height), 2f)
            list.forEachIndexed { i, (a, b) ->
                val x = i * w
                val ha = size.height * a / maxA
                val hb = size.height * b / maxB
                drawRect(blue, androidx.compose.ui.geometry.Offset(x + w * 0.12f, size.height - ha), androidx.compose.ui.geometry.Size(w * 0.36f, ha))
                drawRect(orange, androidx.compose.ui.geometry.Offset(x + w * 0.52f, size.height - hb), androidx.compose.ui.geometry.Size(w * 0.36f, hb))
            }
        }
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("■ Meldungen (max. $maxA/Tag)", color = blue, fontSize = 12.sp)
            Text("■ Kacheln (max. $maxB/Tag)", color = orange, fontSize = 12.sp)
        }
        Text("Letzte 14 Tage. Den verbindlichen Stand zeigt my.tomtom.com.", color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

/** Entwickleroptionen: Simulation, eigene Schlüssel, Prüfwerte – und wieder ausschalten */
@Composable
private fun DevPage(s: AppSettings, onClose: () -> Unit) {
    val pal = LocalPal.current
    EcoAndSimulationSections(s, showEco = false) { onClose() }
    Section("Entwickleroptionen") {
        Text("Ausschalten blendet diese Seite wieder aus. Eingetragene Schlüssel bleiben erhalten.", color = pal.sub, fontSize = 13.sp)
        TextButton(onClick = { Settings.update { it.copy(devMode = false) } }) { Text("Entwickleroptionen ausschalten", color = pal.red) }
    }
}

@Composable
private fun InfoPage() {
    val pal = LocalPal.current
    Section("Version") {
        val s by Settings.state.collectAsState()
        var taps by remember { mutableIntStateOf(0) }
        Text(
            "ELdoroado ${BuildConfigLite.version}", color = pal.text, fontSize = 16.sp,
            // 7× antippen: Entwickleroptionen (eigene Schlüssel) ein-/ausblenden
            modifier = Modifier.clickable {
                taps++
                if (taps >= 7) { taps = 0; Settings.update { it.copy(devMode = !it.devMode) } }
            },
        )
        if (s.devMode) Text("Entwickleroptionen aktiv – eigene Schlüssel unter Dienste bzw. Ladesäulen.", color = Color(0xFFFF9500), fontSize = 13.sp)
        SigningInfo()
    }
    Section("Fehlerprotokoll") {
        val ver by CrashLog.version.collectAsState()
        val ctx = LocalContext.current
        val text = remember(ver) { CrashLog.text() }
        if (text.isBlank()) {
            Text("Keine Fehler aufgezeichnet.", color = pal.sub, fontSize = 14.sp)
        } else {
            val count = Regex("=== ").findAll(text).count()
            Text("$count Einträge, letzter:", color = pal.text, fontSize = 14.sp)
            Text(
                text.trim().substringAfterLast("=== ").take(600), color = pal.sub, fontSize = 12.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, maxLines = 12, overflow = TextOverflow.Ellipsis,
            )
            Row {
                TextButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "ELdoroado Fehlerprotokoll")
                        putExtra(Intent.EXTRA_TEXT, scrubSecrets(CrashLog.text()))
                    }
                    ctx.startActivity(Intent.createChooser(send, "Protokoll teilen"))
                }) { Text("Teilen") }
                TextButton(onClick = { CrashLog.clear() }) { Text("Löschen", color = pal.red) }
            }
        }
    }
    Section("Datenquellen") {
        Text(
            "Kartendaten © OpenStreetMap-Mitwirkende\nKartenstil: OpenFreeMap\nRouting offline: Valhalla (MIT)\nSuche: Photon (Komoot)\n" +
                "Fahrzeugdaten: Open EV Data (github.com/KilowattApp/open-ev-data, MIT-Lizenz)\n" +
                "Ladesäulen: Bundesnetzagentur.de (CC BY 4.0)\n" +
                "Ladeplanung: eigene Berechnung (offline)\nVerkehr optional: TomTom, Autobahn GmbH\nWetter und Höhe: Open-Meteo",
            color = pal.sub, fontSize = 14.sp,
        )
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column {
        Text(title.uppercase(), color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 14.dp, bottom = 6.dp))
        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid) {
            Column(Modifier.fillMaxWidth().padding(14.dp), content = content)
        }
    }
}

@Composable
fun Label(t: String) {
    Text(t, color = LocalPal.current.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.field).padding(3.dp)) {
        options.forEachIndexed { i, o ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                    .background(if (i == selected) pal.selectedSeg else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    o, color = pal.text, fontSize = 14.sp,
                    fontWeight = if (i == selected) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

@Composable
fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = pal.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = value,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = pal.green, checkedThumbColor = Color.White),
        )
    }
}


private fun pct(a: Int, b: Int) = if (b <= 0) "–" else "${(a * 100.0 / b).roundToInt()} %"

// ---------------- Ersteinrichtung ----------------

/** Öffnet die Ersteinrichtung erneut (Einstellungen → Allgemein) */
object SetupFlow {
    val open = kotlinx.coroutines.flow.MutableStateFlow(false)
}

/** Ersteinrichtung beim ersten Start: Standort, Fahrzeug, Akku/OBD, Offline-Daten, Ansagen */
@Composable
fun SetupWizard(s: AppSettings, vm: MainViewModel) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var step by rememberSaveable { mutableIntStateOf(0) }
    val last = 5
    fun finish() {
        Settings.update { it.copy(setupDone = true) }
        SetupFlow.open.value = false
    }
    BackHandler { if (step > 0) step-- else finish() }

    Surface(Modifier.fillMaxSize(), color = pal.screen) {
        Column(Modifier.statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Schritt ${step + 1} von ${last + 1}", color = pal.sub, fontSize = 14.sp, modifier = Modifier.weight(1f))
                if (step < last) TextButton(onClick = { finish() }) { Text("Überspringen", color = pal.sub) }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in 0..last) {
                    Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(if (i <= step) pal.blue else pal.sub.copy(alpha = 0.25f)))
                }
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 24.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                when (step) {
                    0 -> {
                        Text("Willkommen bei ELdoroado", color = pal.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Navigation und Ladeplanung für Elektroautos – offline auf dem Handy, ohne Konto.", color = pal.sub, fontSize = 17.sp)
                        Spacer(Modifier.height(8.dp))
                        IconLine(Icons.Filled.Route, "Routen offline berechnet", pal.text, 16.sp)
                        IconLine(Icons.Filled.Bolt, "Ladestopps nach deinem Fahrzeug und Akku", pal.text, 16.sp)
                        IconLine(Icons.Filled.Traffic, "Staus und Sperrungen auf Autobahnen", pal.text, 16.sp)
                        IconLine(Icons.Filled.Insights, "Lernt aus deinen Fahrten", pal.text, 16.sp)
                        Text("In wenigen Schritten eingerichtet. Alles lässt sich später in den Einstellungen ändern.", color = pal.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    1 -> {
                        val perm by LocationHub.perm.collectAsState()
                        val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                            LocationHub.refreshPermission(ctx)
                            LocationHub.acquire(ctx, "ui")
                        }
                        LaunchedEffect(Unit) { LocationHub.refreshPermission(ctx) }
                        Text("Standort", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("Für Abbiegehinweise braucht die Navigation deinen genauen Standort. Er bleibt auf dem Handy.", color = pal.sub, fontSize = 16.sp)
                        when (perm) {
                            LocationHub.Perm.PRECISE -> IconLine(Icons.Filled.CheckCircle, "Genauer Standort erlaubt", pal.green, 16.sp, FontWeight.SemiBold)
                            LocationHub.Perm.APPROX -> IconLine(Icons.Filled.Warning, "Nur ungefährer Standort – bitte „Genau“ wählen", Color(0xFFFF9500), 15.sp)
                            else -> {}
                        }
                        if (perm != LocationHub.Perm.PRECISE) {
                            Button(onClick = {
                                val list = mutableListOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)
                                if (android.os.Build.VERSION.SDK_INT >= 33) list += android.Manifest.permission.POST_NOTIFICATIONS
                                req.launch(list.toTypedArray())
                            }) { Text("Standort erlauben") }
                        }
                        Text("Benachrichtigungen braucht die App für die laufende Navigation und Downloads.", color = pal.sub, fontSize = 13.sp)
                    }
                    2 -> {
                        val cur = Vehicles.byId(s.vehicleId)
                        Text("Dein Fahrzeug", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(cur.name, color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                Text("${String.format(java.util.Locale.GERMANY, "%.1f", s.usableKwh)} kWh nutzbar · bis ${Vehicles.maxDc(s).roundToInt()} kW DC · ${cur.obd.label}", color = pal.sub, fontSize = 13.sp)
                            }
                        }
                        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) { VehiclePicker(s) {} }
                        }
                        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Wie schnell fährst du auf der Autobahn höchstens?", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                MaxSpeedSlider(s)
                            }
                        }
                    }
                    3 -> {
                        var obd by rememberSaveable { mutableIntStateOf(if (s.obdName.isNotBlank()) 0 else 1) }
                        Text("Akkustand", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Segmented(listOf("Mit OBD2-Adapter", "Ohne Adapter"), obd) { obd = it }
                        if (obd == 0) {
                            Text("Mit einem Bluetooth-Adapter liest die App den Akkustand live aus dem Auto und gleicht die Planung unterwegs ab.", color = pal.sub, fontSize = 15.sp)
                            if (s.obdName.isNotBlank()) IconLine(Icons.Filled.CheckCircle, "Adapter: ${s.obdName}", pal.green, 15.sp, FontWeight.SemiBold)
                            Button(onClick = { vm.openObd() }) { Text(if (s.obdName.isBlank()) "Adapter suchen" else "Adapter prüfen") }
                        } else {
                            Text("Ohne Adapter stellst du den Akku vor der Fahrt am goldenen Band auf dem Startbildschirm ein. Unterwegs rechnet die App selbst weiter.", color = pal.sub, fontSize = 15.sp)
                            Label("Akku jetzt: ${s.socStart.roundToInt()} %")
                            Slider(
                                value = s.socStart.toFloat(),
                                onValueChange = { v -> Settings.update { it.copy(socStart = v.roundToInt().toDouble()) } },
                                valueRange = 5f..100f,
                            )
                        }
                    }
                    4 -> {
                        val vs by ValhallaTiles.state.collectAsState()
                        val n by ChargerRegistry.count.collectAsState()
                        LaunchedEffect(Unit) { if (vs.remote == null && ValhallaEngine.serverConfigured()) ValhallaTiles.check() }
                        Text("Offline-Daten", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("Damit Routen und Ladeplanung ohne Internet funktionieren, lädt die App Kartendaten und das Ladesäulenverzeichnis aufs Handy.", color = pal.sub, fontSize = 15.sp)
                        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Kartendaten Deutschland", color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                when {
                                    vs.ready && !vs.updateAvailable -> IconLine(Icons.Filled.CheckCircle, "Vorhanden · Stand ${vs.installedVersion}", pal.green, 15.sp)
                                    vs.downloading -> {
                                        val frac = if (vs.total > 0) (vs.bytes.toFloat() / vs.total).coerceIn(0f, 1f) else 0f
                                        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.sub.copy(alpha = 0.2f))) {
                                            Box(Modifier.fillMaxWidth(frac.coerceAtLeast(0.01f)).height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.blue))
                                        }
                                        Text(
                                            if (vs.waitingForWifi) "Wartet auf WLAN …" else "${ValhallaTiles.gb(vs.bytes)}" + if (vs.total > 0) " von ${ValhallaTiles.gb(vs.total)}" else "",
                                            color = pal.sub, fontSize = 13.sp,
                                        )
                                        Text("Du kannst schon weitermachen – der Download läuft im Hintergrund.", color = pal.sub, fontSize = 13.sp)
                                    }
                                    else -> Button(onClick = { scope.launch { ValhallaTiles.startDownload(wifiOnly = true) } }) {
                                        Text("Laden" + (vs.remote?.sizeBytes?.let { " (${ValhallaTiles.gb(it)}, nur WLAN)" } ?: " (nur WLAN)"))
                                    }
                                }
                                vs.error?.let { Text(it, color = pal.red, fontSize = 13.sp) }
                            }
                        }
                        OptionalKeysCard(s)
                        Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Ladesäulen", color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                if (n > 0) IconLine(Icons.Filled.CheckCircle, "${"%,d".format(Locale.GERMANY, n)} Standorte offline", pal.green, 15.sp)
                                else Text("Wird automatisch geladen (etwa 10 MB) …", color = pal.sub, fontSize = 14.sp)
                            }
                        }
                    }
                    else -> {
                        val voice = remember { runCatching { NavSession.voice }.getOrNull() }
                        Text("Ansagen", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        ToggleRow("Sprachansagen", s.voice) { v -> Settings.update { it.copy(voice = v) } }
                        Label("Anrede")
                        Segmented(listOf("Sie", "Du"), if (s.voiceDu) 1 else 0) { i -> Settings.update { it.copy(voiceDu = i == 1) } }
                        Spacer(Modifier.height(4.dp))
                        Label("Ausgabe")
                        Segmented(listOf("Automatisch", "Handy", "Bluetooth"), s.voiceOutput.coerceIn(0, 2)) { i -> Settings.update { it.copy(voiceOutput = i) } }
                        TextButton(onClick = {
                            voice?.applyVoice()
                            voice?.say(if (s.voiceDu) "In 300 Metern rechts abbiegen. Nimm die rechte Spur." else "In 300 Metern rechts abbiegen. Benutzen Sie die rechte Spur.")
                        }) { Text("Probe hören") }
                        Text("Stimme, Tempo und weitere Optionen findest du später unter Einstellungen → Navigation.", color = pal.sub, fontSize = 13.sp)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (step > 0) TextButton(onClick = { step-- }) { Text("Zurück") }
                Spacer(Modifier.weight(1f))
                Button(onClick = { if (step == last) finish() else step++ }) { Text(if (step == last) "Los geht’s" else "Weiter") }
            }
        }
    }
}


// ---------------- Höchsttempo und optionale Schlüssel (Einstellungen + Ersteinrichtung) ----------------

/** Höchstgeschwindigkeit auf der Autobahn: wirkt auf Route (Valhalla), Fahrzeit, Verbrauch und Ladeplanung */
@Composable
private fun MaxSpeedSlider(s: AppSettings) {
    val pal = LocalPal.current
    Label(if (s.maxSpeedKmh == 0) "Höchstgeschwindigkeit: offen (nach Tempolimit)" else "Höchstgeschwindigkeit: ${s.maxSpeedKmh} km/h")
    Slider(
        value = (if (s.maxSpeedKmh == 0) 170 else s.maxSpeedKmh).toFloat(),
        onValueChange = { v -> val k = (v / 10).roundToInt() * 10; Settings.update { it.copy(maxSpeedKmh = if (k >= 170) 0 else k) } },
        valueRange = 90f..170f,
    )
    Text("Ganz rechts = offen. Langsamer fahren spart Reichweite – Fahrzeit und Ladestopps passen sich an.", color = pal.sub, fontSize = 12.sp)
}

@Composable
private fun KeyStatus(ok: Boolean?, checking: Boolean) {
    val pal = LocalPal.current
    when {
        checking -> Text("Prüfe Schlüssel …", color = pal.sub, fontSize = 13.sp)
        ok == true -> IconLine(Icons.Filled.CheckCircle, "Schlüssel funktioniert", pal.green, 14.sp, FontWeight.SemiBold)
        ok == false -> IconLine(Icons.Filled.Warning, "Schlüssel wird abgelehnt – bitte prüfen", pal.red, 14.sp)
        else -> {}
    }
}

@Composable
private fun StepLine(n: Int, text: String) {
    val pal = LocalPal.current
    Row(Modifier.padding(top = 3.dp)) {
        Text("$n.", color = pal.sub, fontSize = 13.sp, modifier = Modifier.width(20.dp))
        Text(text, color = pal.text, fontSize = 13.sp)
    }
}

@Composable
private fun LinkLine(label: String, url: String) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    Text(
        label, color = pal.blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(6.dp)).clickable {
            runCatching { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
        }.padding(vertical = 4.dp),
    )
}

/** TomTom: wofür, Anleitung (nur „Traffic API“ anhaken), Eingabe und Prüfung */
@Composable
private fun TomTomKeyBlock(s: AppSettings) {
    val pal = LocalPal.current
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var ok by remember { mutableStateOf<Boolean?>(null) }
    Text("Verkehr in der Stadt (TomTom)", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    Text(
        "Staus, Unfälle und Sperrungen auch abseits der Autobahn und im Ausland. Autobahnen sind schon ohne Schlüssel abgedeckt. " +
            "Kostenlos, Anmeldung mit E-Mail-Adresse; die App fragt nur Verkehrsdaten ab.",
        color = pal.sub, fontSize = 13.sp,
    )
    StepLine(1, "Kostenloses Konto auf developer.tomtom.com anlegen.")
    StepLine(2, "Auf my.tomtom.com unter „Keys“ den Schlüssel öffnen.")
    StepLine(3, "Unter „Self-service APIs“ nur „Traffic API“ anhaken und speichern.")
    StepLine(4, "Schlüssel kopieren und hier einfügen.")
    LinkLine("developer.tomtom.com öffnen", "https://developer.tomtom.com")
    OutlinedTextField(
        value = s.tomtomKey,
        onValueChange = { v -> ok = null; Settings.update { it.copy(tomtomKey = v.trim()) } },
        label = { Text("TomTom-Schlüssel") },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
    )
    LaunchedEffect(s.tomtomKey) {
        if (s.tomtomKey.length >= 20) {
            kotlinx.coroutines.delay(800)
            checking = true
            ok = KeyCheck.tomtom(s.tomtomKey)
            checking = false
        }
    }
    KeyStatus(ok, checking)
}

/** Open Charge Map: nur fürs Ausland (Deutschland ist offline über die Bundesnetzagentur drin) */
@Composable
private fun OcmKeyBlock(s: AppSettings) {
    val pal = LocalPal.current
    var checking by remember { mutableStateOf(false) }
    var ok by remember { mutableStateOf<Boolean?>(null) }
    Text("Ladesäulen im Ausland (Open Charge Map)", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    Text(
        "Ladesäulen in Deutschland sind bereits komplett offline drin (Ladesäulenregister der Bundesnetzagentur). " +
            "Dieser Schlüssel ist nur für Ladesäulen jenseits der Grenze – sinnvoll, sobald Kartendaten für weitere Länder verfügbar sind.",
        color = pal.sub, fontSize = 13.sp,
    )
    StepLine(1, "Kostenloses Konto auf openchargemap.org anlegen.")
    StepLine(2, "„My Profile“ → „My Apps“ öffnen.")
    StepLine(3, "„Register an Application“ wählen, kurz beschreiben (z. B. „ELdoroado, privat“).")
    StepLine(4, "Den angezeigten API-Key kopieren und hier einfügen.")
    LinkLine("openchargemap.org öffnen", "https://openchargemap.org")
    OutlinedTextField(
        value = s.ocmKey,
        onValueChange = { v -> ok = null; Settings.update { it.copy(ocmKey = v.trim()) } },
        label = { Text("Open-Charge-Map-Schlüssel") },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
    )
    LaunchedEffect(s.ocmKey) {
        if (s.ocmKey.length >= 20) {
            kotlinx.coroutines.delay(800)
            checking = true
            ok = KeyCheck.ocm(s.ocmKey)
            checking = false
        }
    }
    KeyStatus(ok, checking)
}

/** Ersteinrichtung: dezent aufklappbar, beide optionalen Schlüssel */
@Composable
private fun OptionalKeysCard(s: AppSettings) {
    val pal = LocalPal.current
    var open by remember { mutableStateOf(false) }
    Surface(shape = RoundedCornerShape(16.dp), color = pal.cardSolid, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { open = !open }.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Optional: eigene Schlüssel", color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        listOfNotNull(
                            if (s.hasTomTom) "Verkehr ✓" else "Verkehr in der Stadt",
                            if (s.ocmKey.isNotBlank()) "Ausland ✓" else "Ladesäulen im Ausland",
                        ).joinToString(" · "),
                        color = pal.sub, fontSize = 13.sp,
                    )
                }
                Text(if (open) "‹" else "›", color = pal.sub, fontSize = 20.sp)
            }
            if (open) {
                Spacer(Modifier.height(12.dp))
                TomTomKeyBlock(s)
                Spacer(Modifier.height(18.dp))
                OcmKeyBlock(s)
            }
        }
    }
}


/** Während der Fahrt / in der Zwischenstopp-Suche: Ort als Zwischenstopp einfügen (Standard) oder als neues Ziel */
@Composable
fun ViaAskDialog(p: Place, vm: MainViewModel) {
    val pal = LocalPal.current
    val dest = NavSession.state.collectAsState().value.dest
    AlertDialog(
        onDismissRequest = { vm.cancelVia() },
        shape = RoundedCornerShape(28.dp),
        title = { Text("Hierhin navigieren?", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                IconLine(Icons.Filled.Place, p.title, pal.text, 16.sp, FontWeight.SemiBold)
                if (dest != null) Text("Aktuelles Ziel: ${dest.title.substringBefore(",")}", color = pal.sub, fontSize = 14.sp)
            }
        },
        confirmButton = {
            Button(onClick = { vm.answerVia(true) }) { Text("Als Zwischenstopp") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { vm.cancelVia() }) { Text("Abbrechen") }
                TextButton(onClick = { vm.answerVia(false) }) { Text("Neues Ziel") }
            }
        },
    )
}
