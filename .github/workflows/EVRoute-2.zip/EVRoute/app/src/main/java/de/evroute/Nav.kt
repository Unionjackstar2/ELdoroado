package de.evroute

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------- Standort ----------------

object LocationHub {
    private val _fix = MutableStateFlow<Fix?>(null)
    val fix: StateFlow<Fix?> = _fix.asStateFlow()
    private var client: FusedLocationProviderClient? = null
    private val holders = mutableSetOf<String>()

    private val callback = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) {
            val l = r.lastLocation ?: return
            _fix.value = Fix(
                pos = LatLon(l.latitude, l.longitude),
                bearing = if (l.hasBearing()) l.bearing else null,
                speed = if (l.hasSpeed()) l.speed.toDouble() else 0.0,
                accuracy = if (l.hasAccuracy()) l.accuracy.toDouble() else 50.0,
                time = l.time,
            )
        }
    }

    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Mehrere Nutzer (Bildschirm, Navigationsdienst) teilen sich ein Abo */
    @SuppressLint("MissingPermission")
    fun acquire(ctx: Context, tag: String) {
        if (!hasPermission(ctx) || tag in holders) return
        val first = holders.isEmpty()
        holders += tag
        if (first) {
            val c = client ?: LocationServices.getFusedLocationProviderClient(ctx.applicationContext).also { client = it }
            val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
                .setMinUpdateIntervalMillis(500L)
                .build()
            c.requestLocationUpdates(req, callback, Looper.getMainLooper())
        }
    }

    fun release(tag: String) {
        if (holders.remove(tag) && holders.isEmpty()) client?.removeLocationUpdates(callback)
    }
}

// ---------------- Position auf der Route ----------------

object NavEngine {
    fun update(r: Route, p: LatLon, lastSeg: Int, fullSearch: Boolean): NavProgress {
        val n = r.points.size
        if (n < 2) {
            return NavProgress(0, p, 0.0, 0.0, r.steps.lastIndex.coerceAtLeast(0), 0.0, 0.0, 0.0, 0.0, null)
        }
        val from = if (fullSearch) 0 else max(0, lastSeg - 5)
        val to = if (fullSearch) n - 2 else min(n - 2, lastSeg + 400)
        var best = from
        var bd = Double.MAX_VALUE
        for (i in from..to) {
            val d = distToSeg(p, r.points[i], r.points[i + 1])
            if (d < bd) { bd = d; best = i }
        }
        val a = r.points[best]
        val b = r.points[best + 1]
        val t = projectT(p, a, b)
        val along = r.cumM[best] + t * (r.cumM[best + 1] - r.cumM[best])

        var s = r.steps.indices.firstOrNull { r.stepAlongM[it] > along + 2 } ?: r.steps.lastIndex
        if (s < 0) s = 0
        val toStep = if (r.steps.isEmpty()) 0.0 else max(0.0, r.stepAlongM[s] - along)

        var remS = 0.0
        for (i in s until r.steps.size) remS += r.steps[i].durationS
        if (s > 0) {
            val cur = r.steps[s - 1]
            remS += cur.durationS * (toStep / max(1.0, cur.distanceM)).coerceAtMost(1.0)
        }
        return NavProgress(
            segIdx = best,
            snapped = lerp(a, b, t),
            routeBearing = bearing(a, b),
            alongM = along,
            stepIdx = s,
            distToStepM = toStep,
            remainingM = max(0.0, r.cumM.last() - along),
            remainingS = remS,
            offRouteM = bd,
            speedLimit = r.maxSpeed?.getOrNull(best)?.takeIf { it > 0 },
        )
    }
}

// ---------------- Sprachansagen ----------------

class Voice(ctx: Context) : TextToSpeech.OnInitListener {
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(attrs)
        .build()
    private val done = mutableSetOf<Int>()
    @Volatile private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext, this)

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts.language = Locale.GERMANY
        tts.setAudioAttributes(attrs)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { audio.abandonAudioFocusRequest(focus) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { audio.abandonAudioFocusRequest(focus) }
        })
        ready = true
    }

    fun say(text: String) {
        if (!ready || !Settings.state.value.voice) return
        audio.requestAudioFocus(focus)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav-${System.nanoTime()}")
    }

    fun stop() { if (ready) tts.stop() }

    fun reset() { done.clear() }

    /** Ansagen abhängig vom Tempo: Autobahn 2 km / 800 m, Stadt 500 m / 150 m, dann „Jetzt“ */
    fun onProgress(r: Route, p: NavProgress, speedMs: Double) {
        val step = r.steps.getOrNull(p.stepIdx) ?: return
        val d = p.distToStepM
        val kmh = speedMs * 3.6
        val stages = if (kmh > 80) listOf(2000.0, 800.0) else listOf(500.0, 150.0)
        val nowDist = max(35.0, speedMs * 4)
        val base = p.stepIdx * 10

        if (d <= nowDist) {
            if (done.add(base + 9)) {
                done.add(base); done.add(base + 1)
                if (step.type == "arrive") { say("Sie haben Ihr Ziel erreicht"); return }
                val next = r.steps.getOrNull(p.stepIdx + 1)
                val then = if (next != null && step.distanceM < 150) {
                    if (next.type == "arrive") ", dann erreichen Sie Ihr Ziel" else ", dann ${next.phrase}"
                } else {
                    ""
                }
                say("Jetzt ${step.phrase}${step.spokenTarget()}$then")
            }
            return
        }
        stages.forEachIndexed { i, s ->
            if (d <= s && d > nowDist + 60 && done.add(base + i)) {
                if (i == 0 && d < stages[1] + 200) done.add(base + 1)
                val text = if (step.type == "arrive") {
                    "In ${spoken(d)} erreichen Sie Ihr Ziel"
                } else {
                    "In ${spoken(d)} ${step.phrase}${step.spokenTarget()}"
                }
                say(text)
                return
            }
        }
    }

    private fun spoken(m: Double): String = when {
        m >= 950 -> {
            val km = (m / 500).roundToInt() / 2.0
            if (abs(km - 1.0) < 0.01) "einem Kilometer"
            else if (km % 1.0 == 0.0) "${km.toInt()} Kilometern"
            else "${km.toString().replace('.', ',')} Kilometern"
        }
        m >= 100 -> "${(m / 50).roundToInt() * 50} Metern"
        else -> "${(m / 10).roundToInt() * 10} Metern"
    }
}

// ---------------- Navigationssitzung ----------------

object NavSession {
    data class State(
        val dest: Place? = null,
        val routes: List<Route> = emptyList(),
        val selected: Int = 0,
        val loading: Boolean = false,
        val error: String? = null,
        val note: String? = null,
        val navigating: Boolean = false,
        val progress: NavProgress? = null,
        val rerouting: Boolean = false,
        val arrived: Boolean = false,
    ) {
        val route: Route? get() = routes.getOrNull(selected)
    }

    private val scope = MainScope()
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private lateinit var app: Context
    lateinit var voice: Voice
        private set

    private var planJob: Job? = null
    private var lastSeg = 0
    private var needFull = true
    private var offCount = 0
    private var lastReroute = 0L

    fun init(ctx: Context) {
        app = ctx.applicationContext
        voice = Voice(app)
        scope.launch { LocationHub.fix.filterNotNull().collect { onFix(it) } }
    }

    fun plan(dest: Place) {
        val fix = LocationHub.fix.value
        planJob?.cancel()
        if (fix == null) {
            _state.value = State(dest = dest, error = "Standort noch nicht verfügbar – GPS aktiv?")
            return
        }
        _state.value = State(dest = dest, loading = true)
        planJob = scope.launch {
            try {
                val opts = fetchOptions(fix.pos, if (fix.speed > 3) fix.bearing else null, dest.pos)
                _state.update { it.copy(routes = opts, selected = 0, loading = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = "Keine Route gefunden: ${e.message}") }
            }
        }
    }

    fun select(i: Int) { _state.update { if (i in it.routes.indices) it.copy(selected = i) else it } }

    fun clear() {
        planJob?.cancel()
        _state.value = State()
    }

    fun start(ctx: Context) {
        val s = _state.value
        val r = s.route ?: return
        lastSeg = 0; needFull = true; offCount = 0
        voice.reset()
        _state.value = s.copy(routes = listOf(r), selected = 0, navigating = true, arrived = false)
        ContextCompat.startForegroundService(ctx, Intent(ctx, NavigationService::class.java))
        val first = r.steps.getOrNull(1)
        voice.say(
            "Route gestartet. " + if (first != null) "${first.phrase.cap()}${first.spokenTarget()}" else "",
        )
        LocationHub.fix.value?.let { onFix(it) }
    }

    fun stop(ctx: Context) {
        voice.stop()
        ctx.stopService(Intent(ctx, NavigationService::class.java))
        planJob?.cancel()
        _state.value = State()
    }

    fun rerouteNow() { LocationHub.fix.value?.let { reroute(it, manual = true) } }

    private fun onFix(f: Fix) {
        val s = _state.value
        if (!s.navigating || s.arrived) return
        val r = s.route ?: return
        val p = NavEngine.update(r, f.pos, lastSeg, needFull)
        lastSeg = p.segIdx
        val off = p.offRouteM > max(50.0, f.accuracy * 1.5)
        needFull = off
        offCount = if (off && f.accuracy < 60) offCount + 1 else 0
        _state.update { it.copy(progress = p) }

        if (offCount >= 3 && !s.rerouting && System.currentTimeMillis() - lastReroute > 8000) {
            reroute(f, manual = false)
        } else if (!off) {
            voice.onProgress(r, p, f.speed)
        }
        if (!off && p.remainingM < 25) {
            _state.update { it.copy(arrived = true) }
            app.stopService(Intent(app, NavigationService::class.java))
        }
    }

    private fun reroute(f: Fix, manual: Boolean) {
        val dest = _state.value.dest ?: return
        lastReroute = System.currentTimeMillis()
        _state.update { it.copy(rerouting = true) }
        voice.say("Route wird neu berechnet")
        scope.launch {
            try {
                val r = routesWithFallback(f.pos, if (f.speed > 3) f.bearing else null, dest.pos, Settings.excludes(), 0).first()
                lastSeg = 0; needFull = true; offCount = 0
                voice.reset()
                _state.update { it.copy(routes = listOf(r.copy(tag = "Neu berechnet")), selected = 0, rerouting = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(rerouting = false) }
                if (manual) voice.say("Neuberechnung fehlgeschlagen")
            }
        }
    }

    /** Bis zu 3 Optionen: Empfohlen + OSRM-Alternativen + Mautfrei (falls verschieden) */
    private suspend fun fetchOptions(from: LatLon, bearing: Float?, to: LatLon): List<Route> = coroutineScope {
        val ex = Settings.excludes()
        val main = async { routesWithFallback(from, bearing, to, ex, 2) }
        val tollFree = if ("toll" !in ex) {
            async { runCatching { Routing.routes(from, bearing, to, ex + "toll", 0) }.getOrDefault(emptyList()) }
        } else {
            null
        }
        val out = mutableListOf<Route>()
        main.await().forEachIndexed { i, r -> out += r.copy(tag = if (i == 0) "Empfohlen" else "Alternative") }
        tollFree?.await()?.firstOrNull()?.let { t -> if (out.none { similar(it, t) }) out += t.copy(tag = "Mautfrei") }
        out.distinctBy { "${it.distanceM.roundToInt() / 200}-${it.durationS.roundToInt() / 60}" }.take(3)
    }

    private suspend fun routesWithFallback(from: LatLon, bearing: Float?, to: LatLon, ex: List<String>, alts: Int): List<Route> {
        return try {
            Routing.routes(from, bearing, to, ex, alts)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (ex.isEmpty()) throw e
            _state.update { it.copy(note = "Die gewählten Vermeiden-Optionen werden vom Routing-Server nicht unterstützt und wurden ignoriert.") }
            Routing.routes(from, bearing, to, emptyList(), alts)
        }
    }

    private fun similar(a: Route, b: Route) =
        abs(a.distanceM - b.distanceM) / a.distanceM < 0.01 && abs(a.durationS - b.durationS) / a.durationS < 0.01
}

// ---------------- Vordergrund-Dienst (Navigation im Hintergrund) ----------------

class NavigationService : Service() {
    private val scope = MainScope()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Navigation", NotificationManager.IMPORTANCE_LOW))
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, ID, build("Navigation läuft", ""), type)
        LocationHub.acquire(this, "nav")
        scope.launch {
            NavSession.state
                .map { s ->
                    val r = s.route
                    val p = s.progress
                    if (r == null || p == null) {
                        "Navigation läuft" to ""
                    } else {
                        val step = r.steps[p.stepIdx]
                        "${fmtDistShort(p.distToStepM)} · ${step.bannerText()}" to
                            "Ankunft ${fmtEta(p.remainingS)} · ${fmtKm(p.remainingM)}"
                    }
                }
                .distinctUntilChanged()
                .collect { (title, text) -> nm.notify(ID, build(title, text)) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        scope.cancel()
        LocationHub.release("nav")
        super.onDestroy()
    }

    private fun build(title: String, text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(R.drawable.ic_nav)
        .setContentTitle(title)
        .setContentText(text)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        )
        .build()

    companion object {
        private const val CHANNEL = "nav"
        private const val ID = 42
    }
}
