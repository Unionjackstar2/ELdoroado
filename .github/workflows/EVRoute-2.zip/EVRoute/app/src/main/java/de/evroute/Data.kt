package de.evroute

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.double
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

object Http {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()

    /** Liefert den Text auch bei 4xx (Fehlermeldung des Servers), wirft bei 5xx/Netzfehler */
    suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", "EVRoute/0.2 (privat)").build()
        client.newCall(req).execute().use { r ->
            if (r.code >= 500) throw IOException("Server-Fehler ${r.code}")
            r.body?.string() ?: throw IOException("Leere Antwort")
        }
    }
}

val json = Json { ignoreUnknownKeys = true }

private fun JsonObject.obj(k: String) = this[k]!!.jsonObject
private fun JsonObject.arr(k: String) = this[k]!!.jsonArray
private fun JsonObject.d(k: String) = this[k]!!.jsonPrimitive.double
private fun JsonObject.s(k: String) = this[k]?.jsonPrimitive?.contentOrNull ?: ""
private val JsonElement.d get() = jsonPrimitive.double

// ---------------- Routing (OSRM) ----------------

object Routing {
    private const val BASE = "https://router.project-osrm.org/route/v1/driving/"

    suspend fun routes(from: LatLon, bearing: Float?, to: LatLon, exclude: List<String>, alternatives: Int): List<Route> {
        val url = buildString {
            append(BASE)
            append("${from.lon.f6()},${from.lat.f6()};${to.lon.f6()},${to.lat.f6()}")
            append("?overview=full&geometries=geojson&steps=true&annotations=maxspeed")
            append("&alternatives=").append(if (alternatives > 0) alternatives.toString() else "false")
            if (bearing != null) append("&bearings=${bearing.roundToInt().mod(360)},45;")
            if (exclude.isNotEmpty()) append("&exclude=").append(exclude.joinToString(","))
        }
        val root = json.parseToJsonElement(Http.get(url)).jsonObject
        val code = root.s("code")
        if (code != "Ok") throw IOException(root.s("message").ifBlank { "Routing-Fehler ($code)" })
        return root.arr("routes").map { parse(it.jsonObject) }
    }

    private fun parse(r: JsonObject): Route {
        val pts = r.obj("geometry").arr("coordinates").map { c ->
            val a = c.jsonArray
            LatLon(a[1].d, a[0].d)
        }
        val steps = mutableListOf<Step>()
        val maxs = mutableListOf<Int>()
        var summary = ""
        for (lg in r.arr("legs")) {
            val leg = lg.jsonObject
            if (summary.isEmpty()) summary = leg.s("summary")
            leg.arr("steps").forEach { steps += parseStep(it.jsonObject) }
            leg["annotation"]?.jsonObject?.get("maxspeed")?.jsonArray?.forEach { m ->
                val o = m.jsonObject
                val sp = o["speed"]?.jsonPrimitive?.doubleOrNull
                val unit = o["unit"]?.jsonPrimitive?.contentOrNull
                maxs += when {
                    sp == null -> 0
                    unit == "mph" -> (sp * 1.609).roundToInt()
                    else -> sp.roundToInt()
                }
            }
        }
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
        val osrmDist = r.d("distance")
        val scale = if (osrmDist > 0 && cum.isNotEmpty()) cum.last() / osrmDist else 1.0
        val stepAlong = DoubleArray(steps.size)
        var acc = 0.0
        steps.forEachIndexed { i, s ->
            stepAlong[i] = acc * scale
            acc += s.distanceM
        }
        return Route(
            points = pts,
            cumM = cum,
            stepAlongM = stepAlong,
            distanceM = osrmDist,
            durationS = r.d("duration"),
            steps = steps,
            maxSpeed = if (maxs.size == pts.size - 1) maxs.toIntArray() else null,
            summary = summary,
        )
    }

    private fun parseStep(s: JsonObject): Step {
        val m = s.obj("maneuver")
        val type = m.s("type")
        val mod = m["modifier"]?.jsonPrimitive?.contentOrNull
        val exit = m["exit"]?.jsonPrimitive?.intOrNull
        val ref = s.s("ref").split(';').firstOrNull()?.trim() ?: ""
        val road = listOf(ref, s.s("name")).filter { it.isNotBlank() }.distinct().joinToString(" · ")
        val dest = s.s("destinations")
        val towards = if (dest.contains(": ")) dest.substringAfter(": ") else dest
        return Step(type, mod, exit, road, towards, s.d("distance"), s.d("duration"), Phrases.build(type, mod, exit))
    }
}

/** Deutsche Manöver-Texte */
object Phrases {
    private fun dir(mod: String?) = when (mod) {
        "left" -> "links"
        "right" -> "rechts"
        "slight left" -> "leicht links"
        "slight right" -> "leicht rechts"
        "sharp left" -> "scharf links"
        "sharp right" -> "scharf rechts"
        else -> "geradeaus"
    }

    fun build(type: String, mod: String?, exit: Int?): String = when (type) {
        "depart" -> "losfahren"
        "arrive" -> "Ziel erreichen"
        "roundabout", "rotary", "roundabout turn" ->
            if (exit != null) "im Kreisverkehr die $exit. Ausfahrt nehmen" else "in den Kreisverkehr fahren"
        "merge" -> if (mod == null || mod == "straight") "einfädeln" else "${dir(mod)} einfädeln"
        "on ramp" -> "die Auffahrt nehmen"
        "off ramp" -> if (mod == null || mod == "straight") "die Ausfahrt nehmen" else "${dir(mod)} die Ausfahrt nehmen"
        "fork" -> "an der Gabelung ${dir(mod)} halten"
        "end of road" -> "am Ende der Straße ${dir(mod)} abbiegen"
        "continue", "new name" -> when (mod) {
            null, "straight" -> "geradeaus weiterfahren"
            "uturn" -> "wenden"
            else -> "${dir(mod)} halten"
        }
        else -> when (mod) {
            null, "straight" -> "geradeaus weiterfahren"
            "uturn" -> "wenden"
            else -> "${dir(mod)} abbiegen"
        }
    }
}

// ---------------- Suche (Photon / OpenStreetMap) ----------------

object Geocode {
    suspend fun search(q: String, near: LatLon?): List<Place> {
        val bias = if (near != null) "&lat=${near.lat.f6()}&lon=${near.lon.f6()}" else ""
        val url = "https://photon.komoot.io/api/?limit=7&lang=de$bias&q=" + URLEncoder.encode(q, "UTF-8")
        return json.parseToJsonElement(Http.get(url)).jsonObject.arr("features").map { f ->
            val p = f.jsonObject.obj("properties")
            val c = f.jsonObject.obj("geometry").arr("coordinates")
            val street = listOf(p.s("street"), p.s("housenumber")).filter { it.isNotBlank() }.joinToString(" ")
            val first = p.s("name").ifBlank { street }
            val parts = listOf(first, if (first == street) "" else street, p.s("city"), p.s("country"))
                .filter { it.isNotBlank() }.distinct()
            Place(parts.joinToString(", "), LatLon(c[1].d, c[0].d))
        }
    }
}
